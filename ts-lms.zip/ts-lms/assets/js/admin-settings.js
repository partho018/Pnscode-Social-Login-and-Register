jQuery(document).ready(function($) {
    // Initialize WordPress Color Picker
    $('.ts-lms-color-picker').wpColorPicker({
        change: function(event, ui) {
            // Trigger custom event for our preset logic
            $(this).trigger('color-change-manual');
        }
    });

    // Handle toggle switch interactions
    $('.ts-lms-switch input').on('change', function() {
        var $switch = $(this);
        var name = $switch.attr('name');
        
        // Social Login Toggles
        if (name && name.indexOf('enable_') !== -1 && name.indexOf('_login') !== -1) {
            var $card = $switch.closest('.social-login-card');
            var $fields = $card.find('.social-api-fields');
            if ($switch.is(':checked')) {
                $fields.slideDown(250);
            } else {
                $fields.slideUp(250);
            }
        }
    });

    // Handle search functionality (placeholder)
    $('.search-box input').on('keyup', function() {
        var value = $(this).val().toLowerCase();
        // Search logic here
    });

    // Handle Reset to Default
    $('.reset-link').on('click', function(e) {
        e.preventDefault();
        
        var $link = $(this);
        var originalText = $link.html();
        
        if (confirm('Are you sure you want to reset all settings in this section to their default values?')) {
            // Show loading state
            $link.html('<span class="dashicons dashicons-update dashicons-spin"></span> Resetting...');
            $link.css('pointer-events', 'none');
            
            // Get current tab from URL
            var urlParams = new URLSearchParams(window.location.search);
            var currentTab = urlParams.get('tab') || 'general';
            
            // Send AJAX request to reset settings
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'ts_lms_reset_settings',
                    tab: currentTab,
                    nonce: $('#ts_lms_settings_nonce').val()
                },
                success: function(response) {
                    if (response.success) {
                        // Reload the page to show reset settings
                        location.reload();
                    } else {
                        alert(response.data.message || 'Failed to reset settings');
                        $link.html(originalText);
                        $link.css('pointer-events', 'auto');
                    }
                },
                error: function() {
                    alert('An error occurred while resetting settings');
                    $link.html(originalText);
                    $link.css('pointer-events', 'auto');
                }
            });
        }
    });

    // Generic Image Upload
    $('.ts-lms-upload-image').on('click', function(e) {
        e.preventDefault();
        var btn = $(this);
        var target = btn.data('target');
        var preview = btn.closest('.logo-upload-box, .logo-upload-container, .logo-preview-container').find('.logo-preview');
        
        var custom_uploader = wp.media({
            title: 'Select Image',
            button: {
                text: 'Use this image'
            },
            multiple: false
        }).on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            $('#' + target).val(attachment.url);
            preview.addClass('has-logo').html('<img src="' + attachment.url + '" alt="Preview">');
            
            // Show remove button if it exists
            var container = btn.closest('.logo-upload-box, .logo-upload-container, .logo-preview-container');
            container.find('.ts-lms-remove-image').show();
        }).open();
    });

    // Handle Image Removal
    $('.ts-lms-remove-image').on('click', function(e) {
        e.preventDefault();
        var btn = $(this);
        var target = btn.data('target');
        var container = btn.closest('.logo-upload-box, .logo-upload-container, .logo-preview-container');
        var preview = container.find('.logo-preview');
        
        // Clear input
        $('#' + target).val('');
        
        // Reset preview
        preview.removeClass('has-logo').html('<span class="dashicons dashicons-format-image"></span><span>Upload Image</span>');
        
        // Hide remove button
        btn.hide();
    });

    // Visual Selection (Columns & Layouts)
    $('.visual-option').on('click', function() {
        var container = $(this).closest('.ts-lms-visual-select');
        container.find('.visual-option').removeClass('selected');
        $(this).addClass('selected');
        $(this).find('input[type="radio"]').prop('checked', true);
    });

    // Color Presets
    $('.preset-option').on('click', function() {
        var colors = $(this).data('colors');
        
        if (colors && colors.length >= 8) {
            $('input[name="ts_lms_settings[primary_color]"]').val(colors[0]);
            $('input[name="ts_lms_settings[primary_hover_color]"]').val(colors[1]);
            $('input[name="ts_lms_settings[text_color]"]').val(colors[2]);
            $('input[name="ts_lms_settings[gray_color]"]').val(colors[3]);
            $('input[name="ts_lms_settings[button_color]"]').val(colors[4]);
            $('input[name="ts_lms_settings[button_hover_color]"]').val(colors[5]);
            $('input[name="ts_lms_settings[button_text_color]"]').val(colors[6]);
            $('input[name="ts_lms_settings[body_bg_color]"]').val(colors[7]);
            
            if (colors.length >= 9) {
                $('input[name="ts_lms_settings[icon_color]"]').val(colors[8]);
            }
            
            $('.ts-lms-color-picker').trigger('color-change-preset');
        }

        $(this).closest('.ts-lms-color-presets').find('.preset-option').removeClass('selected');
        $(this).addClass('selected');
        $(this).find('input[type="radio"]').prop('checked', true); // Ensure radio is checked
    });

    // Update Custom preset when inputs change
    $('input[name="ts_lms_settings[primary_color]"], input[name="ts_lms_settings[primary_hover_color]"], input[name="ts_lms_settings[text_color]"], input[name="ts_lms_settings[gray_color]"], input[name="ts_lms_settings[button_color]"], input[name="ts_lms_settings[button_hover_color]"], input[name="ts_lms_settings[button_text_color]"], input[name="ts_lms_settings[body_bg_color]"], input[name="ts_lms_settings[icon_color]"]').on('input change color-change-manual', function(e) {
        // Ignore if triggered by preset click
        if (e.type === 'color-change-preset') return;

        // Select 'Custom' preset
        var customPreset = $('.preset-option input[value="custom"]').closest('.preset-option');
        
        // Remove 'selected' from all, add to Custom
        $('.preset-option').removeClass('selected');
        customPreset.addClass('selected');
        customPreset.find('input[type="radio"]').prop('checked', true);
        
        // Update Custom preset preview spans
        var pColor = $('input[name="ts_lms_settings[primary_color]"]').val();
        var phColor = $('input[name="ts_lms_settings[primary_hover_color]"]').val();
        var tColor = $('input[name="ts_lms_settings[text_color]"]').val();
        var gColor = $('input[name="ts_lms_settings[gray_color]"]').val();
        var bColor = $('input[name="ts_lms_settings[button_color]"]').val();
        var bhColor = $('input[name="ts_lms_settings[button_hover_color]"]').val();
        var btColor = $('input[name="ts_lms_settings[button_text_color]"]').val();
        var bgColor = $('input[name="ts_lms_settings[body_bg_color]"]').val();
        
        // Update Custom preset preview spans (Only first 4)
        var pColor = $('input[name="ts_lms_settings[primary_color]"]').val();
        var phColor = $('input[name="ts_lms_settings[primary_hover_color]"]').val();
        var tColor = $('input[name="ts_lms_settings[text_color]"]').val();
        var gColor = $('input[name="ts_lms_settings[gray_color]"]').val();
        
        var spans = customPreset.find('.preset-preview span');
        if (spans.length >= 4) {
            $(spans[0]).css('background-color', pColor);
            $(spans[1]).css('background-color', phColor);
            $(spans[2]).css('background-color', tColor);
            $(spans[3]).css('background-color', gColor);
        }
    });

    // Toggle Advanced Colors
    $(document).off('click.tslms_colors').on('click.tslms_colors', '.ts-lms-toggle-colors', function(e) {
        e.preventDefault();
        var link = $(this);
        var container = link.closest('.settings-card').find('.advanced-colors');
        
        if (container.is(':visible')) {
            container.slideUp(250);
            link.html('<span class="dashicons dashicons-plus"></span> Show More');
        } else {
            container.slideDown(250);
            link.html('<span class="dashicons dashicons-minus"></span> Show Less');
        }
    });

    // Toggle Email Configurator
    $('.ts-lms-configure-email').on('click', function(e) {
        e.preventDefault();
        $('#manual-campaign-section').hide();
        $('#email-configurator-section').slideToggle(300);
        
        if ($('#email-configurator-section').is(':visible')) {
            $('html, body').animate({
                scrollTop: $('#email-configurator-section').offset().top - 100
            }, 500);
        }
    });

    // Toggle Manual Campaign
    $('.ts-lms-manual-campaign-btn').on('click', function(e) {
        e.preventDefault();
        $('#email-configurator-section').hide();
        $('#manual-campaign-section').slideToggle(300);
        
        if ($('#manual-campaign-section').is(':visible')) {
            $('html, body').animate({
                scrollTop: $('#manual-campaign-section').offset().top - 100
            }, 500);
        }
    });

    // Handle Manual Recipients Change
    $('#ts-lms-manual-recipients').on('change', function() {
        if ($(this).val() === 'specific_course') {
            $('#specific-course-wrap').slideDown(250);
        } else {
            $('#specific-course-wrap').slideUp(250);
        }
    });

    // Handle Send Manual Email
    $('#ts-lms-send-manual-email').on('click', function() {
        var $btn = $(this);
        var $status = $('#manual-email-status');
        var originalText = $btn.html();
        
        var recipientGroup = $('#ts-lms-manual-recipients').val();
        var courseId = $('#ts-lms-manual-course-id').val();
        var subject = $('#ts-lms-manual-subject').val();
        var message = $('#ts-lms-manual-message').val();
        
        if (!subject || !message) {
            alert('Please fill in both subject and message.');
            return;
        }
        
        if (!confirm('Are you sure you want to send this email to the selected group?')) {
            return;
        }
        
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update dashicons-spin"></span> Sending...');
        $status.html('');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'ts_lms_send_manual_campaign',
                recipient_group: recipientGroup,
                course_id: courseId,
                subject: subject,
                message: message,
                nonce: $('#ts_lms_settings_nonce').val()
            },
            success: function(response) {
                if (response.success) {
                    $status.css('color', '#059669').html(response.data.message);
                    // Clear fields
                    $('#ts-lms-manual-subject').val('');
                    $('#ts-lms-manual-message').val('');
                } else {
                    $status.css('color', '#dc2626').html(response.data.message || 'Failed to send email.');
                }
            },
            error: function() {
                $status.css('color', '#dc2626').html('An error occurred during sending.');
            },
            complete: function() {
                $btn.prop('disabled', false).html(originalText);
            }
        });
    });

    // Handle form submission animation
    $('#ts-lms-settings-form').on('submit', function() {
        var $btn = $('.button-save');
        $btn.addClass('is-saving');
        
        // Change text to 'Saving...'
        var $text = $btn.contents().filter(function() {
            return this.nodeType === 3; // Get text node
        });
        
        if ($text.length) {
            $text[0].nodeValue = ' Saving...';
        }
    });

    // Helper: RGB to Hex
    function rgb2hex(rgb) {
        if (!rgb) return '#000000';
        if (rgb.indexOf('#') !== -1) return rgb;
        var parts = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
        if (!parts) parts = rgb.match(/^rgba\((\d+),\s*(\d+),\s*(\d+),\s*([\d\.]+)\)$/);
        if (!parts) return rgb;
        delete(parts[0]);
        for (var i = 1; i <= 3; ++i) {
            parts[i] = parseInt(parts[i]).toString(16);
            if (parts[i].length == 1) parts[i] = '0' + parts[i];
        }
        return '#' + parts[1] + parts[2] + parts[3];
    }
});
