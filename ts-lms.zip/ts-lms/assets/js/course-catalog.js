/**
 * Course Catalog JavaScript
 * Handles search, filtering, and sorting functionality
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        
        // Search functionality
        $('.ts-search-box input').on('keyup', function() {
            applyFilters();
        });
        
        // Filter functionality - Checkboxes
        $('.ts-filter-section input[type="checkbox"]').on('change', function() {
            applyFilters();
        });
        
        // Clear all filters
        $('.ts-clear-filters').on('click', function(e) {
            e.preventDefault();
            $('.ts-filter-section input[type="checkbox"]').prop('checked', false);
            $('.ts-search-box input').val('');
            applyFilters();
            
            // On mobile, close sidebar after clearing
            if ($(window).width() <= 991) {
                $('.ts-catalog-sidebar').removeClass('active');
                $('body').removeClass('ts-no-scroll');
            }
        });

        // Mobile Filter Toggle
        $('.ts-mobile-filter-toggle').on('click', function() {
            $('.ts-catalog-sidebar').addClass('active');
            $('body').addClass('ts-no-scroll');
        });

        $('.ts-close-mobile-filters').on('click', function() {
            $('.ts-catalog-sidebar').removeClass('active');
            $('body').removeClass('ts-no-scroll');
        });

        // Close sidebar when clicking outside
        $(document).on('click', function(e) {
            if ($(window).width() <= 991) {
                if ($(e.target).hasClass('ts-catalog-sidebar active')) {
                     $('.ts-catalog-sidebar').removeClass('active');
                     $('body').removeClass('ts-no-scroll');
                }
            }
        });

        // Add CSS for body no-scroll
        $('<style>.ts-no-scroll { overflow: hidden !important; }</style>').appendTo('head');
        
        // Sorting functionality
        $('.ts-sort-select').on('change', function() {
            const sortBy = $(this).val();
            const $grid = $('.ts-course-grid');
            const $cards = $grid.find('.ts-course-card').get();
            
            $cards.sort(function(a, b) {
                let valA, valB;
                
                switch(sortBy) {
                    case 'newest':
                        return 0; // Default order is newest
                        
                    case 'oldest':
                        return 1;
                        
                    case 'popular':
                        valA = parseInt($(a).find('.ts-stat-item:first').text().match(/\d+/) || 0);
                        valB = parseInt($(b).find('.ts-stat-item:first').text().match(/\d+/) || 0);
                        return valB - valA;
                        
                    case 'rating':
                        valA = parseFloat($(a).find('.ts-rating-value').text()) || 0;
                        valB = parseFloat($(b).find('.ts-rating-value').text()) || 0;
                        return valB - valA;
                        
                    default:
                        return 0;
                }
            });
            
            $.each($cards, function(idx, card) {
                $grid.append(card);
            });
        });
        
        // Apply filters function
        function applyFilters() {
            const searchTerm = $('.ts-search-box input').val().toLowerCase().trim();
            const filters = {
                type: [],
                level: [],
                price: [],
                category: []
            };
            
            // Collect checked filters
            $('.ts-filter-section').each(function() {
                const $section = $(this);
                const title = $section.find('.ts-filter-title').text().trim().toLowerCase();
                
                $section.find('input[type="checkbox"]:checked').each(function() {
                    let value = $(this).val() || $(this).parent().text().trim().toLowerCase();
                    
                    if (title === 'type') {
                        filters.type.push(value.toLowerCase());
                    } else if (title === 'level') {
                        filters.level.push(value.toLowerCase());
                    } else if (title === 'price' || title === 'price type') {
                        filters.price.push(value.toLowerCase());
                    } else if (title === 'category') {
                        filters.category.push(value.toLowerCase());
                    }
                });
            });
            
            let visibleCount = 0;

            $('.ts-course-card').each(function() {
                const $card = $(this);
                const title = $card.find('.ts-course-title').text().toLowerCase();
                const author = $card.find('.ts-author-info').text().toLowerCase();
                const category = $card.data('category') ? $card.data('category').toLowerCase() : '';
                const level = $card.data('level') ? $card.data('level').toLowerCase() : '';
                const type = $card.data('type') ? $card.data('type').toLowerCase() : '';
                const postType = $card.data('post-type') ? $card.data('post-type').toLowerCase() : '';
                
                let show = true;

                // Search Filter
                if (searchTerm !== '' && !title.includes(searchTerm) && !author.includes(searchTerm) && !category.includes(searchTerm)) {
                    show = false;
                }

                // Category Filter
                if (show && filters.category.length > 0) {
                    if (!filters.category.includes(category)) {
                        show = false;
                    }
                }

                // Type Filter (Course/Bundle)
                if (show && filters.type.length > 0) {
                    if (!filters.type.includes(postType)) {
                        show = false;
                    }
                }

                // Level Filter
                if (show && filters.level.length > 0) {
                    if (!filters.level.includes(level)) {
                        show = false;
                    }
                }

                // Price Filter
                if (show && filters.price.length > 0) {
                    if (filters.price.includes('free') && type !== 'free') {
                        show = false;
                    } else if (filters.price.includes('paid') && type !== 'paid') {
                        show = false;
                    }
                }
                
                if (show) {
                    $card.fadeIn(200);
                    visibleCount++;
                } else {
                    $card.fadeOut(200);
                }
            });

            // No results handling
            $('.ts-no-results').remove();
            if (visibleCount === 0) {
                $('.ts-course-grid').append(
                    '<div class="ts-no-results" style="grid-column: 1/-1; text-align: center; padding: 60px 20px;">' +
                    '<span class="dashicons dashicons-search" style="font-size: 64px; color: #e2e8f0; margin-bottom: 20px;"></span>' +
                    '<h3 style="font-size: 20px; color: #1e293b; margin: 0 0 10px 0;">No courses found</h3>' +
                    '<p style="color: #64748b; margin: 0;">Try adjusting your filters or search terms</p>' +
                    '</div>'
                );
            }
        }
    });
    
})(jQuery);
