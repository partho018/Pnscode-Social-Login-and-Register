/**
 * TS LMS Onboarding Wizard JavaScript
 */

(function($) {
    'use strict';

    const TSWizard = {
        currentStep: 1,
        totalSteps: 6,

        init: function() {
            this.bindEvents();
            this.initCurrentStep();
        },

        bindEvents: function() {
            // Welcome step
            $(document).on('click', '.ts-welcome-start', this.goToNextStep.bind(this));
            $(document).on('click', '.ts-welcome-skip', this.skipWizard.bind(this));

            // Navigation
            $(document).on('click', '.ts-wizard-next', this.goToNextStep.bind(this));
            $(document).on('click', '.ts-wizard-prev', this.goToPrevStep.bind(this));
            $(document).on('click', '.ts-wizard-skip', this.skipCurrentStep.bind(this));

            // Step 2: Basic Settings
            $(document).on('submit', '#ts-wizard-basic-settings-form', this.saveBasicSettings.bind(this));

            // Step 3: Pages
            $(document).on('click', '.ts-toggle-advanced', this.toggleAdvanced);
            $(document).on('click', '.ts-create-pages', this.createPages.bind(this));

            // Step 4: Payment
            $(document).on('click', '.ts-install-woo', this.installWooCommerce.bind(this));
            $(document).on('click', '.ts-activate-woo', this.installWooCommerce.bind(this));

            // Step 5: Sample Data
            $(document).on('click', '.ts-import-data', this.importSampleData.bind(this));

            // Step 6: Complete
            $(document).on('click', '.ts-finish-wizard', this.finishWizard.bind(this));
        },

        initCurrentStep: function() {
            const step = $('.ts-wizard-step').data('step');
            this.currentStep = step || 1;

            // Initialize step-specific functionality
            if (this.currentStep === 4) {
                this.checkWooCommerceStatus();
            }
        },

        goToNextStep: function(e) {
            if (e) e.preventDefault();
            
            const nextStep = this.currentStep + 1;
            if (nextStep <= this.totalSteps) {
                this.navigateToStep(nextStep);
            }
        },

        goToPrevStep: function(e) {
            if (e) e.preventDefault();
            
            const prevStep = this.currentStep - 1;
            if (prevStep >= 1) {
                this.navigateToStep(prevStep);
            }
        },

        navigateToStep: function(step) {
            const url = new URL(window.location.href);
            url.searchParams.set('step', step);
            window.location.href = url.toString();
        },

        skipCurrentStep: function(e) {
            if (e) e.preventDefault();
            this.goToNextStep();
        },

        skipWizard: function(e) {
            if (e) e.preventDefault();

            if (!confirm(tsLmsWizard.strings.skipConfirm || 'Are you sure you want to skip the setup wizard?')) {
                return;
            }

            this.showLoading();

            $.ajax({
                url: tsLmsWizard.ajax_url,
                type: 'POST',
                data: {
                    action: 'ts_lms_wizard_skip',
                    nonce: tsLmsWizard.nonce
                },
                success: function(response) {
                    if (response.success) {
                        window.location.href = response.data.redirect;
                    } else {
                        alert(response.data.message || tsLmsWizard.strings.error);
                        TSWizard.hideLoading();
                    }
                },
                error: function() {
                    alert(tsLmsWizard.strings.error);
                    TSWizard.hideLoading();
                }
            });
        },

        // Step 2: Save Basic Settings
        saveBasicSettings: function(e) {
            e.preventDefault();

            const $form = $('#ts-wizard-basic-settings-form');
            const currency = $('#ts-currency').val();
            const country = $('#ts-country').val();
            const taxEnabled = $('#ts-tax-enabled').is(':checked');

            this.showLoading();

            $.ajax({
                url: tsLmsWizard.ajax_url,
                type: 'POST',
                data: {
                    action: 'ts_lms_wizard_save_basic_settings',
                    nonce: tsLmsWizard.nonce,
                    currency: currency,
                    country: country,
                    tax_enabled: taxEnabled
                },
                success: function(response) {
                    TSWizard.hideLoading();
                    
                    if (response.success) {
                        TSWizard.showSuccess(response.data.message);
                        setTimeout(function() {
                            TSWizard.goToNextStep();
                        }, 1000);
                    } else {
                        TSWizard.showError(response.data.message || tsLmsWizard.strings.error);
                    }
                },
                error: function() {
                    TSWizard.hideLoading();
                    TSWizard.showError(tsLmsWizard.strings.error);
                }
            });
        },

        // Step 3: Create Pages
        createPages: function(e) {
            if (e) e.preventDefault();

            this.showLoading();
            $('.ts-pages-progress').show();

            let progress = 0;
            const progressInterval = setInterval(function() {
                progress += 10;
                if (progress <= 90) {
                    $('.ts-pages-progress .ts-progress-fill').css('width', progress + '%');
                }
            }, 200);

            $.ajax({
                url: tsLmsWizard.ajax_url,
                type: 'POST',
                data: {
                    action: 'ts_lms_wizard_create_pages',
                    nonce: tsLmsWizard.nonce
                },
                success: function(response) {
                    clearInterval(progressInterval);
                    $('.ts-pages-progress .ts-progress-fill').css('width', '100%');
                    
                    setTimeout(function() {
                        TSWizard.hideLoading();
                        $('.ts-pages-progress').hide();
                        
                        if (response.success) {
                            // Update page status indicators
                            $('.ts-page-item').each(function() {
                                $(this).find('.ts-status-pending')
                                    .removeClass('dashicons-minus ts-status-pending')
                                    .addClass('dashicons-yes-alt ts-status-success');
                                $(this).find('.ts-badge-pending')
                                    .removeClass('ts-badge-pending')
                                    .addClass('ts-badge-success')
                                    .text('Created');
                            });
                            
                            TSWizard.showSuccess(response.data.message);
                            setTimeout(function() {
                                TSWizard.goToNextStep();
                            }, 1500);
                        } else {
                            TSWizard.showError(response.data.message || tsLmsWizard.strings.error);
                        }
                    }, 500);
                },
                error: function() {
                    clearInterval(progressInterval);
                    TSWizard.hideLoading();
                    $('.ts-pages-progress').hide();
                    TSWizard.showError(tsLmsWizard.strings.error);
                }
            });
        },

        toggleAdvanced: function(e) {
            e.preventDefault();
            const target = $(this).data('target');
            $('#' + target).slideToggle();
            $(this).find('.dashicons').toggleClass('dashicons-arrow-down-alt2 dashicons-arrow-up-alt2');
        },

        // Step 4: Check WooCommerce Status
        checkWooCommerceStatus: function() {
            $.ajax({
                url: tsLmsWizard.ajax_url,
                type: 'POST',
                data: {
                    action: 'ts_lms_wizard_check_woocommerce',
                    nonce: tsLmsWizard.nonce
                },
                success: function(response) {
                    if (response.success) {
                        TSWizard.updateWooCommerceStatus(response.data);
                    }
                }
            });
        },

        updateWooCommerceStatus: function(data) {
            const $status = $('#ts-woo-status');
            const $actions = $('#ts-woo-actions');

            let iconClass = 'dashicons-update ts-spin';
            let iconColor = '#6c757d';
            let title = '';
            let message = data.message;
            let buttonHtml = '';

            if (data.status === 'active') {
                iconClass = 'dashicons-yes-alt';
                iconColor = '#28a745';
                title = 'WooCommerce is Active';
                buttonHtml = '<button type="button" class="ts-wizard-btn ts-wizard-btn-primary ts-wizard-next">Continue <span class="dashicons dashicons-arrow-right-alt2"></span></button>';
            } else if (data.status === 'inactive') {
                iconClass = 'dashicons-warning';
                iconColor = '#ffc107';
                title = 'WooCommerce Needs Activation';
                buttonHtml = '<button type="button" class="ts-wizard-btn ts-wizard-btn-primary ts-activate-woo">Activate WooCommerce</button>';
            } else {
                iconClass = 'dashicons-download';
                iconColor = '#667eea';
                title = 'Install WooCommerce';
                buttonHtml = '<button type="button" class="ts-wizard-btn ts-wizard-btn-primary ts-install-woo">Install & Activate WooCommerce</button>';
            }

            $status.html(`
                <div class="ts-status-icon">
                    <span class="dashicons ${iconClass}" style="color: ${iconColor}"></span>
                </div>
                <div class="ts-status-content">
                    <h4>${title}</h4>
                    <p>${message}</p>
                </div>
            `);

            $actions.html(buttonHtml).show();
        },

        installWooCommerce: function(e) {
            if (e) e.preventDefault();

            this.showLoading();
            $('.ts-woo-progress').show();

            let progress = 0;
            const progressInterval = setInterval(function() {
                progress += 5;
                if (progress <= 90) {
                    $('.ts-woo-progress .ts-progress-fill').css('width', progress + '%');
                }
            }, 500);

            $.ajax({
                url: tsLmsWizard.ajax_url,
                type: 'POST',
                data: {
                    action: 'ts_lms_wizard_install_woocommerce',
                    nonce: tsLmsWizard.nonce
                },
                success: function(response) {
                    clearInterval(progressInterval);
                    $('.ts-woo-progress .ts-progress-fill').css('width', '100%');
                    
                    setTimeout(function() {
                        TSWizard.hideLoading();
                        $('.ts-woo-progress').hide();
                        
                        if (response.success) {
                            TSWizard.showSuccess(response.data.message);
                            TSWizard.checkWooCommerceStatus();
                        } else {
                            TSWizard.showError(response.data.message || tsLmsWizard.strings.error);
                        }
                    }, 500);
                },
                error: function() {
                    clearInterval(progressInterval);
                    TSWizard.hideLoading();
                    $('.ts-woo-progress').hide();
                    TSWizard.showError(tsLmsWizard.strings.error);
                }
            });
        },

        // Step 5: Import Sample Data
        importSampleData: function(e) {
            if (e) e.preventDefault();

            const importData = $('#ts-import-sample').is(':checked');
            
            if (!importData) {
                this.goToNextStep();
                return;
            }

            this.showLoading();
            $('.ts-import-progress').show();

            const steps = ['courses', 'lessons', 'quizzes', 'certificates'];
            let currentStepIndex = 0;

            const updateProgress = function() {
                const progress = ((currentStepIndex + 1) / steps.length) * 100;
                $('.ts-import-progress .ts-progress-fill').css('width', progress + '%');
                
                // Update step indicators
                $('.ts-import-step').each(function(index) {
                    const $step = $(this);
                    if (index < currentStepIndex) {
                        $step.find('.dashicons')
                            .removeClass('dashicons-update ts-spin dashicons-minus')
                            .addClass('dashicons-yes-alt')
                            .css('color', '#28a745');
                    } else if (index === currentStepIndex) {
                        $step.find('.dashicons')
                            .removeClass('dashicons-minus')
                            .addClass('dashicons-update ts-spin')
                            .css('color', '#667eea');
                    }
                });
            };

            const progressInterval = setInterval(function() {
                if (currentStepIndex < steps.length - 1) {
                    currentStepIndex++;
                    updateProgress();
                }
            }, 1000);

            $.ajax({
                url: tsLmsWizard.ajax_url,
                type: 'POST',
                data: {
                    action: 'ts_lms_wizard_import_sample_data',
                    nonce: tsLmsWizard.nonce
                },
                success: function(response) {
                    clearInterval(progressInterval);
                    currentStepIndex = steps.length - 1;
                    updateProgress();
                    
                    setTimeout(function() {
                        // Mark all steps as complete
                        $('.ts-import-step .dashicons')
                            .removeClass('dashicons-update ts-spin dashicons-minus')
                            .addClass('dashicons-yes-alt')
                            .css('color', '#28a745');
                        
                        setTimeout(function() {
                            TSWizard.hideLoading();
                            $('.ts-import-progress').hide();
                            
                            if (response.success) {
                                TSWizard.showSuccess(response.data.message);
                                setTimeout(function() {
                                    TSWizard.goToNextStep();
                                }, 2000);
                            } else {
                                TSWizard.showError(response.data.message || tsLmsWizard.strings.error);
                            }
                        }, 500);
                    }, 1000);
                },
                error: function() {
                    clearInterval(progressInterval);
                    TSWizard.hideLoading();
                    $('.ts-import-progress').hide();
                    TSWizard.showError(tsLmsWizard.strings.error);
                }
            });
        },

        // Step 6: Finish Wizard
        finishWizard: function(e) {
            if (e) e.preventDefault();

            this.showLoading();

            $.ajax({
                url: tsLmsWizard.ajax_url,
                type: 'POST',
                data: {
                    action: 'ts_lms_wizard_complete',
                    nonce: tsLmsWizard.nonce
                },
                success: function(response) {
                    if (response.success) {
                        window.location.href = response.data.redirect;
                    } else {
                        TSWizard.hideLoading();
                        alert(response.data.message || tsLmsWizard.strings.error);
                    }
                },
                error: function() {
                    TSWizard.hideLoading();
                    alert(tsLmsWizard.strings.error);
                }
            });
        },

        // Utility Functions
        showLoading: function() {
            $('.ts-wizard-loading').fadeIn(200);
        },

        hideLoading: function() {
            $('.ts-wizard-loading').fadeOut(200);
        },

        showSuccess: function(message) {
            const $msg = $('.ts-success-message');
            $msg.find('.ts-message-text').text(message);
            $msg.slideDown();
            
            setTimeout(function() {
                $msg.slideUp();
            }, 5000);
        },

        showError: function(message) {
            const $msg = $('.ts-error-message');
            $msg.find('.ts-message-text').text(message);
            $msg.slideDown();
            
            setTimeout(function() {
                $msg.slideUp();
            }, 5000);
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        TSWizard.init();
    });

})(jQuery);
