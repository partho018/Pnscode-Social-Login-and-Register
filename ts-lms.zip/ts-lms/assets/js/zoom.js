/**
 * Zoom Integration JavaScript
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        /**
         * Tab switching
         */
        $('.ts-zoom-tabs .tab-link').on('click', function(e) {
            const href = $(this).attr('href');
            
            // If it's a hash link, prevent default and handle tab switching
            if (href.indexOf('#') !== -1) {
                e.preventDefault();
                
                $('.ts-zoom-tabs .tab-link').removeClass('active');
                $(this).addClass('active');
            }
        });

        /**
         * Form validation
         */
        $('.zoom-credentials-form').on('submit', function(e) {
            const accountId = $('#zoom-account-id').val().trim();
            const clientId = $('#zoom-client-id').val().trim();
            const clientSecret = $('#zoom-client-secret').val().trim();

            if (!accountId || !clientId || !clientSecret) {
                e.preventDefault();
                alert('Please fill in all required fields.');
                return false;
            }
        });

        /**
         * Input focus animations
         */
        $('.form-field input').on('focus', function() {
            $(this).parent('.form-field').addClass('focused');
        });

        $('.form-field input').on('blur', function() {
            $(this).parent('.form-field').removeClass('focused');
        });

        /**
         * FAQ Accordion Toggle
         */
        $('.faq-question').on('click', function() {
            const faqItem = $(this).parent('.faq-item');
            const wasActive = faqItem.hasClass('active');
            
            // Close all other FAQ items
            $('.faq-item').removeClass('active');
            
            // Toggle current item
            if (!wasActive) {
                faqItem.addClass('active');
            }
        });
    });

})(jQuery);
