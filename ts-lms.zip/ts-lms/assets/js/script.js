/**
 * TS LMS Frontend JavaScript
 *
 * @package TS_LMS
 * @version 1.0.0
 */

(function($) {
    'use strict';

    /**
     * TS LMS Frontend Module
     */
    var TS_LMS = {
        
        /**
         * Initialize the module
         */
        init: function() {
            this.bindEvents();
            this.initComponents();
        },

        bindEvents: function() {
            // Handle clear filters
            $(document).on('click', '.ts-clear-filters', this.handleClearFilters);
            
            // Handle filter checkbox changes (visual only for now)
            $(document).on('change', '.ts-filter-item input', this.handleFilterChange);

            // Handle Wishlist Toggle
            $(document).on('click', '.ts-wishlist-btn', this.handleWishlistToggle.bind(this));
        },

        /**
         * Initialize components
         */
        initComponents: function() {
            // Add any component initialization here
            console.log('TS LMS Frontend initialized');
        },

        /**
         * Handle clear filters
         */
        handleClearFilters: function(e) {
            e.preventDefault();
            $('.ts-catalog-sidebar input[type="checkbox"]').prop('checked', false);
            $('.ts-search-box input').val('');
            console.log('Filters cleared');
        },

        /**
         * Handle filter change
         */
        handleFilterChange: function() {
            // This would normally trigger an AJAX refresh
            console.log('Filter changed');
        },

        /**
         * Handle button click
         */
        handleButtonClick: function(e) {
            e.preventDefault();
            var $button = $(this);
            
            // Add your button click logic here
            console.log('TS LMS button clicked:', $button.data());
        },

        /**
         * Handle form submission
         */
        handleFormSubmit: function(e) {
            e.preventDefault();
            var $form = $(this);
            
            // Add your form submission logic here
            console.log('TS LMS form submitted');
        },

        /**
         * Make an AJAX request
         */
        ajaxRequest: function(action, data, successCallback, errorCallback) {
            $.ajax({
                url: ts_lms_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'ts_lms_' + action,
                    nonce: ts_lms_ajax.nonce,
                    ...data
                },
                success: function(response) {
                    if (response.success) {
                        if (typeof successCallback === 'function') {
                            successCallback(response.data);
                        }
                    } else {
                        if (typeof errorCallback === 'function') {
                            errorCallback(response.data);
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.error('TS LMS AJAX Error:', error);
                    if (typeof errorCallback === 'function') {
                        errorCallback({ message: 'An error occurred. Please try again.' });
                    }
                }
            });
        },

        /**
         * Handle Wishlist Toggle
         */
        handleWishlistToggle: function(e) {
            e.preventDefault();
            e.stopPropagation();

            var $btn = $(e.currentTarget);
            var courseId = $btn.data('course-id');
            var _this = this;

            if ($btn.data('processing')) return;

            $btn.data('processing', true);
            $btn.addClass('processing');

            this.ajaxRequest('toggle_wishlist', { course_id: courseId }, function(data) {
                if (data.status === 'added') {
                    $btn.addClass('active');
                    $btn.attr('title', 'Remove from Wishlist');
                    $btn.find('.dashicons').removeClass('dashicons-bookmark').addClass('dashicons-heart');
                    if ($btn.find('.btn-text').length) {
                        $btn.find('.btn-text').text('In Wishlist');
                    }
                } else {
                    $btn.removeClass('active');
                    $btn.attr('title', 'Add to Wishlist');
                    $btn.find('.dashicons').removeClass('dashicons-heart').addClass('dashicons-bookmark');
                    if ($btn.find('.btn-text').length) {
                        $btn.find('.btn-text').text('Add to Wishlist');
                    }
                }
                $btn.data('processing', false);
                $btn.removeClass('processing');
                
                // Optional: Show a small toast notification
                if (window.showToast) {
                    window.showToast(data.message);
                }
            }, function(error) {
                $btn.data('processing', false);
                $btn.removeClass('processing');
                
                if (error && error.message && error.message.includes('login')) {
                    // Trigger login modal
                    $('.ts-trigger-auth-modal').first().trigger('click');
                } else {
                    alert(error.message || 'An error occurred');
                }
            });
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        TS_LMS.init();
    });

    // Expose to global scope if needed
    window.TS_LMS = TS_LMS;

})(jQuery);
