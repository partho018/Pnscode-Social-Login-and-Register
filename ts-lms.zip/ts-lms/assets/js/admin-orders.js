jQuery(document).ready(function($) {
    // Handle order status change
    $('.ts-order-status-select').on('change', function() {
        var orderId = $(this).data('order-id');
        var newStatus = $(this).val();
        var $select = $(this);
        var originalStatus = $select.data('original-status');
        
        // Disable simple to prevent multiple clicks
        $select.addClass('ts-loading').prop('disabled', true);
        
        $.ajax({
            url: ts_lms_orders.ajax_url,
            type: 'POST',
            data: {
                action: 'ts_lms_update_order_status',
                order_id: orderId,
                status: newStatus,
                nonce: ts_lms_orders.nonce
            },
            success: function(response) {
                $select.removeClass('ts-loading').prop('disabled', false);
                
                if (response.success) {
                    // Update original status data
                    $select.data('original-status', newStatus);
                    
                    // Show success message
                    showNotification('success', response.data.message || 'Order status updated successfully');
                    
                    // Update badge color class if needed (optional enhancement)
                    updateSelectColor($select, newStatus);
                } else {
                    // Revert change
                    $select.val(originalStatus);
                    showNotification('error', response.data.message || 'Failed to update order status');
                }
            },
            error: function() {
                $select.removeClass('ts-loading').prop('disabled', false);
                $select.val(originalStatus);
                showNotification('error', 'Network error occurred. Please try again.');
            }
        });
    });

    // Helper to update select color based on status
    function updateSelectColor($select, status) {
        // Remove existing status classes
        $select.removeClass('ts-status-pending ts-status-processing ts-status-on-hold ts-status-completed ts-status-cancelled ts-status-refunded ts-status-failed');
        
        // Add new class
        $select.addClass('ts-status-' + status);
    }
    
    // Initialize select colors on load
    $('.ts-order-status-select').each(function() {
        updateSelectColor($(this), $(this).val());
    });

    // Notification helper
    function showNotification(type, message) {
        var $notification = $('<div class="ts-status-message ' + type + '">' + message + '</div>');
        $('body').append($notification);
        
        setTimeout(function() {
            $notification.fadeOut(300, function() {
                $(this).remove();
            });
        }, 3000);
    }
});
