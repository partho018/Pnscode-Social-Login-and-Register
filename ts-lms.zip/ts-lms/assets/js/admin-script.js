/**
 * TS LMS Admin JavaScript
 *
 * @package TS_LMS
 * @version 1.0.0
 */

(function ($) {
    'use strict';

    /**
     * TS LMS Admin Module
     */
    var TS_LMS_Admin = {

        /**
         * Initialize the admin module
         */
        init: function () {
            this.bindEvents();
            this.initComponents();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function () {
            // Handle settings form changes
            $(document).on('change', '.ts-lms-settings input, .ts-lms-settings select', this.markUnsavedChanges);

            // Handle tab navigation if tabs exist
            $(document).on('click', '.ts-lms-tab-link', this.handleTabClick);
        },

        /**
         * Initialize components
         */
        initComponents: function () {
            // Initialize any admin components
            this.initTabs();
            this.initVerticalTabs();
            this.initCourseUrlEditor();
            console.log('TS LMS Admin initialized');
        },

        /**
         * Initialize tab navigation
         */
        initTabs: function () {
            var $tabs = $('.ts-lms-tabs');
            if ($tabs.length === 0) return;

            // Show first tab by default
            $tabs.find('.ts-lms-tab-content').hide();
            $tabs.find('.ts-lms-tab-content:first').show();
            $tabs.find('.ts-lms-tab-link:first').addClass('active');
        },

        /**
         * Initialize Vertical Tabs (Options Section)
         */
        initVerticalTabs: function() {
            $(document).on('click', '.ts-opt-tab', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var target = $btn.data('target');
                var $container = $btn.closest('.ts-course-options-box');
                
                // Update buttons
                $container.find('.ts-opt-tab').removeClass('active');
                $btn.addClass('active');
                
                // Update content
                $container.find('.ts-opt-content').removeClass('active');
                $container.find('#opt-' + target).addClass('active');
            });
        },

        /**
         * Initialize Course URL Editor
         */
        initCourseUrlEditor: function() {
            // Edit button click
            $(document).on('click', '.ts-edit-permalink-btn', function(e) {
                e.preventDefault();
                $('.ts-course-url-display').hide();
                $('.ts-course-url-edit').css('display', 'flex');
            });

            // Cancel button click
            $(document).on('click', '.ts-cancel-permalink', function(e) {
                e.preventDefault();
                var currentSlug = $('#course-slug-display').text();
                $('#course-slug').val(currentSlug); // Reset input
                $('.ts-course-url-edit').hide();
                $('.ts-course-url-display').css('display', 'flex');
            });

            // OK button click
            $(document).on('click', '.ts-save-permalink', function(e) {
                e.preventDefault();
                var newSlug = $('#course-slug').val();
                if(!newSlug) newSlug = 'new-course';
                
                // Here we would typically sanitize the slug via AJAX, but for now just update UI
                $('#course-slug-display').text(newSlug);
                
                $('.ts-course-url-edit').hide();
                $('.ts-course-url-display').css('display', 'flex');
            });
        },

        /**
         * Handle tab click
         */
        handleTabClick: function (e) {
            e.preventDefault();
            var $link = $(this);
            var target = $link.attr('href');

            // Update active states
            $link.siblings().removeClass('active');
            $link.addClass('active');

            // Show target content
            $(target).siblings('.ts-lms-tab-content').hide();
            $(target).show();
        },

        /**
         * Mark form as having unsaved changes
         */
        markUnsavedChanges: function () {
            var $form = $(this).closest('form');
            $form.data('unsaved', true);

            // Add visual indicator
            $form.find('.submit .button-primary').addClass('button-primary-unsaved');
        },

        /**
         * Show admin notice
         */
        showNotice: function (message, type) {
            type = type || 'success';
            var $notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');

            $('.wrap h1').after($notice);

            // Auto-dismiss after 5 seconds
            setTimeout(function () {
                $notice.fadeOut(function () {
                    $(this).remove();
                });
            }, 5000);
        }
    };

    /**
     * Course Listing Page Module
     */
    var TS_LMS_CourseList = {

        /**
         * Initialize course listing functionality
         */
        init: function () {
            if (!$('body').hasClass('post-type-ts_course')) {
                return;
            }

            this.bindEvents();
            console.log('TS LMS Course List initialized');
        },

        /**
         * Bind event handlers
         */
        bindEvents: function () {
            // Handle status dropdown change
            $(document).on('change', '.ts-status-select', this.handleStatusChange);

            // Handle more actions click
            $(document).on('click', '.ts-more-actions', this.handleMoreActions);
        },

        /**
         * Handle status change
         */
        handleStatusChange: function (e) {
            var $select = $(this);
            var postId = $select.data('post-id');
            var newStatus = $select.val();
            var oldStatus = $select.find('option:not(:selected)').val();

            // Add loading state
            $select.addClass('ts-loading');

            // Send AJAX request
            $.ajax({
                url: tsLmsCourseList.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ts_lms_change_course_status',
                    nonce: tsLmsCourseList.nonce,
                    post_id: postId,
                    status: newStatus
                },
                success: function (response) {
                    $select.removeClass('ts-loading');

                    if (response.success) {
                        // Update status class
                        $select.removeClass('ts-status-draft ts-status-publish');
                        $select.addClass('ts-status-' + newStatus);

                        // Show success message
                        TS_LMS_CourseList.showMessage(response.data.message, 'success');

                        // Update view button visibility
                        var $rowActions = $select.closest('.ts-date-cell').find('.ts-row-actions');
                        var $viewBtn = $rowActions.find('.ts-btn-view');

                        if (newStatus === 'publish') {
                            if ($viewBtn.length === 0) {
                                // Add view button if it doesn't exist
                                var permalink = ''; // You'd need to pass this from PHP
                                $rowActions.prepend('<a href="' + permalink + '" class="ts-btn-view" target="_blank">View</a>');
                            }
                        } else {
                            $viewBtn.remove();
                        }
                    } else {
                        // Revert to old status
                        $select.val(oldStatus);
                        TS_LMS_CourseList.showMessage(response.data.message, 'error');
                    }
                },
                error: function () {
                    $select.removeClass('ts-loading');
                    $select.val(oldStatus);
                    TS_LMS_CourseList.showMessage('An error occurred. Please try again.', 'error');
                }
            });
        },

        /**
         * Handle more actions click
         */
        handleMoreActions: function (e) {
            e.preventDefault();
            // This could open a dropdown menu with more actions
            // For now, we'll just trigger the default WordPress row actions
            var $row = $(this).closest('tr');
            $row.find('.row-actions').toggle();
        },

        /**
         * Show notification message
         */
        showMessage: function (message, type) {
            var $message = $('<div class="ts-status-message ' + (type === 'error' ? 'error' : '') + '">' + message + '</div>');
            $('body').append($message);

            // Auto-remove after 3 seconds
            setTimeout(function () {
                $message.fadeOut(300, function () {
                    $(this).remove();
                });
            }, 3000);
        }
    };

    // Initialize on document ready
    $(document).ready(function () {
        TS_LMS_Admin.init();
        TS_LMS_CourseList.init();
    });

    // Expose to global scope
    window.TS_LMS_Admin = TS_LMS_Admin;
    window.TS_LMS_CourseList = TS_LMS_CourseList;


})(jQuery);
