jQuery(document).ready(function($) {
    // Number counting animation
    $('.ts-stat-number').each(function() {
        var $this = $(this);
        var target = $this.data('target');
        var current = 0;
        var increment = target / 40; // Fewer steps for faster pop
        var duration = 800; 
        var stepTime = duration / 40;

        var isPrice = $this.text().indexOf('$') !== -1;

        if (target > 0) {
            var counter = setInterval(function() {
                current += increment;
                if (current >= target) {
                    current = target;
                    clearInterval(counter);
                }
                
                var displayValue = Math.floor(current);
                if (isPrice) {
                    $this.text('$' + displayValue.toLocaleString());
                } else {
                    $this.text(displayValue.toLocaleString());
                }
            }, stepTime);
        }
    });

    // Aurora Chart Config
    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.font.weight = '600';
    Chart.defaults.color = '#64748b';

    // Use actual data if available
    var dashboardData = window.tsLmsDashboardData || {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        revenue: [0, 0, 0, 0, 0, 0],
        enrollment: [0, 0, 0, 0, 0, 0],
        currencySymbol: '$'
    };

    // Revenue Chart (Gradient Line)
    var ctxRevenue = document.getElementById('ts-revenue-chart');
    if (ctxRevenue) {
        var revenueChart = new Chart(ctxRevenue, {
            type: 'line',
            data: {
                labels: dashboardData.labels,
                datasets: [{
                    label: 'Revenue',
                    data: dashboardData.revenue,
                    borderColor: '#0077b5',
                    backgroundColor: function(context) {
                        const chart = context.chart;
                        const {ctx, chartArea} = chart;
                        if (!chartArea) return null;
                        const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
                        gradient.addColorStop(0, 'rgba(0, 119, 181, 0)');
                        gradient.addColorStop(1, 'rgba(0, 119, 181, 0.3)');
                        return gradient;
                    },
                    fill: true,
                    tension: 0.4, 
                    borderWidth: 4,
                    pointBackgroundColor: '#00a0dc',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(241, 245, 249, 0.5)' },
                        ticks: { 
                            callback: function(value) { 
                                return dashboardData.currencySymbol + value.toLocaleString(); 
                            } 
                        }
                    },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    // Enrollment Chart (Creative Bar)
    var ctxEnroll = document.getElementById('ts-enrollment-chart');
    if (ctxEnroll) {
        var enrollChart = new Chart(ctxEnroll, {
            type: 'bar',
            data: {
                labels: dashboardData.labels,
                datasets: [{
                    label: 'Enrolled',
                    data: dashboardData.enrollment,
                    backgroundColor: function(context) {
                        const chart = context.chart;
                        const {ctx, chartArea} = chart;
                        if (!chartArea) return null;
                        const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
                        gradient.addColorStop(0, '#0077b5');
                        gradient.addColorStop(1, '#00a0dc');
                        return gradient;
                    },
                    borderRadius: 8,
                    maxBarThickness: 30
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(241, 245, 249, 0.5)' },
                        ticks: { stepSize: 1 }
                    },
                    x: { grid: { display: false } }
                }
            }
        });
    }
});
