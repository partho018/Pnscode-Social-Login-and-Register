/**
 * Google Meet Integration JavaScript
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        // Copy button functionality
        $('#ts-copy-btn').on('click', function() {
            const input = $('#ts-redirect-url');
            const button = $(this);
            
            // Select and copy the text
            input.select();
            document.execCommand('copy');
            
            // Visual feedback
            const originalText = button.text();
            button.text('Copied!').addClass('copied');
            
            setTimeout(function() {
                button.text(originalText).removeClass('copied');
            }, 2000);
        });

        // File input trigger
        $('#ts-choose-file').on('click', function() {
            $('#ts-json-file').click();
        });

        // File selection handler
        $('#ts-json-file').on('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                handleFileUpload(file);
            }
        });

        // Drag and drop functionality
        const uploadCard = $('.ts-google-meet-upload-card');
        
        uploadCard.on('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).addClass('drag-over');
        });

        uploadCard.on('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('drag-over');
        });

        uploadCard.on('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('drag-over');
            
            const files = e.originalEvent.dataTransfer.files;
            if (files.length > 0) {
                handleFileUpload(files[0]);
            }
        });

        /**
         * Handle file upload
         */
        function handleFileUpload(file) {
            const statusDiv = $('#ts-upload-status');
            const statusText = statusDiv.find('.status-text');
            
            // Check file type
            if (!file.name.endsWith('.json')) {
                showStatus('error', 'Please upload a valid JSON file.');
                return;
            }

            // Show loading state
            showStatus('loading', 'Uploading file...');

            // Read file content
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const jsonData = JSON.parse(e.target.result);
                    
                    // Validate JSON structure (basic check)
                    if (!jsonData.client_id || !jsonData.client_secret) {
                        showStatus('error', 'Invalid credentials file. Missing required fields.');
                        return;
                    }

                    // Send to server via AJAX
                    uploadCredentials(jsonData);
                    
                } catch (error) {
                    showStatus('error', 'Invalid JSON file format.');
                }
            };
            
            reader.onerror = function() {
                showStatus('error', 'Error reading file.');
            };
            
            reader.readAsText(file);
        }

        /**
         * Upload credentials to server
         */
        function uploadCredentials(credentials) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'ts_lms_save_google_meet_credentials',
                    nonce: ts_lms_google_meet.nonce,
                    credentials: JSON.stringify(credentials)
                },
                success: function(response) {
                    if (response.success) {
                        showStatus('success', 'Credentials uploaded successfully!');
                        
                        // Reload page after 2 seconds
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        showStatus('error', response.data.message || 'Upload failed.');
                    }
                },
                error: function() {
                    showStatus('error', 'Server error. Please try again.');
                }
            });
        }

        /**
         * Show status message
         */
        function showStatus(type, message) {
            const statusDiv = $('#ts-upload-status');
            const statusText = statusDiv.find('.status-text');
            
            statusDiv.removeClass('success error loading')
                     .addClass(type)
                     .show();
            
            statusText.text(message);
        }

        /**
         * Tab switching (if needed)
         */
        $('.ts-google-meet-tabs .tab-link').on('click', function(e) {
            const href = $(this).attr('href');
            
            // If it's a hash link, prevent default and handle tab switching
            if (href.indexOf('#') !== -1) {
                e.preventDefault();
                
                $('.ts-google-meet-tabs .tab-link').removeClass('active');
                $(this).addClass('active');
                
                // You can add tab content switching logic here
            }
        });

        /**
         * FAQ Accordion Toggle
         */
        $('.faq-question').on('click', function() {
            const faqItem = $(this).parent('.faq-item');
            const wasActive = faqItem.hasClass('active');
            
            // Close all other FAQ items
            $('.faq-item').removeClass('active');
            
            // Toggle current item
            if (!wasActive) {
                faqItem.addClass('active');
            }
        });
    });

})(jQuery);
