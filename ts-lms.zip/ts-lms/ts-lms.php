<?php
/**
 * Plugin Name: TS LMS
 * Description: A simple and standard Learning Management System plugin for WordPress.
 * Version: 1.0.0
 * Author: Techsoulbd 
 * Author URI: https://profiles.wordpress.org/techsoulbd/
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: ts-lms
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Increase execution time for heavy operations
if ( is_admin() ) {
    @set_time_limit( 300 );
}

/**
 * Current plugin version.
 */
define( 'TS_LMS_VERSION', '1.0.0' );

/**
 * Plugin directory path.
 */
define( 'TS_LMS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/**
 * Plugin directory URL.
 */
define( 'TS_LMS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Include helper functions
require_once TS_LMS_PLUGIN_DIR . 'includes/functions.php';

/**
 * Main Class.
 */
define( 'TS_LMS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Load core classes.
 */
if ( file_exists( TS_LMS_PLUGIN_DIR . 'includes/Admin/Settings.php' ) ) {
    require_once TS_LMS_PLUGIN_DIR . 'includes/Admin/Settings.php';
}
if ( file_exists( TS_LMS_PLUGIN_DIR . 'includes/Admin/LicenseValidator.php' ) ) {
    require_once TS_LMS_PLUGIN_DIR . 'includes/Admin/LicenseValidator.php';
}
if ( file_exists( TS_LMS_PLUGIN_DIR . 'includes/Setup/PageManager.php' ) ) {
    require_once TS_LMS_PLUGIN_DIR . 'includes/Setup/PageManager.php';
}
if ( file_exists( TS_LMS_PLUGIN_DIR . 'includes/Setup/Maintenance.php' ) ) {
    require_once TS_LMS_PLUGIN_DIR . 'includes/Setup/Maintenance.php';
}
if ( file_exists( TS_LMS_PLUGIN_DIR . 'includes/Setup/ProfileCompletion.php' ) ) {
    require_once TS_LMS_PLUGIN_DIR . 'includes/Setup/ProfileCompletion.php';
}
if ( file_exists( TS_LMS_PLUGIN_DIR . 'includes/Setup/NotificationHandler.php' ) ) {
    require_once TS_LMS_PLUGIN_DIR . 'includes/Setup/NotificationHandler.php';
}
if ( file_exists( TS_LMS_PLUGIN_DIR . 'includes/Setup/OnboardingWizard.php' ) ) {
    require_once TS_LMS_PLUGIN_DIR . 'includes/Setup/OnboardingWizard.php';
}


// Core boots here


/**
 * Activation hook.
 * Runs when the plugin is activated.
 */
function ts_lms_activate() {
    // Load Course Engine module
    require_once TS_LMS_PLUGIN_DIR . 'modules/courses/Autoloader.php';
    require_once TS_LMS_PLUGIN_DIR . 'modules/courses/Module.php';
    
    // Install Course Engine module
    \TS_LMS\Modules\Courses\Module::install();
    
    // Load and install Subscriptions module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/subscriptions/Module.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/subscriptions/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/subscriptions/Module.php';
        \TS_LMS\Modules\Subscriptions\Autoloader::register();
        \TS_LMS\Modules\Subscriptions\Module::install();
    }
    
    // Load and install Quiz Engine module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/quizzes/Autoloader.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/quizzes/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/quizzes/Module.php';
        \TS_LMS\Modules\Quizzes\Module::install();
    }

    // Load and install AI Studio module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/ai-studio/Autoloader.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/ai-studio/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/ai-studio/Module.php';
        \TS_LMS\Modules\AIStudio\Autoloader::register();
        \TS_LMS\Modules\AIStudio\Module::install();
    }
    

    
    // Load and install Reports module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/reports/Autoloader.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/reports/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/reports/Module.php';
        \TS_LMS\Modules\Reports\Autoloader::register();
        \TS_LMS\Modules\Reports\Module::install();
    }
    
    // Load and install Auth module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/auth/Autoloader.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/auth/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/auth/Module.php';
        \TS_LMS\Modules\Auth\Module::install();
    }
    
    // Load and install Migration module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/migration/Autoloader.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/migration/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/migration/Module.php';
        \TS_LMS\Modules\Migration\Autoloader::register();
        \TS_LMS\Modules\Migration\Module::install();
    }

    
    // Create required pages
    if ( class_exists( '\TS_LMS\Setup\PageManager' ) ) {
        \TS_LMS\Setup\PageManager::instance()->create_pages();
    }

    // Add activation tasks here (e.g., create database tables, set default options)
    add_option( 'ts_lms_activated', true );
    
    // Set flag for onboarding wizard (only if not already completed)
    if ( ! get_option( 'ts_lms_wizard_completed' ) ) {
        set_transient( 'ts_lms_show_wizard', true, 30 );
    }
    
    flush_rewrite_rules();

}
register_activation_hook( __FILE__, 'ts_lms_activate' );

/**
 * Deactivation hook.
 * Runs when the plugin is deactivated.
 */
function ts_lms_deactivate() {
    // Add deactivation tasks here (e.g., cleanup temporary data)
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'ts_lms_deactivate' );

/**
 * Initialize the plugin.
 */
function ts_lms_init() {
    // Load text domain for translations
    load_plugin_textdomain( 'ts-lms', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    
    // Load Course Engine module
    require_once TS_LMS_PLUGIN_DIR . 'modules/courses/Autoloader.php';
    require_once TS_LMS_PLUGIN_DIR . 'modules/courses/Module.php';
    
    // Initialize Course Engine module
    \TS_LMS\Modules\Courses\Module::instance();
    
    // Load Subscriptions module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/subscriptions/Autoloader.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/subscriptions/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/subscriptions/Module.php';
        
        // Register autoloader
        \TS_LMS\Modules\Subscriptions\Autoloader::register();
        
        // Initialize Subscriptions module
        \TS_LMS\Modules\Subscriptions\Module::instance();
    }
    
    // Load Quiz Engine module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/quizzes/Autoloader.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/quizzes/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/quizzes/Module.php';
        
        // Initialize Quiz Engine module
        \TS_LMS\Modules\Quizzes\Module::instance();
    }

    // Load AI Studio module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/ai-studio/Autoloader.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/ai-studio/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/ai-studio/Module.php';
        
        // Register autoloader
        \TS_LMS\Modules\AIStudio\Autoloader::register();
        
        // Initialize AI Studio module
        \TS_LMS\Modules\AIStudio\Module::instance();
    }
    
    // Load Reports module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/reports/Autoloader.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/reports/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/reports/Module.php';
        
        // Register autoloader
        \TS_LMS\Modules\Reports\Autoloader::register();
        
        // Initialize Reports module
        \TS_LMS\Modules\Reports\Module::instance();
    }



// Load Auth module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/auth/Autoloader.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/auth/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/auth/Module.php';
        
        // Initialize Auth module
        \TS_LMS\Modules\Auth\Module::instance();
    }

    // Load Migration module
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/migration/Autoloader.php' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/migration/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/migration/Module.php';
        
        // Register autoloader
        \TS_LMS\Modules\Migration\Autoloader::register();
        
        // Initialize Migration module
        \TS_LMS\Modules\Migration\Module::instance();
    }


    // Load Elementor module (if Elementor is active)
    if ( file_exists( TS_LMS_PLUGIN_DIR . 'modules/elementor/Autoloader.php' ) 
         && did_action( 'elementor/loaded' ) ) {
        require_once TS_LMS_PLUGIN_DIR . 'modules/elementor/Autoloader.php';
        require_once TS_LMS_PLUGIN_DIR . 'modules/elementor/Module.php';
        
        // Initialize Elementor module
        \TS_LMS\Modules\Elementor\Module::instance();
    }

    // Initialize Maintenance Mode
    if ( class_exists( '\TS_LMS\Setup\Maintenance' ) ) {
        \TS_LMS\Setup\Maintenance::instance();
    }

    // Initialize Profile Completion Bar
    if ( class_exists( '\TS_LMS\Setup\ProfileCompletion' ) ) {
        \TS_LMS\Setup\ProfileCompletion::instance();
    }

    // Initialize Notification Handler
    if ( class_exists( '\TS_LMS\Setup\NotificationHandler' ) ) {
        \TS_LMS\Setup\NotificationHandler::instance();
    }

    // Initialize Onboarding Wizard
    if ( class_exists( '\TS_LMS\Setup\OnboardingWizard' ) ) {
        \TS_LMS\Setup\OnboardingWizard::instance();
    }

}
add_action( 'plugins_loaded', 'ts_lms_init' );

/**
 * Enqueue frontend styles and scripts.
 */
function ts_lms_enqueue_scripts() {
    wp_enqueue_style( 'dashicons' );

    wp_enqueue_style(
        'ts-lms-style',
        TS_LMS_PLUGIN_URL . 'assets/css/style.css',
        array(),
        TS_LMS_VERSION
    );

    wp_enqueue_script(
        'ts-lms-script',
        TS_LMS_PLUGIN_URL . 'assets/js/script.js',
        array( 'jquery' ),
        TS_LMS_VERSION,
        true
    );

    // Localize script for AJAX
    wp_localize_script( 'ts-lms-script', 'ts_lms_ajax', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'ts_lms_nonce' ),
    ) );
}
add_action( 'wp_enqueue_scripts', 'ts_lms_enqueue_scripts' );

/**
 * Inject dynamic CSS variables into head.
 */
function ts_lms_inject_dynamic_colors() {
    $settings = get_option( 'ts_lms_settings', array() );
    $primary       = isset( $settings['primary_color'] ) ? $settings['primary_color'] : '#0077B5';
    $primary_hover = isset( $settings['primary_hover_color'] ) ? $settings['primary_hover_color'] : '#005E8F';
    $text          = isset( $settings['text_color'] ) ? $settings['text_color'] : '#374151';
    $gray          = isset( $settings['gray_color'] ) ? $settings['gray_color'] : '#f3f4f6';
    $btn_bg        = isset( $settings['button_color'] ) ? $settings['button_color'] : '#0077B5';
    $btn_hover     = isset( $settings['button_hover_color'] ) ? $settings['button_hover_color'] : '#005E8F';
    $btn_text      = isset( $settings['button_text_color'] ) ? $settings['button_text_color'] : '#ffffff';
    $body_bg       = isset( $settings['body_bg_color'] ) ? $settings['body_bg_color'] : '#ffffff';
    $icon_color    = isset( $settings['icon_color'] ) ? $settings['icon_color'] : '#0077B5';

    ?>
    <style id="ts-lms-dynamic-colors">
        :root {
            --ts-primary: <?php echo esc_attr( $primary ); ?>;
            --ts-primary-hover: <?php echo esc_attr( $primary_hover ); ?>;
            --ts-text: <?php echo esc_attr( $text ); ?>;
            --ts-gray: <?php echo esc_attr( $gray ); ?>;
            --ts-btn-bg: <?php echo esc_attr( $btn_bg ); ?>;
            --ts-btn-hover-bg: <?php echo esc_attr( $btn_hover ); ?>;
            --ts-btn-text: <?php echo esc_attr( $btn_text ); ?>;
            --ts-bg-body: <?php echo esc_attr( $body_bg ); ?>;
            --ts-icon-color: <?php echo esc_attr( $icon_color ); ?>;
            
            /* Legacy/Alias mappings for various templates */
            --plyr-color-main: <?php echo esc_attr( $primary ); ?>;
            --ts-secondary: <?php echo esc_attr( $text ); ?>;
            --ts-bg-light: <?php echo esc_attr( $gray ); ?>;
        }
        <?php if ( is_singular( array( 'ts_course', 'ts_lesson', 'ts_quiz', 'ts_assignment' ) ) ) : ?>
        body { background-color: var(--ts-bg-body) !important; }
        <?php endif; ?>
    </style>
    <?php
}
add_action( 'wp_head', 'ts_lms_inject_dynamic_colors' );

/**
 * Inject dynamic CSS variables into Admin head.
 */
function ts_lms_admin_inject_dynamic_colors() {
    $screen = get_current_screen();
    // Only inject on our plugin pages
    if ( ! $screen || strpos( $screen->id, 'ts-lms' ) === false ) {
        return;
    }

    $settings = get_option( 'ts_lms_settings', array() );
    $primary       = isset( $settings['primary_color'] ) ? $settings['primary_color'] : '#0077B5';
    $btn_bg        = isset( $settings['button_color'] ) ? $settings['button_color'] : '#0077B5';
    $btn_hover     = isset( $settings['button_hover_color'] ) ? $settings['button_hover_color'] : '#005E8F';
    $btn_text      = isset( $settings['button_text_color'] ) ? $settings['button_text_color'] : '#ffffff';
    $icon_color    = isset( $settings['icon_color'] ) ? $settings['icon_color'] : '#0077B5';

    ?>
    <style id="ts-lms-admin-dynamic-colors">
        :root {
            --ts-primary: <?php echo esc_attr( $primary ); ?>;
            --ts-btn-bg: <?php echo esc_attr( $btn_bg ); ?>;
            --ts-btn-hover-bg: <?php echo esc_attr( $btn_hover ); ?>;
            --ts-btn-text: <?php echo esc_attr( $btn_text ); ?>;
            --ts-icon-color: <?php echo esc_attr( $icon_color ); ?>;
        }
        /* Apply primary color to common admin elements if needed */
        .ts-lms-redesign-wrap .button-primary,
        .ts-lms-settings-header .button-save,
        .ts-lms-redesign-nav .nav-item.active {
            background-color: var(--ts-primary) !important;
            border-color: var(--ts-primary) !important;
        }
        .ts-lms-stat-icon span,
        .ts-dashboard-section .dashicons {
            color: var(--ts-icon-color) !important;
        }
    </style>
    <?php
}
add_action( 'admin_head', 'ts_lms_admin_inject_dynamic_colors' );

/**
 * Enqueue admin styles and scripts.
 */
function ts_lms_admin_enqueue_scripts( $hook ) {
    // Only load on plugin admin pages
    if ( strpos( $hook, 'ts-lms' ) === false ) {
        return;
    }

    wp_enqueue_style(
        'ts-lms-admin-style',
        TS_LMS_PLUGIN_URL . 'assets/css/admin-style.css',
        array(),
        TS_LMS_VERSION
    );

    wp_enqueue_style(
        'ts-lms-admin-redesign',
        TS_LMS_PLUGIN_URL . 'assets/css/admin-redesign.css',
        array(),
        time()
    );

    wp_enqueue_style(
        'ts-lms-admin-options',
        TS_LMS_PLUGIN_URL . 'assets/css/admin-course-editor-options.css',
        array(),
        time()
    );

    wp_enqueue_script(
        'ts-lms-admin-script',
        TS_LMS_PLUGIN_URL . 'assets/js/admin-script.js',
        array( 'jquery' ),
        TS_LMS_VERSION,
        true
    );

    // AI Studio page assets (if needed)
}
add_action( 'admin_enqueue_scripts', 'ts_lms_admin_enqueue_scripts' );

/**
 * Initialize Admin specific tasks.
 */
function ts_lms_admin_bootstrap() {
    if ( is_admin() ) {
        if ( file_exists( TS_LMS_PLUGIN_DIR . 'includes/Admin/Menu.php' ) ) {
            require_once TS_LMS_PLUGIN_DIR . 'includes/Admin/Menu.php';
            \TS_LMS\Admin\Menu::init();
        }



        // Initialize Page Manager 
        if ( class_exists( '\TS_LMS\Setup\PageManager' ) ) {
            \TS_LMS\Setup\PageManager::instance();
            // Note: create_pages() should only be called manually or via activation
        }
        
        // Ensure Course Module is loaded before running installer
        // Throttle this check to once per hour to prevent performance issues
        $installer_check_key = 'ts_lms_installer_check_throttle';
        if ( ! get_transient( $installer_check_key ) ) {
            if ( class_exists( '\TS_LMS\Modules\Courses\Database\Installer' ) ) {
                $installed_version = get_option( 'ts_lms_courses_schema_version' );
                if ( $installed_version !== \TS_LMS\Modules\Courses\Database\Installer::SCHEMA_VERSION ) {
                    \TS_LMS\Modules\Courses\Database\Installer::install();
                }
            }
            // Set transient to prevent checking again for 1 hour
            set_transient( $installer_check_key, true, HOUR_IN_SECONDS );
        }
    }
}
add_action( 'init', 'ts_lms_admin_bootstrap' );

/**
 * Upgrade to Pro page callback.
 */
function ts_lms_upgrade_page() {
    ?>
    <div class="wrap">
        <h1><?php _e( 'Upgrade to Pro', 'ts-lms' ); ?></h1>
        <p><?php _e( 'Unlock advanced features with TS LMS Pro.', 'ts-lms' ); ?></p>
    </div>
    <?php
}

/**
 * Admin page callback.
 */
function ts_lms_admin_page() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <div class="ts-lms-dashboard">
            <div class="ts-lms-welcome">
                <h2><?php esc_html_e( 'Welcome to TS LMS', 'ts-lms' ); ?></h2>
                <p><?php esc_html_e( 'Thank you for using TS LMS! This is your Learning Management System dashboard.', 'ts-lms' ); ?></p>
            </div>
            <div class="ts-lms-cards">
                <div class="ts-lms-card">
                    <h3><?php esc_html_e( 'Quick Start', 'ts-lms' ); ?></h3>
                    <p><?php esc_html_e( 'Get started with TS LMS by configuring your settings.', 'ts-lms' ); ?></p>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-settings' ) ); ?>" class="button button-primary">
                        <?php esc_html_e( 'Go to Settings', 'ts-lms' ); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Settings page callback.
 */
function ts_lms_settings_page() {
    // Check user capabilities
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    // Save settings
    if ( isset( $_POST['ts_lms_save_settings'] ) && check_admin_referer( 'ts_lms_settings_nonce', 'ts_lms_nonce' ) ) {
        $enable_feature = isset( $_POST['ts_lms_enable_feature'] ) ? 1 : 0;
        update_option( 'ts_lms_enable_feature', $enable_feature );
        
        $custom_text = sanitize_text_field( $_POST['ts_lms_custom_text'] ?? '' );
        update_option( 'ts_lms_custom_text', $custom_text );
        
        echo '<div class="notice notice-success"><p>' . esc_html__( 'Settings saved successfully!', 'ts-lms' ) . '</p></div>';
    }

    $enable_feature = get_option( 'ts_lms_enable_feature', 0 );
    $custom_text = get_option( 'ts_lms_custom_text', '' );
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <form method="post" action="">
            <?php wp_nonce_field( 'ts_lms_settings_nonce', 'ts_lms_nonce' ); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="ts_lms_enable_feature"><?php esc_html_e( 'Enable Feature', 'ts-lms' ); ?></label>
                    </th>
                    <td>
                        <input type="checkbox" id="ts_lms_enable_feature" name="ts_lms_enable_feature" value="1" <?php checked( $enable_feature, 1 ); ?> />
                        <p class="description"><?php esc_html_e( 'Enable or disable the main feature.', 'ts-lms' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="ts_lms_custom_text"><?php esc_html_e( 'Custom Text', 'ts-lms' ); ?></label>
                    </th>
                    <td>
                        <input type="text" id="ts_lms_custom_text" name="ts_lms_custom_text" value="<?php echo esc_attr( $custom_text ); ?>" class="regular-text" />
                        <p class="description"><?php esc_html_e( 'Enter your custom text here.', 'ts-lms' ); ?></p>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="ts_lms_save_settings" class="button button-primary" value="<?php esc_attr_e( 'Save Settings', 'ts-lms' ); ?>" />
            </p>
        </form>
    </div>
    <?php
}

/**
 * Register a simple shortcode.
 */
function ts_lms_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'title' => __( 'TS LMS Content', 'ts-lms' ),
    ), $atts, 'ts_lms' );

    $output = '<div class="ts-lms-content">';
    $output .= '<h3>' . esc_html( $atts['title'] ) . '</h3>';
    $output .= '<p>' . esc_html__( 'This is content from the TS LMS plugin.', 'ts-lms' ) . '</p>';
    $output .= '</div>';

    return $output;
}
add_shortcode( 'ts_lms', 'ts_lms_shortcode' );

/**
 * Add plugin action links.
 */
function ts_lms_plugin_action_links( $links ) {
    $settings_link = '<a href="' . admin_url( 'admin.php?page=ts-lms-settings' ) . '">' . __( 'Settings', 'ts-lms' ) . '</a>';
    array_unshift( $links, $settings_link );
    return $links;
}
add_filter( 'plugin_action_links_' . TS_LMS_PLUGIN_BASENAME, 'ts_lms_plugin_action_links' );

/**
 * AJAX handler example.
 */
function ts_lms_ajax_handler() {
    // Verify nonce
    if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'ts_lms_nonce' ) ) {
        wp_send_json_error( array( 'message' => __( 'Security check failed.', 'ts-lms' ) ) );
    }

    // Process AJAX request
    $data = array(
        'message' => __( 'AJAX request successful!', 'ts-lms' ),
        'time'    => current_time( 'mysql' ),
    );

    wp_send_json_success( $data );
}
add_action( 'wp_ajax_ts_lms_action', 'ts_lms_ajax_handler' );
add_action( 'wp_ajax_nopriv_ts_lms_action', 'ts_lms_ajax_handler' );
