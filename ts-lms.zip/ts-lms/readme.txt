=== TS LMS ===
Contributors: Techsoulbd
Tags: lms, learning, education, courses, elearning, online-course, academy, tutor
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple and standard Learning Management System plugin for WordPress. Build and sell courses with ease.

== Description ==

TS LMS is a lightweight and easy-to-use Learning Management System plugin for WordPress. It provides essential LMS functionality to help you create and manage online courses with a professional touch.

Whether you're an individual instructor or a small academy, TS LMS gives you the tools to create engaging lessons, manage students, and monetize your content seamlessly.

= Key Features =
* **Intuitive Course Builder:** Create courses, topics, and lessons from a single screen.
* **Student & Instructor Dashboard:** Professional personal hub for every user.
* **WooCommerce Integration:** Sell your courses using any payment gateway supported by WooCommerce.
* **Quiz & Assignment System:** Test student knowledge with interactive quizzes.
* **Certificates:** Award students with customizable certificates upon course completion.
* **Zoom & Google Meet Integration:** Host live classes directly from your LMS.

= External Services =
This plugin relies on several external services to provide advanced functionality:
* **Zoom API:** Used for scheduling and hosting live video lessons. (Privacy Policy: https://zoom.us/privacy)
* **Google Calendar/Meet API:** Used for scheduling and conducting live meetings. (Privacy Policy: https://policies.google.com/privacy)
* **OpenAI API (Optional):** Used in the AI Studio for content generation and assistant features. (Privacy Policy: https://openai.com/policies/privacy-policy)
* **Social Auth (Google/Facebook/GitHub):** Used to provide quick login/registration options.

== Installation ==

1. Upload the `ts-lms` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to **TS LMS > Settings** to configure your core pages and payment options.
4. Start creating your first course from the **TS LMS > Courses** menu.

== Frequently Asked Questions ==

= Does it work with any theme? =
Yes! TS LMS is designed to be compatible with most modern WordPress themes.

= Can I sell courses for free? =
Absolutely. You can set the pricing model to 'Free' for any course.

= Is WooCommerce required? =
WooCommerce is required only if you want to sell paid courses. For free courses, it is not mandatory.

== Screenshots ==

1. **Course Builder Dashboard**: An intuitive interface to manage and organize your courses, topics, and lessons.
2. **Standard Course Grid**: Fully responsive course catalog displaying all your courses with professional cards.
3. **Advanced Learning Interface**: A distraction-free learning mode for students to focus on content.
4. **Interactive Quiz System**: Create multiple-type questions with instant grading and results.
5. **Student & Instructor Dashboard**: Personalized dashboard for users to track their progress and earnings.

== Shortcodes ==
* `[ts_lms_login]` - Display the custom, beautiful login form.
* `[ts_lms_register]` - Display the student registration form.
* `[ts_lms_dashboard]` - The main hub for students and instructors to see their courses and stats.
* `[ts_instructor_registration]` - A dedicated form for users to apply to become an instructor.
* `[ts_course_catalog]` - Showcase all your available courses in a grid layout.

== Changelog ==

= 1.0.0 =
* Initial public release.
* Added Course Builder.
* Added WooCommerce integration.
* Added Zoom & Google Meet support.
