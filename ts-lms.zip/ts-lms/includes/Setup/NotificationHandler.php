<?php
namespace TS_LMS\Setup;

/**
 * Notification Handler
 * 
 * Handles system-wide notifications (Email, On-Site, Push) 
 * while respecting user settings from the admin panel.
 */
class NotificationHandler {

    /**
     * Singleton instance.
     */
    private static $instance = null;

    /**
     * Get instance.
     */
    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Initialize hooks.
     */
    private function init_hooks() {
        // Enrollment Notifications
        add_action( 'ts_lms_student_enrolled', array( $this, 'handle_student_enrolled' ), 10, 2 );
        add_action( 'ts_lms_student_unenrolled', array( $this, 'handle_student_unenrolled' ), 10, 2 );
        
        // Course/Lesson Notifications
        add_action( 'ts_lms_course_completed', array( $this, 'handle_course_completed' ), 10, 2 );
        add_action( 'ts_lms_lesson_comment_posted', array( $this, 'handle_lesson_comment' ), 10, 3 );
        
        // Q&A and Announcements
        add_action( 'ts_lms_qa_answered', array( $this, 'handle_qa_answered' ), 10, 3 );
        add_action( 'ts_lms_announcement_posted', array( $this, 'handle_announcement_posted' ), 10, 2 );
        
        // Grading
        add_action( 'ts_lms_assignment_graded', array( $this, 'handle_assignment_graded' ), 10, 3 );
        add_action( 'ts_lms_quiz_feedback_submitted', array( $this, 'handle_quiz_feedback' ), 10, 3 );

        // Admin Specific Hooks
        add_action( 'user_register', array( $this, 'handle_new_user' ) );
        add_action( 'ts_lms_course_created', array( $this, 'handle_course_created' ), 10, 2 );
        add_action( 'ts_lms_course_updated', array( $this, 'handle_course_updated' ), 10, 2 );

        // 2FA
        add_action( 'ts_lms_send_2fa_email', array( $this, 'send_2fa_email' ), 10, 2 );

        // Custom Email Sender Filters
        add_filter( 'wp_mail_from', array( $this, 'set_mail_from_email' ) );
        add_filter( 'wp_mail_from_name', array( $this, 'set_mail_from_name' ) );
        add_filter( 'wp_mail_content_type', array( $this, 'set_mail_content_type' ) );
    }

    /**
     * Set mail from email from settings.
     */
    public function set_mail_from_email( $email ) {
        $settings = \TS_LMS\Admin\Settings::get_settings();
        return ! empty( $settings['email_sender_email'] ) ? $settings['email_sender_email'] : $email;
    }

    /**
     * Set mail from name from settings.
     */
    public function set_mail_from_name( $name ) {
        $settings = \TS_LMS\Admin\Settings::get_settings();
        return ! empty( $settings['email_sender_name'] ) ? $settings['email_sender_name'] : $name;
    }

    /**
     * Set mail content type to HTML.
     */
    public function set_mail_content_type() {
        return "text/html";
    }

    /**
     * Handle New User Registration (Admin Notified).
     */
    public function handle_new_user( $user_id ) {
        $user = get_userdata( $user_id );
        $role = ! empty( $user->roles ) ? $user->roles[0] : 'student';

        // Welcome Email to Student
        if ( $role === 'student' && ts_lms_is_notification_enabled( 'welcome_email', 'email', 'student' ) ) {
            $this->send_email( $user_id, 'student_welcome' );
        }

        // Notify Admin for Student
        if ( $role === 'student' && ts_lms_is_notification_enabled( 'new_student', 'email', 'admin' ) ) {
            $this->send_email_to_admin( 'admin_new_student', $user_id );
        }

        // Notify Admin for Instructor
        if ( $role === 'instructor' && ts_lms_is_notification_enabled( 'new_instructor', 'email', 'admin' ) ) {
            $this->send_email_to_admin( 'admin_new_instructor', $user_id );
        }
    }

    /**
     * Send 2FA verification email.
     */
    public function send_2fa_email( $user_id, $code ) {
        $this->send_email( $user_id, 'two_factor_code', 0, 0, array( 'code' => $code ) );
    }

    /**
     * Handle Course Created (Admin Notified).
     */
    public function handle_course_created( $course_id, $data ) {
        if ( ts_lms_is_notification_enabled( 'course_for_review', 'email', 'admin' ) ) {
            $this->send_email_to_admin( 'admin_course_created', $course_id );
        }
    }

    /**
     * Handle Course Updated (Admin Notified).
     */
    public function handle_course_updated( $course_id, $data ) {
        if ( ts_lms_is_notification_enabled( 'course_updated', 'email', 'admin' ) ) {
            $this->send_email_to_admin( 'admin_course_updated', $course_id );
        }
    }

    /**
     * Handle Course Completed.
     */
    public function handle_course_completed( $course_id, $user_id ) {
        // 1. Email to Student
        if ( ts_lms_is_notification_enabled( 'course_completed', 'email', 'student' ) ) {
            $this->send_email( $user_id, 'student_course_completed', $course_id );
        }

        // 2. Email to Instructor
        if ( ts_lms_is_notification_enabled( 'student_completed', 'email', 'instructor' ) ) {
            $course = get_post( $course_id );
            $this->send_email( $course->post_author, 'instructor_student_completed', $course_id, $user_id );
        }

        // 3. Email to Admin
        if ( ts_lms_is_notification_enabled( 'order_status_updated', 'email', 'admin' ) ) {
             // Example mapping, could use a more specific admin key if added to settings
        }

        // 4. On-Site & Push
        $this->trigger_onsite_push( 'student_completed', $user_id, array(
            'course_id' => $course_id,
            'title'     => __( 'Congratulations! You completed the course.', 'ts-lms' )
        ) );
    }

    /**
     * Handle Lesson Comment.
     */
    public function handle_lesson_comment( $comment_id, $lesson_id, $user_id ) {
        // Email to Instructor
        if ( ts_lms_is_notification_enabled( 'lesson_comment_inst', 'email', 'instructor' ) ) {
            $lesson = get_post( $lesson_id );
            $this->send_email( $lesson->post_author, 'instructor_lesson_comment', $lesson_id, $comment_id );
        }
    }

    /**
     * Handle Q&A Answered.
     */
    public function handle_qa_answered( $user_id, $question_id, $answer_id ) {
        // Email to Student
        if ( ts_lms_is_notification_enabled( 'qa_answered', 'email', 'student' ) ) {
            $this->send_email( $user_id, 'student_qa_answered', $question_id, $answer_id );
        }
    }

    /**
     * Handle Announcement Posted.
     */
    public function handle_announcement_posted( $announcement_id, $course_id ) {
        // Get all enrolled students
        global $wpdb;
        $table = $wpdb->prefix . 'ts_course_enrollments';
        $students = $wpdb->get_col( $wpdb->prepare(
            "SELECT user_id FROM $table WHERE course_id = %d AND status = 'active'",
            $course_id
        ) );

        if ( ! empty( $students ) ) {
            foreach ( $students as $student_id ) {
                // Email to Student
                if ( ts_lms_is_notification_enabled( 'announcement_posted', 'email', 'student' ) ) {
                    $this->send_email( $student_id, 'student_new_announcement', $announcement_id, $course_id );
                }
            }
        }
    }

    /**
     * Handle Quiz Feedback.
     */
    public function handle_quiz_feedback( $user_id, $quiz_id, $attempt_id ) {
        // Email to Student
        if ( ts_lms_is_notification_enabled( 'quiz_feedback', 'email', 'student' ) ) {
            $this->send_email( $user_id, 'student_quiz_feedback', $quiz_id, $attempt_id );
        }
    }

    /**
     * Handle Student Enrolled.
     */
    public function handle_student_enrolled( $course_id, $user_id ) {
        // 1. Email to Student (Welcome/Enrollment)
        if ( ts_lms_is_notification_enabled( 'welcome_email', 'email', 'student' ) ) {
            $this->send_email( $user_id, 'student_enrollment', $course_id );
        }

        // 2. Email to Instructor
        if ( ts_lms_is_notification_enabled( 'student_enrolled', 'email', 'instructor' ) ) {
            $course = get_post( $course_id );
            $instructor_id = $course->post_author;
            $this->send_email( $instructor_id, 'instructor_new_student', $course_id, $user_id );
        }

        // 3. Email to Admin
        if ( ts_lms_is_notification_enabled( 'new_student', 'email', 'admin' ) ) {
            $this->send_email_to_admin( 'admin_new_student', $user_id, $course_id );
        }

        // 4. On-Site & Push for Student
        $this->trigger_onsite_push( 'course_enrolled', $user_id, array(
            'course_id' => $course_id,
            'title'     => __( 'You have enrolled in a new course!', 'ts-lms' )
        ) );
    }

    /**
     * Handle Student Unenrolled.
     */
    public function handle_student_unenrolled( $course_id, $user_id ) {
        // Email to Student
        if ( ts_lms_is_notification_enabled( 'removed_from_course', 'email', 'student' ) ) {
            $this->send_email( $user_id, 'student_unenrolled', $course_id );
        }

        // On-Site & Push
        $this->trigger_onsite_push( 'removed_from_course', $user_id, array(
            'course_id' => $course_id,
            'title'     => __( 'You have been removed from a course.', 'ts-lms' )
        ) );
    }

    /**
     * Handle Assignment Graded.
     */
    public function handle_assignment_graded( $user_id, $assignment_id, $grade ) {
        // Email to Student
        if ( ts_lms_is_notification_enabled( 'assignment_graded', 'email', 'student' ) ) {
            $this->send_email( $user_id, 'assignment_graded', $assignment_id, null, array( 'grade' => $grade ) );
        }

        // On-Site & Push
        $this->trigger_onsite_push( 'assignment_graded', $user_id, array(
            'assignment_id' => $assignment_id,
            'grade'         => $grade,
            'title'         => __( 'Your assignment has been graded!', 'ts-lms' )
        ) );
    }

    /**
     * Trigger On-Site and Push Notifications.
     */
    private function trigger_onsite_push( $item_id, $user_id, $data ) {
        // Check On-Site
        if ( ts_lms_is_notification_enabled( $item_id, 'onsite' ) ) {
            $this->save_onsite_notification( $user_id, $item_id, $data );
        }

        // Check Push
        if ( ts_lms_is_notification_enabled( $item_id, 'push' ) ) {
            $this->send_push_notification( $user_id, $item_id, $data );
        }
    }

    /**
     * Save notification to database for "On-Site" display.
     */
    private function save_onsite_notification( $user_id, $item_id, $data ) {
        global $wpdb;
        $table = $wpdb->prefix . 'ts_lms_notifications';
        
        // Ensure table exists
        $wpdb->insert( $table, array(
            'user_id'    => $user_id,
            'item_id'    => $item_id,
            'data'       => json_encode( $data ),
            'is_read'    => 0,
            'created_at' => current_time( 'mysql' )
        ) );
    }

    /**
     * Dummy Push Notification sender.
     */
    private function send_push_notification( $user_id, $item_id, $data ) {
        // Integrations like OneSignal or Firebase would go here.
        do_action( 'ts_lms_send_push_notification', $user_id, $item_id, $data );
    }

    /**
     * Helper to send email to site admin.
     */
    private function send_email_to_admin( $template_type, $object_id = 0, $secondary_id = 0 ) {
        $admin_email = get_option( 'admin_email' );
        $admin_user = get_user_by( 'email', $admin_email );
        
        if ( $admin_user ) {
            $this->send_email( $admin_user->ID, $template_type, $object_id, $secondary_id );
        } else {
            // Fallback for wp_mail if admin user not found as student/instructor
            // (Though centralized send_email needs a user_id for display_name etc, we skip it here for simplicity)
        }
    }

    /**
     * Centralized Email sender.
     */
    private function send_email( $to_user_id, $template_type, $object_id = 0, $secondary_id = 0, $extra_data = array() ) {
        $user = get_userdata( $to_user_id );
        if ( ! $user ) return;

        $settings = \TS_LMS\Admin\Settings::get_settings();
        $base_color = ! empty( $settings['email_base_color'] ) ? $settings['email_base_color'] : '#6366f1';
        $bg_color   = ! empty( $settings['email_bg_color'] ) ? $settings['email_bg_color'] : '#f8fafc';
        $logo       = ! empty( $settings['email_logo'] ) ? $settings['email_logo'] : '';
        $footer     = ! empty( $settings['email_footer_text'] ) ? $settings['email_footer_text'] : '';

        // Template Mapping logic
        $subject = __( 'New Notification from ', 'ts-lms' ) . get_bloginfo( 'name' );
        $content = __( 'You have a new notification. Please check your dashboard for details.', 'ts-lms' );

        switch ( $template_type ) {
            case 'two_factor_code':
                $subject = __( 'Your Verification Code', 'ts-lms' );
                $content = sprintf( __( 'Hi %s,', 'ts-lms' ), $user->display_name ) . '<br><br>';
                $content .= __( 'You are trying to log in to your account. Please use the verification code below to complete your login:', 'ts-lms' ) . '<br><br>';
                $content .= '<div style="text-align: center; margin: 30px 0;">
                    <span style="font-size: 32px; font-weight: bold; letter-spacing: 5px; color: ' . esc_attr( $base_color ) . '; padding: 15px 30px; background: #f1f5f9; border-radius: 8px;">' . $extra_data['code'] . '</span>
                </div>';
                $content .= __( 'This code will expire in 10 minutes. If you did not attempt to log in, please secure your account.', 'ts-lms' );
                break;
            case 'student_welcome':
                $subject = sprintf( __( 'Welcome to %s', 'ts-lms' ), get_bloginfo( 'name' ) );
                $dashboard_url = home_url( \TS_LMS\Admin\Settings::get_setting( 'dashboard_page_url', '/dashboard/' ) );
                
                $content = sprintf( __( 'Hi %s,', 'ts-lms' ), $user->display_name ) . '<br><br>';
                $content .= __( 'Welcome to our platform! We are excited to have you on board. You can now start exploring your courses and dashboard.', 'ts-lms' );
                
                // Add verification note if pending
                $status = get_user_meta( $to_user_id, 'ts_lms_user_status', true );
                if ( $status === 'pending' ) {
                    $content .= '<br><br><strong>' . __( 'Please remember to verify your email address to unlock all features.', 'ts-lms' ) . '</strong>';
                }

                $content .= '<br><br><div style="text-align: center; margin-top: 20px;">
                    <a href="' . esc_url( $dashboard_url ) . '" style="background-color: ' . esc_attr( $base_color ) . '; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">' . __( 'Go to Dashboard', 'ts-lms' ) . '</a>
                </div>';
                break;
            case 'student_enrollment':
                $course = get_post( $object_id );
                $subject = sprintf( __( 'Welcome to %s', 'ts-lms' ), $course->post_title );
                $content = sprintf( __( 'Hi %s, you have successfully enrolled in the course: %s. You can start learning now!', 'ts-lms' ), $user->display_name, $course->post_title );
                break;
            case 'instructor_new_student':
                $course = get_post( $object_id );
                $student = get_userdata( $secondary_id );
                $subject = __( 'New Student Enrolled', 'ts-lms' );
                $content = sprintf( __( 'Hi, a new student (%s) has enrolled in your course: %s.', 'ts-lms' ), $student->display_name, $course->post_title );
                break;
            case 'assignment_graded':
                $subject = __( 'Assignment Graded', 'ts-lms' );
                $content = sprintf( __( 'Your assignment has been graded. Your grade is: %s', 'ts-lms' ), $extra_data['grade'] ?? 'N/A' );
                break;
            case 'student_course_completed':
                $course = get_post( $object_id );
                $subject = __( 'Congratulations on completing the course!', 'ts-lms' );
                $content = sprintf( __( 'Hi %s, congratulations on completing the course: %s!', 'ts-lms' ), $user->display_name, $course->post_title );
                break;
            case 'student_unenrolled':
                $course = get_post( $object_id );
                $subject = __( 'Course Access Removed', 'ts-lms' );
                $content = sprintf( __( 'Hi %s, you have been unenrolled from the course: %s. If this was a mistake, please contact support.', 'ts-lms' ), $user->display_name, $course->post_title );
                break;
            case 'instructor_lesson_comment':
                $lesson = get_post( $object_id );
                $subject = __( 'New Comment on your Lesson', 'ts-lms' );
                $content = sprintf( __( 'Hi, a new comment has been posted on your lesson: %s.', 'ts-lms' ), $lesson->post_title );
                break;
            case 'student_qa_answered':
                $question = get_post( $object_id );
                $subject = __( 'Your Question has been Answered', 'ts-lms' );
                $content = sprintf( __( 'Hi %s, your question on the course has been answered. Click below to view the response.', 'ts-lms' ), $user->display_name );
                break;
            case 'student_new_announcement':
                $announcement = get_post( $object_id );
                $subject = __( 'New Course Announcement', 'ts-lms' );
                $content = sprintf( __( 'Hi %s, a new announcement has been posted: %s', 'ts-lms' ), $user->display_name, $announcement->post_title );
                break;
            case 'student_quiz_feedback':
                $quiz = get_post( $object_id );
                $subject = __( 'Quiz Feedback Available', 'ts-lms' );
                $content = sprintf( __( 'Hi %s, your instructor has provided feedback on your recent quiz attempt for: %s.', 'ts-lms' ), $user->display_name, $quiz->post_title );
                break;
            case 'admin_new_student':
                $student = get_userdata( $object_id );
                $subject = __( 'New Student Registration', 'ts-lms' );
                $content = sprintf( __( 'A new student has registered on your platform: %s (%s).', 'ts-lms' ), $student->display_name, $student->user_email );
                break;
            case 'admin_new_instructor':
                $inst = get_userdata( $object_id );
                $subject = __( 'New Instructor Signup', 'ts-lms' );
                $content = sprintf( __( 'A new instructor has signed up: %s (%s).', 'ts-lms' ), $inst->display_name, $inst->user_email );
                break;
            case 'admin_course_created':
                $course = get_post( $object_id );
                $subject = __( 'New Course Submitted', 'ts-lms' );
                $content = sprintf( __( 'A new course has been created/submitted for review: %s.', 'ts-lms' ), $course->post_title );
                break;
            case 'admin_course_updated':
                $course = get_post( $object_id );
                $subject = __( 'Course Updated', 'ts-lms' );
                $content = sprintf( __( 'A course has been updated: %s.', 'ts-lms' ), $course->post_title );
                break;
            // Add more cases as needed...
        }

        // Wrap in HTML template
        ob_start();
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <style>
                body { background-color: <?php echo esc_attr($bg_color); ?>; font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 0; padding: 40px 0; }
                .email-container { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
                .email-header { padding: 40px 30px; text-align: center; background: #ffffff; border-bottom: 1px solid #f1f5f9; }
                .email-body { padding: 40px; color: #1e293b; line-height: 1.6; font-size: 16px; }
                .email-footer { padding: 30px 40px; background: #f8fafc; text-align: center; color: #64748b; font-size: 13px; border-top: 1px solid #f1f5f9; }
                img.logo { max-width: 180px; height: auto; }
                h1, h2, h3 { color: #0f172a; margin-top: 0; }
                .content-box { background: #f1f5f9; padding: 20px; border-radius: 8px; margin-top: 20px; }
            </style>
        </head>
        <body>
            <div class="email-container">
                <?php if ( $logo ) : ?>
                <div class="email-header">
                    <img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" class="logo">
                </div>
                <?php else : ?>
                <div class="email-header">
                    <h2 style="margin:0; color: <?php echo esc_attr($base_color); ?>"><?php echo esc_html(get_bloginfo('name')); ?></h2>
                </div>
                <?php endif; ?>
                <div class="email-body">
                    <?php echo wpautop( $content ); ?>
                </div>
                <div class="email-footer">
                    <div style="margin-bottom: 15px;">
                        <?php echo wp_kses_post( $footer ); ?>
                    </div>
                    <div style="font-size: 11px; opacity: 0.7;">
                        <?php printf( __( 'This email was sent because you registered on %s.', 'ts-lms' ), get_bloginfo('name') ); ?>
                    </div>
                </div>
            </div>
        </body>
        </html>
        <?php
        $message = ob_get_clean();

        wp_mail( $user->user_email, $subject, $message );
    }
}
