<?php
/**
 * Sample Data Importer Class
 *
 * Handles importing sample/demo content for the onboarding wizard.
 *
 * @package TS_LMS\Setup
 * @since 1.0.0
 */

namespace TS_LMS\Setup;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SampleDataImporter {

    /**
     * Import all sample data.
     *
     * @return array
     */
    public function import() {
        $results = array(
            'success' => true,
            'courses' => array(),
            'lessons' => array(),
            'quizzes' => array(),
            'certificates' => array(),
            'message' => '',
        );

        try {
            // Import courses
            $courses = $this->import_courses();
            $results['courses'] = $courses;

            // Import lessons
            $lessons = $this->import_lessons( $courses );
            $results['lessons'] = $lessons;

            // Import quizzes
            $quizzes = $this->import_quizzes( $courses );
            $results['quizzes'] = $quizzes;

            // Import certificate template
            $certificate = $this->import_certificate_template();
            $results['certificates'] = array( $certificate );

            $results['message'] = sprintf(
                __( 'Successfully imported %d courses, %d lessons, %d quizzes, and %d certificate template.', 'ts-lms' ),
                count( $courses ),
                count( $lessons ),
                count( $quizzes ),
                1
            );

        } catch ( \Exception $e ) {
            $results['success'] = false;
            $results['message'] = $e->getMessage();
        }

        return $results;
    }

    /**
     * Import sample courses.
     *
     * @return array Course IDs
     */
    private function import_courses() {
        $courses_data = array(
            array(
                'title' => __( 'Introduction to Web Development', 'ts-lms' ),
                'content' => __( 'Learn the fundamentals of web development including HTML, CSS, and JavaScript. This comprehensive course will take you from beginner to building your first website.', 'ts-lms' ),
                'excerpt' => __( 'Master the basics of HTML, CSS, and JavaScript', 'ts-lms' ),
                'price' => '49.99',
                'difficulty' => 'beginner',
            ),
            array(
                'title' => __( 'Digital Marketing Essentials', 'ts-lms' ),
                'content' => __( 'Discover the power of digital marketing! Learn SEO, social media marketing, content marketing, and email campaigns to grow your business online.', 'ts-lms' ),
                'excerpt' => __( 'Complete guide to digital marketing strategies', 'ts-lms' ),
                'price' => '39.99',
                'difficulty' => 'intermediate',
            ),
            array(
                'title' => __( 'Graphic Design Fundamentals', 'ts-lms' ),
                'content' => __( 'Unlock your creative potential with this graphic design course. Learn design principles, color theory, typography, and industry-standard tools.', 'ts-lms' ),
                'excerpt' => __( 'Learn professional graphic design from scratch', 'ts-lms' ),
                'price' => '59.99',
                'difficulty' => 'beginner',
            ),
        );

        $course_ids = array();

        foreach ( $courses_data as $course_data ) {
            $course_id = wp_insert_post( array(
                'post_title'   => $course_data['title'],
                'post_content' => $course_data['content'],
                'post_excerpt' => $course_data['excerpt'],
                'post_status'  => 'publish',
                'post_type'    => 'ts_course',
                'post_author'  => get_current_user_id(),
            ) );

            if ( ! is_wp_error( $course_id ) ) {
                // Set course meta
                update_post_meta( $course_id, '_ts_course_price', $course_data['price'] );
                update_post_meta( $course_id, '_ts_course_difficulty', $course_data['difficulty'] );
                update_post_meta( $course_id, '_ts_course_duration', '8 weeks' );
                update_post_meta( $course_id, '_ts_course_max_students', '100' );
                update_post_meta( $course_id, '_ts_is_free', '0' );

                $course_ids[] = $course_id;
            }
        }

        return $course_ids;
    }

    /**
     * Import sample lessons.
     *
     * @param array $course_ids Course IDs to attach lessons to.
     * @return array Lesson IDs
     */
    private function import_lessons( $course_ids ) {
        if ( empty( $course_ids ) ) {
            return array();
        }

        $lessons_data = array(
            array(
                'course_index' => 0,
                'title' => __( 'HTML Basics', 'ts-lms' ),
                'content' => __( 'In this lesson, you will learn the fundamentals of HTML including tags, elements, attributes, and document structure. We\'ll cover headings, paragraphs, links, images, and lists.', 'ts-lms' ),
                'video_url' => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
            ),
            array(
                'course_index' => 0,
                'title' => __( 'CSS Fundamentals', 'ts-lms' ),
                'content' => __( 'Discover how to style your web pages with CSS. Learn about selectors, properties, values, the box model, and responsive design principles.', 'ts-lms' ),
                'video_url' => '',
            ),
            array(
                'course_index' => 1,
                'title' => __( 'SEO Basics', 'ts-lms' ),
                'content' => __( 'Learn the fundamentals of Search Engine Optimization. Understand how search engines work, keyword research, on-page SEO, and link building strategies.', 'ts-lms' ),
                'video_url' => '',
            ),
            array(
                'course_index' => 1,
                'title' => __( 'Social Media Marketing', 'ts-lms' ),
                'content' => __( 'Master social media marketing across platforms like Facebook, Instagram, Twitter, and LinkedIn. Learn content strategy, engagement tactics, and analytics.', 'ts-lms' ),
                'video_url' => '',
            ),
            array(
                'course_index' => 2,
                'title' => __( 'Design Principles', 'ts-lms' ),
                'content' => __( 'Explore the fundamental principles of design including balance, contrast, emphasis, movement, pattern, rhythm, and unity. Apply these principles to create stunning visuals.', 'ts-lms' ),
                'video_url' => '',
            ),
        );

        $lesson_ids = array();

        foreach ( $lessons_data as $index => $lesson_data ) {
            $course_id = $course_ids[ $lesson_data['course_index'] ] ?? $course_ids[0];

            $lesson_id = wp_insert_post( array(
                'post_title'   => $lesson_data['title'],
                'post_content' => $lesson_data['content'],
                'post_status'  => 'publish',
                'post_type'    => 'ts_lesson',
                'post_author'  => get_current_user_id(),
            ) );

            if ( ! is_wp_error( $lesson_id ) ) {
                // Link lesson to course
                update_post_meta( $lesson_id, '_ts_lesson_course', $course_id );
                
                if ( ! empty( $lesson_data['video_url'] ) ) {
                    update_post_meta( $lesson_id, '_ts_lesson_video_url', $lesson_data['video_url'] );
                }

                // Add lesson to course curriculum
                $curriculum = get_post_meta( $course_id, '_ts_course_curriculum', true );
                if ( ! is_array( $curriculum ) ) {
                    $curriculum = array();
                }
                $curriculum[] = array(
                    'id' => $lesson_id,
                    'type' => 'lesson',
                    'order' => $index + 1,
                );
                update_post_meta( $course_id, '_ts_course_curriculum', $curriculum );

                $lesson_ids[] = $lesson_id;
            }
        }

        return $lesson_ids;
    }

    /**
     * Import sample quizzes.
     *
     * @param array $course_ids Course IDs to attach quizzes to.
     * @return array Quiz IDs
     */
    private function import_quizzes( $course_ids ) {
        if ( empty( $course_ids ) ) {
            return array();
        }

        $quiz_id = wp_insert_post( array(
            'post_title'   => __( 'Web Development Quiz', 'ts-lms' ),
            'post_content' => __( 'Test your knowledge of HTML and CSS basics with this comprehensive quiz.', 'ts-lms' ),
            'post_status'  => 'publish',
            'post_type'    => 'ts_quiz',
            'post_author'  => get_current_user_id(),
        ) );

        if ( is_wp_error( $quiz_id ) ) {
            return array();
        }

        // Link quiz to first course
        update_post_meta( $quiz_id, '_ts_quiz_course', $course_ids[0] );
        update_post_meta( $quiz_id, '_ts_quiz_time_limit', '30' );
        update_post_meta( $quiz_id, '_ts_quiz_pass_percentage', '70' );

        // Add sample questions
        $questions = array(
            array(
                'question' => __( 'What does HTML stand for?', 'ts-lms' ),
                'type' => 'multiple_choice',
                'options' => array(
                    __( 'Hyper Text Markup Language', 'ts-lms' ),
                    __( 'High Tech Modern Language', 'ts-lms' ),
                    __( 'Home Tool Markup Language', 'ts-lms' ),
                    __( 'Hyperlinks and Text Markup Language', 'ts-lms' ),
                ),
                'correct_answer' => 0,
            ),
            array(
                'question' => __( 'Which CSS property is used to change the text color?', 'ts-lms' ),
                'type' => 'multiple_choice',
                'options' => array(
                    __( 'text-color', 'ts-lms' ),
                    __( 'color', 'ts-lms' ),
                    __( 'font-color', 'ts-lms' ),
                    __( 'text-style', 'ts-lms' ),
                ),
                'correct_answer' => 1,
            ),
            array(
                'question' => __( 'What is the correct HTML element for the largest heading?', 'ts-lms' ),
                'type' => 'multiple_choice',
                'options' => array(
                    __( '<heading>', 'ts-lms' ),
                    __( '<h6>', 'ts-lms' ),
                    __( '<h1>', 'ts-lms' ),
                    __( '<head>', 'ts-lms' ),
                ),
                'correct_answer' => 2,
            ),
        );

        update_post_meta( $quiz_id, '_ts_quiz_questions', $questions );

        // Add quiz to course curriculum
        $curriculum = get_post_meta( $course_ids[0], '_ts_course_curriculum', true );
        if ( ! is_array( $curriculum ) ) {
            $curriculum = array();
        }
        $curriculum[] = array(
            'id' => $quiz_id,
            'type' => 'quiz',
            'order' => count( $curriculum ) + 1,
        );
        update_post_meta( $course_ids[0], '_ts_course_curriculum', $curriculum );

        return array( $quiz_id );
    }

    /**
     * Import certificate template.
     *
     * @return int Template ID
     */
    private function import_certificate_template() {
        $template_content = $this->get_default_certificate_template();

        $template_id = wp_insert_post( array(
            'post_title'   => __( 'Default Certificate Template', 'ts-lms' ),
            'post_content' => $template_content,
            'post_status'  => 'publish',
            'post_type'    => 'ts_certificate',
            'post_author'  => get_current_user_id(),
        ) );

        if ( ! is_wp_error( $template_id ) ) {
            update_post_meta( $template_id, '_ts_certificate_orientation', 'landscape' );
            update_post_meta( $template_id, '_ts_is_default_template', '1' );
        }

        return $template_id;
    }

    /**
     * Get default certificate template HTML.
     *
     * @return string
     */
    private function get_default_certificate_template() {
        return '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: "Georgia", serif;
            margin: 0;
            padding: 0;
        }
        .certificate {
            width: 100%;
            height: 100%;
            padding: 60px;
            box-sizing: border-box;
            border: 20px solid #0077B5;
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            position: relative;
        }
        .certificate-header {
            text-align: center;
            margin-bottom: 40px;
        }
        .certificate-title {
            font-size: 48px;
            font-weight: bold;
            color: #0077B5;
            margin: 0;
            text-transform: uppercase;
            letter-spacing: 4px;
        }
        .certificate-subtitle {
            font-size: 20px;
            color: #666;
            margin: 10px 0 0 0;
        }
        .certificate-body {
            text-align: center;
            margin: 40px 0;
        }
        .student-name {
            font-size: 42px;
            font-weight: bold;
            color: #333;
            margin: 20px 0;
            border-bottom: 2px solid #0077B5;
            display: inline-block;
            padding: 10px 40px;
        }
        .course-name {
            font-size: 28px;
            color: #0077B5;
            margin: 20px 0;
            font-style: italic;
        }
        .completion-text {
            font-size: 18px;
            color: #666;
            line-height: 1.6;
        }
        .certificate-footer {
            margin-top: 60px;
            display: flex;
            justify-content: space-around;
            align-items: flex-end;
        }
        .signature-block {
            text-align: center;
        }
        .signature-line {
            border-top: 2px solid #333;
            width: 200px;
            margin: 0 auto 10px;
        }
        .certificate-date {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="certificate">
        <div class="certificate-header">
            <h1 class="certificate-title">Certificate of Completion</h1>
            <p class="certificate-subtitle">This is to certify that</p>
        </div>
        
        <div class="certificate-body">
            <div class="student-name">{{student_name}}</div>
            
            <p class="completion-text">
                has successfully completed the course
            </p>
            
            <div class="course-name">{{course_name}}</div>
            
            <p class="completion-text">
                with dedication and excellence
            </p>
        </div>
        
        <div class="certificate-footer">
            <div class="signature-block">
                <div class="signature-line"></div>
                <p>Instructor Signature</p>
            </div>
            
            <div class="signature-block">
                <div class="signature-line"></div>
                <p>Date: {{completion_date}}</p>
            </div>
        </div>
    </div>
</body>
</html>';
    }
}
