<?php
namespace TS_LMS\Setup;

/**
 * Profile Completion Handler.
 */
class ProfileCompletion {

    /**
     * Instance of this class.
     */
    private static $instance = null;

    /**
     * Get instance.
     */
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'wp_body_open', array( $this, 'show_completion_bar' ) );
        add_action( 'wp_head', array( $this, 'inject_bar_styles' ) );
    }

    /**
     * Inject bar styles.
     */
    public function inject_bar_styles() {
        if ( ! is_user_logged_in() || ! $this->is_bar_enabled() ) {
            return;
        }

        if ( ! $this->is_profile_incomplete() ) {
            return;
        }
        ?>
        <style id="ts-lms-profile-completion-css">
            .ts-lms-completion-bar {
                background: #fef2f2;
                border-bottom: 1px solid #fee2e2;
                padding: 12px 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 15px;
                position: relative;
                z-index: 9999;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
            }
            .ts-lms-completion-bar p {
                margin: 0;
                color: #991b1b;
                font-size: 14px;
                font-weight: 500;
            }
            .ts-lms-completion-bar a {
                background: #ef4444;
                color: white;
                text-decoration: none;
                padding: 6px 16px;
                border-radius: 6px;
                font-size: 13px;
                font-weight: 600;
                transition: all 0.2s ease;
            }
            .ts-lms-completion-bar a:hover {
                background: #dc2626;
                transform: translateY(-1px);
            }
            @media (max-width: 768px) {
                .ts-lms-completion-bar {
                    flex-direction: column;
                    text-align: center;
                    gap: 10px;
                    padding: 8px 15px;
                    padding-right: 35px;
                }
                .ts-lms-completion-bar p {
                    font-size: 12px;
                }
            }
            .ts-lms-bar-close {
                position: absolute;
                right: 20px;
                top: 50%;
                transform: translateY(-50%);
                background: transparent;
                border: none;
                color: #991b1b;
                cursor: pointer;
                padding: 5px;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: transform 0.2s, opacity 0.2s;
            }
            .ts-lms-bar-close:hover {
                opacity: 0.7;
                transform: translateY(-50%) scale(1.1);
            }
            .ts-lms-bar-close .dashicons {
                font-size: 18px;
                width: 18px;
                height: 18px;
            }
        </style>
        <?php
    }

    /**
     * Check if bar is enabled.
     */
    private function is_bar_enabled() {
        if ( ! class_exists( '\TS_LMS\Admin\Settings' ) ) {
            return false;
        }
        $settings = \TS_LMS\Admin\Settings::get_settings();
        return isset( $settings['profile_completion_bar'] ) ? $settings['profile_completion_bar'] : 0;
    }

    /**
     * Show completion bar.
     */
    public function show_completion_bar() {
        if ( ! is_user_logged_in() || ! $this->is_bar_enabled() ) {
            return;
        }

        if ( ! $this->is_profile_incomplete() ) {
            return;
        }

        $profile_url = '';
        if ( class_exists( '\TS_LMS\Modules\Auth\Module' ) ) {
            // Assuming there is a student/instructor dashboard page
            $settings = \TS_LMS\Admin\Settings::get_settings();
            // Try to find profile edit URL. For now, we'll point to dashboard.
            $profile_url = admin_url( 'profile.php' ); 
        } else {
            $profile_url = admin_url( 'profile.php' );
        }

        ?>
        <div id="ts-lms-profile-completion-notice" class="ts-lms-completion-bar">
            <p>
                <span class="dashicons dashicons-warning" style="vertical-align: middle; margin-right: 5px;"></span>
                <?php _e( 'Your profile is incomplete. Please complete your profile to get the most out of our platform.', 'ts-lms' ); ?>
            </p>
            <a href="<?php echo esc_url( $profile_url ); ?>"><?php _e( 'Complete Profile', 'ts-lms' ); ?></a>
            <button type="button" class="ts-lms-bar-close" onclick="document.getElementById('ts-lms-profile-completion-notice').style.display='none'; localStorage.setItem('ts_lms_hide_profile_bar', 'true');">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <script>
            (function() {
                if (localStorage.getItem('ts_lms_hide_profile_bar')) {
                    var bar = document.getElementById('ts-lms-profile-completion-notice');
                    if (bar) bar.style.display = 'none';
                }
            })();
        </script>
        <?php
    }

    /**
     * Check if profile is incomplete.
     */
    private function is_profile_incomplete() {
        $user_id = get_current_user_id();
        $user = get_userdata( $user_id );

        if ( ! $user ) return false;

        // Criteria for incomplete profile:
        // 1. No first name or last name
        // 2. No bio (description)
        // 3. No avatar (checking if it is default gravatar might be hard, so just check bio/name)
        
        if ( empty( $user->first_name ) || empty( $user->last_name ) || empty( $user->description ) ) {
            return true;
        }

        return false;
    }
}
