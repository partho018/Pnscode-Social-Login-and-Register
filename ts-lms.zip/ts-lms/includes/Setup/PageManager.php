<?php
/**
 * Page Manager Class
 *
 * Handles automatic creation and management of required LMS pages.
 *
 * @package TS_LMS\Setup
 * @since 1.0.0
 */

namespace TS_LMS\Setup;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PageManager {

    /**
     * Singleton instance.
     *
     * @var PageManager
     */
    private static $instance = null;

    /**
     * Get singleton instance.
     *
     * @return PageManager
     */
    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    public function __construct() {
        // Handle manual page creation via AJAX/POST
        add_action( 'admin_init', array( $this, 'handle_manual_creation' ) );
        add_action( 'admin_notices', array( $this, 'display_setup_notice' ) );
    }

    /**
     * Get list of required pages.
     *
     * @return array
     */
    public function get_required_pages() {
        return array(
            'login_page' => array(
                'title'   => 'Login',
                'content' => '[ts_lms_login]',
                'slug'    => 'login',
                'option'  => 'login_page'
            ),
            'register_page' => array(
                'title'   => 'Register',
                'content' => '[ts_lms_register]',
                'slug'    => 'register',
                'option'  => 'student_reg_page'
            ),
            'dashboard_page' => array(
                'title'   => 'Student Dashboard',
                'content' => '[ts_lms_dashboard]',
                'slug'    => 'dashboard',
                'option'  => 'dashboard_page'
            ),
            'courses_page' => array(
                'title'   => 'All Courses',
                'content' => '[ts_course_catalog]',
                'slug'    => 'courses',
                'option'  => 'courses_page'
            ),
            'instructor_reg_page' => array(
                'title'   => 'Become an Instructor',
                'content' => '[ts_instructor_registration]',
                'slug'    => 'become-an-instructor',
                'option'  => 'instructor_reg_page'
            ),
        );
    }

    /**
     * Check if all required pages exist.
     *
     * @return bool|array Returns false if all exist, or array of missing page keys.
     */
    public function get_missing_pages() {
        $pages = $this->get_required_pages();
        $settings = get_option( 'ts_lms_settings', array() );
        $missing = array();

        foreach ( $pages as $key => $page ) {
            $page_id = isset( $settings[$page['option']] ) ? $settings[$page['option']] : 0;
            
            if ( ! $page_id || ! get_post( $page_id ) || get_post_status( $page_id ) === 'trash' ) {
                $missing[] = $key;
            }
        }

        return empty( $missing ) ? false : $missing;
    }

    /**
     * Create missing pages.
     *
     * @return void
     */
    public function create_pages() {
        $required_pages = $this->get_required_pages();
        $settings = get_option( 'ts_lms_settings', array() );
        $updated = false;

        foreach ( $required_pages as $key => $page ) {
            $page_id = isset( $settings[$page['option']] ) ? $settings[$page['option']] : 0;

            // If page ID exists but post is missing/trashed, or if ID doesn't exist
            if ( ! $page_id || ! get_post( $page_id ) || get_post_status( $page_id ) === 'trash' ) {
                
                // Try to find a page by title/slug first to avoid duplicates if user created it manually
                $existing = get_page_by_path( $page['slug'] );
                if ( $existing ) {
                    $settings[$page['option']] = $existing->ID;
                    $updated = true;
                    continue;
                }

                $new_page_id = wp_insert_post( array(
                    'post_title'   => $page['title'],
                    'post_content' => $page['content'],
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_name'    => $page['slug']
                ) );

                if ( ! is_wp_error( $new_page_id ) ) {
                    $settings[$page['option']] = $new_page_id;
                    $updated = true;
                }
            }
        }

        if ( $updated ) {
            update_option( 'ts_lms_settings', $settings );
            flush_rewrite_rules();
        }
    }

    /**
     * Handle manual page creation from admin notice.
     */
    public function handle_manual_creation() {
        if ( isset( $_GET['ts_lms_action'] ) && $_GET['ts_lms_action'] === 'create_pages' ) {
            check_admin_referer( 'ts_lms_create_pages_nonce' );

            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( 'Unauthorized' );
            }

            $this->create_pages();

            wp_redirect( add_query_arg( array( 'ts_lms_setup_complete' => '1' ), remove_query_arg( array( 'ts_lms_action', '_wpnonce' ) ) ) );
            exit;
        }
    }

    /**
     * Display setup notice if pages are missing.
     */
    public function display_setup_notice() {
        // Don't show on our settings page to avoid double notices
        $screen = get_current_screen();
        if ( $screen && strpos( $screen->id, 'ts-lms-settings' ) !== false ) {
            // return;
        }

        if ( isset( $_GET['ts_lms_setup_complete'] ) ) {
            ?>
            <div class="notice notice-success is-dismissible">
                <p><?php esc_html_e( 'TS LMS: All required pages have been created successfully!', 'ts-lms' ); ?></p>
            </div>
            <?php
            return;
        }

        $missing = $this->get_missing_pages();
        if ( $missing ) {
            $create_url = wp_nonce_url( add_query_arg( 'ts_lms_action', 'create_pages' ), 'ts_lms_create_pages_nonce' );
            ?>
            <div class="notice notice-warning ts-lms-setup-notice">
                <p>
                    <strong><?php esc_html_e( 'TS LMS Setup Required:', 'ts-lms' ); ?></strong>
                    <?php esc_html_e( 'Some required pages (Login, Dashboard, etc.) are missing. Click the button below to create them automatically.', 'ts-lms' ); ?>
                </p>
                <p>
                    <a href="<?php echo esc_url( $create_url ); ?>" class="button button-primary">
                        <?php esc_html_e( 'Create Pages', 'ts-lms' ); ?>
                    </a>
                </p>
                <style>
                    .ts-lms-setup-notice {
                        border-left-color: var(--ts-primary, #4f46e5) !important;
                        padding: 15px !important;
                    }
                </style>
            </div>
            <?php
        }
    }
}
