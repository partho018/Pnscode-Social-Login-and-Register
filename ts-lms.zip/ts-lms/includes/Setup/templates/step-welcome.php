<?php
/**
 * Wizard Step 1: Welcome Screen
 *
 * @package TS_LMS\Setup
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="ts-wizard-welcome">
    <div class="ts-welcome-icon">
        <span class="dashicons dashicons-welcome-learn-more"></span>
    </div>

    <h1 class="ts-welcome-title">
        <?php _e( 'Welcome to TS LMS!', 'ts-lms' ); ?>
    </h1>
    
    <p class="ts-welcome-subtitle">
        <?php _e( 'Let\'s set up your Learning Management System in just a few minutes', 'ts-lms' ); ?>
    </p>

    <div class="ts-welcome-features">
        <h3><?php _e( 'What you can do with TS LMS', 'ts-lms' ); ?></h3>
        <ul class="ts-features-list">
            <li>
                <span class="dashicons dashicons-book-alt"></span>
                <div>
                    <strong><?php _e( 'Create Unlimited Courses', 'ts-lms' ); ?></strong>
                    <p><?php _e( 'Build comprehensive courses with lessons, quizzes, and assignments', 'ts-lms' ); ?></p>
                </div>
            </li>
            <li>
                <span class="dashicons dashicons-groups"></span>
                <div>
                    <strong><?php _e( 'Manage Students', 'ts-lms' ); ?></strong>
                    <p><?php _e( 'Track student progress, manage enrollments, and monitor performance', 'ts-lms' ); ?></p>
                </div>
            </li>
            <li>
                <span class="dashicons dashicons-awards"></span>
                <div>
                    <strong><?php _e( 'Quizzes & Certificates', 'ts-lms' ); ?></strong>
                    <p><?php _e( 'Create engaging quizzes and award beautiful certificates', 'ts-lms' ); ?></p>
                </div>
            </li>
            <li>
                <span class="dashicons dashicons-cart"></span>
                <div>
                    <strong><?php _e( 'Sell Courses Online', 'ts-lms' ); ?></strong>
                    <p><?php _e( 'Monetize your content with WooCommerce integration', 'ts-lms' ); ?></p>
                </div>
            </li>
        </ul>
    </div>

    <div class="ts-welcome-actions">
        <button type="button" class="ts-wizard-btn ts-wizard-btn-primary ts-wizard-btn-large ts-welcome-start">
            <?php _e( 'Start Setup', 'ts-lms' ); ?>
            <span class="dashicons dashicons-arrow-right-alt2"></span>
        </button>

        <button type="button" class="ts-wizard-btn ts-wizard-btn-secondary ts-wizard-btn-large ts-welcome-skip">
            <?php _e( 'Skip Setup', 'ts-lms' ); ?>
        </button>

        <a href="<?php echo admin_url( 'admin.php?page=ts-lms' ); ?>" class="ts-welcome-later">
            <?php _e( 'I\'ll do this later from the dashboard', 'ts-lms' ); ?>
        </a>
    </div>

    <div class="ts-welcome-footer">
        <p class="ts-welcome-time">
            <span class="dashicons dashicons-clock"></span>
            <?php _e( 'Setup takes approximately 3-5 minutes', 'ts-lms' ); ?>
        </p>
    </div>
</div>
