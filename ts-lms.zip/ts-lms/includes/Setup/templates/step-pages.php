<?php
/**
 * Wizard Step 3: Pages Auto Create
 *
 * @package TS_LMS\Setup
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$page_manager = \TS_LMS\Setup\PageManager::instance();
$required_pages = $page_manager->get_required_pages();
$settings = get_option( 'ts_lms_settings', array() );
?>

<div class="ts-wizard-pages">
    <div class="ts-step-header">
        <h2><?php _e( 'Create Required Pages', 'ts-lms' ); ?></h2>
        <p><?php _e( 'TS LMS needs several pages to function properly. We can create them automatically for you.', 'ts-lms' ); ?></p>
    </div>

    <div class="ts-pages-list">
        <?php foreach ( $required_pages as $key => $page ) : 
            $page_id = $settings[$page['option']] ?? 0;
            $page_exists = $page_id && get_post( $page_id );
        ?>
            <div class="ts-page-item" data-page-key="<?php echo esc_attr( $key ); ?>">
                <div class="ts-page-info">
                    <div class="ts-page-status">
                        <?php if ( $page_exists ) : ?>
                            <span class="dashicons dashicons-yes-alt ts-status-success"></span>
                        <?php else : ?>
                            <span class="dashicons dashicons-minus ts-status-pending"></span>
                        <?php endif; ?>
                    </div>
                    <div class="ts-page-details">
                        <h4><?php echo esc_html( $page['title'] ); ?></h4>
                        <p class="ts-page-slug">
                            <?php echo home_url( '/' . $page['slug'] ); ?>
                        </p>
                        <?php if ( $page_exists ) : ?>
                            <span class="ts-page-badge ts-badge-success">
                                <?php _e( 'Already Created', 'ts-lms' ); ?>
                            </span>
                        <?php else : ?>
                            <span class="ts-page-badge ts-badge-pending">
                                <?php _e( 'Will be created', 'ts-lms' ); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Advanced: Manual Page Selection -->
                <div class="ts-page-advanced">
                    <button type="button" class="ts-toggle-advanced" data-target="advanced-<?php echo esc_attr( $key ); ?>">
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                        <?php _e( 'Advanced', 'ts-lms' ); ?>
                    </button>
                    <div class="ts-advanced-content" id="advanced-<?php echo esc_attr( $key ); ?>" style="display: none;">
                        <label><?php _e( 'Or select an existing page:', 'ts-lms' ); ?></label>
                        <select class="ts-page-selector" data-option="<?php echo esc_attr( $page['option'] ); ?>">
                            <option value=""><?php _e( 'Create new page', 'ts-lms' ); ?></option>
                            <?php
                            $pages = get_pages();
                            foreach ( $pages as $wp_page ) {
                                printf(
                                    '<option value="%d" %s>%s</option>',
                                    $wp_page->ID,
                                    selected( $page_id, $wp_page->ID, false ),
                                    esc_html( $wp_page->post_title )
                                );
                            }
                            ?>
                        </select>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="ts-pages-actions">
        <button type="button" class="ts-wizard-btn ts-wizard-btn-primary ts-wizard-btn-large ts-create-pages">
            <span class="dashicons dashicons-admin-page"></span>
            <?php _e( 'Create Pages Automatically', 'ts-lms' ); ?>
        </button>
    </div>

    <!-- Progress Indicator -->
    <div class="ts-pages-progress" style="display: none;">
        <div class="ts-progress-bar">
            <div class="ts-progress-fill" style="width: 0%"></div>
        </div>
        <p class="ts-progress-text"><?php _e( 'Creating pages...', 'ts-lms' ); ?></p>
    </div>

    <!-- Success Message -->
    <div class="ts-form-message ts-success-message" style="display: none;">
        <span class="dashicons dashicons-yes-alt"></span>
        <span class="ts-message-text"></span>
    </div>

    <!-- Error Message -->
    <div class="ts-form-message ts-error-message" style="display: none;">
        <span class="dashicons dashicons-warning"></span>
        <span class="ts-message-text"></span>
    </div>

    <div class="ts-pages-note">
        <span class="dashicons dashicons-info"></span>
        <p><?php _e( 'These pages are essential for your LMS to work properly. You can customize them later from the Pages menu.', 'ts-lms' ); ?></p>
    </div>
</div>
