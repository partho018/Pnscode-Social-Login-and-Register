<?php
/**
 * Wizard Container Template
 *
 * Main wizard layout with step navigation.
 *
 * @package TS_LMS\Setup
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php _e( 'TS LMS Setup Wizard', 'ts-lms' ); ?></title>
    <?php do_action( 'admin_print_styles' ); ?>
    <?php do_action( 'admin_print_scripts' ); ?>
</head>
<body class="ts-lms-wizard-body">
    
    <div class="ts-wizard-container">
        <!-- Wizard Header -->
        <div class="ts-wizard-header">
            <div class="ts-wizard-logo">
                <h1><?php _e( 'TS LMS', 'ts-lms' ); ?> <span style="font-weight: 400; color: #6B7280;">Setup Wizard</span></h1>
            </div>
        </div>

        <!-- Progress Indicator -->
        <div class="ts-wizard-progress">
            <div class="ts-progress-bar">
                <div class="ts-progress-fill" style="width: <?php echo ( ( $this->current_step / $this->total_steps ) * 100 ); ?>%"></div>
            </div>
            <div class="ts-progress-steps">
                <?php for ( $i = 1; $i <= $this->total_steps; $i++ ) : ?>
                    <div class="ts-progress-step <?php echo $i <= $this->current_step ? 'active' : ''; ?> <?php echo $i < $this->current_step ? 'completed' : ''; ?>" data-step="<?php echo $i; ?>">
                        <div class="ts-step-number">
                            <?php if ( $i < $this->current_step ) : ?>
                                <span class="dashicons dashicons-yes"></span>
                            <?php else : ?>
                                <?php echo $i; ?>
                            <?php endif; ?>
                        </div>
                        <div class="ts-step-label">
                            <?php
                            $labels = array(
                                1 => __( 'Welcome', 'ts-lms' ),
                                2 => __( 'Settings', 'ts-lms' ),
                                3 => __( 'Pages', 'ts-lms' ),
                                4 => __( 'Payment', 'ts-lms' ),
                                5 => __( 'Sample Data', 'ts-lms' ),
                                6 => __( 'Complete', 'ts-lms' ),
                            );
                            echo $labels[$i] ?? '';
                            ?>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>

        <!-- Wizard Content -->
        <div class="ts-wizard-content">
            <div class="ts-wizard-step" data-step="<?php echo $this->current_step; ?>">
                <?php
                $template = $this->get_step_template( $this->current_step );
                $template_path = TS_LMS_PLUGIN_DIR . 'includes/Setup/templates/' . $template;
                
                if ( file_exists( $template_path ) ) {
                    include $template_path;
                } else {
                    echo '<p>' . __( 'Template not found.', 'ts-lms' ) . '</p>';
                }
                ?>
            </div>
        </div>

        <!-- Wizard Navigation -->
        <div class="ts-wizard-navigation">
            <?php if ( $this->current_step > 1 && $this->current_step < $this->total_steps ) : ?>
                <button type="button" class="ts-wizard-btn ts-wizard-btn-secondary ts-wizard-prev" data-step="<?php echo $this->current_step - 1; ?>">
                    <span class="dashicons dashicons-arrow-left-alt2"></span>
                    <?php _e( 'Previous', 'ts-lms' ); ?>
                </button>
            <?php endif; ?>

            <div class="ts-wizard-nav-spacer"></div>

            <?php if ( $this->current_step < $this->total_steps ) : ?>
                <?php if ( $this->current_step > 1 ) : ?>
                    <button type="button" class="ts-wizard-btn ts-wizard-btn-link ts-wizard-skip">
                        <?php _e( 'Skip this step', 'ts-lms' ); ?>
                    </button>
                <?php endif; ?>
                
                <button type="button" class="ts-wizard-btn ts-wizard-btn-primary ts-wizard-next" data-step="<?php echo $this->current_step + 1; ?>">
                    <?php _e( 'Next', 'ts-lms' ); ?>
                    <span class="dashicons dashicons-arrow-right-alt2"></span>
                </button>
            <?php endif; ?>
        </div>

        <!-- Loading Overlay -->
        <div class="ts-wizard-loading" style="display: none;">
            <div class="ts-loading-spinner">
                <div class="ts-spinner"></div>
                <p class="ts-loading-text"><?php _e( 'Loading...', 'ts-lms' ); ?></p>
            </div>
        </div>
    </div>

    <?php do_action( 'admin_print_footer_scripts' ); ?>
</body>
</html>
