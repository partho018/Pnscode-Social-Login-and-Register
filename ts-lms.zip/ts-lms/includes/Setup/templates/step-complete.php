<?php
/**
 * Wizard Step 6: Setup Complete
 *
 * @package TS_LMS\Setup
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$settings = get_option( 'ts_lms_settings', array() );
$courses_page = $settings['courses_page'] ?? 0;
$dashboard_page = $settings['dashboard_page'] ?? 0;
?>

<div class="ts-wizard-complete">
    <div class="ts-complete-animation">
        <div class="ts-success-icon">
            <span class="dashicons dashicons-yes-alt"></span>
        </div>
    </div>

    <h1 class="ts-complete-title">
        <?php _e( 'All Set! 🎉', 'ts-lms' ); ?>
    </h1>

    <p class="ts-complete-subtitle">
        <?php _e( 'Your Learning Management System is ready to go. Start creating amazing courses!', 'ts-lms' ); ?>
    </p>

    <div class="ts-complete-summary">
        <h3><?php _e( 'What we configured', 'ts-lms' ); ?></h3>
        <ul class="ts-summary-list">
            <li>
                <span class="dashicons dashicons-yes-alt"></span>
                <?php _e( 'Basic settings configured', 'ts-lms' ); ?>
            </li>
            <li>
                <span class="dashicons dashicons-yes-alt"></span>
                <?php _e( 'Required pages created', 'ts-lms' ); ?>
            </li>
            <?php if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) : ?>
            <li>
                <span class="dashicons dashicons-yes-alt"></span>
                <?php _e( 'WooCommerce connected', 'ts-lms' ); ?>
            </li>
            <?php endif; ?>
            <?php if ( get_option( 'ts_lms_sample_data_imported' ) ) : ?>
            <li>
                <span class="dashicons dashicons-yes-alt"></span>
                <?php _e( 'Sample data imported', 'ts-lms' ); ?>
            </li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="ts-complete-actions">
        <h3><?php _e( 'What would you like to do next?', 'ts-lms' ); ?></h3>
        
        <div class="ts-action-cards">
            <a href="<?php echo admin_url( 'admin.php?page=ts-lms' ); ?>" class="ts-action-card">
                <div class="ts-card-icon">
                    <span class="dashicons dashicons-dashboard"></span>
                </div>
                <h4><?php _e( 'View Dashboard', 'ts-lms' ); ?></h4>
                <p><?php _e( 'See your LMS overview and statistics', 'ts-lms' ); ?></p>
            </a>

            <a href="<?php echo admin_url( 'post-new.php?post_type=ts_course' ); ?>" class="ts-action-card">
                <div class="ts-card-icon">
                    <span class="dashicons dashicons-plus-alt"></span>
                </div>
                <h4><?php _e( 'Create Course', 'ts-lms' ); ?></h4>
                <p><?php _e( 'Start building your first course', 'ts-lms' ); ?></p>
            </a>

            <?php if ( $courses_page ) : ?>
            <a href="<?php echo get_permalink( $courses_page ); ?>" class="ts-action-card" target="_blank">
                <div class="ts-card-icon">
                    <span class="dashicons dashicons-visibility"></span>
                </div>
                <h4><?php _e( 'View Courses', 'ts-lms' ); ?></h4>
                <p><?php _e( 'See how courses look to students', 'ts-lms' ); ?></p>
            </a>
            <?php endif; ?>

            <?php if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) : ?>
            <a href="<?php echo admin_url( 'admin.php?page=wc-settings' ); ?>" class="ts-action-card">
                <div class="ts-card-icon">
                    <span class="dashicons dashicons-cart"></span>
                </div>
                <h4><?php _e( 'Payment Settings', 'ts-lms' ); ?></h4>
                <p><?php _e( 'Configure payment gateways', 'ts-lms' ); ?></p>
            </a>
            <?php endif; ?>

            <a href="<?php echo admin_url( 'admin.php?page=ts-lms-settings' ); ?>" class="ts-action-card">
                <div class="ts-card-icon">
                    <span class="dashicons dashicons-admin-settings"></span>
                </div>
                <h4><?php _e( 'Settings', 'ts-lms' ); ?></h4>
                <p><?php _e( 'Customize your LMS', 'ts-lms' ); ?></p>
            </a>

            <a href="https://techsoulbd.com/ts-lms/docs" class="ts-action-card" target="_blank">
                <div class="ts-card-icon">
                    <span class="dashicons dashicons-book"></span>
                </div>
                <h4><?php _e( 'Documentation', 'ts-lms' ); ?></h4>
                <p><?php _e( 'Learn about all features', 'ts-lms' ); ?></p>
            </a>
        </div>
    </div>

    <div class="ts-complete-footer">
        <button type="button" class="ts-wizard-btn ts-wizard-btn-primary ts-wizard-btn-large ts-finish-wizard">
            <?php _e( 'Go to Dashboard', 'ts-lms' ); ?>
            <span class="dashicons dashicons-arrow-right-alt2"></span>
        </button>
    </div>

    <div class="ts-complete-note">
        <p>
            <span class="dashicons dashicons-info"></span>
            <?php _e( 'You can re-run this wizard anytime from Settings', 'ts-lms' ); ?>
        </p>
    </div>
</div>
