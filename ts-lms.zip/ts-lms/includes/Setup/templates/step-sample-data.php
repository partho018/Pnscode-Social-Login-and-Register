<?php
/**
 * Wizard Step 5: Sample Data Import
 *
 * @package TS_LMS\Setup
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="ts-wizard-sample-data">
    <div class="ts-step-header">
        <h2><?php _e( 'Import Sample Data', 'ts-lms' ); ?></h2>
        <p><?php _e( 'Get started quickly with pre-built demo courses and content.', 'ts-lms' ); ?></p>
    </div>

    <div class="ts-sample-data-option">
        <label class="ts-checkbox-card">
            <input type="checkbox" id="ts-import-sample" checked>
            <div class="ts-card-content">
                <div class="ts-card-header">
                    <span class="dashicons dashicons-download"></span>
                    <h3><?php _e( 'Import Sample Courses', 'ts-lms' ); ?></h3>
                </div>
                <p><?php _e( 'We recommend importing sample data to see how everything works. You can delete it later.', 'ts-lms' ); ?></p>
            </div>
        </label>
    </div>

    <div class="ts-sample-data-preview">
        <h3><?php _e( 'What will be imported:', 'ts-lms' ); ?></h3>
        <div class="ts-preview-grid">
            <div class="ts-preview-item">
                <div class="ts-preview-icon">
                    <span class="dashicons dashicons-book-alt"></span>
                </div>
                <div class="ts-preview-content">
                    <h4>3</h4>
                    <p><?php _e( 'Demo Courses', 'ts-lms' ); ?></p>
                </div>
                <ul class="ts-preview-list">
                    <li><?php _e( 'Introduction to Web Development', 'ts-lms' ); ?></li>
                    <li><?php _e( 'Digital Marketing Essentials', 'ts-lms' ); ?></li>
                    <li><?php _e( 'Graphic Design Fundamentals', 'ts-lms' ); ?></li>
                </ul>
            </div>

            <div class="ts-preview-item">
                <div class="ts-preview-icon">
                    <span class="dashicons dashicons-media-document"></span>
                </div>
                <div class="ts-preview-content">
                    <h4>5</h4>
                    <p><?php _e( 'Demo Lessons', 'ts-lms' ); ?></p>
                </div>
                <ul class="ts-preview-list">
                    <li><?php _e( 'HTML Basics', 'ts-lms' ); ?></li>
                    <li><?php _e( 'CSS Fundamentals', 'ts-lms' ); ?></li>
                    <li><?php _e( 'SEO Basics', 'ts-lms' ); ?></li>
                    <li><?php _e( 'Social Media Marketing', 'ts-lms' ); ?></li>
                    <li><?php _e( 'Design Principles', 'ts-lms' ); ?></li>
                </ul>
            </div>

            <div class="ts-preview-item">
                <div class="ts-preview-icon">
                    <span class="dashicons dashicons-edit"></span>
                </div>
                <div class="ts-preview-content">
                    <h4>1</h4>
                    <p><?php _e( 'Demo Quiz', 'ts-lms' ); ?></p>
                </div>
                <ul class="ts-preview-list">
                    <li><?php _e( 'Web Development Quiz', 'ts-lms' ); ?></li>
                    <li><?php _e( 'With 3 sample questions', 'ts-lms' ); ?></li>
                </ul>
            </div>

            <div class="ts-preview-item">
                <div class="ts-preview-icon">
                    <span class="dashicons dashicons-awards"></span>
                </div>
                <div class="ts-preview-content">
                    <h4>1</h4>
                    <p><?php _e( 'Certificate Template', 'ts-lms' ); ?></p>
                </div>
                <ul class="ts-preview-list">
                    <li><?php _e( 'Professional certificate design', 'ts-lms' ); ?></li>
                    <li><?php _e( 'Ready to customize', 'ts-lms' ); ?></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="ts-sample-data-actions">
        <button type="button" class="ts-wizard-btn ts-wizard-btn-primary ts-wizard-btn-large ts-import-data">
            <span class="dashicons dashicons-download"></span>
            <?php _e( 'Import Sample Data', 'ts-lms' ); ?>
        </button>
    </div>

    <!-- Progress Indicator -->
    <div class="ts-import-progress" style="display: none;">
        <div class="ts-progress-bar">
            <div class="ts-progress-fill" style="width: 0%"></div>
        </div>
        <p class="ts-progress-text"><?php _e( 'Importing sample data...', 'ts-lms' ); ?></p>
        <div class="ts-import-steps">
            <div class="ts-import-step" data-step="courses">
                <span class="dashicons dashicons-update ts-spin"></span>
                <span><?php _e( 'Creating courses...', 'ts-lms' ); ?></span>
            </div>
            <div class="ts-import-step" data-step="lessons">
                <span class="dashicons dashicons-minus"></span>
                <span><?php _e( 'Creating lessons...', 'ts-lms' ); ?></span>
            </div>
            <div class="ts-import-step" data-step="quizzes">
                <span class="dashicons dashicons-minus"></span>
                <span><?php _e( 'Creating quizzes...', 'ts-lms' ); ?></span>
            </div>
            <div class="ts-import-step" data-step="certificates">
                <span class="dashicons dashicons-minus"></span>
                <span><?php _e( 'Creating certificate template...', 'ts-lms' ); ?></span>
            </div>
        </div>
    </div>

    <!-- Success Message -->
    <div class="ts-form-message ts-success-message" style="display: none;">
        <span class="dashicons dashicons-yes-alt"></span>
        <span class="ts-message-text"></span>
    </div>

    <!-- Error Message -->
    <div class="ts-form-message ts-error-message" style="display: none;">
        <span class="dashicons dashicons-warning"></span>
        <span class="ts-message-text"></span>
    </div>

    <div class="ts-sample-data-note">
        <span class="dashicons dashicons-info"></span>
        <p><?php _e( 'Sample data helps you understand how the LMS works. You can delete it anytime from your WordPress admin.', 'ts-lms' ); ?></p>
    </div>
</div>
