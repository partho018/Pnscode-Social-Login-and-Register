<?php
/**
 * Wizard Step 4: Payment Setup (WooCommerce)
 *
 * @package TS_LMS\Setup
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="ts-wizard-payment">
    <div class="ts-step-header">
        <h2><?php _e( 'Payment Setup', 'ts-lms' ); ?></h2>
        <p><?php _e( 'Connect WooCommerce to sell your courses online and accept payments.', 'ts-lms' ); ?></p>
    </div>

    <div class="ts-payment-info">
        <div class="ts-info-card">
            <span class="dashicons dashicons-cart"></span>
            <h3><?php _e( 'Why WooCommerce?', 'ts-lms' ); ?></h3>
            <p><?php _e( 'WooCommerce is the most popular eCommerce platform for WordPress. It allows you to:', 'ts-lms' ); ?></p>
            <ul>
                <li><?php _e( 'Accept payments via credit cards, PayPal, and more', 'ts-lms' ); ?></li>
                <li><?php _e( 'Manage orders and customer data', 'ts-lms' ); ?></li>
                <li><?php _e( 'Offer discounts and coupons', 'ts-lms' ); ?></li>
                <li><?php _e( 'Track sales and revenue', 'ts-lms' ); ?></li>
            </ul>
        </div>
    </div>

    <!-- WooCommerce Status -->
    <div class="ts-woo-status-container">
        <div class="ts-woo-status" id="ts-woo-status">
            <div class="ts-status-icon">
                <span class="dashicons dashicons-update ts-spin"></span>
            </div>
            <div class="ts-status-content">
                <h4><?php _e( 'Checking WooCommerce status...', 'ts-lms' ); ?></h4>
                <p><?php _e( 'Please wait...', 'ts-lms' ); ?></p>
            </div>
        </div>
    </div>

    <!-- Action Buttons (will be populated by JavaScript) -->
    <div class="ts-woo-actions" id="ts-woo-actions" style="display: none;">
        <!-- Buttons will be added dynamically -->
    </div>

    <!-- Progress Indicator -->
    <div class="ts-woo-progress" style="display: none;">
        <div class="ts-progress-bar">
            <div class="ts-progress-fill" style="width: 0%"></div>
        </div>
        <p class="ts-progress-text"><?php _e( 'Installing WooCommerce...', 'ts-lms' ); ?></p>
    </div>

    <!-- Success Message -->
    <div class="ts-form-message ts-success-message" style="display: none;">
        <span class="dashicons dashicons-yes-alt"></span>
        <span class="ts-message-text"></span>
    </div>

    <!-- Error Message -->
    <div class="ts-form-message ts-error-message" style="display: none;">
        <span class="dashicons dashicons-warning"></span>
        <span class="ts-message-text"></span>
    </div>

    <!-- Skip Option -->
    <div class="ts-payment-skip">
        <p class="ts-skip-note">
            <span class="dashicons dashicons-info"></span>
            <?php _e( 'If you only plan to offer free courses, you can skip this step.', 'ts-lms' ); ?>
        </p>
    </div>
</div>
