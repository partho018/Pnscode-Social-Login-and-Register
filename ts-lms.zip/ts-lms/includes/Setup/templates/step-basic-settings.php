<?php
/**
 * Wizard Step 2: Basic Settings
 *
 * @package TS_LMS\Setup
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$settings = get_option( 'ts_lms_settings', array() );
$current_currency = $settings['currency'] ?? 'BDT';
$current_country = $settings['country'] ?? 'BD';
$tax_enabled = $settings['tax_enabled'] ?? false;
?>

<div class="ts-wizard-basic-settings">
    <div class="ts-step-header">
        <h2><?php _e( 'Basic Settings', 'ts-lms' ); ?></h2>
        <p><?php _e( 'Configure your basic LMS settings to get started.', 'ts-lms' ); ?></p>
    </div>

    <form id="ts-wizard-basic-settings-form" class="ts-wizard-form">
        
        <!-- Currency Selection -->
        <div class="ts-form-group">
            <label for="ts-currency">
                <span class="dashicons dashicons-money-alt"></span>
                <?php _e( 'Currency', 'ts-lms' ); ?>
            </label>
            <select id="ts-currency" name="currency" class="ts-form-control">
                <option value="USD" <?php selected( $current_currency, 'USD' ); ?>>USD - US Dollar ($)</option>
                <option value="EUR" <?php selected( $current_currency, 'EUR' ); ?>>EUR - Euro (€)</option>
                <option value="GBP" <?php selected( $current_currency, 'GBP' ); ?>>GBP - British Pound (£)</option>
                <option value="BDT" <?php selected( $current_currency, 'BDT' ); ?>>BDT - Bangladeshi Taka (৳)</option>
                <option value="INR" <?php selected( $current_currency, 'INR' ); ?>>INR - Indian Rupee (₹)</option>
                <option value="PKR" <?php selected( $current_currency, 'PKR' ); ?>>PKR - Pakistani Rupee (₨)</option>
                <option value="AUD" <?php selected( $current_currency, 'AUD' ); ?>>AUD - Australian Dollar (A$)</option>
                <option value="CAD" <?php selected( $current_currency, 'CAD' ); ?>>CAD - Canadian Dollar (C$)</option>
                <option value="JPY" <?php selected( $current_currency, 'JPY' ); ?>>JPY - Japanese Yen (¥)</option>
                <option value="CNY" <?php selected( $current_currency, 'CNY' ); ?>>CNY - Chinese Yuan (¥)</option>
            </select>
            <p class="ts-form-description">
                <?php _e( 'Select the currency you\'ll use for course pricing.', 'ts-lms' ); ?>
            </p>
        </div>

        <!-- Country Selection -->
        <div class="ts-form-group">
            <label for="ts-country">
                <span class="dashicons dashicons-admin-site"></span>
                <?php _e( 'Country', 'ts-lms' ); ?>
            </label>
            <select id="ts-country" name="country" class="ts-form-control">
                <option value="BD" <?php selected( $current_country, 'BD' ); ?>><?php _e( 'Bangladesh', 'ts-lms' ); ?></option>
                <option value="IN" <?php selected( $current_country, 'IN' ); ?>><?php _e( 'India', 'ts-lms' ); ?></option>
                <option value="PK" <?php selected( $current_country, 'PK' ); ?>><?php _e( 'Pakistan', 'ts-lms' ); ?></option>
                <option value="US" <?php selected( $current_country, 'US' ); ?>><?php _e( 'United States', 'ts-lms' ); ?></option>
                <option value="GB" <?php selected( $current_country, 'GB' ); ?>><?php _e( 'United Kingdom', 'ts-lms' ); ?></option>
                <option value="CA" <?php selected( $current_country, 'CA' ); ?>><?php _e( 'Canada', 'ts-lms' ); ?></option>
                <option value="AU" <?php selected( $current_country, 'AU' ); ?>><?php _e( 'Australia', 'ts-lms' ); ?></option>
                <option value="DE" <?php selected( $current_country, 'DE' ); ?>><?php _e( 'Germany', 'ts-lms' ); ?></option>
                <option value="FR" <?php selected( $current_country, 'FR' ); ?>><?php _e( 'France', 'ts-lms' ); ?></option>
                <option value="AE" <?php selected( $current_country, 'AE' ); ?>><?php _e( 'United Arab Emirates', 'ts-lms' ); ?></option>
                <option value="SA" <?php selected( $current_country, 'SA' ); ?>><?php _e( 'Saudi Arabia', 'ts-lms' ); ?></option>
            </select>
            <p class="ts-form-description">
                <?php _e( 'Select your country for localization settings.', 'ts-lms' ); ?>
            </p>
        </div>

        <!-- Tax Settings -->
        <div class="ts-form-group">
            <label class="ts-toggle-label">
                <span class="dashicons dashicons-admin-generic"></span>
                <?php _e( 'Tax Settings', 'ts-lms' ); ?>
            </label>
            <div class="ts-toggle-wrapper">
                <label class="ts-toggle-switch">
                    <input type="checkbox" id="ts-tax-enabled" name="tax_enabled" <?php checked( $tax_enabled, true ); ?>>
                    <span class="ts-toggle-slider"></span>
                </label>
                <span class="ts-toggle-text">
                    <?php _e( 'Enable tax calculation on course prices', 'ts-lms' ); ?>
                </span>
            </div>
            <p class="ts-form-description">
                <?php _e( 'Enable this if you need to add tax to your course prices. You can configure tax rates later in settings.', 'ts-lms' ); ?>
            </p>
        </div>

        <!-- Save Button -->
        <div class="ts-form-actions">
            <button type="submit" class="ts-wizard-btn ts-wizard-btn-primary ts-save-settings">
                <span class="dashicons dashicons-saved"></span>
                <?php _e( 'Save & Continue', 'ts-lms' ); ?>
            </button>
        </div>

        <!-- Success Message -->
        <div class="ts-form-message ts-success-message" style="display: none;">
            <span class="dashicons dashicons-yes-alt"></span>
            <span class="ts-message-text"></span>
        </div>

        <!-- Error Message -->
        <div class="ts-form-message ts-error-message" style="display: none;">
            <span class="dashicons dashicons-warning"></span>
            <span class="ts-message-text"></span>
        </div>
    </form>
</div>
