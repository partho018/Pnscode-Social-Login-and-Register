<?php
/**
 * Onboarding Wizard Class
 *
 * Handles the initial setup wizard that appears when the plugin is first activated.
 *
 * @package TS_LMS\Setup
 * @since 1.0.0
 */

namespace TS_LMS\Setup;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class OnboardingWizard {

    /**
     * Singleton instance.
     *
     * @var OnboardingWizard
     */
    private static $instance = null;

    /**
     * Current step.
     *
     * @var int
     */
    private $current_step = 1;

    /**
     * Total steps.
     *
     * @var int
     */
    private $total_steps = 6;

    /**
     * Get singleton instance.
     *
     * @return OnboardingWizard
     */
    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'admin_init', array( $this, 'maybe_redirect_to_wizard' ) );
        add_action( 'admin_menu', array( $this, 'register_wizard_page' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_wizard_assets' ) );
        
        // AJAX handlers
        add_action( 'wp_ajax_ts_lms_wizard_save_basic_settings', array( $this, 'handle_ajax_save_basic_settings' ) );
        add_action( 'wp_ajax_ts_lms_wizard_create_pages', array( $this, 'handle_ajax_create_pages' ) );
        add_action( 'wp_ajax_ts_lms_wizard_check_woocommerce', array( $this, 'handle_ajax_check_woocommerce' ) );
        add_action( 'wp_ajax_ts_lms_wizard_install_woocommerce', array( $this, 'handle_ajax_install_woocommerce' ) );
        add_action( 'wp_ajax_ts_lms_wizard_import_sample_data', array( $this, 'handle_ajax_import_sample_data' ) );
        add_action( 'wp_ajax_ts_lms_wizard_complete', array( $this, 'handle_ajax_complete_wizard' ) );
        add_action( 'wp_ajax_ts_lms_wizard_skip', array( $this, 'handle_ajax_skip_wizard' ) );
    }

    /**
     * Redirect to wizard on first activation.
     */
    public function maybe_redirect_to_wizard() {
        // Check if we should show the wizard
        if ( ! get_transient( 'ts_lms_show_wizard' ) ) {
            return;
        }

        // Delete the transient
        delete_transient( 'ts_lms_show_wizard' );

        // Don't redirect if doing AJAX or if wizard is already completed
        if ( wp_doing_ajax() || get_option( 'ts_lms_wizard_completed' ) ) {
            return;
        }

        // Don't redirect if user can't manage options
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Redirect to wizard
        wp_safe_redirect( admin_url( 'admin.php?page=ts-lms-wizard' ) );
        exit;
    }

    /**
     * Register wizard page in admin menu.
     */
    public function register_wizard_page() {
        add_submenu_page(
            null, // No parent menu (hidden from menu)
            __( 'TS LMS Setup Wizard', 'ts-lms' ),
            __( 'Setup Wizard', 'ts-lms' ),
            'manage_options',
            'ts-lms-wizard',
            array( $this, 'render_wizard' )
        );
    }

    /**
     * Enqueue wizard assets.
     */
    public function enqueue_wizard_assets( $hook ) {
        if ( $hook !== 'admin_page_ts-lms-wizard' ) {
            return;
        }

        wp_enqueue_style(
            'ts-lms-wizard',
            TS_LMS_PLUGIN_URL . 'assets/css/wizard.css',
            array(),
            TS_LMS_VERSION
        );

        wp_enqueue_script(
            'ts-lms-wizard',
            TS_LMS_PLUGIN_URL . 'assets/js/wizard.js',
            array( 'jquery' ),
            TS_LMS_VERSION,
            true
        );

        wp_localize_script( 'ts-lms-wizard', 'tsLmsWizard', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'ts_lms_wizard_nonce' ),
            'strings'  => array(
                'error'   => __( 'An error occurred. Please try again.', 'ts-lms' ),
                'loading' => __( 'Loading...', 'ts-lms' ),
                'success' => __( 'Success!', 'ts-lms' ),
            ),
        ) );
    }

    /**
     * Render wizard page.
     */
    public function render_wizard() {
        $step = isset( $_GET['step'] ) ? absint( $_GET['step'] ) : 1;
        $step = max( 1, min( $step, $this->total_steps ) );
        $this->current_step = $step;

        include TS_LMS_PLUGIN_DIR . 'includes/Setup/templates/wizard-container.php';
    }

    /**
     * Get step template path.
     *
     * @param int $step Step number.
     * @return string
     */
    public function get_step_template( $step ) {
        $templates = array(
            1 => 'step-welcome.php',
            2 => 'step-basic-settings.php',
            3 => 'step-pages.php',
            4 => 'step-payment.php',
            5 => 'step-sample-data.php',
            6 => 'step-complete.php',
        );

        return isset( $templates[$step] ) ? $templates[$step] : 'step-welcome.php';
    }

    /**
     * AJAX: Save basic settings.
     */
    public function handle_ajax_save_basic_settings() {
        check_ajax_referer( 'ts_lms_wizard_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Unauthorized', 'ts-lms' ) ) );
        }

        $currency = sanitize_text_field( $_POST['currency'] ?? 'BDT' );
        $country = sanitize_text_field( $_POST['country'] ?? 'BD' );
        $tax_enabled = isset( $_POST['tax_enabled'] ) && $_POST['tax_enabled'] === 'true';

        $settings = get_option( 'ts_lms_settings', array() );
        $settings['currency'] = $currency;
        $settings['country'] = $country;
        $settings['tax_enabled'] = $tax_enabled;

        update_option( 'ts_lms_settings', $settings );

        wp_send_json_success( array(
            'message' => __( 'Settings saved successfully!', 'ts-lms' ),
        ) );
    }

    /**
     * AJAX: Create pages.
     */
    public function handle_ajax_create_pages() {
        check_ajax_referer( 'ts_lms_wizard_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Unauthorized', 'ts-lms' ) ) );
        }

        // Use existing PageManager to create pages
        if ( class_exists( '\\TS_LMS\\Setup\\PageManager' ) ) {
            PageManager::instance()->create_pages();
            
            wp_send_json_success( array(
                'message' => __( 'Pages created successfully!', 'ts-lms' ),
            ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'PageManager class not found.', 'ts-lms' ) ) );
        }
    }

    /**
     * AJAX: Check WooCommerce status.
     */
    public function handle_ajax_check_woocommerce() {
        check_ajax_referer( 'ts_lms_wizard_nonce', 'nonce' );

        $status = $this->get_woocommerce_status();
        wp_send_json_success( $status );
    }

    /**
     * Get WooCommerce installation status.
     *
     * @return array
     */
    private function get_woocommerce_status() {
        $plugin_path = 'woocommerce/woocommerce.php';
        
        if ( is_plugin_active( $plugin_path ) ) {
            return array(
                'status' => 'active',
                'message' => __( 'WooCommerce is installed and active', 'ts-lms' ),
            );
        }

        $all_plugins = get_plugins();
        if ( isset( $all_plugins[$plugin_path] ) ) {
            return array(
                'status' => 'inactive',
                'message' => __( 'WooCommerce is installed but not active', 'ts-lms' ),
            );
        }

        return array(
            'status' => 'not_installed',
            'message' => __( 'WooCommerce is not installed', 'ts-lms' ),
        );
    }

    /**
     * AJAX: Install/Activate WooCommerce.
     */
    public function handle_ajax_install_woocommerce() {
        check_ajax_referer( 'ts_lms_wizard_nonce', 'nonce' );

        if ( ! current_user_can( 'install_plugins' ) ) {
            wp_send_json_error( array( 'message' => __( 'Unauthorized', 'ts-lms' ) ) );
        }

        $plugin_path = 'woocommerce/woocommerce.php';
        $status = $this->get_woocommerce_status();

        if ( $status['status'] === 'active' ) {
            wp_send_json_success( array( 'message' => __( 'WooCommerce is already active', 'ts-lms' ) ) );
            return;
        }

        if ( $status['status'] === 'inactive' ) {
            // Just activate
            $result = activate_plugin( $plugin_path );
            if ( is_wp_error( $result ) ) {
                wp_send_json_error( array( 'message' => $result->get_error_message() ) );
            } else {
                wp_send_json_success( array( 'message' => __( 'WooCommerce activated successfully!', 'ts-lms' ) ) );
            }
            return;
        }

        // Need to install
        include_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        include_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';

        $api = plugins_api( 'plugin_information', array(
            'slug'   => 'woocommerce',
            'fields' => array( 'sections' => false ),
        ) );

        if ( is_wp_error( $api ) ) {
            wp_send_json_error( array( 'message' => $api->get_error_message() ) );
            return;
        }

        $upgrader = new \Plugin_Upgrader( new \WP_Ajax_Upgrader_Skin() );
        $result = $upgrader->install( $api->download_link );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
            return;
        }

        // Activate after installation
        $activate_result = activate_plugin( $plugin_path );
        if ( is_wp_error( $activate_result ) ) {
            wp_send_json_error( array( 'message' => $activate_result->get_error_message() ) );
        } else {
            wp_send_json_success( array( 'message' => __( 'WooCommerce installed and activated successfully!', 'ts-lms' ) ) );
        }
    }

    /**
     * AJAX: Import sample data.
     */
    public function handle_ajax_import_sample_data() {
        check_ajax_referer( 'ts_lms_wizard_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Unauthorized', 'ts-lms' ) ) );
        }

        // Load SampleDataImporter
        require_once TS_LMS_PLUGIN_DIR . 'includes/Setup/SampleDataImporter.php';
        
        $importer = new SampleDataImporter();
        $result = $importer->import();

        if ( $result['success'] ) {
            update_option( 'ts_lms_sample_data_imported', true );
            wp_send_json_success( $result );
        } else {
            wp_send_json_error( $result );
        }
    }

    /**
     * AJAX: Complete wizard.
     */
    public function handle_ajax_complete_wizard() {
        check_ajax_referer( 'ts_lms_wizard_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Unauthorized', 'ts-lms' ) ) );
        }

        update_option( 'ts_lms_wizard_completed', true );

        wp_send_json_success( array(
            'message' => __( 'Setup completed successfully!', 'ts-lms' ),
            'redirect' => admin_url( 'admin.php?page=ts-lms' ),
        ) );
    }

    /**
     * AJAX: Skip wizard.
     */
    public function handle_ajax_skip_wizard() {
        check_ajax_referer( 'ts_lms_wizard_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Unauthorized', 'ts-lms' ) ) );
        }

        update_option( 'ts_lms_wizard_skipped', true );
        update_option( 'ts_lms_wizard_completed', true ); // Mark as completed to prevent auto-redirect

        wp_send_json_success( array(
            'message' => __( 'Wizard skipped', 'ts-lms' ),
            'redirect' => admin_url( 'admin.php?page=ts-lms' ),
        ) );
    }
}
