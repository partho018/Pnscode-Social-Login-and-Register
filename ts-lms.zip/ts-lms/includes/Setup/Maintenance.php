<?php
namespace TS_LMS\Setup;

/**
 * Maintenance Mode Handler.
 */
class Maintenance {

    /**
     * Instance of this class.
     */
    private static $instance = null;

    /**
     * Get instance.
     */
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'template_redirect', array( $this, 'handle_maintenance_mode' ), 1 );
    }

    /**
     * Handle maintenance mode.
     */
    public function handle_maintenance_mode() {
        // Get settings
        if ( ! class_exists( '\TS_LMS\Admin\Settings' ) ) {
            return;
        }

        $settings = \TS_LMS\Admin\Settings::get_settings();
        $maintenance_mode = isset( $settings['maintenance_mode'] ) ? $settings['maintenance_mode'] : 0;

        if ( ! $maintenance_mode ) {
            return;
        }

        // If user is administrator, allow access
        if ( current_user_can( 'manage_options' ) ) {
            return;
        }

        // Allow access to login page
        $action = isset( $_GET['action'] ) ? $_GET['action'] : '';
        if ( $GLOBALS['pagenow'] === 'wp-login.php' || strpos( $_SERVER['REQUEST_URI'], 'wp-login.php' ) !== false || $action === 'logout' ) {
            return;
        }

        // Show maintenance message
        $this->render_maintenance_page();
        exit;
    }

    /**
     * Render maintenance page.
     */
    private function render_maintenance_page() {
        $site_name = get_bloginfo( 'name' );
        $message = __( 'Something exciting is cooking! We are currently fine-tuning our platform to provide you with the best learning experience. We will be back before you know it.', 'ts-lms' );
        $title = __( 'Currently Improving', 'ts-lms' );
        $primary_color = '#6366f1'; // Indigo fallback
        
        if ( class_exists( '\TS_LMS\Admin\Settings' ) ) {
            $settings = \TS_LMS\Admin\Settings::get_settings();
            $primary_color = isset( $settings['primary_color'] ) ? $settings['primary_color'] : '#6366f1';
        }

        status_header( 503 );
        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo( 'charset' ); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php echo esc_html( $site_name ); ?> - <?php _e( 'Under Maintenance', 'ts-lms' ); ?></title>
            <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
            <style>
                :root {
                    --primary: <?php echo esc_attr( $primary_color ); ?>;
                    --primary-soft: <?php echo esc_attr( $primary_color ); ?>15;
                    --primary-glow: <?php echo esc_attr( $primary_color ); ?>40;
                }

                * { box-sizing: border-box; }

                body {
                    margin: 0;
                    padding: 0;
                    font-family: 'Plus Jakarta Sans', sans-serif;
                    background: #0f172a;
                    height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: #f8fafc;
                    overflow: hidden;
                }

                /* Animated Mesh Gradient Background */
                .bg-wrapper {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    z-index: -1;
                    background-color: #0f172a;
                    background-image: 
                        radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.15) 0px, transparent 50%),
                        radial-gradient(at 100% 0%, rgba(168, 85, 247, 0.15) 0px, transparent 50%),
                        radial-gradient(at 100% 100%, rgba(236, 72, 153, 0.15) 0px, transparent 50%),
                        radial-gradient(at 0% 100%, rgba(59, 130, 246, 0.15) 0px, transparent 50%);
                    animation: movement 20s infinite alternate linear;
                }

                @keyframes movement {
                    0% { filter: hue-rotate(0deg); }
                    100% { filter: hue-rotate(45deg); }
                }

                .floating-objects span {
                    position: absolute;
                    background: white;
                    border-radius: 50%;
                    opacity: 0.1;
                    filter: blur(20px);
                    animation: float-around 25s infinite alternate ease-in-out;
                }

                .obj-1 { width: 300px; height: 300px; top: 10%; left: 10%; background: var(--primary); }
                .obj-2 { width: 250px; height: 250px; bottom: 10%; right: 10%; background: #a855f7; animation-delay: -5s; }

                @keyframes float-around {
                    0% { transform: translate(0, 0) rotate(0deg); }
                    100% { transform: translate(100px, 50px) rotate(360deg); }
                }

                /* Glassmorphism Card */
                .maintenance-card {
                    background: rgba(30, 41, 59, 0.7);
                    backdrop-filter: blur(20px);
                    -webkit-backdrop-filter: blur(20px);
                    padding: 60px 50px;
                    border-radius: 32px;
                    border: 1px solid rgba(255, 255, 255, 0.1);
                    text-align: center;
                    max-width: 600px;
                    width: 90%;
                    position: relative;
                    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
                    animation: fadeInUp 1s cubic-bezier(0.16, 1, 0.3, 1);
                }

                @keyframes fadeInUp {
                    from { opacity: 0; transform: translateY(40px); }
                    to { opacity: 1; transform: translateY(0); }
                }

                .top-badge {
                    display: inline-flex;
                    align-items: center;
                    background: var(--primary-soft);
                    color: var(--primary);
                    padding: 8px 16px;
                    border-radius: 100px;
                    font-size: 12px;
                    font-weight: 700;
                    text-transform: uppercase;
                    letter-spacing: 0.1em;
                    margin-bottom: 30px;
                    border: 1px solid var(--primary-glow);
                }

                .brand-name {
                    font-size: 18px;
                    font-weight: 800;
                    margin-bottom: 40px;
                    background: linear-gradient(to right, #fff, rgba(255,255,255,0.6));
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                }

                /* Visual Loader */
                .visual-loader {
                    width: 100px;
                    height: 100px;
                    margin: 0 auto 40px;
                    position: relative;
                }

                .loader-ring {
                    position: absolute;
                    width: 100%;
                    height: 100%;
                    border: 3px solid transparent;
                    border-top-color: var(--primary);
                    border-radius: 50%;
                    animation: spin 1.5s linear infinite;
                }

                .loader-ring:nth-child(2) {
                    width: 70%;
                    height: 70%;
                    top: 15%;
                    left: 15%;
                    border-top-color: #a855f7;
                    animation-direction: reverse;
                    animation-duration: 2s;
                }

                .loader-core {
                    position: absolute;
                    width: 20px;
                    height: 20px;
                    background: white;
                    border-radius: 50%;
                    top: 40px;
                    left: 40px;
                    box-shadow: 0 0 20px var(--primary);
                    animation: pulse-core 2s infinite ease-in-out;
                }

                @keyframes spin {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }

                @keyframes pulse-core {
                    0%, 100% { transform: scale(1); opacity: 0.8; }
                    50% { transform: scale(1.3); opacity: 1; }
                }

                h1 {
                    font-size: 42px;
                    font-weight: 800;
                    margin: 0 0 20px 0;
                    color: white;
                    letter-spacing: -0.03em;
                    line-height: 1.1;
                }

                p {
                    font-size: 18px;
                    line-height: 1.7;
                    color: #94a3b8;
                    margin: 0 auto;
                    max-width: 440px;
                }

                /* Modern Progress bar */
                .progress-container {
                    margin-top: 50px;
                    width: 100%;
                    height: 6px;
                    background: rgba(255,255,255,0.05);
                    border-radius: 10px;
                    overflow: hidden;
                    position: relative;
                }

                .progress-bar {
                    position: absolute;
                    height: 100%;
                    width: 30%;
                    background: linear-gradient(90deg, transparent, var(--primary), transparent);
                    animation: loading-wave 2s infinite ease-in-out;
                }

                @keyframes loading-wave {
                    0% { left: -30%; }
                    100% { left: 100%; }
                }

                .social-links {
                    margin-top: 40px;
                    display: flex;
                    justify-content: center;
                    gap: 20px;
                }

                .social-icon {
                    width: 40px;
                    height: 40px;
                    border-radius: 12px;
                    background: rgba(255,255,255,0.05);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.3s ease;
                    color: #94a3b8;
                    text-decoration: none;
                }

                .social-icon:hover {
                    background: var(--primary);
                    color: white;
                    transform: translateY(-5px);
                    box-shadow: 0 10px 20px -5px var(--primary-glow);
                }

                @media (max-width: 640px) {
                    .maintenance-card { padding: 40px 25px; }
                    h1 { font-size: 32px; }
                    p { font-size: 16px; }
                }
            </style>
        </head>
        <body>
            <div class="bg-wrapper">
                <div class="floating-objects">
                    <span class="obj-1"></span>
                    <span class="obj-2"></span>
                </div>
            </div>

            <div class="maintenance-card">
                <div class="brand-name"><?php echo esc_html( $site_name ); ?></div>
                
                <div class="top-badge"><?php _e( 'System Upgrade', 'ts-lms' ); ?></div>

                <div class="visual-loader">
                    <div class="loader-ring"></div>
                    <div class="loader-ring"></div>
                    <div class="loader-core"></div>
                </div>

                <h1><?php echo esc_html( $title ); ?></h1>
                <p><?php echo esc_html( $message ); ?></p>

                <div class="progress-container">
                    <div class="progress-bar"></div>
                </div>

                <div class="social-links">
                    <div style="font-size: 12px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em;">
                        <?php _e( 'Stay tuned for updates', 'ts-lms' ); ?>
                    </div>
                </div>
            </div>
        </body>
        </html>
        <?php
    }
}
