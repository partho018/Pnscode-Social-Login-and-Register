<?php
/**
 * Global helper functions for TS LMS
 */

if ( ! function_exists( 'ts_lms_is_notification_enabled' ) ) {
    /**
     * Check if a specific notification is enabled.
     * 
     * @param string $item_id The notification item ID (e.g. 'course_enrolled')
     * @param string $type The notification type: 'email', 'onsite', or 'push'
     * @param string $category The category if it's an email: 'student', 'instructor', or 'admin'
     * @return bool
     */
    function ts_lms_is_notification_enabled( $item_id, $type = 'onsite', $category = '' ) {
        $settings = get_option( 'ts_lms_settings', array() );
        
        if ( $type === 'email' ) {
            $key = "email_notify_{$category}_{$item_id}";
            return isset( $settings[$key] ) && $settings[$key];
        } else {
            return isset( $settings['notifications'][$item_id][$type] ) && $settings['notifications'][$item_id][$type];
        }
    }
}

if ( ! function_exists( 'ts_lms_format_price' ) ) {
    /**
     * Format price with currency
     * 
     * @param float $price
     * @return string
     */
    function ts_lms_format_price( $price ) {
        // If WooCommerce is active, use its formatting
        if ( function_exists( 'wc_price' ) ) {
            return wc_price( $price );
        }
        
        $currency = '$'; // Default
        return $currency . number_format( (float) $price, 2 );
    }
}
