<?php
/**
 * License Validator Class
 * Validates licenses with the Vercel API
 * 
 * @package TS_LMS
 */

namespace TS_LMS\Admin;

class LicenseValidator {
    
    // This should be updated to the actual Vercel deployment URL
    private static $api_url = 'https://license-manager-lms.vercel.app';
    private static $api_key = 'tslms_secure_api_key_2024_v1'; // Must match Vercel API_SECRET_KEY env var
    
    /**
     * Validate license with API
     */
    public static function validate_with_api($license_key, $email) {
        $api_endpoint = self::$api_url . '/api/validate';
        
        $response = wp_remote_post($api_endpoint, array(
            'timeout' => 15,
            'sslverify' => false, // Set to true in production
            'headers' => array(
                'Content-Type' => 'application/json',
                'x-api-key' => self::$api_key
            ),
            'body' => json_encode(array(
                'license_key' => trim($license_key),
                'email' => trim($email),
                'domain' => get_site_url()
            ))
        ));
        
        if (is_wp_error($response)) {
            return array(
                'valid' => false,
                'message' => 'API connection failed: ' . $response->get_error_message()
            );
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($code === 401) {
            return array('valid' => false, 'message' => 'API Key mismatch or unauthorized.');
        }

        if (!$data || !isset($data['success'])) {
            return array(
                'valid' => false, 
                'message' => 'Invalid API response'
            );
        }
        
        if (!$data['success']) {
            return array(
                'valid' => false,
                'message' => $data['message'] ?? 'License validation failed'
            );
        }
        
        // Return success with valid flag
        $result = $data['data'];
        $result['valid'] = true;
        return $result;
    }
    
    /**
     * Validate and cache license
     */
    public static function validate_license($license_key, $email, $use_cache = true) {
        $cache_key = 'ts_lms_license_validation_' . md5($license_key . $email);
        
        // Check cache first (if enabled)
        if ($use_cache) {
            $cached = get_transient($cache_key);
            if ($cached !== false) {
                return $cached;
            }
        }
        
        // 1. Try to validate with API first (to support remote deactivation)
        $result = self::validate_with_api($license_key, $email);
        
        // 2. Localhost fallback: If API fails or key is missing, check if it's local
        if ((!isset($result['valid']) || !$result['valid']) && !empty($license_key)) {
            $site_url = strtolower(get_site_url());
            $http_host = isset($_SERVER['HTTP_HOST']) ? strtolower($_SERVER['HTTP_HOST']) : '';
            
            if (strpos($site_url, 'localhost') !== false || 
                strpos($site_url, '127.0.0.1') !== false || 
                strpos($http_host, 'localhost') !== false) {
                
                // If the server specifically said it's DEACTIVATED or INVALID, respect that!
                if (isset($result['message']) && (strpos($result['message'], 'deactivated') !== false || strpos($result['message'], 'Invalid') !== false)) {
                    update_option('ts_lms_license_status', 'inactive');
                    return $result;
                }

                // Otherwise, allow local development if API is just unreachable
                $result = array(
                    'valid' => true,
                    'status' => 'active',
                    'message' => 'Local Development Mode',
                    'expires' => date('Y-12-31')
                );
            }
        }
        
        // Cache and sync status
        if (isset($result['valid']) && $result['valid']) {
            set_transient($cache_key, $result, 1 * HOUR_IN_SECONDS);
            update_option('ts_lms_license_status', 'active');
        } else {
            update_option('ts_lms_license_status', 'inactive');
        }
        
        return $result;
    }

    /**
     * Check current license status and deactivate locally if needed
     */
    public static function check_local_license() {
        $license_key = get_option('ts_lms_license_key');
        $email = get_option('ts_lms_license_email');
        $status = get_option('ts_lms_license_status');

        if (!$license_key || !$email || $status !== 'active') {
            return;
        }

        // Validate (this will use cache if available, otherwise it hits the API)
        self::validate_license($license_key, $email);
    }
    
    /**
     * Clear license cache
     */
    public static function clear_cache($license_key = null, $email = null) {
        if ($license_key && $email) {
            $cache_key = 'ts_lms_license_validation_' . md5($license_key . $email);
            delete_transient($cache_key);
        } else {
            // Clear all license caches
            global $wpdb;
            $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_ts_lms_license_validation_%'");
            $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_ts_lms_license_validation_%'");
        }
    }

    /**
     * Get local license status
     */
    public static function get_status() {
        return get_option('ts_lms_license_status', 'inactive');
    }

    /**
     * Check if license is active
     */
    public static function is_active() {
        return self::get_status() === 'active';
    }
}
