<?php
namespace TS_LMS\Admin;

/**
 * Admin Menu Handler.
 */
class Menu {

    /**
     * Initialize the menu.
     */
    public static function init() {
        add_action( 'admin_init', array( __CLASS__, 'handle_admin_init' ) );
        add_action( 'admin_menu', array( __CLASS__, 'register_menus' ) );
        // Fix for highlighting parent menu for CPTs and Taxonomies
        add_filter( 'parent_file', array( __CLASS__, 'highlight_parent_menu' ) );
        add_filter( 'submenu_file', array( __CLASS__, 'highlight_submenu_file' ) );
        
        // AJAX for Order Status
        add_action( 'wp_ajax_ts_lms_update_order_status', array( __CLASS__, 'update_order_status' ) );
        
        // AJAX for Reset Settings
        add_action( 'wp_ajax_ts_lms_reset_settings', array( '\\TS_LMS\\Admin\\Settings', 'ajax_reset_settings' ) );

        // AJAX for Manual Campaign
        add_action( 'wp_ajax_ts_lms_send_manual_campaign', array( '\\TS_LMS\\Admin\\Settings', 'ajax_send_manual_campaign' ) );
        
        // AJAX for Google Meet Credentials
        add_action( 'wp_ajax_ts_lms_save_google_meet_credentials', array( __CLASS__, 'ajax_save_google_meet_credentials' ) );

        // License Enforcement
        self::register_license_enforcement();
    }

    /**
     * Handle actions on admin init.
     */
    public static function handle_admin_init() {
        if ( class_exists( '\TS_LMS\Admin\Settings' ) ) {
            \TS_LMS\Admin\Settings::handle_save();
        }
        
        // Handle Google Meet settings save
        if ( isset( $_POST['ts_lms_save_google_meet_settings'] ) ) {
            self::save_google_meet_settings();
        }
        
        // Handle Zoom credentials save
        if ( isset( $_POST['ts_lms_save_zoom_credentials'] ) ) {
            self::save_zoom_credentials();
        }
        
        // Handle License Activation
        if ( isset( $_POST['ts_lms_action'] ) && $_POST['ts_lms_action'] === 'activate_license' ) {
            self::handle_license_activation();
        }
        
        // Handle License Deactivation
        if ( isset( $_POST['ts_lms_action'] ) && $_POST['ts_lms_action'] === 'deactivate_license' ) {
            self::handle_license_deactivation();
        }

        // Periodically check license status with server
        if ( class_exists( '\TS_LMS\Admin\LicenseValidator' ) ) {
            \TS_LMS\Admin\LicenseValidator::check_local_license();
        }
    }
    
    /**
     * Save Google Meet settings.
     */
    private static function save_google_meet_settings() {
        // Verify nonce
        if ( ! isset( $_POST['ts_lms_google_meet_nonce'] ) || 
             ! wp_verify_nonce( $_POST['ts_lms_google_meet_nonce'], 'ts_lms_google_meet_settings' ) ) {
            return;
        }
        
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        
        // Save settings
        if ( isset( $_POST['ts_lms_google_meet_timezone'] ) ) {
            update_option( 'ts_lms_google_meet_timezone', sanitize_text_field( $_POST['ts_lms_google_meet_timezone'] ) );
        }
        
        if ( isset( $_POST['ts_lms_google_meet_reminder'] ) ) {
            update_option( 'ts_lms_google_meet_reminder', sanitize_text_field( $_POST['ts_lms_google_meet_reminder'] ) );
        }
        
        if ( isset( $_POST['ts_lms_google_meet_event_status'] ) ) {
            update_option( 'ts_lms_google_meet_event_status', sanitize_text_field( $_POST['ts_lms_google_meet_event_status'] ) );
        }
        
        if ( isset( $_POST['ts_lms_google_meet_send_updates'] ) ) {
            update_option( 'ts_lms_google_meet_send_updates', sanitize_text_field( $_POST['ts_lms_google_meet_send_updates'] ) );
        }
        
        if ( isset( $_POST['ts_lms_google_meet_transparency'] ) ) {
            update_option( 'ts_lms_google_meet_transparency', sanitize_text_field( $_POST['ts_lms_google_meet_transparency'] ) );
        }
        
        if ( isset( $_POST['ts_lms_google_meet_visibility'] ) ) {
            update_option( 'ts_lms_google_meet_visibility', sanitize_text_field( $_POST['ts_lms_google_meet_visibility'] ) );
        }
        
        // Redirect with success message
        wp_redirect( add_query_arg( array( 
            'page' => 'ts-lms-google-meet', 
            'tab' => 'settings',
            'settings-updated' => 'true' 
        ), admin_url( 'admin.php' ) ) );
        exit;
    }
    
    /**
     * AJAX handler to save Google Meet credentials.
     */
    public static function ajax_save_google_meet_credentials() {
        check_ajax_referer( 'ts_lms_google_meet_settings', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }

        $credentials_json = isset( $_POST['credentials'] ) ? $_POST['credentials'] : '';
        $credentials = json_decode( stripslashes( $credentials_json ), true );

        if ( ! $credentials || ! isset( $credentials['client_id'] ) || ! isset( $credentials['client_secret'] ) ) {
            wp_send_json_error( array( 'message' => 'Invalid credentials format' ) );
        }

        update_option( 'ts_lms_google_meet_client_id', sanitize_text_field( $credentials['client_id'] ) );
        update_option( 'ts_lms_google_meet_client_secret', sanitize_text_field( $credentials['client_secret'] ) );
        update_option( 'ts_lms_google_meet_credentials', $credentials ); // Store full JSON for later use

        wp_send_json_success( array( 'message' => 'Credentials saved successfully' ) );
    }

    /**
     * Get Google Meet Authorization URL.
     */
    private static function get_google_meet_auth_url() {
        $client_id = get_option( 'ts_lms_google_meet_client_id' );
        $redirect_uri = admin_url( 'admin.php?page=ts-lms-google-meet' );
        $scope = 'https://www.googleapis.com/auth/calendar.events';
        
        return "https://accounts.google.com/o/oauth2/v2/auth?" . http_build_query( array(
            'client_id'     => $client_id,
            'redirect_uri'  => $redirect_uri,
            'response_type' => 'code',
            'scope'         => $scope,
            'access_type'   => 'offline',
            'prompt'        => 'consent',
        ) );
    }

    /**
     * Handle Google Meet OAuth Callback.
     */
    private static function handle_google_meet_oauth_callback( $code ) {
        if ( empty( $code ) ) return;

        $client_id = get_option( 'ts_lms_google_meet_client_id' );
        $client_secret = get_option( 'ts_lms_google_meet_client_secret' );
        $redirect_uri = admin_url( 'admin.php?page=ts-lms-google-meet' );

        $response = wp_remote_post( 'https://oauth2.googleapis.com/token', array(
            'body' => array(
                'code'          => $code,
                'client_id'     => $client_id,
                'client_secret' => $client_secret,
                'redirect_uri'  => $redirect_uri,
                'grant_type'    => 'authorization_code',
            ),
        ) );

        if ( is_wp_error( $response ) ) {
            return;
        }

        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( isset( $data['access_token'] ) ) {
            $data['created'] = time();
            update_option( 'ts_lms_google_meet_token', $data );
            
            // Redirect to clear the code from URL
            wp_redirect( admin_url( 'admin.php?page=ts-lms-google-meet&authorized=true' ) );
            exit;
        }
    }

    /**
     * Save Zoom credentials.
     */
    private static function save_zoom_credentials() {
        // Verify nonce
        if ( ! isset( $_POST['ts_lms_zoom_nonce'] ) || 
             ! wp_verify_nonce( $_POST['ts_lms_zoom_nonce'], 'ts_lms_zoom_credentials' ) ) {
            return;
        }
        
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        
        // Save credentials
        if ( isset( $_POST['ts_lms_zoom_account_id'] ) ) {
            update_option( 'ts_lms_zoom_account_id', sanitize_text_field( $_POST['ts_lms_zoom_account_id'] ) );
        }
        
        if ( isset( $_POST['ts_lms_zoom_client_id'] ) ) {
            update_option( 'ts_lms_zoom_client_id', sanitize_text_field( $_POST['ts_lms_zoom_client_id'] ) );
        }
        
        if ( isset( $_POST['ts_lms_zoom_client_secret'] ) ) {
            update_option( 'ts_lms_zoom_client_secret', sanitize_text_field( $_POST['ts_lms_zoom_client_secret'] ) );
        }
        
        // Redirect with success message
        wp_redirect( add_query_arg( array( 
            'page' => 'ts-lms-zoom', 
            'tab' => 'setup',
            'credentials-saved' => 'true' 
        ), admin_url( 'admin.php' ) ) );
        exit;
    }

    /**
     * Handle License Activation.
     */
    private static function handle_license_activation() {
        // Verify nonce
        if ( ! isset( $_POST['ts_lms_license_nonce'] ) || 
             ! wp_verify_nonce( $_POST['ts_lms_license_nonce'], 'ts_lms_activate_license' ) ) {
            wp_die( __( 'Security check failed', 'ts-lms' ) );
        }
        
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Permission denied', 'ts-lms' ) );
        }
        
        // Get form data
        $license_key = isset( $_POST['ts_lms_license_key'] ) ? sanitize_text_field( $_POST['ts_lms_license_key'] ) : '';
        $license_email = isset( $_POST['ts_lms_license_email'] ) ? sanitize_email( $_POST['ts_lms_license_email'] ) : '';
        
        // Validate inputs
        if ( empty( $license_key ) || empty( $license_email ) ) {
            wp_redirect( add_query_arg( array( 
                'page' => 'ts-lms-license', 
                'tab' => 'activation',
                'error' => 'missing_fields' 
            ), admin_url( 'admin.php' ) ) );
            exit;
        }
        
        
        // Validate with API if LicenseValidator class exists
        if ( class_exists( '\TS_LMS\Admin\LicenseValidator' ) ) {
            $validation = \TS_LMS\Admin\LicenseValidator::validate_license( $license_key, $license_email, false );
            
            // Debug log
            error_log('License Activation - Validation Result: ' . print_r($validation, true));
            
            if ( !isset( $validation['valid'] ) || !$validation['valid'] ) {
                $error_msg = isset( $validation['message'] ) ? $validation['message'] : 'invalid_license';
                wp_redirect( add_query_arg( array( 
                    'page' => 'ts-lms-license', 
                    'tab' => 'activation',
                    'error' => 'api_error',
                    'msg' => urlencode($error_msg)
                ), admin_url( 'admin.php' ) ) );
                exit;
            }
            
            // License is valid, save data from API response
            update_option( 'ts_lms_license_key', $license_key );
            update_option( 'ts_lms_license_email', $license_email );
            update_option( 'ts_lms_license_status', $validation['status'] ?? 'active' );
            update_option( 'ts_lms_license_activated_at', current_time( 'mysql' ) );
            
            if ( isset( $validation['expires'] ) && $validation['expires'] ) {
                update_option( 'ts_lms_license_expires', $validation['expires'] );
            }
        } else {
            // No LicenseValidator class found, fail activation
            wp_redirect( add_query_arg( array( 
                'page' => 'ts-lms-license', 
                'tab' => 'activation',
                'error' => 'invalid_license' 
            ), admin_url( 'admin.php' ) ) );
            exit;
        }
        
        // Redirect with success message
        wp_redirect( add_query_arg( array( 
            'page' => 'ts-lms-license', 
            'tab' => 'activation',
            'activated' => 'true' 
        ), admin_url( 'admin.php' ) ) );
        exit;
    }
    
    /**
     * Handle License Deactivation.
     */
    private static function handle_license_deactivation() {
        // Verify nonce
        if ( ! isset( $_POST['ts_lms_license_nonce'] ) || 
             ! wp_verify_nonce( $_POST['ts_lms_license_nonce'], 'ts_lms_deactivate_license' ) ) {
            wp_die( __( 'Security check failed', 'ts-lms' ) );
        }
        
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Permission denied', 'ts-lms' ) );
        }
        
        // Delete license options to persist deactivation
        delete_option( 'ts_lms_license_key' );
        delete_option( 'ts_lms_license_email' );
        delete_option( 'ts_lms_license_status' );
        delete_option( 'ts_lms_license_expires' );
        
        // Clear validation cache
        if ( class_exists( '\TS_LMS\Admin\LicenseValidator' ) ) {
            \TS_LMS\Admin\LicenseValidator::clear_cache();
        }

        update_option( 'ts_lms_license_status', 'inactive' );
        update_option( 'ts_lms_license_deactivated_at', current_time( 'mysql' ) );
        
        // Redirect with success message
        wp_redirect( add_query_arg( array( 
            'page' => 'ts-lms-license', 
            'tab' => 'activation',
            'deactivated' => 'true' 
        ), admin_url( 'admin.php' ) ) );
        exit;
    }

    /**
     * Update order status via AJAX.
     */
    public static function update_order_status() {
        // Verify nonce
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'ts_lms_orders_action' ) ) {
            wp_send_json_error( array( 'message' => 'Invalid security token' ) );
        }

        // Check permissions
        if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }

        $order_id = isset( $_POST['order_id'] ) ? intval( $_POST['order_id'] ) : 0;
        $status = isset( $_POST['status'] ) ? sanitize_text_field( $_POST['status'] ) : '';

        if ( ! $order_id || ! $status ) {
            wp_send_json_error( array( 'message' => 'Invalid parameters' ) );
        }

        if ( ! class_exists( 'WooCommerce' ) ) {
             wp_send_json_error( array( 'message' => 'WooCommerce is not active' ) );
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            wp_send_json_error( array( 'message' => 'Order not found' ) );
        }

        try {
            $order->update_status( $status, __( 'Status updated via TS LMS.', 'ts-lms' ) );
            wp_send_json_success( array( 'message' => 'Order status updated to ' . $status ) );
        } catch ( \Exception $e ) {
            wp_send_json_error( array( 'message' => $e->getMessage() ) );
        }
    }

    /**
     * Register admin menus.
     */
    public static function register_menus() {
        // Main Menu
        add_menu_page(
            __( 'TS LMS', 'ts-lms' ),
            __( 'TS LMS', 'ts-lms' ),
            'manage_options',
            'ts-lms',
            array( __CLASS__, 'render_dashboard' ),
            'dashicons-welcome-learn-more',
            25
        );

        // Remove the auto-generated duplicate submenu
        remove_submenu_page( 'ts-lms', 'ts-lms' );

        // Courses (First position)
        add_submenu_page(
            'ts-lms',
            __( 'Courses', 'ts-lms' ),
            __( 'Courses', 'ts-lms' ),
            'manage_options',
            'ts-lms-course',
            array( '\TS_LMS\Modules\Courses\Admin\CustomCourseListPage', 'render_page' )
        );

        // Categories
        add_submenu_page(
            'ts-lms',
            __( 'Categories', 'ts-lms' ),
            __( 'Categories', 'ts-lms' ),
            'manage_options',
            'edit-tags.php?taxonomy=ts_course_category&post_type=ts_course'
        );

        // Tags
        add_submenu_page(
            'ts-lms',
            __( 'Tags', 'ts-lms' ),
            __( 'Tags', 'ts-lms' ),
            'manage_options',
            'edit-tags.php?taxonomy=ts_course_tag&post_type=ts_course'
        );

        // Reports
        // Check if Reports module class exists
        if ( class_exists( '\TS_LMS\Modules\Reports\Admin\ReportsPage' ) ) {
            add_submenu_page(
                'ts-lms',
                __( 'Reports & Analytics', 'ts-lms' ),
                __( 'Reports', 'ts-lms' ),
                'manage_options',
                'ts-lms-reports',
                array( '\TS_LMS\Modules\Reports\Admin\ReportsPage', 'render' )
            );
        }

        // Orders
        add_submenu_page(
            'ts-lms',
            __( 'Orders', 'ts-lms' ),
            __( 'Orders', 'ts-lms' ),
            'manage_options',
            'ts-lms-orders',
            array( __CLASS__, 'render_orders' )
        );

        /*
        // Announcements
        add_submenu_page(
            'ts-lms',
            __( 'Announcements', 'ts-lms' ),
            __( 'Announcements', 'ts-lms' ),
            'manage_options',
            'ts-lms-announcements',
            array( __CLASS__, 'render_announcements' )
        );
        */

        // Students
        add_submenu_page(
            'ts-lms',
            __( 'Students', 'ts-lms' ),
            __( 'Students', 'ts-lms' ),
            'manage_options',
            'ts-lms-students',
            array( __CLASS__, 'render_students' )
        );

        // Instructors
        add_submenu_page(
            'ts-lms',
            __( 'Instructors', 'ts-lms' ),
            __( 'Instructors', 'ts-lms' ),
            'manage_options',
            'ts-lms-instructors',
            array( __CLASS__, 'render_instructors' )
        );

        // Gradebook
        add_submenu_page(
            'ts-lms',
            __( 'Gradebook', 'ts-lms' ),
            __( 'Gradebook', 'ts-lms' ),
            'manage_options',
            'ts-lms-gradebook',
            array( __CLASS__, 'render_gradebook' )
        );

        // Subscriptions
        if ( class_exists( '\TS_LMS\Modules\Subscriptions\Admin\SubscriptionSettings' ) ) {
            // Check if we can link to the main subscriptions page. 
            // The module usually registers its own page. We rely on the module having a render method or similar.
            // For now, I'll link to a placeholder if I can't find the exact callback, but Subscriptions module has `SubscriptionSettings`.
            // Let's assume there is a main page for subscriptions list.
            add_submenu_page(
                'ts-lms',
                __( 'Subscriptions', 'ts-lms' ),
                __( 'Subscriptions', 'ts-lms' ),
                'manage_options',
                'ts-lms-subscriptions',
                array( '\TS_LMS\Modules\Subscriptions\Admin\SubscriptionPage', 'render' ) 
            );
        }

        // Google Meet
        add_submenu_page(
            'ts-lms',
            __( 'Google Meet', 'ts-lms' ),
            __( 'Google Meet', 'ts-lms' ),
            'manage_options',
            'ts-lms-google-meet',
            array( __CLASS__, 'render_google_meet' )
        );

        // Zoom
        add_submenu_page(
            'ts-lms',
            __( 'Zoom', 'ts-lms' ),
            __( 'Zoom', 'ts-lms' ),
            'manage_options',
            'ts-lms-zoom',
            array( __CLASS__, 'render_zoom' )
        );

        // AI Studio
        if ( class_exists( '\TS_LMS\Modules\AIStudio\Admin\AIStudioPage' ) ) {
             add_submenu_page(
                'ts-lms',
                __( 'AI Studio', 'ts-lms' ),
                __( 'AI Studio', 'ts-lms' ),
                'manage_options',
                'ts-lms-ai-studio',
                array( '\TS_LMS\Modules\AIStudio\Admin\AIStudioPage', 'render' )
            );
        } elseif ( class_exists( '\TS_LMS\Modules\AIStudio\Module' ) ) {
             // Fallback if specific page class not found but module exists
             add_submenu_page(
                'ts-lms',
                __( 'AI Studio', 'ts-lms' ),
                __( 'AI Studio', 'ts-lms' ),
                'manage_options',
                'ts-lms-ai-studio',
                array( __CLASS__, 'render_ai_studio' )
            );
        }

        // License
        add_submenu_page(
            'ts-lms',
            __( 'License', 'ts-lms' ),
            __( 'License', 'ts-lms' ),
            'manage_options',
            'ts-lms-license',
            array( __CLASS__, 'render_license' )
        );

        // Settings
        add_submenu_page(
            'ts-lms',
            __( 'Settings', 'ts-lms' ),
            __( 'Settings', 'ts-lms' ),
            'manage_options',
            'ts-lms-settings',
            array( __CLASS__, 'render_settings' )
        );

        /*
        // Upgrade to Pro
        add_submenu_page(
            'ts-lms',
            __( 'Upgrade to Pro', 'ts-lms' ),
            __( 'Upgrade to Pro', 'ts-lms' ),
            'manage_options',
            'ts-lms-upgrade',
            array( __CLASS__, 'render_upgrade' )
        );
        */
    }

    /**
     * Fix parent file highlighting for CPTs and Taxonomies.
     */
    public static function highlight_parent_menu( $parent_file ) {
        global $current_screen;

        if ( isset( $current_screen->post_type ) && 'ts_course' === $current_screen->post_type ) {
            return 'ts-lms';
        }

        if ( isset( $current_screen->taxonomy ) && ( 'ts_course_category' === $current_screen->taxonomy || 'ts_course_tag' === $current_screen->taxonomy ) ) {
            return 'ts-lms';
        }

        return $parent_file;
    }

     /**
     * Fix submenu file highlighting.
     */
    public static function highlight_submenu_file( $submenu_file ) {
        global $current_screen;

        if ( isset( $current_screen->post_type ) && 'ts_course' === $current_screen->post_type ) {
            if ( $current_screen->base === 'edit' || $current_screen->base === 'post' ) {
                 // Creating new course or editing
                 return 'ts-lms-course';
            }
        }
        
        if ( isset( $current_screen->taxonomy ) ) {
             if ( 'ts_course_category' === $current_screen->taxonomy ) {
                 return 'edit-tags.php?taxonomy=ts_course_category&post_type=ts_course';
             }
             if ( 'ts_course_tag' === $current_screen->taxonomy ) {
                 return 'edit-tags.php?taxonomy=ts_course_tag&post_type=ts_course';
             }
        }

        return $submenu_file;
    }

    // Callbacks

    public static function render_dashboard() {
        // Enqueue dashboard assets
        wp_enqueue_style( 'ts-lms-dashboard', plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/css/admin-dashboard.css', array(), time() );
        wp_enqueue_script( 'chart-js', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js', array(), '4.4.0', true );
        wp_enqueue_script( 'ts-lms-dashboard', plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/js/admin-dashboard.js', array( 'jquery', 'chart-js' ), time(), true );
        
        // Load Inter font for premium look
        add_action('admin_head', function() {
            echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
            echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
            echo '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">';
        });

        // Get statistics
        global $wpdb;
        $current_user = wp_get_current_user();
        $total_courses = wp_count_posts( 'ts_course' );
        $published_courses = isset( $total_courses->publish ) ? $total_courses->publish : 0;
        
        $student_count = count_users();
        $total_students = isset( $student_count['avail_roles']['student'] ) ? $student_count['avail_roles']['student'] : 0;
        
        // Date range
        $thirty_days_ago = date( 'Y-m-d', strtotime( '-30 days' ) );
        $seven_days_ago = date( 'Y-m-d', strtotime( '-7 days' ) );

        // Total Revenue (WooCommerce)
        $total_revenue = $wpdb->get_var( "
            SELECT SUM(pm.meta_value) 
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE p.post_type = 'shop_order'
            AND p.post_status IN ('wc-completed', 'wc-processing')
            AND pm.meta_key = '_order_total'
        " );
        $total_revenue = $total_revenue ? (float) $total_revenue : 0;

        // Recent Enrollments (Last 7 days)
        $recent_enrollments = $wpdb->get_var( $wpdb->prepare( "
            SELECT COUNT(*) 
            FROM {$wpdb->prefix}ts_course_enrollments
            WHERE enrolled_at >= %s
        ", $seven_days_ago ) );
        $total_enrollments = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ts_course_enrollments" );

        // Prepare Chart Data
        $chart_labels = array();
        $revenue_chart_data = array();
        $enrollment_chart_data = array();

        // Optimized Revenue Query
        $daily_revenues = $wpdb->get_results( $wpdb->prepare( "
            SELECT DATE(p.post_date) as date, SUM(pm.meta_value) as total
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE p.post_type = 'shop_order'
            AND p.post_status IN ('wc-completed', 'wc-processing')
            AND pm.meta_key = '_order_total'
            AND p.post_date >= %s
            GROUP BY DATE(p.post_date)
        ", $thirty_days_ago ), OBJECT_K );

        // Optimized Enrollment Query
        $daily_enrollments = $wpdb->get_results( $wpdb->prepare( "
            SELECT DATE(enrolled_at) as date, COUNT(*) as total
            FROM {$wpdb->prefix}ts_course_enrollments
            WHERE enrolled_at >= %s
            GROUP BY DATE(enrolled_at)
        ", $thirty_days_ago ), OBJECT_K );

        for ( $i = 29; $i >= 0; $i-- ) {
            $date = date( 'Y-m-d', strtotime( "-$i days" ) );
            $chart_labels[] = date( 'M d', strtotime( $date ) );
            
            $revenue_chart_data[] = isset( $daily_revenues[$date] ) ? (float) $daily_revenues[$date]->total : 0;
            $enrollment_chart_data[] = isset( $daily_enrollments[$date] ) ? (int) $daily_enrollments[$date]->total : 0;
        }

        // Get currency symbol
        $currency_symbol = '$'; // Default fallback
        if ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
            $currency_symbol = get_woocommerce_currency_symbol();
        }

        // Localize data for JS
        wp_localize_script( 'ts-lms-dashboard', 'tsLmsDashboardData', array(
            'labels'     => $chart_labels,
            'revenue'    => $revenue_chart_data,
            'enrollment' => $enrollment_chart_data,
            'currencySymbol' => $currency_symbol
        ) );

        // Get recent students
        $recent_students = get_users( array(
            'role' => 'student',
            'number' => 5,
            'orderby' => 'registered',
            'order' => 'DESC'
        ) );
        
        // Get recent courses
        $recent_courses = get_posts( array(
            'post_type' => 'ts_course',
            'posts_per_page' => 5,
            'orderby' => 'date',
            'order' => 'DESC'
        ) );
        
        ?>
        <div class="wrap ts-lms-dashboard-wrap">
            <!-- Header Section -->
            <header class="ts-dashboard-header">
                <div class="ts-dashboard-welcome">
                    <h1><?php printf( esc_html__( 'Welcome back, %s!', 'ts-lms' ), esc_html( $current_user->display_name ) ); ?></h1>
                    <p><?php esc_html_e( 'Manage your courses, students, and platform performance effectively.', 'ts-lms' ); ?></p>
                </div>
                <div class="ts-dashboard-date">
                    <span class="dashicons dashicons-calendar-alt"></span>
                    <span><?php echo esc_html( date_i18n( 'l, F j, Y', current_time( 'timestamp' ) ) ); ?></span>
                </div>
            </header>

            <!-- Key Metrics Grid -->
            <div class="ts-dashboard-stats">
                <div class="ts-stat-card ts-stat-courses">
                    <div class="ts-stat-icon">
                        <span class="dashicons dashicons-book-alt"></span>
                    </div>
                    <div class="ts-stat-content">
                        <h3 class="ts-stat-number" data-target="<?php echo esc_attr( $published_courses ); ?>">0</h3>
                        <p class="ts-stat-label"><?php esc_html_e( 'Total Courses', 'ts-lms' ); ?></p>
                    </div>
                    <div class="ts-stat-trend ts-trend-up">
                        <span class="dashicons dashicons-arrow-up-alt"></span>
                        <span>12.5%</span>
                    </div>
                </div>

                <div class="ts-stat-card ts-stat-students">
                    <div class="ts-stat-icon">
                        <span class="dashicons dashicons-groups"></span>
                    </div>
                    <div class="ts-stat-content">
                        <h3 class="ts-stat-number" data-target="<?php echo esc_attr( $total_students ); ?>">0</h3>
                        <p class="ts-stat-label"><?php esc_html_e( 'Active Students', 'ts-lms' ); ?></p>
                    </div>
                    <div class="ts-stat-trend ts-trend-up">
                        <span class="dashicons dashicons-arrow-up-alt"></span>
                        <span>8.2%</span>
                    </div>
                </div>

                <div class="ts-stat-card ts-stat-revenue">
                    <div class="ts-stat-icon">
                        <span class="dashicons dashicons-money-alt"></span>
                    </div>
                    <div class="ts-stat-content">
                        <h3 class="ts-stat-number" data-target="<?php echo esc_attr( $total_revenue ); ?>">$0</h3>
                        <p class="ts-stat-label"><?php esc_html_e( 'Total Revenue', 'ts-lms' ); ?></p>
                    </div>
                    <div class="ts-stat-trend ts-trend-up">
                        <span class="dashicons dashicons-arrow-up-alt"></span>
                        <span>24.8%</span>
                    </div>
                </div>

                <div class="ts-stat-card ts-stat-enrollments">
                    <div class="ts-stat-icon">
                        <span class="dashicons dashicons-welcome-learn-more"></span>
                    </div>
                    <div class="ts-stat-content">
                        <h3 class="ts-stat-number" data-target="<?php echo esc_attr( $recent_enrollments ); ?>">0</h3>
                        <p class="ts-stat-label"><?php esc_html_e( 'New Enrollments', 'ts-lms' ); ?></p>
                    </div>
                    <div class="ts-stat-trend ts-trend-up">
                        <span class="dashicons dashicons-arrow-up-alt"></span>
                        <span>15.3%</span>
                    </div>
                </div>
            </div>

            <!-- Main Dashboard Content -->
            <div class="ts-dashboard-grid">
                <!-- Analytics Column -->
                <div class="ts-dashboard-section ts-charts-section">
                    <div class="ts-dashboard-card">
                        <div class="ts-card-header">
                            <h2><?php esc_html_e( 'Revenue Overview', 'ts-lms' ); ?></h2>
                            <div class="ts-card-actions">
                                <select class="ts-chart-filter">
                                    <option value="7"><?php esc_html_e( 'Last 7 Days', 'ts-lms' ); ?></option>
                                    <option value="30" selected><?php esc_html_e( 'Last 30 Days', 'ts-lms' ); ?></option>
                                    <option value="90"><?php esc_html_e( 'Last 90 Days', 'ts-lms' ); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="ts-card-body">
                            <div style="height: 220px;">
                                <canvas id="ts-revenue-chart"></canvas>
                            </div>
                        </div>
                    </div>

                    <div class="ts-dashboard-card">
                        <div class="ts-card-header">
                            <h2><?php esc_html_e( 'Student Growth', 'ts-lms' ); ?></h2>
                            <div class="ts-card-actions">
                                <select class="ts-chart-filter">
                                    <option value="7"><?php esc_html_e( 'Last 7 Days', 'ts-lms' ); ?></option>
                                    <option value="30" selected><?php esc_html_e( 'Last 30 Days', 'ts-lms' ); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="ts-card-body">
                            <div style="height: 180px;">
                                <canvas id="ts-enrollment-chart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sidebar/Activity Column -->
                <div class="ts-dashboard-section ts-sidebar-section">
                    <!-- Recent Activity -->
                    <div class="ts-dashboard-card ts-recent-activity">
                        <div class="ts-card-header">
                            <h2><?php esc_html_e( 'Recent Activity', 'ts-lms' ); ?></h2>
                        </div>
                        <div class="ts-card-body">
                            <?php if ( ! empty( $recent_students ) ) : ?>
                                <div class="ts-activity-list">
                                    <?php foreach ( $recent_students as $student ) : ?>
                                        <div class="ts-activity-item">
                                            <div class="ts-activity-avatar">
                                                <?php echo get_avatar( $student->ID, 40 ); ?>
                                            </div>
                                            <div class="ts-activity-content">
                                                <p class="ts-activity-text">
                                                    <strong><?php echo esc_html( $student->display_name ); ?></strong>
                                                    <?php esc_html_e( 'registered now', 'ts-lms' ); ?>
                                                </p>
                                                <span class="ts-activity-time">
                                                    <?php echo esc_html( human_time_diff( strtotime( $student->user_registered ), current_time( 'timestamp' ) ) ); ?> 
                                                    <?php esc_html_e( 'ago', 'ts-lms' ); ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else : ?>
                                <div class="ts-empty-state">
                                    <span class="dashicons dashicons-info-outline"></span>
                                    <p><?php esc_html_e( 'No recent activity discovered.', 'ts-lms' ); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Newest Courses -->
                    <div class="ts-dashboard-card ts-newest-courses">
                        <div class="ts-card-header">
                            <h2><?php esc_html_e( 'Newest Courses', 'ts-lms' ); ?></h2>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-course' ) ); ?>" class="ts-view-all">
                                <?php esc_html_e( 'View All', 'ts-lms' ); ?>
                                <span class="dashicons dashicons-arrow-right-alt2"></span>
                            </a>
                        </div>
                        <div class="ts-card-body">
                            <?php if ( ! empty( $recent_courses ) ) : ?>
                                <div class="ts-course-grid">
                                    <?php foreach ( $recent_courses as $course ) : 
                                        $course_status = get_post_status( $course->ID );
                                        $status_class = 'status-' . $course_status;
                                        $status_label = ucfirst( $course_status );
                                    ?>
                                        <div class="ts-course-card <?php echo esc_attr( $status_class ); ?>">
                                            <div class="ts-course-thumbnail">
                                                <?php if ( has_post_thumbnail( $course->ID ) ) : ?>
                                                    <?php echo get_the_post_thumbnail( $course->ID, 'medium' ); ?>
                                                <?php else : ?>
                                                    <div class="ts-course-placeholder">
                                                        <span class="dashicons dashicons-book"></span>
                                                    </div>
                                                <?php endif; ?>
                                                <span class="ts-course-status-badge"><?php echo esc_html( $status_label ); ?></span>
                                            </div>
                                            <div class="ts-course-details">
                                                <h4 class="ts-course-title"><?php echo esc_html( $course->post_title ); ?></h4>
                                                <div class="ts-course-meta">
                                                    <span class="ts-course-date">
                                                        <span class="dashicons dashicons-calendar-alt"></span>
                                                        <?php echo esc_html( human_time_diff( strtotime( $course->post_date ), current_time( 'timestamp' ) ) ); ?>
                                                        <?php esc_html_e( 'ago', 'ts-lms' ); ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="ts-course-actions">
                                                <a href="<?php echo esc_url( get_edit_post_link( $course->ID ) ); ?>" class="ts-btn-edit">
                                                    <span class="dashicons dashicons-edit"></span>
                                                    <?php esc_html_e( 'Edit', 'ts-lms' ); ?>
                                                </a>
                                                <a href="<?php echo esc_url( get_permalink( $course->ID ) ); ?>" class="ts-btn-view" target="_blank">
                                                    <span class="dashicons dashicons-visibility"></span>
                                                    <?php esc_html_e( 'View', 'ts-lms' ); ?>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else : ?>
                                <div class="ts-empty-state">
                                    <span class="dashicons dashicons-book-alt"></span>
                                    <p><?php esc_html_e( 'No courses yet. Start by creating your first course.', 'ts-lms' ); ?></p>
                                    <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=ts_course' ) ); ?>" class="ts-btn-create">
                                        <span class="dashicons dashicons-plus-alt"></span>
                                        <?php esc_html_e( 'Create Course', 'ts-lms' ); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    // Redesigned Callbacks
    
    private static function render_redesign_header( $main_title, $sub_title, $tabs = array() ) {
        $active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : ( ! empty( $tabs ) ? array_key_first( $tabs ) : '' );
        ?>
        <div class="ts-lms-redesign-header">
            <div class="ts-lms-redesign-title">
                <h1>
                    <span class="main-title"><?php echo esc_html( $main_title ); ?></span>
                    <?php if ( $sub_title ) : ?>
                        <span class="separator">/</span>
                        <span class="sub-title"><?php echo esc_html( $sub_title ); ?></span>
                    <?php endif; ?>
                </h1>
            </div>

            <?php if ( ! empty( $tabs ) ) : ?>
            <nav class="ts-lms-redesign-nav">
                <?php foreach ( $tabs as $slug => $label ) : ?>
                    <a href="?page=<?php echo esc_attr( $_GET['page'] ); ?>&tab=<?php echo esc_attr( $slug ); ?>" class="nav-item <?php echo $active_tab === $slug ? 'active' : ''; ?>">
                        <?php echo esc_html( $label ); ?>
                    </a>
                <?php endforeach; ?>
            </nav>
            <?php endif; ?>
        </div>
        <?php
        return $active_tab;
    }

    public static function render_orders() {
        // Enqueue scripts
         wp_enqueue_script( 'ts-lms-orders', plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/js/admin-orders.js', array( 'jquery' ), '1.0.0', true );
        wp_localize_script( 'ts-lms-orders', 'ts_lms_orders', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce( 'ts_lms_orders_action' )
        ) );

        ?>
        <div class="wrap ts-lms-redesign-wrap">
            <?php 
            $current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'all';
            self::render_redesign_header( 'Orders', 'All Orders', array( 'all' => 'All Orders', 'pending' => 'Pending', 'completed' => 'Completed' ) ); 
            
            if ( ! class_exists( 'WooCommerce' ) ) {
                ?>
                <div class="notice notice-error inline"><p><?php esc_html_e( 'WooCommerce is required to view orders.', 'ts-lms' ); ?></p></div>
                </div>
                <?php
                return;
            }

            // Args for query
            $args = array(
                'limit' => 20,
                'orderby' => 'date',
                'order' => 'DESC',
                'paginate' => true,
            );

            // Handle pagination
             if ( isset( $_GET['paged'] ) ) {
                $args['page'] = intval( $_GET['paged'] );
            }

            // Tabs
            if ( $current_tab === 'pending' ) {
                $args['status'] = array( 'pending', 'processing', 'on-hold' );
            } elseif ( $current_tab === 'completed' ) {
                $args['status'] = array( 'completed' );
            }

            $results = wc_get_orders( $args );
            $orders = $results->orders;
            $total_orders = $results->total;
            $max_pages = $results->max_num_pages;
            
            ?>
            <div class="ts-lms-redesign-content">
                <div class="ts-lms-stats-grid">
                    <div class="ts-lms-premium-card">
                        <div class="ts-lms-stat-box">
                            <div class="ts-lms-stat-icon"><span class="dashicons dashicons-cart"></span></div>
                            <div class="ts-lms-stat-info">
                                <h3><?php echo esc_html( $total_orders ); ?></h3>
                                <p><?php esc_html_e( 'Total Orders', 'ts-lms' ); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ts-lms-premium-card">
                    <table class="ts-lms-modern-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Order ID', 'ts-lms' ); ?></th>
                                <th><?php esc_html_e( 'Customer', 'ts-lms' ); ?></th>
                                <th><?php esc_html_e( 'Status', 'ts-lms' ); ?></th>
                                <th><?php esc_html_e( 'Total', 'ts-lms' ); ?></th>
                                <th><?php esc_html_e( 'Date', 'ts-lms' ); ?></th>
                                <th><?php esc_html_e( 'Actions', 'ts-lms' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ( ! empty( $orders ) ) : ?>
                                <?php foreach ( $orders as $order ) : 
                                    $order_status = $order->get_status();
                                    $statuses = wc_get_order_statuses();
                                ?>
                                <tr>
                                    <td>
                                        <strong>#<?php echo esc_html( $order->get_id() ); ?></strong>
                                    </td>
                                    <td>
                                        <?php 
                                            // Get customer name
                                            $billing_first_name = $order->get_billing_first_name();
                                            $billing_last_name  = $order->get_billing_last_name();
                                            echo esc_html( $billing_first_name . ' ' . $billing_last_name );
                                            
                                            if ( empty( $billing_first_name ) && empty( $billing_last_name ) ) {
                                                echo esc_html__( 'Guest', 'ts-lms' );
                                            }
                                        ?>
                                        <div style="font-size:12px; color:#666;"><?php echo esc_html( $order->get_billing_email() ); ?></div>
                                    </td>
                                    <td>
                                        <select class="ts-order-status-select" data-order-id="<?php echo esc_attr( $order->get_id() ); ?>" data-original-status="<?php echo esc_attr( $order_status ); ?>">
                                            <?php foreach ( $statuses as $status_key => $status_label ) : ?>
                                                <option value="<?php echo esc_attr( substr( $status_key, 3 ) ); ?>" <?php selected( $order_status, substr( $status_key, 3 ) ); ?>>
                                                    <?php echo esc_html( $status_label ); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    <td><?php echo $order->get_formatted_order_total(); ?></td>
                                    <td>
                                        <?php echo esc_html( $order->get_date_created()->date_i18n( get_option( 'date_format' ) ) ); ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>" class="button button-small" target="_blank">
                                            <?php esc_html_e( 'View', 'ts-lms' ); ?>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr><td colspan="6" style="text-align:center; padding:50px;"><?php esc_html_e( 'No orders found.', 'ts-lms' ); ?></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                    <?php if ( $max_pages > 1 ) : ?>
                    <div class="ts-pagination" style="margin-top:20px; text-align:center;">
                        <?php 
                        echo paginate_links( array(
                            'base' => add_query_arg( 'paged', '%#%' ),
                            'format' => '',
                            'current' => max( 1, isset( $_GET['paged'] ) ? intval( $_GET['paged'] ) : 1 ),
                            'total' => $max_pages,
                            'prev_text' => '&laquo;',
                            'next_text' => '&raquo;'
                        ) );
                        ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }

    public static function render_announcements() {
        ?>
        <div class="wrap ts-lms-redesign-wrap">
            <?php self::render_redesign_header( 'Announcements', 'All Notifications' ); ?>
            <div class="ts-lms-redesign-content">
                <div class="ts-lms-premium-card" style="text-align: center; padding: 60px;">
                    <span class="dashicons dashicons-megaphone" style="font-size: 60px; width: 60px; height: 60px; color: #ccd0d4; margin-bottom: 20px;"></span>
                    <h2>No Announcements Yet</h2>
                    <p>Create your first announcement to notify your students.</p>
                    <button class="button button-primary button-large">Create Announcement</button>
                </div>
            </div>
        </div>
        <?php
    }

    public static function render_students() {
        $users = get_users( array( 'role__in' => array( 'student', 'subscriber' ), 'number' => 10 ) );
        $total_students = count_users();
        $student_count = isset( $total_students['avail_roles']['student'] ) ? $total_students['avail_roles']['student'] : 0;
        ?>
        <div class="wrap ts-lms-redesign-wrap">
            <?php self::render_redesign_header( 'Students', 'Directory' ); ?>
            <div class="ts-lms-redesign-content">
                <div class="ts-lms-stats-grid">
                    <div class="ts-lms-premium-card">
                        <div class="ts-lms-stat-box">
                            <div class="ts-lms-stat-icon"><span class="dashicons dashicons-groups"></span></div>
                            <div class="ts-lms-stat-info"><h3><?php echo esc_html( $student_count ); ?></h3><p>Total Students</p></div>
                        </div>
                    </div>
                </div>
                <div class="ts-lms-premium-card">
                    <table class="ts-lms-modern-table">
                        <thead><tr><th>ID</th><th>Student</th><th>Email</th><th>Phone</th><th>Enrolled Courses</th><th>Joined</th></tr></thead>
                        <tbody>
                            <?php if ( $users ) : foreach ( $users as $user ) : ?>
                                <tr>
                                    <td>#<?php echo esc_html( $user->ID ); ?></td>
                                    <td><strong><?php echo esc_html( $user->display_name ); ?></strong></td>
                                    <td><?php echo esc_html( $user->user_email ); ?></td>
                                    <td><?php echo esc_html( get_user_meta( $user->ID, 'ts_lms_phone', true ) ?: '-' ); ?></td>
                                    <td>0</td>
                                    <td><?php echo esc_html( date_i18n( get_option('date_format'), strtotime($user->user_registered) ) ); ?></td>
                                </tr>
                            <?php endforeach; else : ?>
                                <tr><td colspan="6" style="text-align:center; padding:50px;">No students found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    public static function render_gradebook() {
        ?>
        <div class="wrap ts-lms-redesign-wrap">
            <?php self::render_redesign_header( 'Gradebook', 'Class Results' ); ?>
            <div class="ts-lms-redesign-content">
                <div class="ts-lms-premium-card">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                        <h3>Student Grades</h3>
                        <select><option>Select Course</option></select>
                    </div>
                    <table class="ts-lms-modern-table">
                        <thead><tr><th>Student</th><th>Course</th><th>Average Grade</th><th>Status</th></tr></thead>
                        <tbody><tr><td colspan="4" style="text-align:center; padding:50px;">No grade data available.</td></tr></tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    public static function render_google_meet() {
        // Enqueue Google Meet specific styles
        wp_enqueue_style( 'ts-lms-google-meet', plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/css/google-meet.css', array(), '1.0.0' );
        wp_enqueue_script( 'ts-lms-google-meet', plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/js/google-meet.js', array( 'jquery' ), '1.0.0', true );
        
        // Get current tab
        $current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'setup';
        
        // Get saved settings
        $timezone = get_option( 'ts_lms_google_meet_timezone', '(GMT-11:00) Midway Island, Samoa' );
        $reminder_time = get_option( 'ts_lms_google_meet_reminder', '30' );
        $event_status = get_option( 'ts_lms_google_meet_event_status', 'confirmed' );
        $send_updates = get_option( 'ts_lms_google_meet_send_updates', 'all' );
        $transparency = get_option( 'ts_lms_google_meet_transparency', 'opaque' );
        $visibility = get_option( 'ts_lms_google_meet_visibility', 'default' );
        
        $redirect_url = admin_url( 'admin.php?page=ts-lms-google-meet' );

        // Handle OAuth code exchange if present
        if ( isset( $_GET['code'] ) ) {
            self::handle_google_meet_oauth_callback( $_GET['code'] );
        }

        $has_credentials = get_option( 'ts_lms_google_meet_client_id' ) && get_option( 'ts_lms_google_meet_client_secret' );
        $token = get_option( 'ts_lms_google_meet_token' );
        $is_authorized = ! empty( $token );
        ?>
        <div class="wrap ts-lms-google-meet-wrap">
            <div class="ts-google-meet-header">
                <h1><?php esc_html_e( 'Google Meet', 'ts-lms' ); ?></h1>
                <div class="ts-google-meet-tabs">
                    <a href="?page=ts-lms-google-meet&tab=setup" class="tab-link <?php echo $current_tab === 'setup' ? 'active' : ''; ?>"><?php esc_html_e( 'Set API', 'ts-lms' ); ?></a>
                    <a href="?page=ts-lms-google-meet&tab=settings" class="tab-link <?php echo $current_tab === 'settings' ? 'active' : ''; ?>"><?php esc_html_e( 'Settings', 'ts-lms' ); ?></a>
                    <a href="?page=ts-lms-google-meet&tab=help" class="tab-link <?php echo $current_tab === 'help' ? 'active' : ''; ?>"><?php esc_html_e( 'Help', 'ts-lms' ); ?></a>
                </div>
            </div>

            <div class="ts-google-meet-content">
                <?php if ( $current_tab === 'setup' ) : ?>
                    <!-- Setup Card -->
                    <div class="ts-google-meet-setup-card">
                        <div class="setup-content">
                            <h2><?php esc_html_e( 'Setup your Google Meet Integration', 'ts-lms' ); ?></h2>
                            <p class="setup-description">
                                <?php esc_html_e( 'To integrate with Google Meet, go to this link & create your OAuth access Credentials. During this process, copy the link below and paste it as your Redirect URI. For a more detailed guide, please refer to our', 'ts-lms' ); ?>
                                <a href="#" class="documentation-link"><?php esc_html_e( 'documentation', 'ts-lms' ); ?></a>.
                            </p>
                            
                            <div class="redirect-url-field">
                                <input type="text" readonly value="<?php echo esc_attr( $redirect_url ); ?>" id="ts-redirect-url">
                                <button type="button" class="copy-btn" id="ts-copy-btn">
                                    <?php esc_html_e( 'Copy', 'ts-lms' ); ?>
                                </button>
                            </div>
                        </div>
                        
                        <div class="setup-illustration">
                            <svg viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
                                <!-- Person 1 (Left) -->
                                <g class="person-left">
                                    <circle cx="100" cy="120" r="30" fill="#FDB797"/>
                                    <path d="M 70 110 Q 70 80 100 80 Q 130 80 130 110" fill="#8B4513"/>
                                    <rect x="75" y="150" width="50" height="60" rx="25" fill="#FF6B6B"/>
                                    <circle cx="70" cy="170" r="12" fill="#FFD93D"/>
                                    <circle cx="130" cy="170" r="12" fill="#FFD93D"/>
                                    <rect x="85" y="165" width="30" height="20" rx="3" fill="#4CAF50"/>
                                    <circle cx="95" cy="175" r="3" fill="white"/>
                                    <circle cx="105" cy="175" r="3" fill="white"/>
                                </g>
                                
                                <g class="person-right">
                                    <circle cx="300" cy="140" r="35" fill="#A0D8F1"/>
                                    <path d="M 265 130 Q 265 95 300 95 Q 335 95 335 130" fill="#2C3E50"/>
                                    <rect x="270" y="175" width="60" height="80" rx="30" fill="#4A90E2"/>
                                    <ellipse cx="340" cy="200" rx="15" ry="25" fill="#4A90E2" transform="rotate(-30 340 200)"/>
                                    <circle cx="350" cy="190" r="10" fill="#A0D8F1"/>
                                </g>
                                
                                <g class="floating-icons">
                                    <rect x="180" y="80" width="30" height="30" rx="3" fill="#34A853"/>
                                    <rect x="185" y="75" width="20" height="5" fill="#34A853"/>
                                    <line x1="190" y1="95" x2="200" y2="95" stroke="white" stroke-width="2"/>
                                    <circle cx="250" cy="100" r="15" fill="#FBBC04"/>
                                    <path d="M 245 95 L 245 105 L 255 100 Z" fill="white"/>
                                </g>
                            </svg>
                        </div>
                    </div>

                    <!-- File Upload Card -->
                    <div class="ts-google-meet-upload-card">
                        <div class="upload-icon">
                            <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="30" cy="30" r="30" fill="#E8F0FE"/>
                                <path d="M25 35V25H20L30 15L40 25H35V35H25Z" fill="#4285F4"/>
                                <rect x="18" y="38" width="24" height="3" rx="1.5" fill="#4285F4"/>
                            </svg>
                        </div>
                        
                        <p class="upload-text">
                            <?php esc_html_e( 'Drag & Drop your JSON File here, or', 'ts-lms' ); ?>
                        </p>
                        
                        <button type="button" class="choose-file-btn" id="ts-choose-file">
                            <?php esc_html_e( 'Choose a file', 'ts-lms' ); ?>
                        </button>
                        
                        <input type="file" id="ts-json-file" accept=".json" style="display: none;">
                        
                        <div class="upload-status" id="ts-upload-status" style="display: none;">
                            <span class="status-icon"></span>
                            <span class="status-text"></span>
                        </div>
                    </div>

                    <?php if ( $has_credentials ) : ?>
                        <!-- Authorization Card -->
                        <div class="ts-google-meet-auth-card <?php echo $is_authorized ? 'authorized' : ''; ?>">
                            <div class="auth-status">
                                <?php if ( $is_authorized ) : ?>
                                    <span class="dashicons dashicons-yes-alt"></span>
                                    <h3><?php esc_html_e( 'Account Authorized', 'ts-lms' ); ?></h3>
                                    <p><?php esc_html_e( 'Your Google account is successfully linked.', 'ts-lms' ); ?></p>
                                    <a href="<?php echo esc_url( self::get_google_meet_auth_url() ); ?>" class="ts-btn-reauthorize"><?php esc_html_e( 'Re-authorize Account', 'ts-lms' ); ?></a>
                                <?php else : ?>
                                    <span class="dashicons dashicons-warning"></span>
                                    <h3><?php esc_html_e( 'Account Not Authorized', 'ts-lms' ); ?></h3>
                                    <p><?php esc_html_e( 'Please authorize your account to start scheduling meetings.', 'ts-lms' ); ?></p>
                                    <a href="<?php echo esc_url( self::get_google_meet_auth_url() ); ?>" class="ts-btn-authorize"><?php esc_html_e( 'Authorize Account', 'ts-lms' ); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                <?php elseif ( $current_tab === 'settings' ) : ?>
                    <!-- Settings Content -->
                    <div class="ts-google-meet-settings">
                        <h2 class="settings-title"><?php esc_html_e( 'Settings', 'ts-lms' ); ?></h2>
                        
                        <?php if ( isset( $_GET['settings-updated'] ) && $_GET['settings-updated'] === 'true' ) : ?>
                            <div class="settings-updated-notice">
                                <span class="dashicons dashicons-yes-alt"></span>
                                <span><?php esc_html_e( 'Settings saved successfully!', 'ts-lms' ); ?></span>
                            </div>
                        <?php endif; ?>
                        
                        <form method="post" action="" class="ts-google-meet-settings-form">
                            <?php wp_nonce_field( 'ts_lms_google_meet_settings', 'ts_lms_google_meet_nonce' ); ?>
                            
                            <!-- Default Timezone -->
                            <div class="settings-card">
                                <h3><?php esc_html_e( 'Default Timezone', 'ts-lms' ); ?></h3>
                                <p class="setting-description"><?php esc_html_e( 'Set the default timezone for Google Meet', 'ts-lms' ); ?></p>
                                
                                <select name="ts_lms_google_meet_timezone" class="settings-select">
                                    <option value="(GMT-11:00) Midway Island, Samoa" <?php selected( $timezone, '(GMT-11:00) Midway Island, Samoa' ); ?>>(GMT-11:00) Midway Island, Samoa</option>
                                    <option value="(GMT-10:00) Hawaii" <?php selected( $timezone, '(GMT-10:00) Hawaii' ); ?>>(GMT-10:00) Hawaii</option>
                                    <option value="(GMT-08:00) Pacific Time" <?php selected( $timezone, '(GMT-08:00) Pacific Time' ); ?>>(GMT-08:00) Pacific Time</option>
                                    <option value="(GMT-05:00) Eastern Time" <?php selected( $timezone, '(GMT-05:00) Eastern Time' ); ?>>(GMT-05:00) Eastern Time</option>
                                    <option value="(GMT+00:00) UTC" <?php selected( $timezone, '(GMT+00:00) UTC' ); ?>>(GMT+00:00) UTC</option>
                                    <option value="(GMT+06:00) Dhaka" <?php selected( $timezone, '(GMT+06:00) Dhaka' ); ?>>(GMT+06:00) Dhaka</option>
                                </select>
                            </div>

                            <!-- Default Reminder Time -->
                            <div class="settings-card">
                                <h3><?php esc_html_e( 'Default Reminder Time', 'ts-lms' ); ?></h3>
                                <p class="setting-description"><?php esc_html_e( 'Set a default reminder time to get an email notification', 'ts-lms' ); ?></p>
                                
                                <div class="radio-group">
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_reminder" value="5" <?php checked( $reminder_time, '5' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( '5 Minutes Before', 'ts-lms' ); ?></span>
                                    </label>
                                    
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_reminder" value="15" <?php checked( $reminder_time, '15' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( '15 Minutes Before', 'ts-lms' ); ?></span>
                                    </label>
                                    
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_reminder" value="30" <?php checked( $reminder_time, '30' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( '30 Minutes Before', 'ts-lms' ); ?></span>
                                    </label>
                                </div>
                            </div>

                            <!-- Set Default Event Status -->
                            <div class="settings-card">
                                <h3><?php esc_html_e( 'Set Default Event Status', 'ts-lms' ); ?></h3>
                                <p class="setting-description"><?php esc_html_e( 'Set a default status for Google Meet event', 'ts-lms' ); ?></p>
                                
                                <div class="radio-group">
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_event_status" value="confirmed" <?php checked( $event_status, 'confirmed' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( 'Confirmed', 'ts-lms' ); ?></span>
                                    </label>
                                    
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_event_status" value="tentative" <?php checked( $event_status, 'tentative' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( 'Tentative', 'ts-lms' ); ?></span>
                                    </label>
                                </div>
                            </div>

                            <!-- Send Updates -->
                            <div class="settings-card">
                                <h3><?php esc_html_e( 'Send Updates', 'ts-lms' ); ?></h3>
                                <p class="setting-description"><?php esc_html_e( 'Select how to send notifications about the creation of the new event. Note that some emails might still be sent.', 'ts-lms' ); ?></p>
                                
                                <div class="radio-group">
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_send_updates" value="all" <?php checked( $send_updates, 'all' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( 'All', 'ts-lms' ); ?></span>
                                    </label>
                                    
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_send_updates" value="external" <?php checked( $send_updates, 'external' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( 'External Only', 'ts-lms' ); ?></span>
                                    </label>
                                    
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_send_updates" value="none" <?php checked( $send_updates, 'none' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( 'None', 'ts-lms' ); ?></span>
                                    </label>
                                </div>
                            </div>

                            <!-- Transparency -->
                            <div class="settings-card">
                                <h3><?php esc_html_e( 'Transparency', 'ts-lms' ); ?></h3>
                                <p class="setting-description"><?php esc_html_e( 'Select if the events block time on the calendar by default.', 'ts-lms' ); ?></p>
                                
                                <div class="radio-group">
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_transparency" value="opaque" <?php checked( $transparency, 'opaque' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( 'Opaque, Blocks Time on the Calendar', 'ts-lms' ); ?></span>
                                    </label>
                                    
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_transparency" value="transparent" <?php checked( $transparency, 'transparent' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( 'Transparent, does not Blocks Time', 'ts-lms' ); ?></span>
                                    </label>
                                </div>
                            </div>

                            <!-- Visibility on Calendar -->
                            <div class="settings-card">
                                <h3><?php esc_html_e( 'Visibility on Calendar', 'ts-lms' ); ?></h3>
                                <p class="setting-description"><?php esc_html_e( 'Set the default visibility of the event on the calendar.', 'ts-lms' ); ?></p>
                                
                                <div class="radio-group">
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_visibility" value="default" <?php checked( $visibility, 'default' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( 'Default', 'ts-lms' ); ?></span>
                                    </label>
                                    
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_visibility" value="public" <?php checked( $visibility, 'public' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( 'Public', 'ts-lms' ); ?></span>
                                    </label>
                                    
                                    <label class="radio-option">
                                        <input type="radio" name="ts_lms_google_meet_visibility" value="private" <?php checked( $visibility, 'private' ); ?>>
                                        <span class="radio-label"><?php esc_html_e( 'Private', 'ts-lms' ); ?></span>
                                    </label>
                                </div>
                            </div>

                            <div class="settings-actions">
                                <button type="submit" name="ts_lms_save_google_meet_settings" class="save-settings-btn">
                                    <?php esc_html_e( 'Save Settings', 'ts-lms' ); ?>
                                </button>
                            </div>
                        </form>
                    </div>

                <?php elseif ( $current_tab === 'help' ) : ?>
                    <!-- Help Content -->
                    <div class="ts-google-meet-help">
                        <h2 class="faq-title"><?php esc_html_e( 'FAQ', 'ts-lms' ); ?></h2>
                        
                        <div class="faq-accordion">
                            <!-- FAQ Item 1 -->
                            <div class="faq-item">
                                <div class="faq-question">
                                    <span class="faq-icon">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M10 5V15M5 10H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </span>
                                    <h3><?php esc_html_e( 'How do I connect Google Meet with my LMS Website?', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="faq-answer">
                                    <p>
                                        <?php esc_html_e( 'To integrate with Google Meet, go to', 'ts-lms' ); ?>
                                        <a href="https://console.cloud.google.com" target="_blank"><?php esc_html_e( 'this link', 'ts-lms' ); ?></a>
                                        <?php esc_html_e( '& create your OAuth Access Credentials. During this process, copy the link from the Set API Tab and paste it as your Redirect URI. For a more detailed guide, please refer to our', 'ts-lms' ); ?>
                                        <a href="#" class="documentation-link"><?php esc_html_e( 'documentation', 'ts-lms' ); ?></a>.
                                    </p>
                                </div>
                            </div>

                            <!-- FAQ Item 2 -->
                            <div class="faq-item">
                                <div class="faq-question">
                                    <span class="faq-icon">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M10 5V15M5 10H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </span>
                                    <h3><?php esc_html_e( 'How do I create a Live Lesson on TS LMS?', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="faq-answer">
                                    <p>
                                        <?php esc_html_e( 'You can create a live lesson by going into the course editor for any TS LMS course. There you will see a section for Google Meet where you can create a Google Meet meeting. You can also add lesson-specific meetings by navigating into any topic and selecting the Google Meet Live Lesson option.', 'ts-lms' ); ?>
                                    </p>
                                </div>
                            </div>

                            <!-- FAQ Item 3 -->
                            <div class="faq-item">
                                <div class="faq-question">
                                    <span class="faq-icon">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M10 5V15M5 10H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </span>
                                    <h3><?php esc_html_e( 'How do I notify students about live lessons?', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="faq-answer">
                                    <p>
                                        <?php esc_html_e( 'You can notify students about live lessons using Email Notifications of TS LMS and from the Google Meet settings on TS LMS frontend and backend.', 'ts-lms' ); ?>
                                    </p>
                                </div>
                            </div>

                            <!-- FAQ Item 4 -->
                            <div class="faq-item">
                                <div class="faq-question">
                                    <span class="faq-icon">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M10 5V15M5 10H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </span>
                                    <h3><?php esc_html_e( 'Do I need a Google account to integrate Google Meet with TS LMS?', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="faq-answer">
                                    <p>
                                        <?php esc_html_e( 'Yes, you would need a Google Account to go through the entire process of setting up Google Meet with TS LMS. You will also need a Google account to host meetings with Google Meet.', 'ts-lms' ); ?>
                                    </p>
                                </div>
                            </div>

                            <!-- FAQ Item 5 -->
                            <div class="faq-item">
                                <div class="faq-question">
                                    <span class="faq-icon">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M10 5V15M5 10H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </span>
                                    <h3><?php esc_html_e( 'What Equipment Do I Need To Hold a Live Class?', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="faq-answer">
                                    <p>
                                        <?php esc_html_e( 'You will need a Microphone, a PC running Windows or Mac OS, and preferably a Webcam to effectively hold a live class.', 'ts-lms' ); ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    public static function render_zoom() {
        // Enqueue Zoom specific styles (reuse Google Meet styles)
        wp_enqueue_style( 'ts-lms-zoom', plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/css/zoom.css', array(), '1.0.0' );
        wp_enqueue_script( 'ts-lms-zoom', plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/js/zoom.js', array( 'jquery' ), '1.0.0', true );
        
        // Get current tab
        $current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'setup';
        
        // Get saved settings
        $account_id = get_option( 'ts_lms_zoom_account_id', '' );
        $client_id = get_option( 'ts_lms_zoom_client_id', '' );
        $client_secret = get_option( 'ts_lms_zoom_client_secret', '' );
        ?>
        <div class="wrap ts-lms-zoom-wrap">
            <div class="ts-zoom-header">
                <h1><?php esc_html_e( 'Zoom', 'ts-lms' ); ?></h1>
                <div class="ts-zoom-tabs">
                    <a href="?page=ts-lms-zoom&tab=setup" class="tab-link <?php echo $current_tab === 'setup' ? 'active' : ''; ?>"><?php esc_html_e( 'Set API', 'ts-lms' ); ?></a>
                    <a href="?page=ts-lms-zoom&tab=settings" class="tab-link <?php echo $current_tab === 'settings' ? 'active' : ''; ?>"><?php esc_html_e( 'Settings', 'ts-lms' ); ?></a>
                    <a href="?page=ts-lms-zoom&tab=help" class="tab-link <?php echo $current_tab === 'help' ? 'active' : ''; ?>"><?php esc_html_e( 'Help', 'ts-lms' ); ?></a>
                </div>
            </div>

            <div class="ts-zoom-content">
                <?php if ( $current_tab === 'setup' ) : ?>
                    <!-- Setup Card -->
                    <div class="ts-zoom-setup-card">
                        <div class="setup-form">
                            <h2><?php esc_html_e( 'Setup your Zoom Integration', 'ts-lms' ); ?></h2>
                            <p class="setup-description">
                                <?php esc_html_e( 'Visit your Zoom account and fetch the API key to connect Zoom with your eLearning website. Go to', 'ts-lms' ); ?>
                                <a href="https://marketplace.zoom.us/" target="_blank" class="zoom-link"><?php esc_html_e( 'Zoom Website', 'ts-lms' ); ?></a>.
                            </p>
                            
                            <form method="post" action="" class="zoom-credentials-form">
                                <?php wp_nonce_field( 'ts_lms_zoom_credentials', 'ts_lms_zoom_nonce' ); ?>
                                
                                <div class="form-field">
                                    <label for="zoom-account-id"><?php esc_html_e( 'Account ID', 'ts-lms' ); ?></label>
                                    <input type="text" id="zoom-account-id" name="ts_lms_zoom_account_id" 
                                           placeholder="<?php esc_attr_e( 'Enter Your Zoom Account ID', 'ts-lms' ); ?>" 
                                           value="<?php echo esc_attr( $account_id ); ?>">
                                </div>
                                
                                <div class="form-field">
                                    <label for="zoom-client-id"><?php esc_html_e( 'Client ID', 'ts-lms' ); ?></label>
                                    <input type="text" id="zoom-client-id" name="ts_lms_zoom_client_id" 
                                           placeholder="<?php esc_attr_e( 'Enter Your Zoom Client ID', 'ts-lms' ); ?>" 
                                           value="<?php echo esc_attr( $client_id ); ?>">
                                </div>
                                
                                <div class="form-field">
                                    <label for="zoom-client-secret"><?php esc_html_e( 'Client Secret', 'ts-lms' ); ?></label>
                                    <input type="password" id="zoom-client-secret" name="ts_lms_zoom_client_secret" 
                                           placeholder="<?php esc_attr_e( 'Enter Your Zoom  Client Secret', 'ts-lms' ); ?>" 
                                           value="<?php echo esc_attr( $client_secret ); ?>">
                                </div>
                                
                                <button type="submit" name="ts_lms_save_zoom_credentials" class="save-zoom-btn">
                                    <?php esc_html_e( 'Save & Check Connection', 'ts-lms' ); ?>
                                </button>
                            </form>
                        </div>
                        
                        <div class="setup-illustration">
                            <svg viewBox="0 0 500 350" xmlns="http://www.w3.org/2000/svg">
                                <!-- Laptop Screen -->
                                <g class="laptop">
                                    <rect x="180" y="80" width="180" height="120" rx="8" fill="#E8F0FE" stroke="#4A90E2" stroke-width="3"/>
                                    <!-- Zoom Icon -->
                                    <circle cx="270" cy="140" r="25" fill="#2D8CFF"/>
                                    <path d="M260 135 L260 145 L280 140 Z" fill="white"/>
                                </g>
                                
                                <!-- Person 1 (Left - Blue outfit) -->
                                <g class="person-left">
                                    <circle cx="120" cy="180" r="25" fill="#8B6F47"/>
                                    <path d="M 95 170 Q 95 145 120 145 Q 145 145 145 170" fill="#2C3E50"/>
                                    <rect x="95" y="205" width="50" height="80" rx="25" fill="#4A90E2"/>
                                    <rect x="85" y="220" width="15" height="40" rx="8" fill="#4A90E2"/>
                                    <circle cx="92" cy="260" r="8" fill="#8B6F47"/>
                                    <!-- Chair -->
                                    <rect x="100" y="285" width="40" height="5" fill="#D1D5DB"/>
                                    <rect x="105" y="290" width="5" height="30" fill="#D1D5DB"/>
                                    <rect x="130" y="290" width="5" height="30" fill="#D1D5DB"/>
                                </g>
                                
                                <!-- Person 2 (Right - Yellow outfit) -->
                                <g class="person-right">
                                    <circle cx="380" cy="180" r="25" fill="#8B6F47"/>
                                    <ellipse cx="365" cy="165" rx="15" ry="20" fill="#2C3E50"/>
                                    <ellipse cx="395" cy="165" rx="15" ry="20" fill="#2C3E50"/>
                                    <rect x="355" y="205" width="50" height="80" rx="25" fill="#FDB813"/>
                                    <rect x="400" y="220" width="15" height="40" rx="8" fill="#FDB813"/>
                                    <circle cx="407" cy="260" r="8" fill="#8B6F47"/>
                                    <!-- Chair -->
                                    <rect x="360" y="285" width="40" height="5" fill="#D1D5DB"/>
                                    <rect x="365" y="290" width="5" height="30" fill="#D1D5DB"/>
                                    <rect x="390" y="290" width="5" height="30" fill="#D1D5DB"/>
                                    <!-- Legs -->
                                    <rect x="360" y="285" width="12" height="35" fill="#4A90E2"/>
                                    <rect x="388" y="285" width="12" height="35" fill="#4A90E2"/>
                                    <ellipse cx="366" cy="320" rx="8" ry="4" fill="#2C3E50"/>
                                    <ellipse cx="394" cy="320" rx="8" ry="4" fill="#2C3E50"/>
                                </g>
                            </svg>
                        </div>
                    </div>

                <?php elseif ( $current_tab === 'settings' ) : ?>
                    <div class="ts-zoom-settings">
                        <h2><?php esc_html_e( 'Zoom Settings', 'ts-lms' ); ?></h2>
                        <p><?php esc_html_e( 'Configure your Zoom meeting settings here.', 'ts-lms' ); ?></p>
                    </div>

                <?php elseif ( $current_tab === 'help' ) : ?>
                    <div class="ts-zoom-help">
                        <h2 class="faq-title"><?php esc_html_e( 'FAQ', 'ts-lms' ); ?></h2>
                        
                        <div class="faq-accordion">
                            <!-- FAQ Item 1 -->
                            <div class="faq-item">
                                <div class="faq-question">
                                    <span class="faq-icon">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M10 5V15M5 10H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </span>
                                    <h3><?php esc_html_e( 'How Do I Connect Zoom With my LMS Website?', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="faq-answer">
                                    <p>
                                        <?php esc_html_e( 'To connect Zoom with your eLearning website powered by TS LMS, you need to first create an app on Zoom by following', 'ts-lms' ); ?>
                                        <a href="https://marketplace.zoom.us/" target="_blank"><?php esc_html_e( 'this link', 'ts-lms' ); ?></a>.
                                        <?php esc_html_e( 'Then create a JWT, OAuth or S2S Credentials, and paste it to the TS LMS backend by navigating to WP Admin > TS LMS Pro > Zoom > Set API.', 'ts-lms' ); ?>
                                    </p>
                                </div>
                            </div>

                            <!-- FAQ Item 2 -->
                            <div class="faq-item">
                                <div class="faq-question">
                                    <span class="faq-icon">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M10 5V15M5 10H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </span>
                                    <h3><?php esc_html_e( 'How Do I Create a Live Lesson on TS LMS?', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="faq-answer">
                                    <p>
                                        <?php esc_html_e( 'You can create a live lesson by going into any TS LMS course editor. There, you will see a section called Zoom Meeting from where you can schedule a General Zoom meeting. You can also add lesson-specific meetings by navigating into any topic and then selecting the <strong>Zoom Live Lesson</strong> option.', 'ts-lms' ); ?>
                                    </p>
                                </div>
                            </div>

                            <!-- FAQ Item 3 -->
                            <div class="faq-item">
                                <div class="faq-question">
                                    <span class="faq-icon">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M10 5V15M5 10H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </span>
                                    <h3><?php esc_html_e( 'How Do I Notify Students about Live Lessons?', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="faq-answer">
                                    <p>
                                        <?php esc_html_e( 'You can notify students about live lessons using Email Notifications and Announcements. Docs for Email Notifications can be found', 'ts-lms' ); ?>
                                        <a href="#" target="_blank"><?php esc_html_e( 'here', 'ts-lms' ); ?></a>.
                                    </p>
                                </div>
                            </div>

                            <!-- FAQ Item 4 -->
                            <div class="faq-item">
                                <div class="faq-question">
                                    <span class="faq-icon">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M10 5V15M5 10H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </span>
                                    <h3><?php esc_html_e( 'Is Zoom Free to Use?', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="faq-answer">
                                    <p>
                                        <?php esc_html_e( 'Zoom follows a freemium monetization plan. Therefore, for smaller-scaled and limited operations, Zoom is free. However, for medium to larger websites, it\'s best to upgrade to a premium plan to get the most out of this platform.', 'ts-lms' ); ?>
                                    </p>
                                </div>
                            </div>

                            <!-- FAQ Item 5 -->
                            <div class="faq-item">
                                <div class="faq-question">
                                    <span class="faq-icon">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M10 5V15M5 10H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                        </svg>
                                    </span>
                                    <h3><?php esc_html_e( 'What Equipment Do I Need To Hold a Live Class?', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="faq-answer">
                                    <p>
                                        <?php esc_html_e( 'You will need a Microphone, a PC running Windows or Mac OS, and preferably a Webcam to effectively hold a live class.', 'ts-lms' ); ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    public static function render_ai_studio() {
        if ( class_exists( '\TS_LMS\Modules\AIStudio\Admin\AIStudioPage' ) ) {
            \TS_LMS\Modules\AIStudio\Admin\AIStudioPage::render();
        } else {
            self::render_placeholder( 'AI Studio', 'AI Content Generation Tools.' );
        }
    }

    public static function render_upgrade() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Upgrade to Pro', 'ts-lms' ); ?></h1>
            <p><?php esc_html_e( 'Unlock advanced features with TS LMS Pro.', 'ts-lms' ); ?></p>
        </div>
        <?php
    }

    public static function render_license() {
        $active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'activation';
        
        // Get license information
        $license_key = get_option( 'ts_lms_license_key', '' );
        $license_email = get_option( 'ts_lms_license_email', '' );

        // Auto-sync on page load (silent)
        if ( $license_key && $license_email && class_exists( '\TS_LMS\Admin\LicenseValidator' ) ) {
             \TS_LMS\Admin\LicenseValidator::validate_license( $license_key, $license_email, false );
        }

        $license_status = get_option( 'ts_lms_license_status', 'inactive' );
        $license_expires = get_option( 'ts_lms_license_expires', '' );
        
        ?>
        <style>
            .ts-lms-license-wrap {
                max-width: 900px;
                margin: 40px auto;
                background: #fff;
                padding: 0;
            }
            .ts-lms-license-header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 40px;
                border-radius: 12px 12px 0 0;
                color: #fff;
                text-align: center;
            }
            .ts-lms-license-header h1 {
                color: #fff;
                font-size: 32px;
                margin: 0 0 10px 0;
                font-weight: 700;
            }
            .ts-lms-license-header p {
                color: rgba(255,255,255,0.9);
                font-size: 16px;
                margin: 0;
            }
            .ts-lms-license-tabs {
                display: flex;
                border-bottom: 2px solid #e5e7eb;
                background: #f9fafb;
                padding: 0 40px;
            }
            .ts-lms-license-tabs a {
                padding: 16px 24px;
                text-decoration: none;
                color: #6b7280;
                font-weight: 600;
                border-bottom: 3px solid transparent;
                margin-bottom: -2px;
                transition: all 0.3s;
            }
            .ts-lms-license-tabs a:hover {
                color: #667eea;
            }
            .ts-lms-license-tabs a.active {
                color: #667eea;
                border-bottom-color: #667eea;
            }
            .ts-lms-license-content {
                padding: 40px;
            }
            .ts-license-card {
                background: #fff;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                padding: 32px;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }
            .ts-license-card h2 {
                font-size: 24px;
                margin: 0 0 24px 0;
                color: #111827;
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .ts-license-card h2 svg {
                width: 28px;
                height: 28px;
            }
            .ts-license-form-group {
                margin-bottom: 24px;
            }
            .ts-license-form-group label {
                display: block;
                font-weight: 600;
                color: #374151;
                margin-bottom: 8px;
                font-size: 14px;
            }
            .ts-license-form-group input {
                width: 100%;
                padding: 12px 16px;
                border: 2px solid #e5e7eb;
                border-radius: 8px;
                font-size: 15px;
                transition: all 0.3s;
            }
            .ts-license-form-group input:focus {
                outline: none;
                border-color: #667eea;
                box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            }
            .ts-license-form-group .description {
                margin-top: 6px;
                font-size: 13px;
                color: #6b7280;
            }
            .ts-license-btn {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #fff;
                padding: 14px 32px;
                border: none;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s;
                box-shadow: 0 4px 6px rgba(102, 126, 234, 0.3);
            }
            .ts-license-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 12px rgba(102, 126, 234, 0.4);
            }
            .ts-license-btn-secondary {
                background: #f3f4f6;
                color: #374151;
                padding: 12px 24px;
                border: 2px solid #e5e7eb;
                border-radius: 8px;
                font-size: 15px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s;
            }
            .ts-license-btn-secondary:hover {
                background: #e5e7eb;
            }
            .ts-license-alert {
                padding: 16px 20px;
                border-radius: 8px;
                margin-bottom: 24px;
                display: flex;
                align-items: flex-start;
                gap: 12px;
            }
            .ts-license-alert svg {
                width: 20px;
                height: 20px;
                flex-shrink: 0;
                margin-top: 2px;
            }
            .ts-license-alert-success {
                background: #d1fae5;
                color: #065f46;
                border: 1px solid #6ee7b7;
            }
            .ts-license-alert-error {
                background: #fee2e2;
                color: #991b1b;
                border: 1px solid #fca5a5;
            }
            .ts-license-alert-warning {
                background: #fef3c7;
                color: #92400e;
                border: 1px solid #fcd34d;
            }
            .ts-license-info-grid {
                display: grid;
                gap: 16px;
            }
            .ts-license-info-item {
                display: flex;
                justify-content: space-between;
                padding: 16px;
                background: #f9fafb;
                border-radius: 8px;
                border: 1px solid #e5e7eb;
            }
            .ts-license-info-item label {
                font-weight: 600;
                color: #6b7280;
                font-size: 14px;
            }
            .ts-license-info-item span {
                color: #111827;
                font-weight: 500;
            }
            .ts-license-status-badge {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                padding: 6px 12px;
                border-radius: 20px;
                font-size: 13px;
                font-weight: 600;
            }
            .ts-license-status-badge.active {
                background: #d1fae5;
                color: #065f46;
            }
            .ts-license-status-badge.inactive {
                background: #fee2e2;
                color: #991b1b;
            }
        </style>
        
        <div class="wrap ts-lms-license-wrap">
            <div class="ts-lms-license-header">
                <h1><?php esc_html_e( 'TS LMS License Manager', 'ts-lms' ); ?></h1>
                <p><?php esc_html_e( 'Manage your license activation and view license information', 'ts-lms' ); ?></p>
            </div>
            
            <div class="ts-lms-license-tabs">
                <a href="?page=ts-lms-license&tab=activation" class="<?php echo $active_tab == 'activation' ? 'active' : ''; ?>">
                    <?php esc_html_e( 'Activation', 'ts-lms' ); ?>
                </a>
                <a href="?page=ts-lms-license&tab=info" class="<?php echo $active_tab == 'info' ? 'active' : ''; ?>">
                    <?php esc_html_e( 'License Info', 'ts-lms' ); ?>
                </a>
            </div>
            
            <div class="ts-lms-license-content">
                <?php
                // Display success/error messages
                if ( isset( $_GET['activated'] ) && $_GET['activated'] === 'true' ) {
                    ?>
                    <div class="ts-license-alert ts-license-alert-success">
                        <svg fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        <div>
                            <strong><?php esc_html_e( 'Success!', 'ts-lms' ); ?></strong>
                            <p style="margin: 4px 0 0 0;"><?php esc_html_e( 'Your license has been activated successfully.', 'ts-lms' ); ?></p>
                        </div>
                    </div>
                    <?php
                }
                
                if ( isset( $_GET['deactivated'] ) && $_GET['deactivated'] === 'true' ) {
                    ?>
                    <div class="ts-license-alert ts-license-alert-warning">
                        <svg fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                        <div>
                            <p style="margin: 0;"><?php esc_html_e( 'Your license has been deactivated.', 'ts-lms' ); ?></p>
                        </div>
                    </div>
                    <?php
                }
                
                if ( isset( $_GET['error'] ) && $_GET['error'] === 'api_error' && isset( $_GET['msg'] ) ) {
                    ?>
                    <div class="ts-license-alert ts-license-alert-error">
                        <svg fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/></svg>
                        <div>
                            <strong><?php esc_html_e( 'Activation Error!', 'ts-lms' ); ?></strong>
                            <p style="margin: 4px 0 0 0;"><?php echo esc_html( urldecode( $_GET['msg'] ) ); ?></p>
                        </div>
                    </div>
                    <?php
                }
                
                if ( isset( $_GET['error'] ) && $_GET['error'] === 'invalid_license' ) {
                    ?>
                    <div class="ts-license-alert ts-license-alert-error">
                        <svg fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/></svg>
                        <div>
                            <strong><?php esc_html_e( 'Invalid License!', 'ts-lms' ); ?></strong>
                            <p style="margin: 4px 0 0 0;"><?php esc_html_e( 'The license key and email combination could not be verified. Please check your details and try again.', 'ts-lms' ); ?></p>
                        </div>
                    </div>
                    <?php
                }
                
                switch ( $active_tab ) {
                    case 'activation':
                        ?>
                        <div class="ts-license-card">
                            <h2>
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
                                <?php esc_html_e( 'License Activation', 'ts-lms' ); ?>
                            </h2>
                            
                            <?php if ( $license_status === 'active' ) : ?>
                                <div class="ts-license-alert ts-license-alert-success">
                                    <svg fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                                    <div>
                                        <strong><?php esc_html_e( 'License Active!', 'ts-lms' ); ?></strong>
                                        <p style="margin: 4px 0 0 0;"><?php esc_html_e( 'Your license is currently active and valid.', 'ts-lms' ); ?></p>
                                    </div>
                                </div>
                                
                                <div class="ts-license-info-grid">
                                    <div class="ts-license-info-item">
                                        <label><?php esc_html_e( 'License Key', 'ts-lms' ); ?></label>
                                        <span><code><?php 
                                            if ( $license_key ) {
                                                $masked = str_repeat('*', strlen($license_key) - 4) . substr($license_key, -4);
                                                echo esc_html( $masked );
                                            } else {
                                                echo 'N/A';
                                            }
                                        ?></code></span>
                                    </div>
                                    <div class="ts-license-info-item">
                                        <label><?php esc_html_e( 'Status', 'ts-lms' ); ?></label>
                                        <span class="ts-license-status-badge active">
                                            <svg width="8" height="8" fill="currentColor"><circle cx="4" cy="4" r="4"/></svg>
                                            <?php esc_html_e( 'Active', 'ts-lms' ); ?>
                                        </span>
                                    </div>
                                    <div class="ts-license-info-item">
                                        <label><?php esc_html_e( 'Licensed Email', 'ts-lms' ); ?></label>
                                        <span><?php echo esc_html( $license_email ); ?></span>
                                    </div>
                                    <?php if ( $license_expires ) : ?>
                                    <div class="ts-license-info-item">
                                        <label><?php esc_html_e( 'Expires', 'ts-lms' ); ?></label>
                                        <span><?php echo esc_html( date( 'F j, Y', strtotime( $license_expires ) ) ); ?></span>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                
                                <form method="post" action="" style="margin-top: 24px;">
                                    <?php wp_nonce_field( 'ts_lms_deactivate_license', 'ts_lms_license_nonce' ); ?>
                                    <input type="hidden" name="ts_lms_action" value="deactivate_license">
                                    <button type="submit" class="ts-license-btn-secondary">
                                        <?php esc_html_e( 'Disconnect Locally', 'ts-lms' ); ?>
                                    </button>
                                </form>
                                
                            <?php else : ?>
                                <div class="ts-license-alert ts-license-alert-warning">
                                    <svg fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                                    <div>
                                        <p style="margin: 0;"><?php esc_html_e( 'Please activate your license to receive updates and support.', 'ts-lms' ); ?></p>
                                    </div>
                                </div>
                                
                                <form method="post" action="">
                                    <?php wp_nonce_field( 'ts_lms_activate_license', 'ts_lms_license_nonce' ); ?>
                                    <input type="hidden" name="ts_lms_action" value="activate_license">
                                    
                                    <div class="ts-license-form-group">
                                        <label for="ts_lms_license_key"><?php esc_html_e( 'License Key', 'ts-lms' ); ?></label>
                                        <input type="text" 
                                               id="ts_lms_license_key" 
                                               name="ts_lms_license_key" 
                                               value="<?php echo isset($_GET['error']) ? '' : esc_attr( $license_key ); ?>" 
                                               placeholder="<?php esc_attr_e( 'TSLMS-XXXX-XXXX-XXXX-XXXX', 'ts-lms' ); ?>">
                                        <p class="description">
                                            <?php esc_html_e( 'Enter the license key you received after purchase.', 'ts-lms' ); ?>
                                        </p>
                                    </div>
                                    
                                    <div class="ts-license-form-group">
                                        <label for="ts_lms_license_email"><?php esc_html_e( 'Email Address', 'ts-lms' ); ?></label>
                                        <input type="email" 
                                               id="ts_lms_license_email" 
                                               name="ts_lms_license_email" 
                                               value="<?php echo isset($_GET['error']) ? '' : esc_attr( $license_email ); ?>" 
                                               placeholder="<?php esc_attr_e( 'your@email.com', 'ts-lms' ); ?>">
                                        <p class="description">
                                            <?php esc_html_e( 'The email address used for purchase.', 'ts-lms' ); ?>
                                        </p>
                                    </div>
                                    
                                    <button type="submit" class="ts-license-btn">
                                        <?php esc_html_e( 'Activate License', 'ts-lms' ); ?>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                        <?php
                        break;
                        
                    case 'info':
                        ?>
                        <div class="ts-license-info-section">
                            <h2><?php esc_html_e( 'License Information', 'ts-lms' ); ?></h2>
                            
                            <table class="widefat striped">
                                <thead>
                                    <tr>
                                        <th><?php esc_html_e( 'Property', 'ts-lms' ); ?></th>
                                        <th><?php esc_html_e( 'Value', 'ts-lms' ); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><strong><?php esc_html_e( 'License Status', 'ts-lms' ); ?></strong></td>
                                        <td>
                                            <span class="ts-license-status <?php echo esc_attr( $license_status ); ?>">
                                                <?php echo esc_html( ucfirst( $license_status ) ); ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php esc_html_e( 'License Key', 'ts-lms' ); ?></strong></td>
                                        <td><?php 
                                            if ( $license_key ) {
                                                echo esc_html( str_repeat('*', strlen($license_key) - 4) . substr($license_key, -4) );
                                            } else {
                                                esc_html_e( 'Not set', 'ts-lms' );
                                            }
                                        ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php esc_html_e( 'Email', 'ts-lms' ); ?></strong></td>
                                        <td><?php echo esc_html( $license_email ? $license_email : 'Not set' ); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php esc_html_e( 'Expiration Date', 'ts-lms' ); ?></strong></td>
                                        <td><?php echo esc_html( $license_expires ? date( 'F j, Y', strtotime( $license_expires ) ) : 'Not set' ); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php esc_html_e( 'Site URL', 'ts-lms' ); ?></strong></td>
                                        <td><?php echo esc_html( get_site_url() ); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                            
                            <div class="ts-license-help" style="margin-top: 20px;">
                                <h3><?php esc_html_e( 'Need Help?', 'ts-lms' ); ?></h3>
                                <p><?php esc_html_e( 'If you have any issues with your license, please contact our support team.', 'ts-lms' ); ?></p>
                            </div>
                        </div>
                        <?php
                        break;
                        
                    default:
                        echo '<p>' . esc_html__( 'Invalid tab.', 'ts-lms' ) . '</p>';
                        break;
                }
                ?>
            </div>
            
            <style>
                .ts-lms-license-wrap .ts-license-status {
                    display: inline-block;
                    padding: 4px 12px;
                    border-radius: 3px;
                    font-weight: 600;
                    font-size: 12px;
                    text-transform: uppercase;
                }
                .ts-lms-license-wrap .ts-license-status.active {
                    background: #d4edda;
                    color: #155724;
                }
                .ts-lms-license-wrap .ts-license-status.inactive {
                    background: #f8d7da;
                    color: #721c24;
                }
                .ts-lms-license-wrap .ts-license-status.expired {
                    background: #fff3cd;
                    color: #856404;
                }
            </style>
        </div>
        <?php
    }

    public static function render_settings() {
        if ( class_exists( '\TS_LMS\Admin\Settings' ) ) {
            \TS_LMS\Admin\Settings::render();
        } else {
            $active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'general';
            ?>
            <div class="wrap">
                <h1><?php esc_html_e( 'TS LMS Settings', 'ts-lms' ); ?></h1>
                <h2 class="nav-tab-wrapper">
                    <a href="?page=ts-lms-settings&tab=general" class="nav-tab <?php echo $active_tab == 'general' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'General', 'ts-lms' ); ?></a>
                    <a href="?page=ts-lms-settings&tab=course" class="nav-tab <?php echo $active_tab == 'course' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Course', 'ts-lms' ); ?></a>
                    <a href="?page=ts-lms-settings&tab=design" class="nav-tab <?php echo $active_tab == 'design' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Design', 'ts-lms' ); ?></a>
                    <a href="?page=ts-lms-settings&tab=advanced" class="nav-tab <?php echo $active_tab == 'advanced' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Advanced', 'ts-lms' ); ?></a>
                    <a href="?page=ts-lms-settings&tab=email" class="nav-tab <?php echo $active_tab == 'email' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Email', 'ts-lms' ); ?></a>
                    <a href="?page=ts-lms-settings&tab=notifications" class="nav-tab <?php echo $active_tab == 'notifications' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Notifications', 'ts-lms' ); ?></a>
                    <a href="?page=ts-lms-settings&tab=authentication" class="nav-tab <?php echo $active_tab == 'authentication' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Authentication', 'ts-lms' ); ?></a>
                    <a href="?page=ts-lms-settings&tab=certificate" class="nav-tab <?php echo $active_tab == 'certificate' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Certificate', 'ts-lms' ); ?></a>

                </h2>
                <div class="ts-lms-settings-content">
                    <?php
                    switch ( $active_tab ) {
                        case 'general':
                            echo '<p>' . esc_html__( 'General settings content goes here.', 'ts-lms' ) . '</p>';
                            break;
                        case 'course':
                            echo '<p>' . esc_html__( 'Course settings content goes here.', 'ts-lms' ) . '</p>';
                            break;

                        default:
                            echo '<p>' . esc_html__( 'Settings content.', 'ts-lms' ) . '</p>';
                            break;
                    }
                    ?>
                </div>
            </div>
            <?php
        }
    }

    public static function render_instructors() {
        if ( class_exists( '\TS_LMS\Modules\Auth\Admin\InstructorApplications' ) ) {
            \TS_LMS\Modules\Auth\Admin\InstructorApplications::render();
        } else {
            // Manually include if autoloader failed
            $file = TS_LMS_PLUGIN_DIR . 'modules/auth/includes/Admin/InstructorApplications.php';
            if ( file_exists( $file ) ) {
                require_once $file;
                \TS_LMS\Modules\Auth\Admin\InstructorApplications::render();
            } else {
                echo '<div class="wrap"><h1>Instructors</h1><p>Module file not found.</p></div>';
            }
        }
    }

    private static function render_placeholder( $title, $description ) {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html( $title ); ?></h1>
            <p><?php echo esc_html( $description ); ?></p>
            <div class="notice notice-info inline">
                <p><?php esc_html_e( 'This module is coming soon.', 'ts-lms' ); ?></p>
            </div>
        </div>
        <?php
    }

    /**
     * Enforce license check for TS LMS pages.
     */
    public static function register_license_enforcement() {
        add_action( 'admin_head', array( __CLASS__, 'inject_license_blocker' ) );
    }

    /**
     * Inject a blocking overlay if the license is not active.
     */
    public static function inject_license_blocker() {
        if ( ! class_exists( '\TS_LMS\Admin\LicenseValidator' ) ) {
            return;
        }

        $screen = get_current_screen();
        $page = isset( $_GET['page'] ) ? $_GET['page'] : '';
        
        // List of pages to block
        $is_ts_lms_page = ( 
            ( $page && strpos( $page, 'ts-lms' ) === 0 ) || 
            ( isset( $screen->post_type ) && strpos( $screen->post_type, 'ts_' ) === 0 ) ||
            ( isset( $screen->taxonomy ) && strpos( $screen->taxonomy, 'ts_' ) === 0 )
        );

        // Don't block the license page itself!
        if ( ! $is_ts_lms_page || $page === 'ts-lms-license' ) {
            return;
        }

        if ( ! \TS_LMS\Admin\LicenseValidator::is_active() ) {
            ?>
            <style>
                #wpcontent { position: relative; }
                .ts-lms-license-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(255, 255, 255, 0.85);
                    backdrop-filter: blur(15px);
                    -webkit-backdrop-filter: blur(15px);
                    z-index: 999999;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    flex-direction: column;
                }
                .ts-lms-license-popup {
                    background: #fff;
                    padding: 60px 40px;
                    border-radius: 30px;
                    box-shadow: 0 50px 100px -20px rgba(0, 0, 0, 0.3);
                    text-align: center;
                    max-width: 500px;
                    border: 1px solid rgba(229, 231, 235, 1);
                    animation: tsLmsPopupScale 0.6s cubic-bezier(0.16, 1, 0.3, 1);
                }
                @keyframes tsLmsPopupScale {
                    from { opacity: 0; transform: translateY(40px) scale(0.9); }
                    to { opacity: 1; transform: translateY(0) scale(1); }
                }
                .ts-lms-lock-icon {
                    width: 100px;
                    height: 100px;
                    background: #fef2f2;
                    color: #ef4444;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin: 0 auto 30px;
                    font-size: 50px;
                }
                .ts-lms-license-popup h2 {
                    font-size: 32px;
                    color: #111827;
                    margin: 0 0 20px 0;
                    font-weight: 800;
                    letter-spacing: -0.025em;
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                }
                .ts-lms-license-popup p {
                    font-size: 18px;
                    color: #4b5563;
                    line-height: 1.7;
                    margin: 0 0 40px 0;
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                }
                .ts-lms-activate-btn-large {
                    display: inline-flex;
                    align-items: center;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: #fff !important;
                    padding: 18px 45px;
                    border-radius: 16px;
                    font-weight: 700;
                    text-decoration: none !important;
                    font-size: 18px;
                    transition: all 0.3s;
                    box-shadow: 0 15px 30px -10px rgba(102, 126, 234, 0.5);
                }
                .ts-lms-activate-btn-large:hover {
                    transform: translateY(-3px);
                    box-shadow: 0 25px 40px -15px rgba(102, 126, 234, 0.6);
                    opacity: 0.95;
                }
                #wpbody-content { filter: blur(12px) grayscale(1); pointer-events: none; }
                #adminmenu, #wpadminbar, #footer-thankyou { pointer-events: none; opacity: 0.6; }
            </style>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const blockUi = () => {
                        if (document.querySelector('.ts-lms-license-overlay')) return;
                        const overlay = document.createElement('div');
                        overlay.className = 'ts-lms-license-overlay';
                        overlay.innerHTML = `
                            <div class="ts-lms-license-popup">
                                <div class="ts-lms-lock-icon">🔒</div>
                                <h2>License Activation Required</h2>
                                <p>To use TS LMS premium features, including courses, settings, and reports, you must have an active license. Activate your license now to unlock full access.</p>
                                <a href="<?php echo admin_url('admin.php?page=ts-lms-license'); ?>" class="ts-lms-activate-btn-large">Activate Now</a>
                            </div>
                        `;
                        document.body.appendChild(overlay);
                        document.body.style.overflow = 'hidden';
                    };
                    blockUi();
                    setInterval(blockUi, 1000);
                });
            </script>
            <?php
        }
    }
}
