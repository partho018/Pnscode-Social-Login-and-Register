<?php
namespace TS_LMS\Admin;

/**
 * Settings Page Handler.
 */
class Settings {

    /**
     * Option name for storing settings.
     */
    const OPTION_NAME = 'ts_lms_settings';

    /**
     * Get settings.
     */
    public static function get_settings() {
        return get_option( self::OPTION_NAME, array() );
    }

    /**
     * Get a specific setting.
     */
    public static function get_setting( $key, $default = '' ) {
        $settings = self::get_settings();
        return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
    }

    /**
     * Save settings.
     */
    public static function save_settings( $data ) {
        $settings = self::get_settings();
        $updated_settings = array_merge( $settings, $data );
        $saved = update_option( self::OPTION_NAME, $updated_settings );

        // Clear WooCommerce integration cache
        if ( class_exists( '\TS_LMS\Modules\Courses\Integration\WooIntegration' ) ) {
            delete_transient( 'ts_lms_course_product_ids' );
        }

        return $saved;
    }

    /**
     * Get email notification types.
     */
    public static function get_email_notification_types() {
        return array(
            'student' => array(
                'title' => __( 'Email to Students', 'ts-lms' ),
                'emails' => array(
                    'welcome_email'             => __( 'Welcome Email After Registration', 'ts-lms' ),
                    'course_finished'           => __( 'Course Finished', 'ts-lms' ),
                    'reminder_inactive'         => __( 'Reminder to Inactive Students', 'ts-lms' ),
                    'lesson_comment'            => __( 'Comments in Lesson', 'ts-lms' ),
                    'quiz_completed'            => __( 'Quiz Completed', 'ts-lms' ),
                    'course_completed'          => __( 'Completed a Course', 'ts-lms' ),
                    'removed_from_course'       => __( 'Removed From Course', 'ts-lms' ),
                    'assignment_graded'         => __( 'Assignment Graded', 'ts-lms' ),
                    'announcement_posted'       => __( 'New Announcement Posted', 'ts-lms' ),
                    'announcement_updated'      => __( 'New Announcement Updated', 'ts-lms' ),
                    'qa_answered'               => __( 'Q&A Message Answered', 'ts-lms' ),
                    'quiz_feedback'             => __( 'Feedback Submitted For Quiz Attempt', 'ts-lms' ),
                    'enrollment_expired'        => __( 'Course Enrollment Expired', 'ts-lms' ),
                    'lesson_published'          => __( 'New Lesson Published', 'ts-lms' ),
                    'quiz_published'            => __( 'New Quiz Published', 'ts-lms' ),
                    'assignment_published'      => __( 'New Assignment Published', 'ts-lms' ),
                    'order_placed'              => __( 'New Order Placed', 'ts-lms' ),
                    'order_status_updated'      => __( 'Order Status Updated', 'ts-lms' ),
                    'sub_trial_activated'       => __( 'Subscription Trial Activated', 'ts-lms' ),
                    'sub_activated'             => __( 'Subscription Activated', 'ts-lms' ),
                    'sub_on_hold'               => __( 'Subscription on Hold', 'ts-lms' ),
                    'sub_renewed'               => __( 'Subscription Renewed', 'ts-lms' ),
                    'sub_expired'               => __( 'Subscription Expired', 'ts-lms' ),
                    'sub_cancelled'             => __( 'Subscription Cancelled', 'ts-lms' ),
                )
            ),
            'instructor' => array(
                'title' => __( 'Email to Instructors', 'ts-lms' ),
                'emails' => array(
                    'student_enrolled'    => __( 'A Student Enroll In Course', 'ts-lms' ),
                    'student_completed'   => __( 'A Student Completed Course', 'ts-lms' ),
                    'course_reviewed'     => __( 'Student Submitted a Course Review', 'ts-lms' ),
                    'lesson_completed'    => __( 'A Student Completed Lesson', 'ts-lms' ),
                    'new_qa_message'      => __( 'New Q&A Message', 'ts-lms' ),
                    'lesson_comment_inst' => __( 'Comments in Lesson', 'ts-lms' ),
                    'quiz_submitted'      => __( 'Student Submitted Quiz', 'ts-lms' ),
                    'assignment_submitted'=> __( 'Student Submitted Assignment', 'ts-lms' ),
                    'withdraw_approved'   => __( 'Withdrawal Request Approved', 'ts-lms' ),
                    'withdraw_rejected'   => __( 'Withdrawal Request Rejected', 'ts-lms' ),
                    'withdraw_received'   => __( 'Withdrawal Request Received', 'ts-lms' ),
                    'inst_app_accepted'   => __( 'Instructor Application Accepted', 'ts-lms' ),
                    'inst_app_rejected'   => __( 'Instructor Application Rejected', 'ts-lms' ),
                    'inst_app_received'   => __( 'Instructor Application Received', 'ts-lms' ),
                    'course_published'    => __( 'Instructor Course Published', 'ts-lms' ),
                    'course_rejected'     => __( 'An Instructor\'s Course Rejected', 'ts-lms' ),
                    'order_placed'        => __( 'New Order Placed', 'ts-lms' ),
                    'order_status_updated'=> __( 'Order Status Updated', 'ts-lms' ),
                )
            ),
            'admin' => array(
                'title' => __( 'Email to Admin', 'ts-lms' ),
                'emails' => array(
                    'new_instructor'      => __( 'New Instructor Signup', 'ts-lms' ),
                    'new_student'         => __( 'New Student Signup', 'ts-lms' ),
                    'course_for_review'   => __( 'New Course Submitted For Review', 'ts-lms' ),
                    'course_published'    => __( 'New Course Published', 'ts-lms' ),
                    'course_updated'      => __( 'Course Edited/Updated', 'ts-lms' ),
                    'withdraw_requested'  => __( 'New Withdrawal Request', 'ts-lms' ),
                    'course_reviewed_adm' => __( 'Student Submitted a Course Review', 'ts-lms' ),
                    'order_placed'        => __( 'New Order Placed', 'ts-lms' ),
                    'order_status_updated'=> __( 'Order Status Updated', 'ts-lms' ),
                )
            )
        );
    }

    /**
     * Render the settings page.
     */
    public static function render() {
        // Enqueue media uploader
        wp_enqueue_media();

        // Enqueue settings page CSS
        wp_enqueue_style( 'ts-lms-admin-settings', plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/css/admin-settings.css', array(), '1.0.0' );
        
        // Enqueue Color Picker
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );

        // Enqueue Settings JS
        wp_enqueue_script( 'ts-lms-admin-settings-js', plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'assets/js/admin-settings.js', array( 'jquery', 'wp-color-picker', 'media-upload', 'media-views' ), '1.0.0', true );
        
        $active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'general';
        $sub_tab = isset( $_GET['sub_tab'] ) ? sanitize_text_field( $_GET['sub_tab'] ) : '';
        
        $settings = self::get_settings();

        ?>
        <!-- Critical CSS to prevent FOUC -->
        <style>
            /* Prevent flash of unstyled content */
            .ts-lms-settings-wrap {
                opacity: 0;
            }
            .ts-lms-settings-wrap.loaded {
                opacity: 1;
                transition: opacity 0.1s ease-in;
            }
            /* Minimal styling for immediate render */
            .ts-lms-settings-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 20px;
                background: #fff;
                border-bottom: 1px solid #ddd;
            }
            .ts-lms-settings-container {
                display: flex;
                min-height: 500px;
            }
            .ts-lms-settings-sidebar {
                width: 220px;
                background: #f9f9f9;
                border-right: 1px solid #ddd;
            }
            .ts-lms-settings-content {
                flex: 1;
                padding: 20px;
                background: #fff;
            }
        </style>
        <script>
            // Add loaded class immediately when DOM is ready
            document.addEventListener('DOMContentLoaded', function() {
                var wrap = document.querySelector('.ts-lms-settings-wrap');
                if (wrap) {
                    wrap.classList.add('loaded');
                }
            });
        </script>
        <div class="ts-lms-settings-wrap active-tab-<?php echo esc_attr( $active_tab ); ?>">
            <header class="ts-lms-settings-header">
                <div class="header-left">
                    <h1><?php esc_html_e( 'Settings', 'ts-lms' ); ?></h1>
                </div>
                <div class="header-right">
                    <div class="search-box">
                        <span class="dashicons dashicons-search"></span>
                        <input type="text" placeholder="<?php esc_attr_e( 'Search ... ^` + S or Alt+S for shortcut', 'ts-lms' ); ?>">
                    </div>
                    <button type="submit" form="ts-lms-settings-form" class="button-save">
                        <span class="dashicons dashicons-update" style="display: none;"></span>
                        <?php esc_html_e( 'Save Changes', 'ts-lms' ); ?>
                    </button>
                </div>
            </header>

            <div class="ts-lms-settings-container">
                <aside class="ts-lms-settings-sidebar">
                    <nav>
                        <ul>
                            <li class="<?php echo $active_tab === 'general' ? 'active' : ''; ?>">
                                <a href="?page=ts-lms-settings&tab=general">
                                    <span class="dashicons dashicons-admin-generic"></span>
                                    <?php esc_html_e( 'General', 'ts-lms' ); ?>
                                </a>
                            </li>
                            <li class="<?php echo $active_tab === 'course' ? 'active' : ''; ?>">
                                <a href="?page=ts-lms-settings&tab=course">
                                    <span class="dashicons dashicons-welcome-learn-more"></span>
                                    <?php esc_html_e( 'Course', 'ts-lms' ); ?>
                                </a>
                            </li>
                            <li class="<?php echo $active_tab === 'design' ? 'active' : ''; ?>">
                                <a href="?page=ts-lms-settings&tab=design">
                                    <span class="dashicons dashicons-art"></span>
                                    <?php esc_html_e( 'Design', 'ts-lms' ); ?>
                                </a>
                            </li>
                            <li class="<?php echo $active_tab === 'advanced' ? 'active' : ''; ?>">
                                <a href="?page=ts-lms-settings&tab=advanced">
                                    <span class="dashicons dashicons-admin-tools"></span>
                                    <?php esc_html_e( 'Advanced', 'ts-lms' ); ?>
                                </a>
                            </li>
                            <li class="<?php echo $active_tab === 'gradebook' ? 'active' : ''; ?>">
                                <a href="?page=ts-lms-settings&tab=gradebook">
                                    <span class="dashicons dashicons-welcome-widgets-menus"></span>
                                    <?php esc_html_e( 'Gradebook', 'ts-lms' ); ?>
                                </a>
                            </li>
                            <li class="<?php echo $active_tab === 'email' ? 'active' : ''; ?>">
                                <a href="?page=ts-lms-settings&tab=email">
                                    <span class="dashicons dashicons-email"></span>
                                    <?php esc_html_e( 'Email', 'ts-lms' ); ?>
                                </a>
                            </li>
                            <li class="<?php echo $active_tab === 'notifications' ? 'active' : ''; ?>">
                                <a href="?page=ts-lms-settings&tab=notifications">
                                    <span class="dashicons dashicons-megaphone"></span>
                                    <?php esc_html_e( 'Notifications', 'ts-lms' ); ?>
                                </a>
                            </li>
                            <li class="<?php echo $active_tab === 'authentication' ? 'active' : ''; ?>">
                                <a href="?page=ts-lms-settings&tab=authentication">
                                    <span class="dashicons dashicons-shield"></span>
                                    <?php esc_html_e( 'Authentication', 'ts-lms' ); ?>
                                </a>
                            </li>
                            <li class="<?php echo $active_tab === 'certificate' ? 'active' : ''; ?>">
                                <a href="?page=ts-lms-settings&tab=certificate">
                                    <span class="dashicons dashicons-awards"></span>
                                    <?php esc_html_e( 'Certificate', 'ts-lms' ); ?>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </aside>

                <main class="ts-lms-settings-content">
                    <form id="ts-lms-settings-form" method="post" action="">
                        <input type="hidden" name="active_tab" value="<?php echo esc_attr( $active_tab ); ?>">
                        <?php wp_nonce_field( 'ts_lms_save_settings', 'ts_lms_settings_nonce' ); ?>
                        <?php settings_errors( 'ts_lms_settings' ); ?>
                        
                        <?php if ( $active_tab === 'course' ) : ?>
                            <div class="section-header">
                                <h2><?php esc_html_e( 'Course', 'ts-lms' ); ?></h2>
                                <a href="#" class="reset-link"><span class="dashicons dashicons-undo"></span> <?php esc_html_e( 'Reset to Default', 'ts-lms' ); ?></a>
                            </div>

                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Course Visibility', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Students must be logged in to view course.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[course_visibility]" value="1" <?php checked( isset( $settings['course_visibility'] ) && $settings['course_visibility'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Course Content Access', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Allow instructors and admins to view the course content without enrolling.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[course_content_access]" value="1" <?php checked( isset( $settings['course_content_access'] ) && $settings['course_content_access'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Content Summary', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enabling this feature will show a course content summary on the Course Details page.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[content_summary]" value="1" <?php checked( isset( $settings['content_summary'] ) && $settings['content_summary'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Spotlight Mode', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'This will hide the header and the footer and enable spotlight (full screen) mode when students view lessons.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[spotlight_mode]" value="1" <?php checked( isset( $settings['spotlight_mode'] ) && $settings['spotlight_mode'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Auto Complete Course on All Lesson Completion', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'If enabled, an Enrolled Course will be automatically completed if all its Lessons, Quizzes, and Assignments are already completed by the Student.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[auto_complete_course]" value="1" <?php checked( isset( $settings['auto_complete_course'] ) && $settings['auto_complete_course'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Course Completion Process', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose when a user can click on the "Complete Course" button.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field nested-options">
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[course_completion_process]" value="flexible" <?php checked( !isset( $settings['course_completion_process'] ) || $settings['course_completion_process'] === 'flexible' ); ?>>
                                            <div class="radio-info">
                                                <span class="option-title"><?php esc_html_e( 'Flexible', 'ts-lms' ); ?></span>
                                                <span class="option-desc"><?php esc_html_e( 'Students can complete courses anytime in the Flexible mode.', 'ts-lms' ); ?></span>
                                            </div>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[course_completion_process]" value="strict" <?php checked( isset( $settings['course_completion_process'] ) && $settings['course_completion_process'] === 'strict' ); ?>>
                                            <div class="radio-info">
                                                <span class="option-title"><?php esc_html_e( 'Strict', 'ts-lms' ); ?></span>
                                                <span class="option-desc"><?php esc_html_e( 'Students must complete all lessons, quizzes, and assignments to mark their courses as complete.', 'ts-lms' ); ?></span>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Course Retake', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enabling this feature will allow students to reset course progress and start over.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[course_retake]" value="1" <?php checked( isset( $settings['course_retake'] ) && $settings['course_retake'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Publish Course Review on Admin\'s Approval', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable to publish/re-publish Course Review after the approval of Site Admin.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[publish_review_approval]" value="1" <?php checked( isset( $settings['publish_review_approval'] ) && $settings['publish_review_approval'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Redirect Instructor to "My Courses" once Publish button is Clicked', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable to Redirect an Instructor to the "My Courses" Page once he clicks on the "Publish" button.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[redirect_instructor_publish]" value="1" <?php checked( isset( $settings['redirect_instructor_publish'] ) && $settings['redirect_instructor_publish'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Attachment Open Mode', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'How you want users to view attached files.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field inline-options">
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[attachment_mode]" value="download" <?php checked( !isset( $settings['attachment_mode'] ) || $settings['attachment_mode'] === 'download' ); ?>>
                                            <div class="radio-info">
                                                <span class="option-title"><?php esc_html_e( 'Download', 'ts-lms' ); ?></span>
                                            </div>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[attachment_mode]" value="new_tab" <?php checked( isset( $settings['attachment_mode'] ) && $settings['attachment_mode'] === 'new_tab' ); ?>>
                                            <div class="radio-info">
                                                <span class="option-title"><?php esc_html_e( 'View in new tab', 'ts-lms' ); ?></span>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Enrollment Expiration', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable to allow enrollment expiration feature in all courses.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[enrollment_expiration]" value="1" <?php checked( isset( $settings['enrollment_expiration'] ) && $settings['enrollment_expiration'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Lesson', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'WP Editor for Lesson', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable classic editor to edit lesson.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[lesson_wp_editor]" value="1" <?php checked( isset( $settings['lesson_wp_editor'] ) && $settings['lesson_wp_editor'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Automatically Load Next Course Content', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable this feature to automatically load the next course content after the current one is finished.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[auto_load_next]" value="1" <?php checked( isset( $settings['auto_load_next'] ) && $settings['auto_load_next'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Enable Lesson Comment', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable this feature to allow students to post comments on lessons.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[lesson_comment]" value="1" <?php checked( isset( $settings['lesson_comment'] ) && $settings['lesson_comment'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Quiz', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'When time expires', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose which action to follow when the quiz time expires.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field nested-options">
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[quiz_expiry_action]" value="auto_submit" <?php checked( !isset( $settings['quiz_expiry_action'] ) || $settings['quiz_expiry_action'] === 'auto_submit' ); ?>>
                                            <div class="radio-info">
                                                <span class="option-title"><?php esc_html_e( 'Auto Submit', 'ts-lms' ); ?></span>
                                                <span class="option-desc"><?php esc_html_e( 'The current quiz answers are submitted automatically.', 'ts-lms' ); ?></span>
                                            </div>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[quiz_expiry_action]" value="auto_abandon" <?php checked( isset( $settings['quiz_expiry_action'] ) && $settings['quiz_expiry_action'] === 'auto_abandon' ); ?>>
                                            <div class="radio-info">
                                                <span class="option-title"><?php esc_html_e( 'Auto Abandon', 'ts-lms' ); ?></span>
                                                <span class="option-desc"><?php esc_html_e( 'Attempts must be submitted before time expires, otherwise they will not be counted.', 'ts-lms' ); ?></span>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Correct Answer Display Time (When Reveal Mode is enabled)', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Put the answer display time in seconds.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="number" name="ts_lms_settings[quiz_reveal_time]" value="<?php echo esc_attr( isset( $settings['quiz_reveal_time'] ) ? $settings['quiz_reveal_time'] : 2 ); ?>" class="ts-lms-input-number">
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Default Quiz Attempt Limit (When Retry Mode is enabled)', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'The highest number of attempts allowed for students to participate a quiz. 0 means unlimited. This will work as the default Quiz Attempt limit in case of Quiz Retry Mode.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="number" name="ts_lms_settings[quiz_attempt_limit]" value="<?php echo esc_attr( isset( $settings['quiz_attempt_limit'] ) ? $settings['quiz_attempt_limit'] : 10 ); ?>" class="ts-lms-input-number">
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Show Quiz Previous Button', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose whether to show or hide the previous button for each question.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[quiz_prev_button]" value="1" <?php checked( isset( $settings['quiz_prev_button'] ) && $settings['quiz_prev_button'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Final Grade Calculation', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'When multiple attempts are allowed, select which method should be used to calculate a student\'s final grade for the quiz.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field inline-options">
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[quiz_grade_method]" value="highest" <?php checked( !isset( $settings['quiz_grade_method'] ) || $settings['quiz_grade_method'] === 'highest' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'Highest Grade', 'ts-lms' ); ?></span>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[quiz_grade_method]" value="average" <?php checked( isset( $settings['quiz_grade_method'] ) && $settings['quiz_grade_method'] === 'average' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'Average Grade', 'ts-lms' ); ?></span>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[quiz_grade_method]" value="first" <?php checked( isset( $settings['quiz_grade_method'] ) && $settings['quiz_grade_method'] === 'first' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'First Attempt', 'ts-lms' ); ?></span>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[quiz_grade_method]" value="last" <?php checked( isset( $settings['quiz_grade_method'] ) && $settings['quiz_grade_method'] === 'last' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'Last Attempt', 'ts-lms' ); ?></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Hide Quiz Details From Students', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'If enabled, the students will not be able to see their quiz attempts details.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[quiz_hide_details]" value="1" <?php checked( isset( $settings['quiz_hide_details'] ) && $settings['quiz_hide_details'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Video', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Prevent Video Recording', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable this to prevent screen recording and screenshots on lesson pages (right-click, keyboard shortcuts, etc.).', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[prevent_video_recording]" value="1" <?php checked( isset( $settings['prevent_video_recording'] ) && $settings['prevent_video_recording'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Enable Video Watermark', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Display a watermark image on video lessons.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[video_watermark_enabled]" value="1" <?php checked( isset( $settings['video_watermark_enabled'] ) && $settings['video_watermark_enabled'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Watermark Image', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Upload an image to use as watermark on video lessons.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field logo-upload-box">
                                        <div class="logo-preview-container">
                                            <?php $watermark_url = isset( $settings['video_watermark_image'] ) ? $settings['video_watermark_image'] : ''; ?>
                                            <div class="logo-preview <?php echo $watermark_url ? 'has-logo' : ''; ?>">
                                                <?php if ( $watermark_url ) : ?>
                                                    <img src="<?php echo esc_url( $watermark_url ); ?>" alt="Watermark">
                                                <?php else : ?>
                                                    <span class="dashicons dashicons-format-image"></span>
                                                    <span><?php esc_html_e( 'Upload Watermark', 'ts-lms' ); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="logo-upload-info">
                                                <p><?php esc_html_e( 'Recommended: PNG with transparency', 'ts-lms' ); ?></p>
                                                <p><?php esc_html_e( 'File Support: .jpg, .jpeg or .png', 'ts-lms' ); ?></p>
                                                <input type="hidden" name="ts_lms_settings[video_watermark_image]" id="ts_lms_watermark_image" value="<?php echo esc_attr( $watermark_url ); ?>">
                                                <button type="button" class="button button-secondary ts-lms-upload-image" data-target="ts_lms_watermark_image"><?php esc_html_e( 'Upload Image', 'ts-lms' ); ?></button>
                                                <?php if ( $watermark_url ) : ?>
                                                    <button type="button" class="button button-secondary ts-lms-remove-image" data-target="ts_lms_watermark_image" style="margin-left: 5px;"><?php esc_html_e( 'Remove', 'ts-lms' ); ?></button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="settings-row bordered vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Watermark Size', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Select the size of the watermark on the video.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field inline-options">
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[video_watermark_size]" value="small" <?php checked( !isset( $settings['video_watermark_size'] ) || $settings['video_watermark_size'] === 'small' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'Small', 'ts-lms' ); ?></span>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[video_watermark_size]" value="medium" <?php checked( isset( $settings['video_watermark_size'] ) && $settings['video_watermark_size'] === 'medium' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'Medium', 'ts-lms' ); ?></span>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[video_watermark_size]" value="large" <?php checked( isset( $settings['video_watermark_size'] ) && $settings['video_watermark_size'] === 'large' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'Large', 'ts-lms' ); ?></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Watermark Position', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose where the watermark should appear on the video.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field inline-options">
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[video_watermark_position]" value="top-left" <?php checked( !isset( $settings['video_watermark_position'] ) || $settings['video_watermark_position'] === 'top-left' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'Top Left', 'ts-lms' ); ?></span>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[video_watermark_position]" value="top-right" <?php checked( isset( $settings['video_watermark_position'] ) && $settings['video_watermark_position'] === 'top-right' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'Top Right', 'ts-lms' ); ?></span>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[video_watermark_position]" value="bottom-left" <?php checked( isset( $settings['video_watermark_position'] ) && $settings['video_watermark_position'] === 'bottom-left' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'Bottom Left', 'ts-lms' ); ?></span>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[video_watermark_position]" value="bottom-right" <?php checked( isset( $settings['video_watermark_position'] ) && $settings['video_watermark_position'] === 'bottom-right' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'Bottom Right', 'ts-lms' ); ?></span>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[video_watermark_position]" value="center" <?php checked( isset( $settings['video_watermark_position'] ) && $settings['video_watermark_position'] === 'center' ); ?>>
                                            <span class="option-title"><?php esc_html_e( 'Center', 'ts-lms' ); ?></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Watermark Movement', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose whether the watermark should stay fixed or move around the video.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field nested-options">
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[video_watermark_movement]" value="static" <?php checked( !isset( $settings['video_watermark_movement'] ) || $settings['video_watermark_movement'] === 'static' ); ?>>
                                            <div class="radio-info">
                                                <span class="option-title"><?php esc_html_e( 'Static', 'ts-lms' ); ?></span>
                                                <span class="option-desc"><?php esc_html_e( 'Watermark stays in the selected position.', 'ts-lms' ); ?></span>
                                            </div>
                                        </label>
                                        <label class="ts-lms-radio-wrapper">
                                            <input type="radio" name="ts_lms_settings[video_watermark_movement]" value="moving" <?php checked( isset( $settings['video_watermark_movement'] ) && $settings['video_watermark_movement'] === 'moving' ); ?>>
                                            <div class="radio-info">
                                                <span class="option-title"><?php esc_html_e( 'Moving', 'ts-lms' ); ?></span>
                                                <span class="option-desc"><?php esc_html_e( 'Watermark moves around the video continuously.', 'ts-lms' ); ?></span>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Watermark Opacity', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Set the transparency level of the watermark (0-100, where 100 is fully opaque).', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="number" name="ts_lms_settings[video_watermark_opacity]" value="<?php echo esc_attr( isset( $settings['video_watermark_opacity'] ) ? $settings['video_watermark_opacity'] : 70 ); ?>" min="0" max="100" class="ts-lms-input-number">
                                    </div>
                                </div>
                            </div>

                        <?php elseif ( $active_tab === 'general' ) : ?>
                            <div class="section-header">
                                <h2><?php esc_html_e( 'General', 'ts-lms' ); ?></h2>
                                <a href="#" class="reset-link"><span class="dashicons dashicons-undo"></span> <?php esc_html_e( 'Reset to Default', 'ts-lms' ); ?></a>
                            </div>

                            <div class="settings-card">
                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Dashboard Page', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'This page will be used for student and instructor dashboard', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <?php wp_dropdown_pages( array(
                                            'name'              => 'ts_lms_settings[dashboard_page]',
                                            'selected'          => isset( $settings['dashboard_page'] ) ? $settings['dashboard_page'] : 0,
                                            'show_option_none'  => __( 'Select Option', 'ts-lms' ),
                                            'option_none_value' => '0',
                                            'class'             => 'ts-lms-select'
                                        ) ); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="settings-card">
                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Terms and Conditions Page', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'This page will be used as the Terms and Conditions page', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <?php wp_dropdown_pages( array(
                                            'name'              => 'ts_lms_settings[terms_page]',
                                            'selected'          => isset( $settings['terms_page'] ) ? $settings['terms_page'] : 0,
                                            'show_option_none'  => __( 'Select Option', 'ts-lms' ),
                                            'option_none_value' => '0',
                                            'class'             => 'ts-lms-select'
                                        ) ); ?>
                                    </div>
                                </div>
                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Privacy Policy', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose the page for privacy policy.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <?php wp_dropdown_pages( array(
                                            'name'              => 'ts_lms_settings[privacy_page]',
                                            'selected'          => isset( $settings['privacy_page'] ) ? $settings['privacy_page'] : 0,
                                            'show_option_none'  => __( 'Select Option', 'ts-lms' ),
                                            'option_none_value' => '0',
                                            'class'             => 'ts-lms-select'
                                        ) ); ?>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Others', 'ts-lms' ); ?></h3>
                            <div class="settings-card">
                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Enable Marketplace', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Allow multiple instructors to sell their courses.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[enable_marketplace]" value="1" <?php checked( isset( $settings['enable_marketplace'] ) && $settings['enable_marketplace'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="settings-card">
                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Pagination', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Set the number of rows to be displayed per page', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="number" name="ts_lms_settings[pagination]" value="<?php echo esc_attr( isset( $settings['pagination'] ) ? $settings['pagination'] : 20 ); ?>" class="ts-lms-input-number">
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Instructor', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Become an Instructor Button', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable the option to display this button on the student dashboard.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[become_instructor_button]" value="1" <?php checked( isset( $settings['become_instructor_button'] ) && $settings['become_instructor_button'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Instructor Registration Limit', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Maximum number of instructors allowed to register. Set 0 for unlimited.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="number" name="ts_lms_settings[instructor_registration_limit]" value="<?php echo esc_attr( isset( $settings['instructor_registration_limit'] ) ? $settings['instructor_registration_limit'] : 0 ); ?>" class="ts-lms-input-number" min="0">
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Allow Instructors to Publish Courses', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable instructors to publish the course directly. If disabled, admins will be able to review course content before publishing.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[allow_publish_courses]" value="1" <?php checked( isset( $settings['allow_publish_courses'] ) && $settings['allow_publish_courses'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Allow Instructors to Trash Courses', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable this setting to allow instructors to delete courses.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[allow_trash_courses]" value="1" <?php checked( isset( $settings['allow_trash_courses'] ) && $settings['allow_trash_courses'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Allow Instructors to Change Course Author', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'If enabled, instructors can change the course author for their courses.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[allow_change_author]" value="1" <?php checked( isset( $settings['allow_change_author'] ) && $settings['allow_change_author'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                </div>
                            </div>

                        <?php elseif ( $active_tab === 'design' ) : ?>
                            <div class="section-header">
                                <h2><?php esc_html_e( 'Design', 'ts-lms' ); ?></h2>
                                <a href="#" class="reset-link"><span class="dashicons dashicons-undo"></span> <?php esc_html_e( 'Reset to Default', 'ts-lms' ); ?></a>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Course', 'ts-lms' ); ?></h3>
                            <div class="settings-card">
                                <div class="settings-row vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Course Builder Page Logo', 'ts-lms' ); ?></h3>
                                    </div>
                                    <div class="settings-field logo-upload-box">
                                        <div class="logo-preview-container">
                                            <?php $logo_url = isset( $settings['builder_logo'] ) ? $settings['builder_logo'] : ''; ?>
                                            <div class="logo-preview <?php echo $logo_url ? 'has-logo' : ''; ?>">
                                                <?php if ( $logo_url ) : ?>
                                                    <img src="<?php echo esc_url( $logo_url ); ?>" alt="Logo">
                                                <?php else : ?>
                                                    <span class="dashicons dashicons-format-image"></span>
                                                    <span><?php esc_html_e( 'Upload Image', 'ts-lms' ); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="logo-upload-info">
                                                <p><?php esc_html_e( 'Size: 700x430 pixels', 'ts-lms' ); ?></p>
                                                <p><?php esc_html_e( 'File Support: .jpg, .jpeg or .png', 'ts-lms' ); ?></p>
                                                <input type="hidden" name="ts_lms_settings[builder_logo]" id="ts_lms_builder_logo" value="<?php echo esc_attr( $logo_url ); ?>">
                                                <button type="button" class="button button-secondary ts-lms-upload-image" data-target="ts_lms_builder_logo"><?php esc_html_e( 'Upload Image', 'ts-lms' ); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Column Per Row', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Define how many columns you want to use to display courses.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <div class="ts-lms-visual-select columns-select">
                                            <?php 
                                            $col_val = isset( $settings['course_columns'] ) ? $settings['course_columns'] : 'three';
                                            $cols = array(
                                                'one'   => 'One Column',
                                                'two'   => 'Two Columns',
                                                'three' => 'Three Columns',
                                                'four'  => 'Four Columns'
                                            );
                                            foreach ( $cols as $key => $label ) : ?>
                                                <label class="visual-option <?php echo $col_val === $key ? 'selected' : ''; ?>">
                                                    <input type="radio" name="ts_lms_settings[course_columns]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $col_val, $key ); ?>>
                                                    <div class="option-icon columns-icon-<?php echo esc_attr( $key ); ?>"></div>
                                                    <span><?php echo esc_html( $label ); ?></span>
                                                </label>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Courses Per Page', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Set the number of courses to display per page on the Course List page.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="number" name="ts_lms_settings[courses_per_page]" value="<?php echo esc_attr( isset( $settings['courses_per_page'] ) ? $settings['courses_per_page'] : 12 ); ?>" class="ts-lms-input-number">
                                    </div>
                                </div>

                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Course Filter', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Show sorting and filtering options on course archive page.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[course_filter]" value="1" <?php checked( isset( $settings['course_filter'] ) && $settings['course_filter'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>

                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Course Sorting', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'If enabled, the courses will be sortable by Course Name or Creation Date in either Ascending or Descending order.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[course_sorting]" value="1" <?php checked( isset( $settings['course_sorting'] ) && $settings['course_sorting'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Course Catalog Filters', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Show Search Box', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Display search box in course catalog sidebar.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[catalog_show_search]" value="1" <?php checked( !isset( $settings['catalog_show_search'] ) || $settings['catalog_show_search'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Show Type Filter', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Filter by course type (Course/Bundle).', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[catalog_show_type]" value="1" <?php checked( !isset( $settings['catalog_show_type'] ) || $settings['catalog_show_type'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Show Category Filter', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Filter courses by category.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[catalog_show_category]" value="1" <?php checked( !isset( $settings['catalog_show_category'] ) || $settings['catalog_show_category'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Show Tag Filter', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Filter courses by tag.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[catalog_show_tag]" value="1" <?php checked( !isset( $settings['catalog_show_tag'] ) || $settings['catalog_show_tag'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Show Level Filter', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Filter by difficulty level.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[catalog_show_level]" value="1" <?php checked( !isset( $settings['catalog_show_level'] ) || $settings['catalog_show_level'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Show Price Filter', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Filter by price (Free/Paid).', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[catalog_show_price]" value="1" <?php checked( !isset( $settings['catalog_show_price'] ) || $settings['catalog_show_price'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Layout', 'ts-lms' ); ?></h3>
                            <div class="settings-card">
                                <div class="settings-row vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Instructor List Layout', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose a layout for the list of instructors inside a course page. You can change this at any time.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <div class="ts-lms-visual-select instructor-list-layout-select">
                                            <?php 
                                            $inst_layout = isset( $settings['instructor_list_layout'] ) ? $settings['instructor_list_layout'] : 'portrait';
                                            $layouts = array(
                                                'portrait'           => 'Portrait',
                                                'cover'              => 'Cover',
                                                'minimal'            => 'Minimal',
                                                'portrait_horizontal' => 'Portrait Horizontal',
                                                'minimal_horizontal'  => 'Minimal Horizontal'
                                            );
                                            foreach ( $layouts as $key => $label ) : ?>
                                                <label class="visual-option layout-option <?php echo $inst_layout === $key ? 'selected' : ''; ?>">
                                                    <input type="radio" name="ts_lms_settings[instructor_list_layout]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $inst_layout, $key ); ?>>
                                                    <div class="option-preview layout-preview-<?php echo esc_attr( $key ); ?>">
                                                        <div class="preview-item-avatar"></div>
                                                        <div class="preview-item-lines">
                                                            <div class="line title"></div>
                                                            <div class="line meta"></div>
                                                        </div>
                                                    </div>
                                                    <span><?php echo esc_html( $label ); ?></span>
                                                </label>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="settings-row vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Instructor Public Profile Layout', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose a layout design for a instructor\'s public profile.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <div class="ts-lms-visual-select profile-layout-select">
                                            <?php 
                                            $inst_profile = isset( $settings['instructor_profile_layout'] ) ? $settings['instructor_profile_layout'] : 'classic';
                                            $p_layouts = array(
                                                'private' => 'Private',
                                                'modern'  => 'Modern',
                                                'minimal' => 'Minimal',
                                                'classic' => 'Classic'
                                            );
                                            foreach ( $p_layouts as $key => $label ) : ?>
                                                <label class="visual-option profile-option <?php echo $inst_profile === $key ? 'selected' : ''; ?>">
                                                    <input type="radio" name="ts_lms_settings[instructor_profile_layout]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $inst_profile, $key ); ?>>
                                                    <div class="option-preview profile-preview-<?php echo esc_attr( $key ); ?>">
                                                        <div class="preview-hero"></div>
                                                        <div class="preview-body">
                                                            <div class="preview-sidebar"></div>
                                                            <div class="preview-content">
                                                                <div class="line"></div>
                                                                <div class="line"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <span><?php echo esc_html( $label ); ?></span>
                                                </label>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="settings-row vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Student Public Profile Layout', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose a layout design for a student\'s public profile.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <div class="ts-lms-visual-select profile-layout-select">
                                            <?php 
                                            $stud_profile = isset( $settings['student_profile_layout'] ) ? $settings['student_profile_layout'] : 'classic';
                                            foreach ( $p_layouts as $key => $label ) : ?>
                                                <label class="visual-option profile-option <?php echo $stud_profile === $key ? 'selected' : ''; ?>">
                                                    <input type="radio" name="ts_lms_settings[student_profile_layout]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $stud_profile, $key ); ?>>
                                                    <div class="option-preview profile-preview-<?php echo esc_attr( $key ); ?>">
                                                        <div class="preview-hero"></div>
                                                        <div class="preview-body">
                                                            <div class="preview-sidebar"></div>
                                                            <div class="preview-content">
                                                                <div class="line"></div>
                                                                <div class="line"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <span><?php echo esc_html( $label ); ?></span>
                                                </label>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Course Details', 'ts-lms' ); ?></h3>
                            <div class="settings-card">
                                <div class="settings-row vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Page Features', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'You can keep the following features active or inactive as per the need of your business model.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field feature-toggle-grid">
                                        <?php 
                                        $features = array(
                                            'instructor_info' => 'Instructor Info',
                                            'wishlist'        => 'Wishlist',
                                            'q_a'             => 'Q&A',
                                            'author'          => 'Author',
                                            'level'           => 'Level',
                                            'social_share'    => 'Social Share',
                                            'duration'        => 'Duration',
                                            'total_enrolled'  => 'Total Enrolled',
                                            'update_date'     => 'Update Date',
                                            'progress_bar'    => 'Progress Bar',
                                            'material'        => 'Material',
                                            'about'           => 'About',
                                            'description'     => 'Description',
                                            'benefits'        => 'Benefits',
                                            'requirements'    => 'Requirements',
                                            'target_audience' => 'Target audience',
                                            'announcements'   => 'Announcements',
                                            'review'          => 'Review',
                                            'sticky_sidebar'  => 'Sticky Sidebar'
                                        );
                                        
                                        // Default to checked if not explicitly set
                                        $current_features = isset( $settings['course_features'] ) ? (array)$settings['course_features'] : array_keys( $features );
                                        
                                        foreach ( $features as $key => $label ) : ?>
                                            <div class="feature-item">
                                                <div class="feature-toggle-card">
                                                    <label class="ts-lms-switch">
                                                        <input type="checkbox" name="ts_lms_settings[course_features][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $current_features ) ); ?>>
                                                        <span class="slider round"></span>
                                                    </label>
                                                    <span class="feature-label"><?php echo esc_html( $label ); ?></span>
                                                    <span class="dashicons dashicons-info"></span>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Position of the Enrollment Box in Mobile View', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'You can decide where you want to show Enrollment Box on your Course Details page by selecting an option from here.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <select name="ts_lms_settings[enrollment_box_mobile]" class="ts-lms-select">
                                            <option value="page_bottom" <?php selected( isset( $settings['enrollment_box_mobile'] ) ? $settings['enrollment_box_mobile'] : 'page_bottom', 'page_bottom' ); ?>><?php esc_html_e( 'On Page Bottom', 'ts-lms' ); ?></option>
                                            <option value="page_top" <?php selected( isset( $settings['enrollment_box_mobile'] ) ? $settings['enrollment_box_mobile'] : 'page_bottom', 'page_top' ); ?>><?php esc_html_e( 'On Page Top', 'ts-lms' ); ?></option>
                                        </select>
                                    </div>
                                </div>

                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Showcase Certificate', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable to show certificate on course details.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[show_certificate]" value="1" <?php checked( isset( $settings['show_certificate'] ) && $settings['show_certificate'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Colors', 'ts-lms' ); ?></h3>
                            <div class="settings-card">
                                <div class="settings-row vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Preset Colors', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'These colors will be used throughout your website. Choose between these presets or create your own custom palette.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <div class="ts-lms-color-presets">
                                            <?php 
                                            $active_preset = isset( $settings['color_preset'] ) ? $settings['color_preset'] : 'default';
                                            
                                            // Determine custom colors based on current settings or defaults
                                            $custom_colors = array( '#0077B5', '#005E8F', '#1F2937', '#F3F4F6', '#0077B5', '#005E8F', '#ffffff', '#ffffff', '#0077B5' );
                                            if ( $active_preset === 'custom' ) {
                                                $custom_colors = array(
                                                    isset($settings['primary_color']) ? $settings['primary_color'] : '#0077B5',
                                                    isset($settings['primary_hover_color']) ? $settings['primary_hover_color'] : '#005E8F',
                                                    isset($settings['text_color']) ? $settings['text_color'] : '#1F2937',
                                                    isset($settings['gray_color']) ? $settings['gray_color'] : '#F3F4F6',
                                                    isset($settings['button_color']) ? $settings['button_color'] : '#0077B5',
                                                    isset($settings['button_hover_color']) ? $settings['button_hover_color'] : '#005E8F',
                                                    isset($settings['button_text_color']) ? $settings['button_text_color'] : '#ffffff',
                                                    isset($settings['body_bg_color']) ? $settings['body_bg_color'] : '#ffffff',
                                                    isset($settings['icon_color']) ? $settings['icon_color'] : '#0077B5'
                                                );
                                            }

                                            $presets = array(
                                                'default'   => array( '#0077B5', '#005E8F', '#1F2937', '#F3F4F6', '#0077B5', '#005E8F', '#ffffff', '#ffffff', '#0077B5' ),
                                                'landscape' => array( '#10b981', '#059669', '#111827', '#f9fafb', '#10b981', '#059669', '#ffffff', '#ffffff', '#10b981' ),
                                                'ocean'     => array( '#0ea5e9', '#0284c7', '#0f172a', '#f1f5f9', '#0ea5e9', '#0284c7', '#ffffff', '#ffffff', '#0ea5e9' ),
                                                'custom'    => $custom_colors
                                            );
                                            foreach ( $presets as $key => $colors ) : ?>
                                                <label class="preset-option <?php echo $active_preset === $key ? 'selected' : ''; ?>" data-colors='<?php echo json_encode( $colors ); ?>'>
                                                    <input type="radio" name="ts_lms_settings[color_preset]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $active_preset, $key ); ?>>
                                                    <div class="preset-preview">
                                                        <?php 
                                                        $preview_colors = array_slice( $colors, 0, 4 );
                                                        foreach ( $preview_colors as $color ) : ?>
                                                            <span style="background-color: <?php echo esc_attr( $color ); ?>"></span>
                                                        <?php endforeach; ?>
                                                    </div>
                                                    <span class="preset-label"><?php echo esc_html( ucfirst( $key ) ); ?></span>
                                                </label>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Primary Color', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose a primary color.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[primary_color]" value="<?php echo esc_attr( isset( $settings['primary_color'] ) ? $settings['primary_color'] : '#0077B5' ); ?>" class="ts-lms-color-picker">
                                    </div>
                                </div>
                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Primary Hover Color', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose a primary hover color.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[primary_hover_color]" value="<?php echo esc_attr( isset( $settings['primary_hover_color'] ) ? $settings['primary_hover_color'] : '#005E8F' ); ?>" class="ts-lms-color-picker">
                                    </div>
                                </div>
                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Text Color', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose a text color for your website.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[text_color]" value="<?php echo esc_attr( isset( $settings['text_color'] ) ? $settings['text_color'] : '#1e293b' ); ?>" class="ts-lms-color-picker">
                                    </div>
                                </div>
                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Gray', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose a color for elements like table, card etc.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[gray_color]" value="<?php echo esc_attr( isset( $settings['gray_color'] ) ? $settings['gray_color'] : '#f8fafc' ); ?>" class="ts-lms-color-picker">
                                    </div>
                                </div>
                                <div class="advanced-colors" style="display: none;">
                                    <div class="settings-row">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Button Color', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'Choose a background color for buttons.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field">
                                            <input type="text" name="ts_lms_settings[button_color]" value="<?php echo esc_attr( isset( $settings['button_color'] ) ? $settings['button_color'] : '#0077B5' ); ?>" class="ts-lms-color-picker">
                                        </div>
                                    </div>
                                    <div class="settings-row">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Button Hover Color', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'Choose a hover color for buttons.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field">
                                            <input type="text" name="ts_lms_settings[button_hover_color]" value="<?php echo esc_attr( isset( $settings['button_hover_color'] ) ? $settings['button_hover_color'] : '#005E8F' ); ?>" class="ts-lms-color-picker">
                                        </div>
                                    </div>
                                    <div class="settings-row">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Button Text Color', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'Choose a text color for buttons.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field">
                                            <input type="text" name="ts_lms_settings[button_text_color]" value="<?php echo esc_attr( isset( $settings['button_text_color'] ) ? $settings['button_text_color'] : '#ffffff' ); ?>" class="ts-lms-color-picker">
                                        </div>
                                    </div>
                                    <div class="settings-row">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Website Background Color', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'Choose a background color for the body.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field">
                                            <input type="text" name="ts_lms_settings[body_bg_color]" value="<?php echo esc_attr( isset( $settings['body_bg_color'] ) ? $settings['body_bg_color'] : '#ffffff' ); ?>" class="ts-lms-color-picker">
                                        </div>
                                    </div>
                                    <div class="settings-row">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Global Icon Color', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'Choose a color for icons throughout the website.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field">
                                            <input type="text" name="ts_lms_settings[icon_color]" value="<?php echo esc_attr( isset( $settings['icon_color'] ) ? $settings['icon_color'] : '#0077B5' ); ?>" class="ts-lms-color-picker">
                                        </div>
                                    </div>
                                </div>
                                <div class="show-more-colors">
                                    <a href="#" class="ts-lms-toggle-colors"><span class="dashicons dashicons-plus"></span> <?php esc_html_e( 'Show More', 'ts-lms' ); ?></a>
                                </div>
                            </div>
                        <?php elseif ( $active_tab === 'notifications' ) : ?>
                            <div class="section-header">
                                <h2><?php esc_html_e( 'Notifications', 'ts-lms' ); ?></h2>
                                <a href="#" class="reset-link">
                                    <span class="dashicons dashicons-image-rotate"></span>
                                    <?php esc_html_e( 'Reset to Default', 'ts-lms' ); ?>
                                </a>
                            </div>

                            <div class="notifications-container">
                                <?php
                                $notification_sections = array(
                                    'student' => array(
                                        'title' => __( 'Student Notification', 'ts-lms' ),
                                        'icon'  => 'dashicons-id',
                                        'items' => array(
                                            'course_enrolled' => array(
                                                'title' => __( 'Course Enrolled', 'ts-lms' ),
                                                'desc'  => __( 'Notification when a student enrolls in a course.', 'ts-lms' ),
                                            ),
                                            'cancel_enrollment' => array(
                                                'title' => __( 'Cancel Enrollment', 'ts-lms' ),
                                                'desc'  => __( 'Notification when a student\'s enrollment is cancelled.', 'ts-lms' ),
                                            ),
                                            'assignment_graded' => array(
                                                'title' => __( 'Assignment Graded', 'ts-lms' ),
                                                'desc'  => __( 'When an instructor grades a submitted assignment of the student.', 'ts-lms' ),
                                            ),
                                            'new_announcement' => array(
                                                'title' => __( 'New Announcement Posted', 'ts-lms' ),
                                                'desc'  => __( 'Notification for new announcements posted by the instructor.', 'ts-lms' ),
                                            ),
                                            'qa_answered' => array(
                                                'title' => __( 'Q&A Message Answered', 'ts-lms' ),
                                                'desc'  => __( 'When someone answers one of the student\'s Q&A.', 'ts-lms' ),
                                            ),
                                            'quiz_feedback' => array(
                                                'title' => __( 'Feedback Submitted for Quiz Attempt', 'ts-lms' ),
                                                'desc'  => __( 'Student receives feedback for a quiz attempt.', 'ts-lms' ),
                                            ),
                                            'removed_from_course' => array(
                                                'title' => __( 'Removed From Course', 'ts-lms' ),
                                                'desc'  => __( 'An instructor/admin deletes a student from the enrollment list.', 'ts-lms' ),
                                                'no_onsite' => true,
                                            ),
                                        ),
                                    ),
                                    'instructor' => array(
                                        'title' => __( 'Instructor Notification', 'ts-lms' ),
                                        'icon'  => 'dashicons-businessman',
                                        'items' => array(
                                            'inst_app_accepted' => array(
                                                'title' => __( 'Instructor Application Accepted', 'ts-lms' ),
                                                'desc'  => __( 'Submitted instructor registration application is accepted by the admin.', 'ts-lms' ),
                                            ),
                                            'inst_app_rejected' => array(
                                                'title' => __( 'Instructor Application Rejected', 'ts-lms' ),
                                                'desc'  => __( 'Submitted instructor registration application is rejected by the admin.', 'ts-lms' ),
                                            ),
                                        ),
                                    ),
                                    'admin' => array(
                                        'title' => __( 'Admin Notification', 'ts-lms' ),
                                        'icon'  => 'dashicons-admin-users',
                                        'items' => array(
                                            'inst_app_received' => array(
                                                'title' => __( 'Instructor Application Received', 'ts-lms' ),
                                                'desc'  => __( 'When you receive an application from someone wanting to register as an instructor', 'ts-lms' ),
                                            ),
                                        ),
                                    ),
                                );

                                foreach ( $notification_sections as $section_id => $section ) : ?>
                                    <div class="notification-section">
                                        <div class="category-header">
                                            <div class="header-info">
                                                <span class="category-icon dashicons <?php echo esc_attr($section['icon']); ?>"></span>
                                                <h3><?php echo esc_html( $section['title'] ); ?></h3>
                                            </div>
                                            <div class="header-status-labels">
                                                <span><?php _e('On Site', 'ts-lms'); ?></span>
                                                <span><?php _e('Push', 'ts-lms'); ?></span>
                                            </div>
                                        </div>
                                        <div class="settings-card no-padding">
                                            <div class="notification-list">
                                                <?php foreach ( $section['items'] as $item_id => $item ) : 
                                                    $onsite_enabled = isset( $settings['notifications'][ $item_id ]['onsite'] ) && $settings['notifications'][ $item_id ]['onsite'];
                                                    $push_enabled = isset( $settings['notifications'][ $item_id ]['push'] ) && $settings['notifications'][ $item_id ]['push'];
                                                    $is_active = $onsite_enabled || $push_enabled;
                                                ?>
                                                    <div class="notification-row <?php echo $is_active ? 'is-active' : ''; ?>">
                                                        <div class="notification-info">
                                                            <h4><?php echo esc_html( $item['title'] ); ?></h4>
                                                            <p><?php echo esc_html( $item['desc'] ); ?></p>
                                                        </div>
                                                        <div class="notification-controls">
                                                            <div class="control-group">
                                                                <?php if ( ! isset( $item['no_onsite'] ) ) : ?>
                                                                    <label class="ts-lms-switch mini">
                                                                        <input type="checkbox" name="ts_lms_settings[notifications][<?php echo esc_attr( $item_id ); ?>][onsite]" value="1" <?php checked( $onsite_enabled, 1 ); ?>>
                                                                        <span class="slider round"></span>
                                                                    </label>
                                                                <?php else : ?>
                                                                    <span class="not-available">—</span>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="control-group">
                                                                <label class="ts-lms-switch mini">
                                                                    <input type="checkbox" name="ts_lms_settings[notifications][<?php echo esc_attr( $item_id ); ?>][push]" value="1" <?php checked( $push_enabled, 1 ); ?>>
                                                                    <span class="slider round"></span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>


                        <?php elseif ( $active_tab === 'advanced' ) : ?>
                            <div class="section-header">
                                <h2><?php esc_html_e( 'Advanced', 'ts-lms' ); ?></h2>
                                <a href="#" class="reset-link"><span class="dashicons dashicons-undo"></span> <?php esc_html_e( 'Reset to Default', 'ts-lms' ); ?></a>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Course Builder Fields Visibility Control', 'ts-lms' ); ?></h3>
                            <div class="visibility-control-table-container">
                                <table class="visibility-control-table">
                                    <thead>
                                        <tr>
                                            <th><?php esc_html_e( 'Field/Section Name', 'ts-lms' ); ?></th>
                                            <th class="checkbox-cell"><?php esc_html_e( 'Admin', 'ts-lms' ); ?></th>
                                            <th class="checkbox-cell"><?php esc_html_e( 'Instructor', 'ts-lms' ); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $visibility_groups = array(
                                            'basics' => array(
                                                'title' => __( 'Course Basics & Sidebar', 'ts-lms' ),
                                                'items' => array(
                                                    'general'         => __( 'General Tab', 'ts-lms' ),
                                                    'content_drip'    => __( 'Content Drip Tab', 'ts-lms' ),
                                                    'enrollment'      => __( 'Enrollment Tab', 'ts-lms' ),
                                                    'featured_image'  => __( 'Featured Image', 'ts-lms' ),
                                                    'intro_video'     => __( 'Intro Video', 'ts-lms' ),
                                                    'pricing_options' => __( 'Pricing Options', 'ts-lms' ),
                                                    'categories'      => __( 'Categories', 'ts-lms' ),
                                                    'tags'            => __( 'Tags', 'ts-lms' ),
                                                    'author'          => __( 'Author', 'ts-lms' ),
                                                )
                                            ),
                                            'overview' => array(
                                                'title' => __( 'Course Overview Fields', 'ts-lms' ),
                                                'items' => array(
                                                    'overview_learn'    => __( 'What Will I Learn?', 'ts-lms' ),
                                                    'overview_audience' => __( 'Target Audience', 'ts-lms' ),
                                                    'overview_duration' => __( 'Total Course Duration', 'ts-lms' ),
                                                    'overview_materials'=> __( 'Materials Included', 'ts-lms' ),
                                                    'overview_reqs'     => __( 'Requirements/Instructions', 'ts-lms' ),
                                                )
                                            ),
                                            'extra' => array(
                                                'title' => __( 'Additional Components', 'ts-lms' ),
                                                'items' => array(
                                                    'certificate' => __( 'Certificate Section', 'ts-lms' ),
                                                    'attachments' => __( 'Attachments', 'ts-lms' ),
                                                    'live_class'  => __( 'Live Class (Meet/Zoom)', 'ts-lms' ),
                                                )
                                            ),
                                            'lesson' => array(
                                                'title' => __( 'Lesson Modal Settings', 'ts-lms' ),
                                                'items' => array(
                                                    'lesson_featured_image' => __( 'Lesson Featured Image', 'ts-lms' ),
                                                    'lesson_video'          => __( 'Lesson Video', 'ts-lms' ),
                                                    'lesson_v_playback'     => __( 'Video Playback Time', 'ts-lms' ),
                                                    'lesson_exercise'       => __( 'Exercise Files', 'ts-lms' ),
                                                    'lesson_preview'        => __( 'Lesson Preview Toggle', 'ts-lms' ),
                                                )
                                            ),
                                        );

                                        foreach ( $visibility_groups as $group_id => $group ) : ?>
                                            <tr class="row-group-title">
                                                <td colspan="3"><?php echo esc_html( $group['title'] ); ?></td>
                                            </tr>
                                            <?php foreach ( $group['items'] as $id => $label ) : 
                                                $admin_checked = !isset( $settings['builder_visibility'][$id]['admin'] ) || $settings['builder_visibility'][$id]['admin'];
                                                $inst_checked = !isset( $settings['builder_visibility'][$id]['instructor'] ) || $settings['builder_visibility'][$id]['instructor'];
                                            ?>
                                                <tr>
                                                    <td><?php echo esc_html( $label ); ?></td>
                                                    <td class="checkbox-cell">
                                                        <label class="ts-lms-switch mini">
                                                            <input type="checkbox" name="ts_lms_settings[builder_visibility][<?php echo $id; ?>][admin]" value="1" <?php checked( $admin_checked ); ?>>
                                                            <span class="slider round"></span>
                                                        </label>
                                                    </td>
                                                    <td class="checkbox-cell">
                                                        <label class="ts-lms-switch mini">
                                                            <input type="checkbox" name="ts_lms_settings[builder_visibility][<?php echo $id; ?>][instructor]" value="1" <?php checked( $inst_checked ); ?>>
                                                            <span class="slider round"></span>
                                                        </label>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Course', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Gutenberg Editor', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable this to create courses using the Gutenberg Editor.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[enable_gutenberg]" value="1" <?php checked( isset( $settings['enable_gutenberg'] ) && $settings['enable_gutenberg'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Hide Course Products on Shop Page', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'If enabled, products that are linked to courses will be hidden from the WooCommerce shop page. Customers can still purchase courses through the course pages.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[hide_course_products_shop]" value="1" <?php checked( !isset( $settings['hide_course_products_shop'] ) || $settings['hide_course_products_shop'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Course Archive Page', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'This page will be used to list all the published courses.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <?php wp_dropdown_pages( array(
                                            'name'              => 'ts_lms_settings[course_archive_page]',
                                            'selected'          => isset( $settings['course_archive_page'] ) ? $settings['course_archive_page'] : 0,
                                            'show_option_none'  => __( 'Select Option', 'ts-lms' ),
                                            'option_none_value' => '0',
                                            'class'             => 'ts-lms-select'
                                        ) ); ?>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Instructor Registration Page', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose the page for instructor registration.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <?php wp_dropdown_pages( array(
                                            'name'              => 'ts_lms_settings[instructor_reg_page]',
                                            'selected'          => isset( $settings['instructor_reg_page'] ) ? $settings['instructor_reg_page'] : 0,
                                            'show_option_none'  => __( 'Select Option', 'ts-lms' ),
                                            'option_none_value' => '0',
                                            'class'             => 'ts-lms-select'
                                        ) ); ?>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Student Registration Page', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose the page for student registration.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <?php wp_dropdown_pages( array(
                                            'name'              => 'ts_lms_settings[student_reg_page]',
                                            'selected'          => isset( $settings['student_reg_page'] ) ? $settings['student_reg_page'] : 0,
                                            'show_option_none'  => __( 'Select Option', 'ts-lms' ),
                                            'option_none_value' => '0',
                                            'class'             => 'ts-lms-select'
                                        ) ); ?>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'YouTube API Key', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'For fetch the videos on your platform using YouTube, enter your YouTube API Key.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[youtube_api_key]" value="<?php echo esc_attr( isset( $settings['youtube_api_key'] ) ? $settings['youtube_api_key'] : '' ); ?>" class="ts-lms-input-text" placeholder="<?php esc_attr_e( 'Insert API key here', 'ts-lms' ); ?>">
                                    </div>
                                </div>

                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Base Permalink', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Course Permalink', 'ts-lms' ); ?></h3>
                                        <div class="permalink-preview">
                                            <code>http://localhost/new-plugin-main/example-course/</code> <strong>example-course</strong>
                                        </div>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[course_base]" value="<?php echo esc_attr( isset( $settings['course_base'] ) ? $settings['course_base'] : 'courses' ); ?>" class="ts-lms-input-text">
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Lesson Permalink', 'ts-lms' ); ?></h3>
                                        <div class="permalink-preview">
                                            <code>http://localhost/new-plugin-main/example-course/lessons/</code> <strong>example-lesson</strong>
                                        </div>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[lesson_base]" value="<?php echo esc_attr( isset( $settings['lesson_base'] ) ? $settings['lesson_base'] : 'lessons' ); ?>" class="ts-lms-input-text">
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Quiz Permalink', 'ts-lms' ); ?></h3>
                                        <div class="permalink-preview">
                                            <code>http://localhost/new-plugin-main/example-course/quizzes/</code> <strong>example-quiz</strong>
                                        </div>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[quiz_base]" value="<?php echo esc_attr( isset( $settings['quiz_base'] ) ? $settings['quiz_base'] : 'quizzes' ); ?>" class="ts-lms-input-text">
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Assignment Permalink', 'ts-lms' ); ?></h3>
                                        <div class="permalink-preview">
                                            <code>http://localhost/new-plugin-main/example-course/assignments/</code> <strong>example-assignment</strong>
                                        </div>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[assignment_base]" value="<?php echo esc_attr( isset( $settings['assignment_base'] ) ? $settings['assignment_base'] : 'assignments' ); ?>" class="ts-lms-input-text">
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Options', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Profile Completion', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enabling this tool will show a notification bar to students and instructors to complete their profile information.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[profile_completion_bar]" value="1" <?php checked( isset( $settings['profile_completion_bar'] ) && $settings['profile_completion_bar'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <!-- Removed duplicated custom login toggle -->
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Erase upon uninstallation', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Delete all data during uninstallation.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[erase_on_uninstall]" value="1" <?php checked( isset( $settings['erase_on_uninstall'] ) && $settings['erase_on_uninstall'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Maintenance Mode', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enabling maintenance mode will display a custom message on the frontend. During maintenance mode, visitors cannot access site content, but the wp-admin dashboard remains accessible.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[maintenance_mode]" value="1" <?php checked( isset( $settings['maintenance_mode'] ) && $settings['maintenance_mode'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Content Security', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Prevent Hotlinking', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Use hotlink protection for your self-hosted images and videos.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[prevent_hotlinking]" value="1" <?php checked( isset( $settings['prevent_hotlinking'] ) && $settings['prevent_hotlinking'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Copy Protection', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Prevent right-click and copy actions on your website.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[copy_protection]" value="1" <?php checked( isset( $settings['copy_protection'] ) && $settings['copy_protection'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'AI Studio', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Enable', 'ts-lms' ); ?></h3>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[enable_ai_studio]" value="1" <?php checked( isset( $settings['enable_ai_studio'] ) ? $settings['enable_ai_studio'] : 1, 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Insert OpenAI API Key', 'ts-lms' ); ?></h3>
                                        <p><?php printf( __( 'Find your OpenAI API key in your %s settings and paste it here.', 'ts-lms' ), '<a href="https://platform.openai.com/account/api-keys" target="_blank">' . __( 'OpenAI User', 'ts-lms' ) . '</a>' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[openai_api_key]" value="<?php echo esc_attr( isset( $settings['openai_api_key'] ) ? $settings['openai_api_key'] : '' ); ?>" class="ts-lms-input-text" placeholder="<?php esc_attr_e( 'API key', 'ts-lms' ); ?>">
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Migration', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Enable Migration Menu', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Checking this box will show the Migration menu in the admin sidebar. Use this if you want to migrate data from Tutor LMS.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[enable_migration]" value="1" <?php checked( isset( $settings['enable_migration'] ) && $settings['enable_migration'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                        <?php elseif ( $active_tab === 'authentication' ) : ?>
                            <div class="section-header">
                                <h2><?php esc_html_e( 'Authentication', 'ts-lms' ); ?></h2>
                                <a href="#" class="reset-link"><span class="dashicons dashicons-undo"></span> <?php esc_html_e( 'Reset to Default', 'ts-lms' ); ?></a>
                            </div>

                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Custom Login System', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable to use the custom TS LMS login/register system, overriding WordPress defaults.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[enable_custom_login]" value="1" <?php checked( isset( $settings['enable_custom_login'] ) && $settings['enable_custom_login'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Pages', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Login Page', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose the page that contains the [ts_lms_login] shortcode.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <?php wp_dropdown_pages( array(
                                            'name'              => 'ts_lms_settings[login_page]',
                                            'selected'          => isset( $settings['login_page'] ) ? $settings['login_page'] : 0,
                                            'show_option_none'  => __( 'Select Option', 'ts-lms' ),
                                            'option_none_value' => '0',
                                            'class'             => 'ts-lms-select'
                                        ) ); ?>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Registration Page', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose the page that contains the [ts_lms_register] shortcode.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <?php wp_dropdown_pages( array(
                                            'name'              => 'ts_lms_settings[student_reg_page]',
                                            'selected'          => isset( $settings['student_reg_page'] ) ? $settings['student_reg_page'] : 0,
                                            'show_option_none'  => __( 'Select Option', 'ts-lms' ),
                                            'option_none_value' => '0',
                                            'class'             => 'ts-lms-select'
                                        ) ); ?>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Dashboard Page', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose the page that contains the [ts_lms_dashboard] shortcode.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <?php wp_dropdown_pages( array(
                                            'name'              => 'ts_lms_settings[dashboard_page]',
                                            'selected'          => isset( $settings['dashboard_page'] ) ? $settings['dashboard_page'] : 0,
                                            'show_option_none'  => __( 'Select Option', 'ts-lms' ),
                                            'option_none_value' => '0',
                                            'class'             => 'ts-lms-select'
                                        ) ); ?>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Registration Fields', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Phone Number Field', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Control how phone number field behaves in registration.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <select name="ts_lms_settings[reg_phone_field]" class="ts-lms-select">
                                            <option value="disabled" <?php selected( isset( $settings['reg_phone_field'] ) ? $settings['reg_phone_field'] : 'disabled', 'disabled' ); ?>><?php esc_html_e( 'Disabled', 'ts-lms' ); ?></option>
                                            <option value="optional" <?php selected( isset( $settings['reg_phone_field'] ) && $settings['reg_phone_field'] === 'optional' ); ?>><?php esc_html_e( 'Optional', 'ts-lms' ); ?></option>
                                            <option value="required" <?php selected( isset( $settings['reg_phone_field'] ) && $settings['reg_phone_field'] === 'required' ); ?>><?php esc_html_e( 'Required', 'ts-lms' ); ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Redirect Controls', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Login Redirect URL', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Where to redirect users after successful login.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[login_redirect_url]" value="<?php echo esc_attr( isset( $settings['login_redirect_url'] ) ? $settings['login_redirect_url'] : '/dashboard/' ); ?>" class="ts-lms-input-text" placeholder="/dashboard/">
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Registration Redirect URL', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Where to redirect users after successful registration.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[reg_redirect_url]" value="<?php echo esc_attr( isset( $settings['reg_redirect_url'] ) ? $settings['reg_redirect_url'] : '/dashboard/' ); ?>" class="ts-lms-input-text" placeholder="/dashboard/">
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Social Login System', 'ts-lms' ); ?></h3>
                            <?php 
                            $social_providers = array(
                                'google' => array(
                                    'title' => 'Google',
                                    'icon'  => 'google',
                                    'help'  => 'https://console.cloud.google.com/'
                                ),
                                'facebook' => array(
                                    'title' => 'Facebook',
                                    'icon'  => 'facebook',
                                    'help'  => 'https://developers.facebook.com/'
                                ),
                                'github' => array(
                                    'title' => 'GitHub',
                                    'icon'  => 'github',
                                    'help'  => 'https://github.com/settings/developers'
                                )
                            );

                            foreach ( $social_providers as $id => $provider ) :
                                $is_enabled = isset( $settings["enable_{$id}_login"] ) && $settings["enable_{$id}_login"];
                            ?>
                            <div class="settings-card social-login-card">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php echo esc_html( $provider['title'] ); ?></h3>
                                        <p><?php printf( esc_html__( 'Enable %s social login.', 'ts-lms' ), $provider['title'] ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[enable_<?php echo $id; ?>_login]" value="1" <?php checked( $is_enabled, 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="social-api-fields" style="<?php echo $is_enabled ? '' : 'display: none;'; ?>">
                                    <div class="settings-row bordered mini">
                                        <div class="settings-info">
                                            <p><?php printf( esc_html__( 'To configure %s login, you need to create an app in the %s Developer Console.', 'ts-lms' ), $provider['title'], $provider['title'] ); ?> 
                                               <a href="<?php echo esc_url( $provider['help'] ); ?>" target="_blank"><?php esc_html_e( 'Step-by-step Setup Guide', 'ts-lms' ); ?></a>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="settings-row bordered">
                                        <div class="settings-info">
                                            <p><strong><?php esc_html_e( 'Callback URL:', 'ts-lms' ); ?></strong></p>
                                            <code><?php echo home_url( '/ts-lms/auth/' . $id . '/callback' ); ?></code>
                                        </div>
                                    </div>
                                    <div class="settings-row bordered">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'App ID / Client ID', 'ts-lms' ); ?></h3>
                                        </div>
                                        <div class="settings-field">
                                            <input type="text" name="ts_lms_settings[<?php echo $id; ?>_app_id]" value="<?php echo esc_attr( isset( $settings[$id . '_app_id'] ) ? $settings[$id . '_app_id'] : '' ); ?>" class="ts-lms-input-text">
                                        </div>
                                    </div>
                                    <div class="settings-row bordered">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'App Secret / Client Secret', 'ts-lms' ); ?></h3>
                                        </div>
                                        <div class="settings-field">
                                            <input type="password" name="ts_lms_settings[<?php echo $id; ?>_app_secret]" value="<?php echo esc_attr( isset( $settings[$id . '_app_secret'] ) ? $settings[$id . '_app_secret'] : '' ); ?>" class="ts-lms-input-text">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>

                            <h3 class="group-title"><?php esc_html_e( 'Advanced Security', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Two-Factor Authentication', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable email-based 2FA for all users.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[enable_2fa]" value="1" <?php checked( isset( $settings['enable_2fa'] ) && $settings['enable_2fa'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Limit Active Login Sessions', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Prevent multiple concurrent logins from the same account. If you turn on this session, if you are logged in on one device, the account will not be logged in on another device. If you try to log in, you will be given a warning.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field" style="display: flex; align-items: center; gap: 15px;">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[limit_active_sessions]" value="1" <?php checked( ! isset( $settings['limit_active_sessions'] ) || $settings['limit_active_sessions'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                        <div class="input-with-unit" style="margin-left: auto;">
                                            <label style="margin-right: 8px; font-weight: 500; color: #64748b;"><?php esc_html_e( 'Max Sessions:', 'ts-lms' ); ?></label>
                                            <input type="number" name="ts_lms_settings[max_active_sessions]" value="<?php echo esc_attr( isset( $settings['max_active_sessions'] ) ? $settings['max_active_sessions'] : 1 ); ?>" class="ts-lms-input-number" min="1" max="10" style="width: 80px;">
                                        </div>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Email Verification', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Require users to verify their email before they can access features.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[enable_email_verification]" value="1" <?php checked( isset( $settings['enable_email_verification'] ) && $settings['enable_email_verification'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>


                        <?php elseif ( $active_tab === 'certificate' ) : ?>
                            <div class="section-header">
                                <h2><?php esc_html_e( 'Certificate Settings', 'ts-lms' ); ?></h2>
                                <a href="#" class="reset-link"><span class="dashicons dashicons-undo"></span> <?php esc_html_e( 'Reset to Default', 'ts-lms' ); ?></a>
                            </div>

                            <p class="section-desc">
                                <?php esc_html_e( 'Configure your course completion certificates. These settings define the issuer details and how certificates are delivered to your students.', 'ts-lms' ); ?>
                            </p>

                            <h3 class="group-title"><?php esc_html_e( 'Issuer Details', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Authorised Name', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'This name will be printed under the signature on the certificate.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[cert_auth_name]" value="<?php echo esc_attr( isset( $settings['cert_auth_name'] ) ? $settings['cert_auth_name'] : '' ); ?>" class="ts-lms-input-text" placeholder="<?php esc_attr_e( 'e.g. John Doe', 'ts-lms' ); ?>">
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Authorised Company Name', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'The company name printed under the authorised name.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <input type="text" name="ts_lms_settings[cert_auth_company]" value="<?php echo esc_attr( isset( $settings['cert_auth_company'] ) ? $settings['cert_auth_company'] : '' ); ?>" class="ts-lms-input-text" placeholder="<?php esc_attr_e( 'e.g. Acme Academy', 'ts-lms' ); ?>">
                                    </div>
                                </div>
                                <div class="settings-row vertical">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Signature', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Upload an image of the signature to be used on certificates.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field logo-upload-box">
                                        <div class="logo-preview-container">
                                            <?php $sig_url = isset( $settings['cert_signature'] ) ? $settings['cert_signature'] : ''; ?>
                                            <div class="logo-preview <?php echo $sig_url ? 'has-logo' : ''; ?> ts-lms-upload-image" data-target="ts_lms_cert_signature">
                                                <?php if ( $sig_url ) : ?>
                                                    <img src="<?php echo esc_url( $sig_url ); ?>" alt="Signature">
                                                <?php else : ?>
                                                    <span class="dashicons dashicons-format-image"></span>
                                                    <span><?php esc_html_e( 'Upload Signature', 'ts-lms' ); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="logo-upload-info">
                                                <p><?php esc_html_e( 'Recommended Size: 300x150 pixels', 'ts-lms' ); ?></p>
                                                <p><?php esc_html_e( 'Supported: .png, .jpg, .svg (Transparent PNG recommended)', 'ts-lms' ); ?></p>
                                                <input type="hidden" name="ts_lms_settings[cert_signature]" id="ts_lms_cert_signature" value="<?php echo esc_attr( $sig_url ); ?>">
                                                <div class="button-group" style="margin-top: 10px;">
                                                    <button type="button" class="button button-secondary ts-lms-upload-image" data-target="ts_lms_cert_signature"><?php esc_html_e( 'Choose Image', 'ts-lms' ); ?></button>
                                                    <?php if ( $sig_url ) : ?>
                                                        <button type="button" class="button button-link-delete ts-lms-remove-image" data-target="ts_lms_cert_signature" style="color: #d63638;"><?php esc_html_e( 'Remove', 'ts-lms' ); ?></button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Certificate Configuration', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Certificate Landing Page', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Choose the page that will display the certificate to students.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <?php wp_dropdown_pages( array(
                                            'name'              => 'ts_lms_settings[certificate_page]',
                                            'selected'          => isset( $settings['certificate_page'] ) ? $settings['certificate_page'] : 0,
                                            'show_option_none'  => __( 'Select Certificate Page', 'ts-lms' ),
                                            'option_none_value' => '0',
                                            'class'             => 'ts-lms-select'
                                        ) ); ?>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Display Instructor Name', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'If enabled, the instructor\'s name will be shown on the certificate alongside the authorised name.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[cert_show_instructor]" value="1" <?php checked( isset( $settings['cert_show_instructor'] ) && $settings['cert_show_instructor'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Email Certificate Link', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Automatically include a link to the certificate in the course completion email.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[cert_link_in_email]" value="1" <?php checked( isset( $settings['cert_link_in_email'] ) && $settings['cert_link_in_email'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>


                        <?php elseif ( $active_tab === 'email' ) : ?>
                            <div class="section-header">
                                <h2><?php esc_html_e( 'Email Settings', 'ts-lms' ); ?></h2>
                                <a href="#" class="reset-link"><span class="dashicons dashicons-undo"></span> <?php esc_html_e( 'Reset to Default', 'ts-lms' ); ?></a>
                            </div>

                            <div class="email-quick-actions">
                                <div class="settings-card email-action-card highlight">
                                    <div class="card-icon">
                                        <span class="dashicons dashicons-email-alt"></span>
                                    </div>
                                    <div class="card-body">
                                        <h3><?php esc_html_e( 'Email Configurator', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Logo, Sender Name, Footer Text & Template Colors.', 'ts-lms' ); ?></p>
                                        <a href="#email-configurator-section" class="ts-lms-btn btn-outline btn-sm ts-lms-configure-email"><?php esc_html_e( 'Configure Now', 'ts-lms' ); ?></a>
                                    </div>
                                </div>
                                <div class="settings-card email-action-card">
                                    <div class="card-icon">
                                        <span class="dashicons dashicons-edit"></span>
                                    </div>
                                    <div class="card-body">
                                        <h3><?php esc_html_e( 'Manual Campaign', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Send custom emails to specific student groups.', 'ts-lms' ); ?></p>
                                        <a href="#manual-campaign-section" class="ts-lms-btn btn-outline btn-sm ts-lms-manual-campaign-btn"><?php esc_html_e( 'Create Email', 'ts-lms' ); ?></a>
                                    </div>
                                </div>
                            </div>

                            <div id="email-configurator-section" class="email-configurator-section" style="display: none; margin-bottom: 40px;">
                                <div class="section-header">
                                    <h3><?php esc_html_e( 'Email Design & Sender Info', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="settings-card">
                                    <div class="settings-row bordered vertical">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Email Logo', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'Upload a logo that will appear at the top of all system emails.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field logo-upload-box">
                                            <div class="logo-preview-container">
                                                <?php $email_logo = isset( $settings['email_logo'] ) ? $settings['email_logo'] : ''; ?>
                                                <div class="logo-preview <?php echo $email_logo ? 'has-logo' : ''; ?> ts-lms-upload-image" data-target="ts_lms_email_logo">
                                                    <?php if ( $email_logo ) : ?>
                                                        <img src="<?php echo esc_url( $email_logo ); ?>" alt="Email Logo">
                                                    <?php else : ?>
                                                        <span class="dashicons dashicons-format-image"></span>
                                                        <span><?php esc_html_e( 'Upload Logo', 'ts-lms' ); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="logo-upload-info">
                                                    <input type="hidden" name="ts_lms_settings[email_logo]" id="ts_lms_email_logo" value="<?php echo esc_attr( $email_logo ); ?>">
                                                    <button type="button" class="button button-secondary ts-lms-upload-image" data-target="ts_lms_email_logo"><?php esc_html_e( 'Choose Image', 'ts-lms' ); ?></button>
                                                    <?php if ( $email_logo ) : ?>
                                                        <button type="button" class="button button-link-delete ts-lms-remove-image" data-target="ts_lms_email_logo" style="color: #d63638;"><?php esc_html_e( 'Remove', 'ts-lms' ); ?></button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="settings-row bordered">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Sender Name', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'The name that appears in the "From" field.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field">
                                            <input type="text" name="ts_lms_settings[email_sender_name]" value="<?php echo esc_attr( isset( $settings['email_sender_name'] ) ? $settings['email_sender_name'] : get_bloginfo('name') ); ?>" class="ts-lms-input-text">
                                        </div>
                                    </div>
                                    <div class="settings-row bordered">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Sender Email', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'The email address that appears in the "From" field.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field">
                                            <input type="email" name="ts_lms_settings[email_sender_email]" value="<?php echo esc_attr( isset( $settings['email_sender_email'] ) ? $settings['email_sender_email'] : get_bloginfo('admin_email') ); ?>" class="ts-lms-input-text">
                                        </div>
                                    </div>
                                    <div class="settings-row bordered vertical">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Footer Text', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'Text that appears at the bottom of every email. HTML allowed.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field" style="width: 100%;">
                                            <textarea name="ts_lms_settings[email_footer_text]" class="ts-lms-input-text" style="height: 100px; max-width: 100%;"><?php echo esc_textarea( isset( $settings['email_footer_text'] ) ? $settings['email_footer_text'] : sprintf( __( '&copy; %s %s. All rights reserved.', 'ts-lms' ), date('Y'), get_bloginfo('name') ) ); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="settings-row bordered">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Base Color', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'The main color for email buttons, headers, and highlights.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field">
                                            <input type="text" name="ts_lms_settings[email_base_color]" value="<?php echo esc_attr( isset( $settings['email_base_color'] ) ? $settings['email_base_color'] : '#6366f1' ); ?>" class="ts-lms-color-picker">
                                        </div>
                                    </div>
                                    <div class="settings-row">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Background Color', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'The overall background color of the email.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field">
                                            <input type="text" name="ts_lms_settings[email_bg_color]" value="<?php echo esc_attr( isset( $settings['email_bg_color'] ) ? $settings['email_bg_color'] : '#f8fafc' ); ?>" class="ts-lms-color-picker">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="manual-campaign-section" class="manual-campaign-section" style="display: none; margin-bottom: 40px;">
                                <div class="section-header">
                                    <h3><?php esc_html_e( 'Create Manual Email Campaign', 'ts-lms' ); ?></h3>
                                </div>
                                <div class="settings-card">
                                    <div class="settings-row bordered">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Recipients', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'Who should receive this email?', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field">
                                            <select id="ts-lms-manual-recipients" class="ts-lms-select">
                                                <option value="all_students"><?php esc_html_e( 'All Students', 'ts-lms' ); ?></option>
                                                <option value="all_instructors"><?php esc_html_e( 'All Instructors', 'ts-lms' ); ?></option>
                                                <option value="specific_course"><?php esc_html_e( 'Students in a Specific Course', 'ts-lms' ); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div id="specific-course-wrap" class="settings-row bordered" style="display: none;">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Select Course', 'ts-lms' ); ?></h3>
                                        </div>
                                        <div class="settings-field">
                                            <?php 
                                            $courses = get_posts(array('post_type' => 'ts_course', 'posts_per_page' => -1));
                                            ?>
                                            <select id="ts-lms-manual-course-id" class="ts-lms-select">
                                                <?php foreach ($courses as $course) : ?>
                                                    <option value="<?php echo $course->ID; ?>"><?php echo esc_html($course->post_title); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="settings-row bordered">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Email Subject', 'ts-lms' ); ?></h3>
                                        </div>
                                        <div class="settings-field" style="width: 100%;">
                                            <input type="text" id="ts-lms-manual-subject" class="ts-lms-input-text" style="max-width: 100%;" placeholder="<?php esc_attr_e( 'Enter subject...', 'ts-lms' ); ?>">
                                        </div>
                                    </div>
                                    <div class="settings-row bordered vertical">
                                        <div class="settings-info">
                                            <h3><?php esc_html_e( 'Message Content', 'ts-lms' ); ?></h3>
                                            <p><?php esc_html_e( 'Write your message here. It will be wrapped in the system email template.', 'ts-lms' ); ?></p>
                                        </div>
                                        <div class="settings-field" style="width: 100%;">
                                            <textarea id="ts-lms-manual-message" class="ts-lms-input-text" style="height: 200px; max-width: 100%;" placeholder="<?php esc_attr_e( 'Write your message...', 'ts-lms' ); ?>"></textarea>
                                        </div>
                                    </div>
                                    <div class="settings-row">
                                        <div class="settings-info"></div>
                                        <div class="settings-field">
                                            <button type="button" id="ts-lms-send-manual-email" class="ts-lms-btn">
                                                <span class="dashicons dashicons-send" style="margin-right: 5px;"></span>
                                                <?php esc_html_e( 'Send Campaign Now', 'ts-lms' ); ?>
                                            </button>
                                            <div id="manual-email-status" style="margin-top: 10px; font-weight: 600;"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <div class="email-notifications-wrap">
                                <?php 
                                $email_categories = self::get_email_notification_types();
                                foreach ( $email_categories as $cat_key => $category ) : ?>
                                    <div class="email-category-section">
                                        <div class="category-header">
                                            <div class="header-info">
                                                <span class="category-icon dashicons <?php 
                                                    echo $cat_key === 'student' ? 'dashicons-id' : ($cat_key === 'instructor' ? 'dashicons-businessman' : 'dashicons-admin-users'); 
                                                ?>"></span>
                                                <h3><?php echo esc_html( $category['title'] ); ?></h3>
                                            </div>
                                            <div class="header-actions">
                                                <span class="email-count"><?php echo count($category['emails']); ?> <?php _e('Templates', 'ts-lms'); ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="settings-card no-padding">
                                            <div class="email-grid">
                                                <?php foreach ( $category['emails'] as $email_key => $label ) : 
                                                    $setting_name = "email_notify_{$cat_key}_{$email_key}";
                                                    $is_enabled = isset( $settings[ $setting_name ] ) && $settings[ $setting_name ];
                                                ?>
                                                    <div class="email-row <?php echo $is_enabled ? 'is-active' : ''; ?>">
                                                        <div class="email-info">
                                                            <span class="email-label"><?php echo esc_html( $label ); ?></span>
                                                            <div class="email-meta">
                                                                <span class="dashicons dashicons-info"></span>
                                                                <div class="tooltip"><?php echo sprintf(__('Settings for %s email', 'ts-lms'), $label); ?></div>
                                                            </div>
                                                        </div>
                                                        <div class="email-toggle">
                                                            <label class="ts-lms-switch mini">
                                                                <input type="checkbox" name="ts_lms_settings[<?php echo esc_attr( $setting_name ); ?>]" value="1" <?php checked( $is_enabled, 1 ); ?>>
                                                                <span class="slider round"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'Delivery Settings', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'WP-Cron Delivery', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Use WordPress background tasks to send bulk emails without slowing down your site.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[enable_email_cron]" value="1" <?php checked( isset( $settings['enable_email_cron'] ) && $settings['enable_email_cron'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Retry Frequency', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Interval in seconds between each background sending cycle.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field align-right">
                                        <div class="input-with-unit">
                                            <input type="number" name="ts_lms_settings[email_cron_frequency]" value="<?php echo esc_attr( isset( $settings['email_cron_frequency'] ) ? $settings['email_cron_frequency'] : 300 ); ?>" class="ts-lms-input-number">
                                            <span class="unit"><?php _e('sec', 'ts-lms'); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="settings-row">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Batch Size', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Number of emails to process in a single background task.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field align-right">
                                        <div class="input-with-unit">
                                            <input type="number" name="ts_lms_settings[email_per_cron]" value="<?php echo esc_attr( isset( $settings['email_per_cron'] ) ? $settings['email_per_cron'] : 10 ); ?>" class="ts-lms-input-number">
                                            <span class="unit"><?php _e('emails', 'ts-lms'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        <?php elseif ( $active_tab === 'gradebook' ) : ?>
                            <div class="section-header">
                                <h2><?php esc_html_e( 'Gradebook', 'ts-lms' ); ?></h2>
                                <a href="#" class="reset-link"><span class="dashicons dashicons-undo"></span> <?php esc_html_e( 'Reset to Default', 'ts-lms' ); ?></a>
                            </div>

                            <h3 class="group-title"><?php esc_html_e( 'SETTINGS', 'ts-lms' ); ?></h3>
                            <div class="settings-card no-padding">
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Use Points Instead of Grades', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Enable this option to use numerical points instead of letter grades.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field align-right">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[gradebook_use_points]" value="1" <?php checked( isset( $settings['gradebook_use_points'] ) && $settings['gradebook_use_points'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Enable GPA Scale Limit', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Turn it on if you want to show the limit of GPA scales, such as 3.8/4.0', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field align-right">
                                        <label class="ts-lms-switch">
                                            <input type="checkbox" name="ts_lms_settings[gradebook_enable_gpa_limit]" value="1" <?php checked( isset( $settings['gradebook_enable_gpa_limit'] ) && $settings['gradebook_enable_gpa_limit'], 1 ); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Separator Between Scores', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Input the separator text or symbol to display. Example: Insert / to display 3.8/4.0 or "out of" 3.8 out of 4.', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field align-right">
                                        <input type="text" name="ts_lms_settings[gradebook_separator]" value="<?php echo esc_attr( isset( $settings['gradebook_separator'] ) ? $settings['gradebook_separator'] : '/' ); ?>" class="ts-lms-input-text align-center" style="width: 120px;">
                                    </div>
                                </div>
                                <div class="settings-row bordered">
                                    <div class="settings-info">
                                        <h3><?php esc_html_e( 'Set the GPA Scale Limit', 'ts-lms' ); ?></h3>
                                        <p><?php esc_html_e( 'Insert the highest limit of grade point out of which the final results will be calculated', 'ts-lms' ); ?></p>
                                    </div>
                                    <div class="settings-field align-right">
                                        <input type="text" name="ts_lms_settings[gradebook_gpa_limit]" value="<?php echo esc_attr( isset( $settings['gradebook_gpa_limit'] ) ? $settings['gradebook_gpa_limit'] : '4.0' ); ?>" class="ts-lms-input-text align-center" style="width: 120px;">
                                    </div>
                                </div>
                            </div>



                        <?php else : ?>
                            <div class="section-header">
                                <h2><?php echo esc_html( ucfirst( $active_tab ) ); ?></h2>
                            </div>
                            <div class="settings-card">
                                <p><?php esc_html_e( 'Settings for this section are coming soon.', 'ts-lms' ); ?></p>
                            </div>
                        <?php endif; ?>
                    </form>
                </main>
            </div>
        </div>
        <?php
    }

    /**
     * Handle saving settings.
     */
    public static function handle_save() {
        if ( ! isset( $_POST['ts_lms_settings_nonce'] ) || ! wp_verify_nonce( $_POST['ts_lms_settings_nonce'], 'ts_lms_save_settings' ) ) {
            return;
        }

        if ( isset( $_POST['ts_lms_settings'] ) ) {
            $data = $_POST['ts_lms_settings'];
            $current_tab = isset( $_POST['active_tab'] ) ? sanitize_text_field( $_POST['active_tab'] ) : '';

            // Map checkboxes to tabs to prevent resetting checkboxes on other tabs
            $checkbox_map = array(
                'general'        => array( 'become_instructor_button', 'allow_publish_courses', 'allow_trash_courses', 'allow_change_author', 'enable_marketplace' ),
                'course'         => array( 
                    'course_visibility', 'course_content_access', 'content_summary', 'spotlight_mode', 
                    'auto_complete_course', 'course_retake', 'enrollment_expiration', 'lesson_wp_editor', 
                    'auto_load_next', 'lesson_comment', 'quiz_prev_button', 'quiz_hide_details', 
                    'prevent_video_recording', 'course_filter', 'course_sorting', 'catalog_show_search', 
                    'catalog_show_type', 'catalog_show_category', 'catalog_show_tag', 'catalog_show_level', 
                    'catalog_show_price', 'show_certificate' 
                ),
                'advanced'       => array( 
                    'enable_gutenberg', 'hide_course_products_shop', 
                    'prevent_hotlinking', 'copy_protection', 'enable_ai_studio', 
                    'maintenance_mode', 'erase_on_uninstall', 'profile_completion_bar', 'enable_migration'
                ),
                'gradebook'      => array( 'gradebook_use_points', 'gradebook_enable_gpa_limit' ),
                'email'          => array( 'enable_email_cron' ),
                'authentication' => array( 
                    'enable_custom_login', 'enable_2fa', 'enable_fraud_protection', 
                    'limit_active_sessions', 'enable_email_verification', 'enable_google_login', 
                    'enable_facebook_login', 'enable_github_login' 
                ),
                'certificate'    => array( 'cert_show_instructor', 'cert_link_in_email' ),
            );

            // Add dynamic email checkboxes to the email tab
            if ( $current_tab === 'email' ) {
                $email_types = self::get_email_notification_types();
                foreach ( $email_types as $cat_key => $category ) {
                    foreach ( $category['emails'] as $email_key => $label ) {
                        $checkbox_map['email'][] = "email_notify_{$cat_key}_{$email_key}";
                    }
                }
            }

            // Only process checkboxes for the current tab
            if ( isset( $checkbox_map[$current_tab] ) ) {
                foreach ( $checkbox_map[$current_tab] as $cb ) {
                    if ( ! isset( $data[ $cb ] ) ) {
                        $data[ $cb ] = 0;
                    }
                }
            }

            // Handle special arrays
            if ( $current_tab === 'design' ) {
                if ( ! isset( $data['course_features'] ) ) {
                    $data['course_features'] = array();
                }
            }

            // Handle nested notifications only if on notifications tab
            if ( $current_tab === 'notifications' ) {
                if ( ! isset( $data['notifications'] ) ) {
                    $data['notifications'] = array();
                }
                $notification_items = array(
                    'course_enrolled', 'cancel_enrollment', 'assignment_graded', 
                    'new_announcement', 'qa_answered', 'quiz_feedback', 
                    'removed_from_course', 'inst_app_accepted', 
                    'inst_app_rejected', 'inst_app_received'
                );
                foreach ( $notification_items as $item_id ) {
                    if ( ! isset( $data['notifications'][ $item_id ] ) ) {
                        $data['notifications'][ $item_id ] = array();
                    }
                    if ( ! isset( $data['notifications'][ $item_id ]['onsite'] ) ) {
                        $data['notifications'][ $item_id ]['onsite'] = 0;
                    }
                    if ( ! isset( $data['notifications'][ $item_id ]['push'] ) ) {
                        $data['notifications'][ $item_id ]['push'] = 0;
                    }
                }
            }

            // Handle builder visibility only if on advanced tab
            if ( $current_tab === 'advanced' ) {
                if ( ! isset( $data['builder_visibility'] ) ) {
                    $data['builder_visibility'] = array();
                }
                $visibility_items = array(
                    'general', 'content_drip', 'enrollment', 'featured_image', 'intro_video',
                    'pricing_options', 'categories', 'tags', 'author', 
                    'overview_learn', 'overview_audience', 'overview_duration', 'overview_materials', 'overview_reqs',
                    'certificate', 'attachments', 'live_class',
                    'lesson_featured_image', 'lesson_video', 'lesson_v_playback', 'lesson_exercise', 'lesson_preview'
                );
                foreach ( $visibility_items as $item_id ) {
                    if ( ! isset( $data['builder_visibility'][$item_id] ) ) {
                        $data['builder_visibility'][$item_id] = array();
                    }
                    if ( ! isset( $data['builder_visibility'][$item_id]['admin'] ) ) {
                        $data['builder_visibility'][$item_id]['admin'] = 0;
                    }
                    if ( ! isset( $data['builder_visibility'][$item_id]['instructor'] ) ) {
                        $data['builder_visibility'][$item_id]['instructor'] = 0;
                    }
                }
            }

            self::save_settings( $data );
            
            add_settings_error( 'ts_lms_settings', 'settings_updated', __( 'Settings saved successfully.', 'ts-lms' ), 'updated' );
        }
    }

    /**
     * Handle AJAX reset settings request.
     */
    public static function ajax_reset_settings() {
        // Verify nonce
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'ts_lms_save_settings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'ts-lms' ) ) );
        }

        // Check permissions
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
        }

        $tab = isset( $_POST['tab'] ) ? sanitize_text_field( $_POST['tab'] ) : 'general';
        
        // Get current settings
        $settings = self::get_settings();
        
        // Define default values for each tab
        $defaults = self::get_default_settings( $tab );
        
        // Merge with current settings (reset only the tab-specific settings)
        $updated_settings = array_merge( $settings, $defaults );
        
        // Save updated settings
        update_option( self::OPTION_NAME, $updated_settings );
        
        wp_send_json_success( array( 
            'message' => __( 'Settings reset to default successfully.', 'ts-lms' )
        ) );
    }

    /**
     * Get default settings for a specific tab.
     */
    private static function get_default_settings( $tab ) {
        $defaults = array();
        
        switch ( $tab ) {
            case 'general':
                $defaults = array(
                    'dashboard_page' => 0,
                    'terms_page' => 0,
                    'privacy_page' => 0,
                    'enable_marketplace' => 0,
                    'pagination' => 20,
                    'become_instructor_button' => 1,
                    'instructor_registration_limit' => 0,
                    'allow_publish_courses' => 1,
                    'allow_trash_courses' => 1,
                    'allow_change_author' => 1,
                );
                break;
                
            case 'course':
                $defaults = array(
                    'allow_manage_co_instructors' => 1,
                    'course_visibility' => 1,
                    'course_content_access' => 1,
                    'content_summary' => 1,
                    'spotlight_mode' => 0,
                    'auto_complete_course' => 0,
                    'course_retake' => 1,
                    'publish_review_approval' => 0,
                    'redirect_instructor_publish' => 0,
                    'attachment_mode' => 'download',
                    'enrollment_expiration' => 1,
                    'lesson_wp_editor' => 0,
                    'auto_load_next' => 1,
                    'lesson_comment' => 1,
                    'quiz_expiry_action' => 'auto_submit',
                    'quiz_reveal_time' => 2,
                    'quiz_attempt_limit' => 10,
                    'quiz_prev_button' => 1,
                    'quiz_grade_method' => 'highest',
                    'quiz_hide_details' => 0,
                    'video_sources' => array( 'youtube' ),
                    'youtube_player' => 0,
                    'prevent_video_recording' => 0,
                    'vimeo_player' => 0,
                );
                break;
                
            case 'design':
                $defaults = array(
                    'builder_logo' => '',
                    'course_columns' => 'three',
                    'courses_per_page' => 12,
                    'course_filter' => 1,
                    'course_sorting' => 1,
                    'catalog_show_search' => 1,
                    'catalog_show_type' => 1,
                    'catalog_show_category' => 1,
                    'catalog_show_tag' => 1,
                    'catalog_show_level' => 1,
                    'catalog_show_price' => 1,
                    'instructor_list_layout' => 'portrait',
                    'instructor_profile_layout' => 'classic',
                    'student_profile_layout' => 'classic',
                    'enrollment_box_mobile' => 'page_bottom',
                    'show_certificate' => 1,
                    'course_features' => array(
                        'instructor_info',
                        'wishlist',
                        'q_a',
                        'author',
                        'level',
                        'social_share',
                        'duration',
                        'total_enrolled',
                        'update_date',
                        'progress_bar',
                        'material',
                        'about',
                        'description',
                        'benefits',
                        'requirements',
                        'target_audience',
                        'announcements',
                        'review',
                        'sticky_sidebar'
                    ),
                    'color_preset' => 'default',
                    'primary_color' => '#0077B5',
                    'primary_hover_color' => '#005E8F',
                    'text_color' => '#1F2937',
                    'gray_color' => '#F3F4F6',
                    'button_color' => '#0077B5',
                    'button_hover_color' => '#005E8F',
                    'button_text_color' => '#ffffff',
                    'body_bg_color' => '#ffffff',
                    'icon_color' => '#0077B5',
                );
                break;
                
            case 'authentication':
                $defaults = array(
                    'enable_custom_login' => 1,
                    'login_redirect_url' => '/dashboard/',
                    'reg_redirect_url' => '/dashboard/',
                    'reg_phone_field' => 'disabled',
                    'enable_2fa' => 0,
                    'limit_active_sessions' => 1,
                    'enable_email_verification' => 0,
                    'enable_google_login' => 0,
                    'enable_facebook_login' => 0,
                    'enable_github_login' => 0,
                );
                break;

            case 'notifications':
                $defaults = array(
                    'notifications' => array()
                );
                break;

            case 'email':
                $defaults = array(
                    'enable_email_cron' => 0,
                    'email_cron_frequency' => 300,
                    'email_per_cron' => 10,
                    'email_logo' => '',
                    'email_sender_name' => get_bloginfo('name'),
                    'email_sender_email' => get_bloginfo('admin_email'),
                    'email_footer_text' => sprintf( __( '&copy; %s %s. All rights reserved.', 'ts-lms' ), date('Y'), get_bloginfo('name') ),
                    'email_base_color' => '#6366f1',
                    'email_bg_color' => '#f8fafc',
                );
                break;

            case 'certificate':
                $defaults = array(
                    'cert_show_instructor' => 1,
                    'cert_link_in_email' => 1,
                    'cert_auth_name' => '',
                    'cert_auth_company' => '',
                    'cert_signature' => '',
                    'certificate_page' => 0,
                );
                break;

            case 'advanced':
                $defaults = array(
                    'enable_gutenberg' => 0,
                    'hide_course_products_shop' => 1,
                    'prevent_hotlinking' => 0,
                    'copy_protection' => 0,
                    'enable_ai_studio' => 1,
                    'enable_migration' => 0,
                    'maintenance_mode' => 0,
                    'erase_on_uninstall' => 0,
                    'profile_completion_bar' => 0,
                    'builder_visibility' => array()
                );
                break;

            case 'gradebook':
                $defaults = array(
                    'gradebook_use_points' => 0,
                    'gradebook_enable_gpa_limit' => 0,
                    'gradebook_separator' => '/',
                    'gradebook_gpa_limit' => '4.0',
                );
                break;

            default:
                $defaults = array();
                break;
        }
        
        return $defaults;
    }

    /**
     * AJAX handler for sending manual email campaign.
     */
    public static function ajax_send_manual_campaign() {
        check_ajax_referer( 'ts_lms_save_settings', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
        }

        $recipient_group = isset( $_POST['recipient_group'] ) ? sanitize_text_field( $_POST['recipient_group'] ) : '';
        $course_id       = isset( $_POST['course_id'] ) ? intval( $_POST['course_id'] ) : 0;
        $subject         = isset( $_POST['subject'] ) ? sanitize_text_field( $_POST['subject'] ) : '';
        $message_body    = isset( $_POST['message'] ) ? wp_kses_post( stripslashes( $_POST['message'] ) ) : '';

        if ( empty( $subject ) || empty( $message_body ) ) {
            wp_send_json_error( array( 'message' => __( 'Subject and message are required.', 'ts-lms' ) ) );
        }

        $user_ids = array();

        switch ( $recipient_group ) {
            case 'all_students':
                $users = get_users( array( 'role' => 'student', 'fields' => 'ID' ) );
                $user_ids = $users;
                break;

            case 'all_instructors':
                $users = get_users( array( 'role' => 'instructor', 'fields' => 'ID' ) );
                $user_ids = $users;
                break;

            case 'specific_course':
                if ( ! $course_id ) {
                    wp_send_json_error( array( 'message' => __( 'Please select a course.', 'ts-lms' ) ) );
                }
                global $wpdb;
                $table = $wpdb->prefix . 'ts_course_enrollments';
                $enrolled_users = $wpdb->get_col( $wpdb->prepare(
                    "SELECT user_id FROM $table WHERE course_id = %d AND status = 'active'",
                    $course_id
                ) );
                $user_ids = array_unique( array_map( 'intval', $enrolled_users ) );
                break;

            default:
                wp_send_json_error( array( 'message' => __( 'Invalid recipient group.', 'ts-lms' ) ) );
        }

        if ( empty( $user_ids ) ) {
            wp_send_json_error( array( 'message' => __( 'No users found in the selected group.', 'ts-lms' ) ) );
        }

        // Get template settings
        $settings = self::get_settings();
        $base_color = ! empty( $settings['email_base_color'] ) ? $settings['email_base_color'] : '#6366f1';
        $bg_color   = ! empty( $settings['email_bg_color'] ) ? $settings['email_bg_color'] : '#f8fafc';
        $logo       = ! empty( $settings['email_logo'] ) ? $settings['email_logo'] : '';
        $footer     = ! empty( $settings['email_footer_text'] ) ? $settings['email_footer_text'] : '';

        // Prepare HTML Template
        ob_start();
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <style>
                body { background-color: <?php echo esc_attr($bg_color); ?>; font-family: sans-serif; margin: 0; padding: 40px 0; }
                .email-container { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
                .email-header { padding: 30px; text-align: center; border-bottom: 1px solid #eeeeee; }
                .email-body { padding: 40px; color: #333333; line-height: 1.6; font-size: 16px; }
                .email-footer { padding: 20px 40px; background: #f9f9f9; text-align: center; color: #666666; font-size: 12px; }
                img.logo { max-width: 150px; height: auto; }
            </style>
        </head>
        <body>
            <div class="email-container">
                <?php if ( $logo ) : ?>
                <div class="email-header">
                    <img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" class="logo">
                </div>
                <?php endif; ?>
                <div class="email-body">
                    <?php echo wpautop( $message_body ); ?>
                </div>
                <div class="email-footer">
                    <?php echo wp_kses_post( $footer ); ?>
                </div>
            </div>
        </body>
        </html>
        <?php
        $html_message = ob_get_clean();

        // Send emails
        $sent_count = 0;
        foreach ( $user_ids as $uid ) {
            $user = get_userdata( $uid );
            if ( $user && $user->user_email ) {
                if ( wp_mail( $user->user_email, $subject, $html_message ) ) {
                    $sent_count++;
                }
            }
        }

        wp_send_json_success( array( 
            'message' => sprintf( __( 'Campaign sent successfully to %d users.', 'ts-lms' ), $sent_count ) 
        ) );
    }
}
