<?php
/**
 * Export Manager
 *
 * Manages export file generation, storage, and cleanup.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Export;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ExportManager class.
 */
class ExportManager {

	/**
	 * Export directory path.
	 *
	 * @var string
	 */
	private $export_dir;

	/**
	 * Export retention period in days.
	 *
	 * @var int
	 */
	private $retention_days = 7;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$upload_dir = wp_upload_dir();
		$this->export_dir = trailingslashit( $upload_dir['basedir'] ) . 'ts-lms-reports/';

		// Create directory if it doesn't exist
		if ( ! file_exists( $this->export_dir ) ) {
			wp_mkdir_p( $this->export_dir );

			// Add .htaccess to protect files
			$htaccess = $this->export_dir . '.htaccess';
			if ( ! file_exists( $htaccess ) ) {
				file_put_contents( $htaccess, 'Deny from all' );
			}
		}
	}

	/**
	 * Create an export file.
	 *
	 * @param string $report_type Report type.
	 * @param string $format      Export format (csv, excel).
	 * @param array  $filters     Report filters.
	 * @return int Export ID.
	 * @throws \Exception On export failure.
	 */
	public function create_export( $report_type, $format, $filters = array() ) {
		// Generate report data
		$generator_map = array(
			'course_sales'        => 'TS_LMS\\Modules\\Reports\\Generators\\CourseSalesReport',
			'student_progress'    => 'TS_LMS\\Modules\\Reports\\Generators\\StudentProgressReport',
			'instructor_earnings' => 'TS_LMS\\Modules\\Reports\\Generators\\InstructorEarningsReport',
			'quiz_performance'    => 'TS_LMS\\Modules\\Reports\\Generators\\QuizPerformanceReport',
		);

		if ( ! isset( $generator_map[ $report_type ] ) ) {
			throw new \Exception( __( 'Invalid report type.', 'ts-lms' ) );
		}

		$generator_class = $generator_map[ $report_type ];
		$generator = new $generator_class();
		$data = $generator->generate( $filters );

		// Get export handler
		$handler = $this->get_export_handler( $format );

		// Generate filename
		$filename = $this->generate_filename( $report_type, $format );
		$file_path = $this->export_dir . $filename;

		// Export data
		$file_path = $handler->export( $data, $file_path );

		// Store export record in database
		$export_id = $this->store_export_record( $report_type, $filename, $file_path, $format );

		return $export_id;
	}

	/**
	 * Get export handler for format.
	 *
	 * @param string $format Export format.
	 * @return ExportInterface Export handler.
	 * @throws \Exception If format is invalid.
	 */
	private function get_export_handler( $format ) {
		switch ( $format ) {
			case 'csv':
				return new CsvExport();
			case 'excel':
			case 'xls':
			case 'xlsx':
				return new ExcelExport();
			default:
				throw new \Exception( __( 'Invalid export format.', 'ts-lms' ) );
		}
	}

	/**
	 * Generate unique filename for export.
	 *
	 * @param string $report_type Report type.
	 * @param string $format      Export format.
	 * @return string Filename.
	 */
	private function generate_filename( $report_type, $format ) {
		$timestamp = gmdate( 'Y-m-d_H-i-s' );
		$random = wp_generate_password( 8, false );
		$extension = $format === 'csv' ? 'csv' : 'xls';

		return "{$report_type}_{$timestamp}_{$random}.{$extension}";
	}

	/**
	 * Store export record in database.
	 *
	 * @param string $report_type Report type.
	 * @param string $filename    Filename.
	 * @param string $file_path   Full file path.
	 * @param string $format      Export format.
	 * @return int Export ID.
	 */
	private function store_export_record( $report_type, $filename, $file_path, $format ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_report_exports';
		$file_size = file_exists( $file_path ) ? filesize( $file_path ) : 0;

		$wpdb->insert(
			$table,
			array(
				'user_id'     => get_current_user_id(),
				'report_type' => $report_type,
				'file_name'   => $filename,
				'file_path'   => $file_path,
				'file_size'   => $file_size,
				'format'      => $format,
				'created_at'  => current_time( 'mysql' ),
				'expires_at'  => gmdate( 'Y-m-d H:i:s', time() + ( $this->retention_days * DAY_IN_SECONDS ) ),
			),
			array( '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
		);

		return $wpdb->insert_id;
	}

	/**
	 * Get download URL for export.
	 *
	 * @param int $export_id Export ID.
	 * @return string Download URL.
	 */
	public function get_download_url( $export_id ) {
		return add_query_arg(
			array(
				'action'    => 'ts_lms_download_export',
				'export_id' => $export_id,
				'nonce'     => wp_create_nonce( 'ts_lms_reports' ),
			),
			admin_url( 'admin-ajax.php' )
		);
	}

	/**
	 * Download export file.
	 *
	 * @param int $export_id Export ID.
	 * @return void
	 * @throws \Exception If export not found or expired.
	 */
	public function download_export( $export_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_report_exports';

		$export = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE id = %d",
				$export_id
			)
		);

		if ( ! $export ) {
			throw new \Exception( __( 'Export not found.', 'ts-lms' ) );
		}

		// Check if expired
		if ( strtotime( $export->expires_at ) < time() ) {
			throw new \Exception( __( 'Export has expired.', 'ts-lms' ) );
		}

		// Check if file exists
		if ( ! file_exists( $export->file_path ) ) {
			throw new \Exception( __( 'Export file not found.', 'ts-lms' ) );
		}

		// Increment download count
		$wpdb->update(
			$table,
			array( 'download_count' => intval( $export->download_count ) + 1 ),
			array( 'id' => $export_id ),
			array( '%d' ),
			array( '%d' )
		);

		// Get content type
		$handler = $this->get_export_handler( $export->format );
		$content_type = $handler->get_content_type();

		// Send file
		header( 'Content-Type: ' . $content_type );
		header( 'Content-Disposition: attachment; filename="' . $export->file_name . '"' );
		header( 'Content-Length: ' . filesize( $export->file_path ) );
		header( 'Cache-Control: no-cache, must-revalidate' );
		header( 'Expires: 0' );

		readfile( $export->file_path );
		exit;
	}

	/**
	 * Cleanup expired export files.
	 *
	 * @return int Number of files deleted.
	 */
	public function cleanup_expired_exports() {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_report_exports';

		// Get expired exports
		$expired = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE expires_at < %s",
				current_time( 'mysql' )
			)
		);

		$deleted_count = 0;

		foreach ( $expired as $export ) {
			// Delete file
			if ( file_exists( $export->file_path ) ) {
				unlink( $export->file_path );
			}

			// Delete database record
			$wpdb->delete(
				$table,
				array( 'id' => $export->id ),
				array( '%d' )
			);

			$deleted_count++;
		}

		return $deleted_count;
	}
}
