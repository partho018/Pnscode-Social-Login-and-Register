<?php
/**
 * Excel Export Handler
 *
 * Handles Excel (XLSX) export generation.
 * Note: This is a basic implementation using XML. For advanced features,
 * consider installing PHPSpreadsheet via Composer.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Export;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ExcelExport class.
 */
class ExcelExport implements ExportInterface {

	/**
	 * Export data to Excel file.
	 *
	 * @param array  $data     Report data.
	 * @param string $filename Output filename.
	 * @return string File path on success.
	 * @throws \Exception On export failure.
	 */
	public function export( $data, $filename ) {
		if ( empty( $data['data'] ) || ! is_array( $data['data'] ) ) {
			throw new \Exception( __( 'No data to export.', 'ts-lms' ) );
		}

		// Ensure filename has correct extension
		if ( substr( $filename, -5 ) !== '.xlsx' ) {
			$filename .= '.xlsx';
		}

		// For now, create an XML-based Excel file (Excel 2003 XML format)
		// This is compatible with Excel and doesn't require external libraries
		$xml_filename = str_replace( '.xlsx', '.xls', $filename );
		
		$xml = $this->generate_excel_xml( $data );

		if ( file_put_contents( $xml_filename, $xml ) === false ) {
			throw new \Exception( __( 'Failed to create export file.', 'ts-lms' ) );
		}

		return $xml_filename;
	}

	/**
	 * Generate Excel XML content.
	 *
	 * @param array $data Report data.
	 * @return string XML content.
	 */
	private function generate_excel_xml( $data ) {
		$xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
		$xml .= '<?mso-application progid="Excel.Sheet"?>' . "\n";
		$xml .= '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"' . "\n";
		$xml .= ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' . "\n";
		
		// Styles
		$xml .= '<Styles>' . "\n";
		$xml .= '<Style ss:ID="Header">' . "\n";
		$xml .= '<Font ss:Bold="1"/>' . "\n";
		$xml .= '<Interior ss:Color="#CCCCCC" ss:Pattern="Solid"/>' . "\n";
		$xml .= '</Style>' . "\n";
		$xml .= '</Styles>' . "\n";

		// Worksheet
		$xml .= '<Worksheet ss:Name="Report">' . "\n";
		$xml .= '<Table>' . "\n";

		// Headers
		$columns = $data['columns'] ?? array();
		if ( ! empty( $columns ) ) {
			$xml .= '<Row>' . "\n";
			foreach ( $columns as $column ) {
				$xml .= '<Cell ss:StyleID="Header"><Data ss:Type="String">' . $this->escape_xml( $column ) . '</Data></Cell>' . "\n";
			}
			$xml .= '</Row>' . "\n";
		}

		// Data rows
		foreach ( $data['data'] as $row ) {
			$xml .= '<Row>' . "\n";
			foreach ( $row as $key => $value ) {
				// Skip nested arrays/objects
				if ( is_array( $value ) || is_object( $value ) ) {
					continue;
				}

				// Determine data type
				$type = is_numeric( $value ) ? 'Number' : 'String';
				$xml .= '<Cell><Data ss:Type="' . $type . '">' . $this->escape_xml( $value ) . '</Data></Cell>' . "\n";
			}
			$xml .= '</Row>' . "\n";
		}

		$xml .= '</Table>' . "\n";
		$xml .= '</Worksheet>' . "\n";
		$xml .= '</Workbook>';

		return $xml;
	}

	/**
	 * Escape XML special characters.
	 *
	 * @param mixed $value Value to escape.
	 * @return string Escaped value.
	 */
	private function escape_xml( $value ) {
		return htmlspecialchars( (string) $value, ENT_XML1, 'UTF-8' );
	}

	/**
	 * Get content type.
	 *
	 * @return string MIME type.
	 */
	public function get_content_type() {
		return 'application/vnd.ms-excel';
	}

	/**
	 * Get file extension.
	 *
	 * @return string File extension.
	 */
	public function get_file_extension() {
		return 'xls';
	}
}
