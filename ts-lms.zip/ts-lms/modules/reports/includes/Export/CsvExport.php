<?php
/**
 * CSV Export Handler
 *
 * Handles CSV export generation.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Export;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CsvExport class.
 */
class CsvExport implements ExportInterface {

	/**
	 * Delimiter character.
	 *
	 * @var string
	 */
	private $delimiter = ',';

	/**
	 * Enclosure character.
	 *
	 * @var string
	 */
	private $enclosure = '"';

	/**
	 * Export data to CSV file.
	 *
	 * @param array  $data     Report data.
	 * @param string $filename Output filename.
	 * @return string File path on success.
	 * @throws \Exception On export failure.
	 */
	public function export( $data, $filename ) {
		if ( empty( $data['data'] ) || ! is_array( $data['data'] ) ) {
			throw new \Exception( __( 'No data to export.', 'ts-lms' ) );
		}

		// Ensure filename has correct extension
		if ( substr( $filename, -4 ) !== '.csv' ) {
			$filename .= '.csv';
		}

		// Open file handle
		$file_handle = fopen( $filename, 'w' );
		if ( ! $file_handle ) {
			throw new \Exception( __( 'Failed to create export file.', 'ts-lms' ) );
		}

		// Add UTF-8 BOM for Excel compatibility
		fprintf( $file_handle, chr(0xEF) . chr(0xBB) . chr(0xBF) );

		// Write headers
		$columns = $data['columns'] ?? array();
		if ( ! empty( $columns ) ) {
			fputcsv( $file_handle, array_values( $columns ), $this->delimiter, $this->enclosure );
		} else {
			// Use first row keys as headers
			$first_row = reset( $data['data'] );
			if ( $first_row ) {
				fputcsv( $file_handle, array_keys( $first_row ), $this->delimiter, $this->enclosure );
			}
		}

		// Write data rows
		foreach ( $data['data'] as $row ) {
			// Remove nested arrays/objects for CSV
			$flat_row = $this->flatten_row( $row );
			fputcsv( $file_handle, $flat_row, $this->delimiter, $this->enclosure );
		}

		fclose( $file_handle );

		return $filename;
	}

	/**
	 * Flatten row data (remove nested arrays/objects).
	 *
	 * @param array $row Row data.
	 * @return array Flattened row.
	 */
	private function flatten_row( $row ) {
		$flat = array();

		foreach ( $row as $key => $value ) {
			if ( is_array( $value ) || is_object( $value ) ) {
				// Skip nested data in CSV export
				continue;
			}
			$flat[ $key ] = $value;
		}

		return $flat;
	}

	/**
	 * Get content type.
	 *
	 * @return string MIME type.
	 */
	public function get_content_type() {
		return 'text/csv';
	}

	/**
	 * Get file extension.
	 *
	 * @return string File extension.
	 */
	public function get_file_extension() {
		return 'csv';
	}
}
