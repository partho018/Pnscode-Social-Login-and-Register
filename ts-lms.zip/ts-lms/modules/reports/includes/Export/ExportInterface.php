<?php
/**
 * Export Interface
 *
 * Defines the contract for export handlers.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Export;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ExportInterface interface.
 */
interface ExportInterface {

	/**
	 * Export data to file.
	 *
	 * @param array  $data     Report data.
	 * @param string $filename Output filename.
	 * @return string File path on success.
	 * @throws \Exception On export failure.
	 */
	public function export( $data, $filename );

	/**
	 * Get content type for HTTP headers.
	 *
	 * @return string MIME type.
	 */
	public function get_content_type();

	/**
	 * Get file extension.
	 *
	 * @return string File extension (without dot).
	 */
	public function get_file_extension();
}
