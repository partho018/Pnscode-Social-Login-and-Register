<?php
/**
 * Reports Admin Page
 *
 * Renders the reports dashboard in WordPress admin.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ReportsPage class.
 */
class ReportsPage {

	/**
	 * Render the reports page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'ts-lms' ) );
		}

		$active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'overview';
		$stats = self::get_overview_stats();
		?>
		<div class="wrap ts-lms-reports ts-lms-reports-redesign">
			<div class="ts-lms-reports-header">
				<div class="ts-lms-reports-title">
					<h1>
						<span class="main-title"><?php esc_html_e( 'LMS Reports', 'ts-lms' ); ?></span>
						<span class="separator">/</span>
						<span class="sub-title"><?php echo esc_html( ucfirst( str_replace( '_', ' ', $active_tab ) ) ); ?></span>
					</h1>
				</div>

				<nav class="ts-lms-reports-nav">
					<a href="?page=ts-lms-reports&tab=overview" class="nav-item <?php echo $active_tab === 'overview' ? 'active' : ''; ?>">
						<?php esc_html_e( 'Overview', 'ts-lms' ); ?>
					</a>
					<a href="?page=ts-lms-reports&tab=courses" class="nav-item <?php echo $active_tab === 'courses' ? 'active' : ''; ?>">
						<?php esc_html_e( 'Courses', 'ts-lms' ); ?>
					</a>
					<a href="?page=ts-lms-reports&tab=reviews" class="nav-item <?php echo $active_tab === 'reviews' ? 'active' : ''; ?>">
						<?php esc_html_e( 'Reviews', 'ts-lms' ); ?>
					</a>
					<a href="?page=ts-lms-reports&tab=sales" class="nav-item <?php echo $active_tab === 'sales' ? 'active' : ''; ?>">
						<?php esc_html_e( 'Sales', 'ts-lms' ); ?>
					</a>
					<a href="?page=ts-lms-reports&tab=students" class="nav-item <?php echo $active_tab === 'students' ? 'active' : ''; ?>">
						<?php esc_html_e( 'Students', 'ts-lms' ); ?>
					</a>
				</nav>
			</div>

			<div class="ts-lms-reports-content-area">
				<?php if ( $active_tab === 'overview' ) : ?>
					<div class="ts-lms-overview-grid">
						<!-- Published Courses -->
						<div class="ts-lms-stat-card">
							<div class="stat-icon-wrapper courses">
								<span class="dashicons dashicons-welcome-learn-more"></span>
							</div>
							<div class="stat-content">
								<div class="stat-value"><?php echo esc_html( $stats['published_courses'] ); ?></div>
								<div class="stat-label"><?php esc_html_e( 'Published Courses', 'ts-lms' ); ?></div>
							</div>
						</div>

						<!-- Course Enrolled -->
						<div class="ts-lms-stat-card">
							<div class="stat-icon-wrapper enrollees">
								<span class="dashicons dashicons-groups"></span>
							</div>
							<div class="stat-content">
								<div class="stat-value"><?php echo esc_html( $stats['enrolled_total'] ); ?></div>
								<div class="stat-label"><?php esc_html_e( 'Course Enrolled', 'ts-lms' ); ?></div>
							</div>
						</div>

						<!-- Lessons -->
						<div class="ts-lms-stat-card">
							<div class="stat-icon-wrapper lessons">
								<span class="dashicons dashicons-welcome-edit-page"></span>
							</div>
							<div class="stat-content">
								<div class="stat-value"><?php echo esc_html( $stats['published_lessons'] ); ?></div>
								<div class="stat-label"><?php esc_html_e( 'Lessons', 'ts-lms' ); ?></div>
							</div>
						</div>

						<!-- Quiz -->
						<div class="ts-lms-stat-card">
							<div class="stat-icon-wrapper quizzes">
								<span class="dashicons dashicons-clipboard"></span>
							</div>
							<div class="stat-content">
								<div class="stat-value"><?php echo esc_html( $stats['published_quizzes'] ); ?></div>
								<div class="stat-label"><?php esc_html_e( 'Quiz', 'ts-lms' ); ?></div>
							</div>
						</div>

						<!-- Questions -->
						<div class="ts-lms-stat-card">
							<div class="stat-icon-wrapper questions">
								<span class="dashicons dashicons-editor-help"></span>
							</div>
							<div class="stat-content">
								<div class="stat-value"><?php echo esc_html( $stats['published_questions'] ); ?></div>
								<div class="stat-label"><?php esc_html_e( 'Questions', 'ts-lms' ); ?></div>
							</div>
						</div>

						<!-- Instructors -->
						<div class="ts-lms-stat-card">
							<div class="stat-icon-wrapper instructors">
								<span class="dashicons dashicons-admin-users"></span>
							</div>
							<div class="stat-content">
								<div class="stat-value"><?php echo esc_html( $stats['instructors_count'] ); ?></div>
								<div class="stat-label"><?php esc_html_e( 'Instructors', 'ts-lms' ); ?></div>
							</div>
						</div>

						<!-- Students -->
						<div class="ts-lms-stat-card">
							<div class="stat-icon-wrapper students">
								<span class="dashicons dashicons-id-alt"></span>
							</div>
							<div class="stat-content">
								<div class="stat-value"><?php echo esc_html( $stats['students_count'] ); ?></div>
								<div class="stat-label"><?php esc_html_e( 'Students', 'ts-lms' ); ?></div>
							</div>
						</div>

						<!-- Reviews -->
						<div class="ts-lms-stat-card">
							<div class="stat-icon-wrapper reviews">
								<span class="dashicons dashicons-star-filled"></span>
							</div>
							<div class="stat-content">
								<div class="stat-value"><?php echo esc_html( $stats['reviews_total'] ); ?></div>
								<div class="stat-label"><?php esc_html_e( 'Reviews', 'ts-lms' ); ?></div>
							</div>
						</div>
					</div>
				<?php else : ?>
					<div class="ts-lms-reports-container">
						<!-- Filters -->
						<div class="ts-lms-reports-filters">
							<h3><?php esc_html_e( 'Filters', 'ts-lms' ); ?></h3>
							
							<div class="filter-group">
								<label for="date-from"><?php esc_html_e( 'Date From:', 'ts-lms' ); ?></label>
								<input type="date" id="date-from" name="date_from" class="report-filter">
							</div>

							<div class="filter-group">
								<label for="date-to"><?php esc_html_e( 'Date To:', 'ts-lms' ); ?></label>
								<input type="date" id="date-to" name="date_to" class="report-filter">
							</div>

							<?php if ( in_array( $active_tab, array( 'sales', 'students', 'courses' ), true ) ) : ?>
							<div class="filter-group">
								<label for="course-filter"><?php esc_html_e( 'Course:', 'ts-lms' ); ?></label>
								<?php self::render_course_dropdown(); ?>
							</div>
							<?php endif; ?>

							<div class="filter-actions">
								<button type="button" id="apply-filters" class="button button-primary">
									<?php esc_html_e( 'Apply Filters', 'ts-lms' ); ?>
								</button>
								<button type="button" id="reset-filters" class="button">
									<?php esc_html_e( 'Reset', 'ts-lms' ); ?>
								</button>
							</div>
						</div>

						<!-- Report Content -->
						<div class="ts-lms-reports-content">
							<!-- Summary Cards -->
							<div id="report-summary" class="report-summary">
								<div class="loading-spinner">
									<span class="spinner is-active"></span>
									<p><?php esc_html_e( 'Loading report...', 'ts-lms' ); ?></p>
								</div>
							</div>

							<!-- Export Buttons -->
							<div class="report-actions">
								<button type="button" id="export-csv" class="button">
									<span class="dashicons dashicons-download"></span>
									<?php esc_html_e( 'Export CSV', 'ts-lms' ); ?>
								</button>
								<button type="button" id="export-excel" class="button">
									<span class="dashicons dashicons-media-spreadsheet"></span>
									<?php esc_html_e( 'Export Excel', 'ts-lms' ); ?>
								</button>
							</div>

							<!-- Report Table -->
							<div id="report-table" class="report-table">
								<!-- Table will be populated via AJAX -->
							</div>

							<!-- Pagination -->
							<div id="report-pagination" class="report-pagination">
								<!-- Pagination will be populated via AJAX -->
							</div>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<input type="hidden" id="current-report-type" value="<?php echo esc_attr( $active_tab ); ?>">
		<?php
	}

	/**
	 * Get overview statistics.
	 *
	 * @return array
	 */
	private static function get_overview_stats() {
		global $wpdb;

		// Post counts
		$course_count = wp_count_posts( 'ts_course' )->publish;
		$lesson_count = wp_count_posts( 'ts_lesson' )->publish;
		$quiz_count = wp_count_posts( 'ts_quiz' )->publish;
		$question_count = wp_count_posts( 'ts_question' )->publish;

		// Enrollments
		$enrolled_count = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ts_course_enrollments" );

		// User counts
		$instructor_count = $wpdb->get_var( "SELECT COUNT(DISTINCT instructor_id) FROM {$wpdb->prefix}ts_course_instructors" );
		
		// For students, we look for users who have at least one enrollment if specific role is not set
		$student_count = $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->prefix}ts_course_enrollments" );

		// Reviews (assuming comments for now)
		$reviews_count = get_comments( array(
			'post_type' => 'ts_course',
			'count'     => true,
			'status'    => 'approve'
		) );

		return array(
			'published_courses'   => $course_count,
			'enrolled_total'      => $enrolled_count,
			'published_lessons'   => $lesson_count,
			'published_quizzes'   => $quiz_count,
			'published_questions' => $question_count,
			'instructors_count'   => $instructor_count,
			'students_count'      => $student_count,
			'reviews_total'       => $reviews_count,
		);
	}

	/**
	 * Render course dropdown filter.
	 *
	 * @return void
	 */
	private static function render_course_dropdown() {
		$courses = get_posts(
			array(
				'post_type'      => 'ts_course',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);

		?>
		<select id="course-filter" name="course_id" class="report-filter">
			<option value=""><?php esc_html_e( 'All Courses', 'ts-lms' ); ?></option>
			<?php foreach ( $courses as $course ) : ?>
				<option value="<?php echo esc_attr( $course->ID ); ?>">
					<?php echo esc_html( $course->post_title ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
	}

	/**
	 * Render instructor dropdown filter.
	 *
	 * @return void
	 */
	private static function render_instructor_dropdown() {
		global $wpdb;

		$instructors_table = $wpdb->prefix . 'ts_course_instructors';
		$users_table = $wpdb->prefix . 'users';

		$instructors = $wpdb->get_results(
			"SELECT DISTINCT u.ID, u.display_name 
			FROM {$users_table} u
			INNER JOIN {$instructors_table} ci ON u.ID = ci.instructor_id
			ORDER BY u.display_name ASC"
		);

		?>
		<select id="instructor-filter" name="instructor_id" class="report-filter">
			<option value=""><?php esc_html_e( 'All Instructors', 'ts-lms' ); ?></option>
			<?php foreach ( $instructors as $instructor ) : ?>
				<option value="<?php echo esc_attr( $instructor->ID ); ?>">
					<?php echo esc_html( $instructor->display_name ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
	}
}
