<?php
/**
 * Cache Manager
 *
 * Manages report result caching for performance optimization.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Cache;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CacheManager class.
 */
class CacheManager {

	/**
	 * Default cache TTL in seconds (1 hour).
	 */
	const DEFAULT_TTL = 3600;

	/**
	 * Cache TTL by report type.
	 *
	 * @var array
	 */
	private static $ttl_map = array(
		'course_sales'        => 1800,  // 30 minutes
		'student_progress'    => 3600,  // 1 hour
		'instructor_earnings' => 1800,  // 30 minutes
		'quiz_performance'    => 3600,  // 1 hour
	);

	/**
	 * Get cached report data.
	 *
	 * @param string $report_type Report type.
	 * @param array  $filters     Filters.
	 * @return array|null Cached data or null if not found/expired.
	 */
	public static function get( $report_type, $filters ) {
		global $wpdb;

		$cache_key = self::generate_cache_key( $report_type, $filters );
		$table = $wpdb->prefix . 'ts_report_cache';

		$cached = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT data, expires_at FROM {$table} WHERE cache_key = %s",
				$cache_key
			)
		);

		if ( ! $cached ) {
			return null;
		}

		// Check if expired
		if ( strtotime( $cached->expires_at ) < time() ) {
			self::delete( $cache_key );
			return null;
		}

		return json_decode( $cached->data, true );
	}

	/**
	 * Store report data in cache.
	 *
	 * @param string $report_type Report type.
	 * @param array  $filters     Filters.
	 * @param array  $data        Report data.
	 * @return bool True on success, false on failure.
	 */
	public static function set( $report_type, $filters, $data ) {
		global $wpdb;

		$cache_key = self::generate_cache_key( $report_type, $filters );
		$table = $wpdb->prefix . 'ts_report_cache';
		$ttl = self::$ttl_map[ $report_type ] ?? self::DEFAULT_TTL;

		$result = $wpdb->replace(
			$table,
			array(
				'cache_key'   => $cache_key,
				'report_type' => $report_type,
				'filters'     => wp_json_encode( $filters ),
				'data'        => wp_json_encode( $data ),
				'created_at'  => current_time( 'mysql' ),
				'expires_at'  => gmdate( 'Y-m-d H:i:s', time() + $ttl ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		return $result !== false;
	}

	/**
	 * Delete cached report data.
	 *
	 * @param string $cache_key Cache key.
	 * @return bool True on success, false on failure.
	 */
	public static function delete( $cache_key ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_report_cache';

		$result = $wpdb->delete(
			$table,
			array( 'cache_key' => $cache_key ),
			array( '%s' )
		);

		return $result !== false;
	}

	/**
	 * Invalidate all cache entries for a specific report type.
	 *
	 * @param string $report_type Report type.
	 * @return int Number of rows deleted.
	 */
	public static function invalidate_by_type( $report_type ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_report_cache';

		return $wpdb->delete(
			$table,
			array( 'report_type' => $report_type ),
			array( '%s' )
		);
	}

	/**
	 * Clear all expired cache entries.
	 *
	 * @return int Number of rows deleted.
	 */
	public static function clear_expired() {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_report_cache';

		return $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE expires_at < %s",
				current_time( 'mysql' )
			)
		);
	}

	/**
	 * Clear all cache entries.
	 *
	 * @return int Number of rows deleted.
	 */
	public static function clear_all() {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_report_cache';

		return $wpdb->query( "TRUNCATE TABLE {$table}" );
	}

	/**
	 * Generate cache key from report type and filters.
	 *
	 * @param string $report_type Report type.
	 * @param array  $filters     Filters.
	 * @return string Cache key.
	 */
	private static function generate_cache_key( $report_type, $filters ) {
		// Sort filters for consistent key generation
		ksort( $filters );

		// Create hash from report type and filters
		$key_data = $report_type . '_' . wp_json_encode( $filters );

		return 'ts_report_' . md5( $key_data );
	}

	/**
	 * Get cache statistics.
	 *
	 * @return array Cache statistics.
	 */
	public static function get_stats() {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_report_cache';

		$stats = array(
			'total_entries'   => 0,
			'expired_entries' => 0,
			'by_type'         => array(),
		);

		// Total entries
		$stats['total_entries'] = $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		// Expired entries
		$stats['expired_entries'] = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE expires_at < %s",
				current_time( 'mysql' )
			)
		);

		// Entries by type
		$by_type = $wpdb->get_results(
			"SELECT report_type, COUNT(*) as count FROM {$table} GROUP BY report_type"
		);

		foreach ( $by_type as $row ) {
			$stats['by_type'][ $row->report_type ] = intval( $row->count );
		}

		return $stats;
	}
}
