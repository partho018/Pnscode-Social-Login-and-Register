<?php
/**
 * Student Progress Report Generator
 *
 * Generates formatted student progress reports.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Generators;

use TS_LMS\Modules\Reports\Query\StudentProgressQuery;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * StudentProgressReport class.
 */
class StudentProgressReport extends ReportGenerator {

	/**
	 * Generate report.
	 *
	 * @param array $filters Filters to apply.
	 * @return array Formatted report data.
	 */
	public function generate( $filters = array() ) {
		$this->query_builder = new StudentProgressQuery();
		$this->query_builder->set_filters( $filters );

		$results = $this->query_builder->get_results();

		return array(
			'summary'  => $results['summary'] ?? array(),
			'data'     => $results['data'] ?? array(),
			'columns'  => $this->get_columns(),
			'metadata' => $this->get_metadata(),
		);
	}

	/**
	 * Get column definitions.
	 *
	 * @return array Column definitions.
	 */
	public function get_columns() {
		return array(
			'course_id'           => __( 'Course ID', 'ts-lms' ),
			'course_name'         => __( 'Course Name', 'ts-lms' ),
			'enrollment_count'    => __( 'Enrollments', 'ts-lms' ),
			'completed_count'     => __( 'Completed', 'ts-lms' ),
			'active_count'        => __( 'Active', 'ts-lms' ),
			'completion_rate'     => __( 'Completion Rate', 'ts-lms' ),
			'total_lessons'       => __( 'Total Lessons', 'ts-lms' ),
			'avg_completion_days' => __( 'Avg Days to Complete', 'ts-lms' ),
		);
	}
}
