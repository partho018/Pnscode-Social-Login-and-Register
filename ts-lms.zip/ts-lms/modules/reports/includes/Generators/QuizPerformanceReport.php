<?php
/**
 * Quiz Performance Report Generator
 *
 * Generates formatted quiz performance reports.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Generators;

use TS_LMS\Modules\Reports\Query\QuizPerformanceQuery;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * QuizPerformanceReport class.
 */
class QuizPerformanceReport extends ReportGenerator {

	/**
	 * Generate report.
	 *
	 * @param array $filters Filters to apply.
	 * @return array Formatted report data.
	 */
	public function generate( $filters = array() ) {
		$this->query_builder = new QuizPerformanceQuery();
		$this->query_builder->set_filters( $filters );

		$results = $this->query_builder->get_results();

		return array(
			'summary'  => $results['summary'] ?? array(),
			'data'     => $results['data'] ?? array(),
			'columns'  => $this->get_columns(),
			'metadata' => $this->get_metadata(),
		);
	}

	/**
	 * Get column definitions.
	 *
	 * @return array Column definitions.
	 */
	public function get_columns() {
		return array(
			'quiz_id'         => __( 'Quiz ID', 'ts-lms' ),
			'quiz_name'       => __( 'Quiz Name', 'ts-lms' ),
			'course_name'     => __( 'Course', 'ts-lms' ),
			'attempt_count'   => __( 'Attempts', 'ts-lms' ),
			'student_count'   => __( 'Students', 'ts-lms' ),
			'avg_score'       => __( 'Avg Score', 'ts-lms' ),
			'pass_rate'       => __( 'Pass Rate', 'ts-lms' ),
			'passed_count'    => __( 'Passed', 'ts-lms' ),
			'failed_count'    => __( 'Failed', 'ts-lms' ),
			'avg_time_spent'  => __( 'Avg Time', 'ts-lms' ),
		);
	}
}
