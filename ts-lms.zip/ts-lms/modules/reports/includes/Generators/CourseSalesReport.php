<?php
/**
 * Course Sales Report Generator
 *
 * Generates formatted course sales reports.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Generators;

use TS_LMS\Modules\Reports\Query\CourseSalesQuery;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CourseSalesReport class.
 */
class CourseSalesReport extends ReportGenerator {

	/**
	 * Generate report.
	 *
	 * @param array $filters Filters to apply.
	 * @return array Formatted report data.
	 */
	public function generate( $filters = array() ) {
		$this->query_builder = new CourseSalesQuery();
		$this->query_builder->set_filters( $filters );

		$results = $this->query_builder->get_results();

		return array(
			'summary'  => $results['summary'] ?? array(),
			'data'     => $results['data'] ?? array(),
			'columns'  => $this->get_columns(),
			'metadata' => $this->get_metadata(),
		);
	}

	/**
	 * Get column definitions.
	 *
	 * @return array Column definitions.
	 */
	public function get_columns() {
		return array(
			'bundle_id'    => __( 'Bundle ID', 'ts-lms' ),
			'bundle_name'  => __( 'Bundle Name', 'ts-lms' ),
			'sales_count'  => __( 'Sales', 'ts-lms' ),
			'revenue'      => __( 'Revenue', 'ts-lms' ),
			'avg_price'    => __( 'Avg Price', 'ts-lms' ),
			'first_sale'   => __( 'First Sale', 'ts-lms' ),
			'last_sale'    => __( 'Last Sale', 'ts-lms' ),
		);
	}
}
