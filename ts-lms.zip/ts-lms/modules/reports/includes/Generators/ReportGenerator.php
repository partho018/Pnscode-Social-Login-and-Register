<?php
/**
 * Report Generator Base Class
 *
 * Abstract base class for all report generators.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Generators;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ReportGenerator abstract class.
 */
abstract class ReportGenerator {

	/**
	 * Query builder instance.
	 *
	 * @var mixed
	 */
	protected $query_builder;

	/**
	 * Generate report.
	 *
	 * @param array $filters Filters to apply.
	 * @return array Formatted report data.
	 */
	abstract public function generate( $filters = array() );

	/**
	 * Get column definitions for the report.
	 *
	 * @return array Column definitions.
	 */
	abstract public function get_columns();

	/**
	 * Format report data for display/export.
	 *
	 * @param array $data Raw data.
	 * @return array Formatted data.
	 */
	protected function format_data( $data ) {
		return $data;
	}

	/**
	 * Get report metadata.
	 *
	 * @return array Report metadata.
	 */
	public function get_metadata() {
		return array(
			'generated_at' => current_time( 'mysql' ),
			'generated_by' => get_current_user_id(),
		);
	}
}
