<?php
/**
 * Instructor Earnings Report Generator
 *
 * Generates formatted instructor earnings reports.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Generators;

use TS_LMS\Modules\Reports\Query\InstructorEarningsQuery;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * InstructorEarningsReport class.
 */
class InstructorEarningsReport extends ReportGenerator {

	/**
	 * Generate report.
	 *
	 * @param array $filters Filters to apply.
	 * @return array Formatted report data.
	 */
	public function generate( $filters = array() ) {
		$this->query_builder = new InstructorEarningsQuery();
		$this->query_builder->set_filters( $filters );

		$results = $this->query_builder->get_results();

		return array(
			'summary'  => $results['summary'] ?? array(),
			'data'     => $results['data'] ?? array(),
			'columns'  => $this->get_columns(),
			'metadata' => $this->get_metadata(),
		);
	}

	/**
	 * Get column definitions.
	 *
	 * @return array Column definitions.
	 */
	public function get_columns() {
		return array(
			'instructor_id'     => __( 'Instructor ID', 'ts-lms' ),
			'instructor_name'   => __( 'Instructor Name', 'ts-lms' ),
			'instructor_email'  => __( 'Email', 'ts-lms' ),
			'course_count'      => __( 'Courses', 'ts-lms' ),
			'student_count'     => __( 'Students', 'ts-lms' ),
			'total_earnings'    => __( 'Total Earnings', 'ts-lms' ),
			'bundle_earnings'   => __( 'Bundle Earnings', 'ts-lms' ),
		);
	}
}
