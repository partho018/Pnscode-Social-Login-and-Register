<?php
/**
 * Quiz Performance Query Builder
 *
 * Builds queries for quiz performance reports.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Query;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * QuizPerformanceQuery class.
 */
class QuizPerformanceQuery extends QueryBuilder {

	/**
	 * Report type identifier.
	 *
	 * @var string
	 */
	protected $report_type = 'quiz_performance';

	/**
	 * Execute the query.
	 *
	 * @return array Query results.
	 */
	protected function execute_query() {
		$results = array(
			'summary' => $this->get_summary(),
			'data'    => $this->get_performance_data(),
		);

		return $results;
	}

	/**
	 * Get summary statistics.
	 *
	 * @return array Summary data.
	 */
	private function get_summary() {
		$attempts_table = $this->get_table( 'ts_quiz_attempts' );
		$grades_table = $this->get_table( 'ts_quiz_grades' );
		$quizzes_table = $this->get_table( 'posts' );

		$date_filter = $this->build_date_filter( 'a.completed_at' );
		$course_filter = '';

		if ( ! empty( $this->filters['course_id'] ) ) {
			$course_filter = $this->build_in_filter( 'a.course_id', $this->filters['course_id'] );
		}

		$query = "
			SELECT 
				COUNT(DISTINCT a.id) as total_attempts,
				COUNT(DISTINCT a.user_id) as total_students,
				COUNT(DISTINCT a.quiz_id) as total_quizzes,
				COUNT(DISTINCT CASE WHEN a.status = 'completed' THEN a.id END) as completed_attempts,
				AVG(a.percentage) as avg_score,
				COUNT(DISTINCT CASE WHEN g.passed = 1 THEN g.id END) as passed_count,
				COUNT(DISTINCT g.id) as graded_count
			FROM {$attempts_table} a
			INNER JOIN {$quizzes_table} q ON a.quiz_id = q.ID
			LEFT JOIN {$grades_table} g ON a.id = g.attempt_id
			WHERE q.post_type = 'ts_quiz'
				AND a.status = 'completed'
				{$date_filter}
				{$course_filter}
		";

		$summary = $this->wpdb->get_row( $query, ARRAY_A );

		$graded = intval( $summary['graded_count'] ?? 0 );
		$passed = intval( $summary['passed_count'] ?? 0 );
		$pass_rate = $graded > 0 ? ( $passed / $graded ) * 100 : 0;

		return array(
			'total_attempts'      => intval( $summary['total_attempts'] ?? 0 ),
			'completed_attempts'  => intval( $summary['completed_attempts'] ?? 0 ),
			'total_students'      => intval( $summary['total_students'] ?? 0 ),
			'total_quizzes'       => intval( $summary['total_quizzes'] ?? 0 ),
			'avg_score'           => $this->format_percentage( $summary['avg_score'] ?? 0 ),
			'pass_rate'           => $this->format_percentage( $pass_rate ),
			'passed_count'        => $passed,
			'failed_count'        => $graded - $passed,
		);
	}

	/**
	 * Get performance data by quiz.
	 *
	 * @return array Performance data.
	 */
	private function get_performance_data() {
		$attempts_table = $this->get_table( 'ts_quiz_attempts' );
		$grades_table = $this->get_table( 'ts_quiz_grades' );
		$quizzes_table = $this->get_table( 'posts' );
		$courses_table = $this->get_table( 'posts' );

		$date_filter = $this->build_date_filter( 'a.completed_at' );
		$course_filter = '';

		if ( ! empty( $this->filters['course_id'] ) ) {
			$course_filter = $this->build_in_filter( 'a.course_id', $this->filters['course_id'] );
		}

		$query = "
			SELECT 
				q.ID as quiz_id,
				q.post_title as quiz_name,
				c.ID as course_id,
				c.post_title as course_name,
				COUNT(DISTINCT a.id) as attempt_count,
				COUNT(DISTINCT a.user_id) as student_count,
				COUNT(DISTINCT CASE WHEN a.status = 'completed' THEN a.id END) as completed_count,
				AVG(a.percentage) as avg_score,
				MIN(a.percentage) as min_score,
				MAX(a.percentage) as max_score,
				AVG(a.time_spent) as avg_time_spent,
				COUNT(DISTINCT CASE WHEN g.passed = 1 THEN g.id END) as passed_count,
				COUNT(DISTINCT CASE WHEN g.passed = 0 THEN g.id END) as failed_count,
				MIN(a.completed_at) as first_attempt,
				MAX(a.completed_at) as last_attempt
			FROM {$attempts_table} a
			INNER JOIN {$quizzes_table} q ON a.quiz_id = q.ID
			LEFT JOIN {$courses_table} c ON a.course_id = c.ID
			LEFT JOIN {$grades_table} g ON a.id = g.attempt_id
			WHERE q.post_type = 'ts_quiz'
				AND a.status = 'completed'
				{$date_filter}
				{$course_filter}
			GROUP BY q.ID, q.post_title, c.ID, c.post_title
			ORDER BY attempt_count DESC
		";

		$results = $this->wpdb->get_results( $query, ARRAY_A );

		// Format results
		foreach ( $results as &$row ) {
			$row['quiz_id'] = intval( $row['quiz_id'] );
			$row['course_id'] = intval( $row['course_id'] ?? 0 );
			$row['attempt_count'] = intval( $row['attempt_count'] );
			$row['student_count'] = intval( $row['student_count'] );
			$row['completed_count'] = intval( $row['completed_count'] );
			$row['passed_count'] = intval( $row['passed_count'] );
			$row['failed_count'] = intval( $row['failed_count'] );
			
			$row['avg_score'] = $this->format_percentage( $row['avg_score'] ?? 0 );
			$row['min_score'] = $this->format_percentage( $row['min_score'] ?? 0 );
			$row['max_score'] = $this->format_percentage( $row['max_score'] ?? 0 );
			
			$total_graded = $row['passed_count'] + $row['failed_count'];
			$pass_rate = $total_graded > 0 ? ( $row['passed_count'] / $total_graded ) * 100 : 0;
			$row['pass_rate'] = $this->format_percentage( $pass_rate );
			
			// Format time spent (convert seconds to minutes)
			$avg_time = (float) ( $row['avg_time_spent'] ?? 0 );
			$row['avg_time_spent'] = $avg_time > 0 
				? number_format( $avg_time / 60, 1 ) . ' min' 
				: 'N/A';

			// Get question-level analytics
			$row['question_analytics'] = $this->get_question_analytics( $row['quiz_id'] );
		}

		return $results;
	}

	/**
	 * Get question-level analytics for a quiz.
	 *
	 * @param int $quiz_id Quiz ID.
	 * @return array Question analytics.
	 */
	private function get_question_analytics( $quiz_id ) {
		$quiz_questions_table = $this->get_table( 'ts_quiz_questions' );
		$responses_table = $this->get_table( 'ts_quiz_responses' );
		$questions_table = $this->get_table( 'posts' );

		$query = $this->wpdb->prepare(
			"SELECT 
				q.ID as question_id,
				q.post_title as question_text,
				COUNT(r.id) as response_count,
				COUNT(CASE WHEN r.is_correct = 1 THEN 1 END) as correct_count,
				COUNT(CASE WHEN r.is_correct = 0 THEN 1 END) as incorrect_count,
				AVG(r.points_earned) as avg_points
			FROM {$quiz_questions_table} qq
			INNER JOIN {$questions_table} q ON qq.question_id = q.ID
			LEFT JOIN {$responses_table} r ON q.ID = r.question_id
			WHERE qq.quiz_id = %d
				AND q.post_type = 'ts_question'
			GROUP BY q.ID, q.post_title
			ORDER BY correct_count ASC
			LIMIT 5",
			$quiz_id
		);

		$results = $this->wpdb->get_results( $query, ARRAY_A );

		foreach ( $results as &$row ) {
			$row['question_id'] = intval( $row['question_id'] );
			$row['response_count'] = intval( $row['response_count'] );
			$row['correct_count'] = intval( $row['correct_count'] );
			$row['incorrect_count'] = intval( $row['incorrect_count'] );
			
			$accuracy = $row['response_count'] > 0 
				? ( $row['correct_count'] / $row['response_count'] ) * 100 
				: 0;
			$row['accuracy'] = $this->format_percentage( $accuracy );
			
			$row['avg_points'] = number_format( (float) $row['avg_points'], 2 );
		}

		return $results;
	}

	/**
	 * Validate and sanitize filters.
	 *
	 * @param array $filters Raw filters.
	 * @return array Validated filters.
	 */
	protected function validate_filters( $filters ) {
		$validated = array();

		// Date filters
		if ( ! empty( $filters['date_from'] ) ) {
			$validated['date_from'] = sanitize_text_field( $filters['date_from'] );
		}

		if ( ! empty( $filters['date_to'] ) ) {
			$validated['date_to'] = sanitize_text_field( $filters['date_to'] );
		}

		// Course filter
		if ( ! empty( $filters['course_id'] ) ) {
			$validated['course_id'] = array_map( 'intval', (array) $filters['course_id'] );
		}

		// Quiz filter
		if ( ! empty( $filters['quiz_id'] ) ) {
			$validated['quiz_id'] = array_map( 'intval', (array) $filters['quiz_id'] );
		}

		return $validated;
	}
}
