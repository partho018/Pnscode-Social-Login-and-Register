<?php
/**
 * Query Builder Base Class
 *
 * Abstract base class for all report query builders.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Query;

use TS_LMS\Modules\Reports\Cache\CacheManager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * QueryBuilder abstract class.
 */
abstract class QueryBuilder {

	/**
	 * WordPress database instance.
	 *
	 * @var \wpdb
	 */
	protected $wpdb;

	/**
	 * Filters applied to the query.
	 *
	 * @var array
	 */
	protected $filters = array();

	/**
	 * Pagination parameters.
	 *
	 * @var array
	 */
	protected $pagination = array(
		'page'     => 1,
		'per_page' => 50,
	);

	/**
	 * Whether to use cache.
	 *
	 * @var bool
	 */
	protected $use_cache = true;

	/**
	 * Report type identifier.
	 *
	 * @var string
	 */
	protected $report_type = '';

	/**
	 * Constructor.
	 */
	public function __construct() {
		global $wpdb;
		$this->wpdb = $wpdb;
	}

	/**
	 * Set filters.
	 *
	 * @param array $filters Filters to apply.
	 * @return self
	 */
	public function set_filters( $filters ) {
		$this->filters = $this->validate_filters( $filters );
		return $this;
	}

	/**
	 * Set pagination.
	 *
	 * @param int $page     Page number.
	 * @param int $per_page Items per page.
	 * @return self
	 */
	public function set_pagination( $page, $per_page ) {
		$this->pagination = array(
			'page'     => max( 1, intval( $page ) ),
			'per_page' => max( 1, min( 1000, intval( $per_page ) ) ),
		);
		return $this;
	}

	/**
	 * Disable cache for this query.
	 *
	 * @return self
	 */
	public function disable_cache() {
		$this->use_cache = false;
		return $this;
	}

	/**
	 * Execute the query and return results.
	 *
	 * @return array Query results.
	 */
	public function get_results() {
		// Try to get from cache
		if ( $this->use_cache ) {
			$cached = CacheManager::get( $this->report_type, $this->filters );
			if ( $cached !== null ) {
				return $this->apply_pagination( $cached );
			}
		}

		// Build and execute query
		$results = $this->execute_query();

		// Store in cache
		if ( $this->use_cache && ! empty( $results ) ) {
			CacheManager::set( $this->report_type, $this->filters, $results );
		}

		return $this->apply_pagination( $results );
	}

	/**
	 * Get total count (without pagination).
	 *
	 * @return int Total count.
	 */
	public function get_total_count() {
		$results = $this->get_results();
		return isset( $results['total'] ) ? $results['total'] : count( $results['data'] ?? array() );
	}

	/**
	 * Execute the query (to be implemented by child classes).
	 *
	 * @return array Query results.
	 */
	abstract protected function execute_query();

	/**
	 * Validate and sanitize filters (to be implemented by child classes).
	 *
	 * @param array $filters Raw filters.
	 * @return array Validated filters.
	 */
	abstract protected function validate_filters( $filters );

	/**
	 * Apply pagination to results.
	 *
	 * @param array $results Full results.
	 * @return array Paginated results.
	 */
	protected function apply_pagination( $results ) {
		if ( ! isset( $results['data'] ) || ! is_array( $results['data'] ) ) {
			return $results;
		}

		$total = count( $results['data'] );
		$offset = ( $this->pagination['page'] - 1 ) * $this->pagination['per_page'];

		$results['pagination'] = array(
			'page'        => $this->pagination['page'],
			'per_page'    => $this->pagination['per_page'],
			'total'       => $total,
			'total_pages' => ceil( $total / $this->pagination['per_page'] ),
		);

		$results['data'] = array_slice(
			$results['data'],
			$offset,
			$this->pagination['per_page']
		);

		return $results;
	}

	/**
	 * Build date range WHERE clause.
	 *
	 * @param string $column Column name.
	 * @return string WHERE clause.
	 */
	protected function build_date_filter( $column ) {
		$where = '';

		if ( ! empty( $this->filters['date_from'] ) ) {
			$date_from = sanitize_text_field( $this->filters['date_from'] );
			$where .= $this->wpdb->prepare( " AND {$column} >= %s", $date_from . ' 00:00:00' );
		}

		if ( ! empty( $this->filters['date_to'] ) ) {
			$date_to = sanitize_text_field( $this->filters['date_to'] );
			$where .= $this->wpdb->prepare( " AND {$column} <= %s", $date_to . ' 23:59:59' );
		}

		return $where;
	}

	/**
	 * Build IN clause for array filters.
	 *
	 * @param string $column Column name.
	 * @param array  $values Values.
	 * @return string WHERE clause.
	 */
	protected function build_in_filter( $column, $values ) {
		if ( empty( $values ) || ! is_array( $values ) ) {
			return '';
		}

		$values = array_map( 'intval', $values );
		$placeholders = implode( ',', array_fill( 0, count( $values ), '%d' ) );

		return $this->wpdb->prepare( " AND {$column} IN ({$placeholders})", $values );
	}

	/**
	 * Get table name with prefix.
	 *
	 * @param string $table Table name without prefix.
	 * @return string Full table name.
	 */
	protected function get_table( $table ) {
		return $this->wpdb->prefix . $table;
	}

	/**
	 * Format currency value.
	 *
	 * @param float $value Value to format.
	 * @return string Formatted value.
	 */
	protected function format_currency( $value ) {
		return number_format( (float) $value, 2, '.', '' );
	}

	/**
	 * Format percentage value.
	 *
	 * @param float $value Value to format.
	 * @return string Formatted value.
	 */
	protected function format_percentage( $value ) {
		return number_format( (float) $value, 2, '.', '' );
	}
}
