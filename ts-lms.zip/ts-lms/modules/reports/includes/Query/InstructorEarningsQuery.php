<?php
/**
 * Instructor Earnings Query Builder
 *
 * Builds queries for instructor earnings reports.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Query;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * InstructorEarningsQuery class.
 */
class InstructorEarningsQuery extends QueryBuilder {

	/**
	 * Report type identifier.
	 *
	 * @var string
	 */
	protected $report_type = 'instructor_earnings';

	/**
	 * Execute the query.
	 *
	 * @return array Query results.
	 */
	protected function execute_query() {
		$results = array(
			'summary' => $this->get_summary(),
			'data'    => $this->get_earnings_data(),
		);

		return $results;
	}

	/**
	 * Get summary statistics.
	 *
	 * @return array Summary data.
	 */
	private function get_summary() {
		$data = $this->get_earnings_data();
		
		$total_earnings = 0;
		$total_instructors = count( $data );
		$total_courses = 0;
		$total_students = 0;

		foreach ( $data as $row ) {
			$total_earnings += (float) $row['total_earnings'];
			$total_courses += intval( $row['course_count'] );
			$total_students += intval( $row['student_count'] );
		}

		$avg_earnings = $total_instructors > 0 ? $total_earnings / $total_instructors : 0;

		return array(
			'total_earnings'     => $this->format_currency( $total_earnings ),
			'total_instructors'  => $total_instructors,
			'total_courses'      => $total_courses,
			'total_students'     => $total_students,
			'avg_earnings'       => $this->format_currency( $avg_earnings ),
		);
	}

	/**
	 * Get earnings data by instructor.
	 *
	 * @return array Earnings data.
	 */
	private function get_earnings_data() {
		$instructors_table = $this->get_table( 'ts_course_instructors' );
		$bundle_courses_table = $this->get_table( 'ts_bundle_courses' );
		$enrollments_table = $this->get_table( 'ts_course_enrollments' );
		$users_table = $this->get_table( 'users' );
		$courses_table = $this->get_table( 'posts' );
		$orders_table = $this->get_table( 'posts' );
		$order_items_table = $this->get_table( 'woocommerce_order_items' );
		$order_itemmeta_table = $this->get_table( 'woocommerce_order_itemmeta' );
		$postmeta_table = $this->get_table( 'postmeta' );

		$date_filter = $this->build_date_filter( 'orders.post_date' );
		$instructor_filter = '';

		if ( ! empty( $this->filters['instructor_id'] ) ) {
			$instructor_filter = $this->build_in_filter( 'ci.instructor_id', $this->filters['instructor_id'] );
		}

		// Get all instructors with their courses
		$query = "
			SELECT 
				u.ID as instructor_id,
				u.display_name as instructor_name,
				u.user_email as instructor_email,
				COUNT(DISTINCT ci.course_id) as course_count,
				COUNT(DISTINCT e.user_id) as student_count
			FROM {$users_table} u
			INNER JOIN {$instructors_table} ci ON u.ID = ci.instructor_id
			INNER JOIN {$courses_table} c ON ci.course_id = c.ID
			LEFT JOIN {$enrollments_table} e ON c.ID = e.course_id
			WHERE c.post_type = 'ts_course'
				AND c.post_status = 'publish'
				{$instructor_filter}
			GROUP BY u.ID, u.display_name, u.user_email
			ORDER BY u.display_name ASC
		";

		$instructors = $this->wpdb->get_results( $query, ARRAY_A );

		// Calculate earnings for each instructor
		foreach ( $instructors as &$instructor ) {
			$instructor['instructor_id'] = intval( $instructor['instructor_id'] );
			$instructor['course_count'] = intval( $instructor['course_count'] );
			$instructor['student_count'] = intval( $instructor['student_count'] );
			
			// Calculate earnings from bundle sales
			$earnings = $this->calculate_instructor_earnings( 
				$instructor['instructor_id'], 
				$date_filter 
			);
			
			$instructor['total_earnings'] = $this->format_currency( $earnings['total'] );
			$instructor['bundle_earnings'] = $this->format_currency( $earnings['bundle'] );
			$instructor['course_breakdown'] = $earnings['by_course'];
		}

		return $instructors;
	}

	/**
	 * Calculate earnings for a specific instructor.
	 *
	 * @param int    $instructor_id Instructor ID.
	 * @param string $date_filter   Date filter SQL.
	 * @return array Earnings breakdown.
	 */
	private function calculate_instructor_earnings( $instructor_id, $date_filter ) {
		$instructors_table = $this->get_table( 'ts_course_instructors' );
		$bundle_courses_table = $this->get_table( 'ts_bundle_courses' );
		$bundles_table = $this->get_table( 'posts' );
		$orders_table = $this->get_table( 'posts' );
		$order_items_table = $this->get_table( 'woocommerce_order_items' );
		$order_itemmeta_table = $this->get_table( 'woocommerce_order_itemmeta' );
		$postmeta_table = $this->get_table( 'postmeta' );

		// Get bundle sales for instructor's courses
		$query = $this->wpdb->prepare(
			"SELECT 
				bc.bundle_id,
				bc.course_id,
				bc.course_price,
				bundles.post_title as bundle_name,
				pm_price.meta_value as bundle_price,
				COUNT(DISTINCT orders.ID) as sale_count,
				SUM(oim_total.meta_value) as total_revenue
			FROM {$instructors_table} ci
			INNER JOIN {$bundle_courses_table} bc ON ci.course_id = bc.course_id
			INNER JOIN {$bundles_table} bundles ON bc.bundle_id = bundles.ID
			INNER JOIN {$postmeta_table} pm_price ON bundles.ID = pm_price.post_id 
				AND pm_price.meta_key = '_bundle_price'
			INNER JOIN {$postmeta_table} pm_product ON bundles.ID = pm_product.post_id 
				AND pm_product.meta_key = '_bundle_woo_product_id'
			INNER JOIN {$order_itemmeta_table} oim_product ON pm_product.meta_value = oim_product.meta_value 
				AND oim_product.meta_key = '_product_id'
			INNER JOIN {$order_items_table} oi ON oim_product.order_item_id = oi.order_item_id
			INNER JOIN {$orders_table} orders ON oi.order_id = orders.ID
			LEFT JOIN {$order_itemmeta_table} oim_total ON oi.order_item_id = oim_total.order_item_id 
				AND oim_total.meta_key = '_line_total'
			WHERE ci.instructor_id = %d
				AND orders.post_type = 'shop_order'
				AND orders.post_status IN ('wc-completed', 'wc-processing')
				AND bundles.post_type = 'ts_bundle'
				{$date_filter}
			GROUP BY bc.bundle_id, bc.course_id, bc.course_price, bundles.post_title, pm_price.meta_value",
			$instructor_id
		);

		$sales = $this->wpdb->get_results( $query, ARRAY_A );

		$total_earnings = 0;
		$by_course = array();

		foreach ( $sales as $sale ) {
			$bundle_price = (float) $sale['bundle_price'];
			$course_price = (float) $sale['course_price'];
			$total_revenue = (float) $sale['total_revenue'];
			
			// Calculate total course prices in bundle
			$bundle_id = intval( $sale['bundle_id'] );
			$total_course_price = $this->get_bundle_total_course_price( $bundle_id );
			
			// Calculate weighted commission
			$commission_per_sale = 0;
			if ( $total_course_price > 0 ) {
				$commission_per_sale = ( $bundle_price * ( $course_price / $total_course_price ) );
			}
			
			$course_earnings = $commission_per_sale * intval( $sale['sale_count'] );
			$total_earnings += $course_earnings;
			
			$course_id = intval( $sale['course_id'] );
			if ( ! isset( $by_course[ $course_id ] ) ) {
				$by_course[ $course_id ] = 0;
			}
			$by_course[ $course_id ] += $course_earnings;
		}

		return array(
			'total'     => $total_earnings,
			'bundle'    => $total_earnings, // All earnings are from bundles currently
			'by_course' => $by_course,
		);
	}

	/**
	 * Get total course price for a bundle.
	 *
	 * @param int $bundle_id Bundle ID.
	 * @return float Total course price.
	 */
	private function get_bundle_total_course_price( $bundle_id ) {
		$bundle_courses_table = $this->get_table( 'ts_bundle_courses' );

		$query = $this->wpdb->prepare(
			"SELECT SUM(course_price) as total
			FROM {$bundle_courses_table}
			WHERE bundle_id = %d",
			$bundle_id
		);

		$result = $this->wpdb->get_var( $query );

		return (float) $result;
	}

	/**
	 * Validate and sanitize filters.
	 *
	 * @param array $filters Raw filters.
	 * @return array Validated filters.
	 */
	protected function validate_filters( $filters ) {
		$validated = array();

		// Date filters
		if ( ! empty( $filters['date_from'] ) ) {
			$validated['date_from'] = sanitize_text_field( $filters['date_from'] );
		}

		if ( ! empty( $filters['date_to'] ) ) {
			$validated['date_to'] = sanitize_text_field( $filters['date_to'] );
		}

		// Instructor filter
		if ( ! empty( $filters['instructor_id'] ) ) {
			$validated['instructor_id'] = array_map( 'intval', (array) $filters['instructor_id'] );
		}

		// Course filter
		if ( ! empty( $filters['course_id'] ) ) {
			$validated['course_id'] = array_map( 'intval', (array) $filters['course_id'] );
		}

		return $validated;
	}
}
