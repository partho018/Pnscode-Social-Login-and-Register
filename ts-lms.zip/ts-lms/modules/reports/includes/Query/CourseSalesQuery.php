<?php
/**
 * Course Sales Query Builder
 *
 * Builds queries for course sales reports.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Query;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CourseSalesQuery class.
 */
class CourseSalesQuery extends QueryBuilder {

	/**
	 * Report type identifier.
	 *
	 * @var string
	 */
	protected $report_type = 'course_sales';

	/**
	 * Execute the query.
	 *
	 * @return array Query results.
	 */
	protected function execute_query() {
		$results = array(
			'summary' => $this->get_summary(),
			'data'    => $this->get_sales_data(),
		);

		return $results;
	}

	/**
	 * Get summary statistics.
	 *
	 * @return array Summary data.
	 */
	private function get_summary() {
		$orders_table = $this->get_table( 'posts' );
		$order_items_table = $this->get_table( 'woocommerce_order_items' );
		$order_itemmeta_table = $this->get_table( 'woocommerce_order_itemmeta' );
		$postmeta_table = $this->get_table( 'postmeta' );

		$date_filter = $this->build_date_filter( 'orders.post_date' );

		$query = "
			SELECT 
				COUNT(DISTINCT orders.ID) as total_orders,
				COUNT(DISTINCT oi.order_item_id) as total_items,
				SUM(oim_total.meta_value) as total_revenue,
				AVG(oim_total.meta_value) as avg_order_value
			FROM {$orders_table} orders
			INNER JOIN {$order_items_table} oi ON orders.ID = oi.order_id
			INNER JOIN {$order_itemmeta_table} oim_product ON oi.order_item_id = oim_product.order_item_id 
				AND oim_product.meta_key = '_product_id'
			INNER JOIN {$postmeta_table} pm ON oim_product.meta_value = pm.post_id 
				AND pm.meta_key = '_ts_lms_bundle_id'
			LEFT JOIN {$order_itemmeta_table} oim_total ON oi.order_item_id = oim_total.order_item_id 
				AND oim_total.meta_key = '_line_total'
			WHERE orders.post_type = 'shop_order'
				AND orders.post_status IN ('wc-completed', 'wc-processing')
				{$date_filter}
		";

		$summary = $this->wpdb->get_row( $query, ARRAY_A );

		return array(
			'total_orders'     => intval( $summary['total_orders'] ?? 0 ),
			'total_items'      => intval( $summary['total_items'] ?? 0 ),
			'total_revenue'    => $this->format_currency( $summary['total_revenue'] ?? 0 ),
			'avg_order_value'  => $this->format_currency( $summary['avg_order_value'] ?? 0 ),
		);
	}

	/**
	 * Get sales data by course/bundle.
	 *
	 * @return array Sales data.
	 */
	private function get_sales_data() {
		$orders_table = $this->get_table( 'posts' );
		$order_items_table = $this->get_table( 'woocommerce_order_items' );
		$order_itemmeta_table = $this->get_table( 'woocommerce_order_itemmeta' );
		$postmeta_table = $this->get_table( 'postmeta' );
		$bundles_table = $orders_table; // Bundles are custom post type

		$date_filter = $this->build_date_filter( 'orders.post_date' );
		$course_filter = '';

		if ( ! empty( $this->filters['course_id'] ) ) {
			$course_filter = $this->build_in_filter( 'pm.meta_value', $this->filters['course_id'] );
		}

		$query = "
			SELECT 
				bundles.ID as bundle_id,
				bundles.post_title as bundle_name,
				COUNT(DISTINCT orders.ID) as sales_count,
				SUM(oim_total.meta_value) as revenue,
				AVG(oim_total.meta_value) as avg_price,
				MIN(orders.post_date) as first_sale,
				MAX(orders.post_date) as last_sale
			FROM {$orders_table} orders
			INNER JOIN {$order_items_table} oi ON orders.ID = oi.order_id
			INNER JOIN {$order_itemmeta_table} oim_product ON oi.order_item_id = oim_product.order_item_id 
				AND oim_product.meta_key = '_product_id'
			INNER JOIN {$postmeta_table} pm ON oim_product.meta_value = pm.post_id 
				AND pm.meta_key = '_ts_lms_bundle_id'
			INNER JOIN {$bundles_table} bundles ON pm.meta_value = bundles.ID
			LEFT JOIN {$order_itemmeta_table} oim_total ON oi.order_item_id = oim_total.order_item_id 
				AND oim_total.meta_key = '_line_total'
			WHERE orders.post_type = 'shop_order'
				AND orders.post_status IN ('wc-completed', 'wc-processing')
				AND bundles.post_type = 'ts_bundle'
				{$date_filter}
				{$course_filter}
			GROUP BY bundles.ID, bundles.post_title
			ORDER BY revenue DESC
		";

		$results = $this->wpdb->get_results( $query, ARRAY_A );

		// Format results
		foreach ( $results as &$row ) {
			$row['bundle_id'] = intval( $row['bundle_id'] );
			$row['sales_count'] = intval( $row['sales_count'] );
			$row['revenue'] = $this->format_currency( $row['revenue'] );
			$row['avg_price'] = $this->format_currency( $row['avg_price'] );
		}

		return $results;
	}

	/**
	 * Validate and sanitize filters.
	 *
	 * @param array $filters Raw filters.
	 * @return array Validated filters.
	 */
	protected function validate_filters( $filters ) {
		$validated = array();

		// Date filters
		if ( ! empty( $filters['date_from'] ) ) {
			$validated['date_from'] = sanitize_text_field( $filters['date_from'] );
		}

		if ( ! empty( $filters['date_to'] ) ) {
			$validated['date_to'] = sanitize_text_field( $filters['date_to'] );
		}

		// Course/Bundle filter
		if ( ! empty( $filters['course_id'] ) ) {
			$validated['course_id'] = array_map( 'intval', (array) $filters['course_id'] );
		}

		return $validated;
	}
}
