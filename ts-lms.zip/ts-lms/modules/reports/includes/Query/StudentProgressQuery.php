<?php
/**
 * Student Progress Query Builder
 *
 * Builds queries for student progress reports.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports\Query;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * StudentProgressQuery class.
 */
class StudentProgressQuery extends QueryBuilder {

	/**
	 * Report type identifier.
	 *
	 * @var string
	 */
	protected $report_type = 'student_progress';

	/**
	 * Execute the query.
	 *
	 * @return array Query results.
	 */
	protected function execute_query() {
		$results = array(
			'summary' => $this->get_summary(),
			'data'    => $this->get_progress_data(),
		);

		return $results;
	}

	/**
	 * Get summary statistics.
	 *
	 * @return array Summary data.
	 */
	private function get_summary() {
		$enrollments_table = $this->get_table( 'ts_course_enrollments' );
		$courses_table = $this->get_table( 'posts' );

		$date_filter = $this->build_date_filter( 'e.enrolled_at' );
		$course_filter = '';

		if ( ! empty( $this->filters['course_id'] ) ) {
			$course_filter = $this->build_in_filter( 'e.course_id', $this->filters['course_id'] );
		}

		$query = "
			SELECT 
				COUNT(DISTINCT e.id) as total_enrollments,
				COUNT(DISTINCT e.user_id) as total_students,
				COUNT(DISTINCT e.course_id) as total_courses,
				COUNT(DISTINCT CASE WHEN e.status = 'completed' THEN e.id END) as completed_enrollments,
				COUNT(DISTINCT CASE WHEN e.status = 'active' THEN e.id END) as active_enrollments
			FROM {$enrollments_table} e
			INNER JOIN {$courses_table} c ON e.course_id = c.ID
			WHERE c.post_type = 'ts_course'
				AND c.post_status = 'publish'
				{$date_filter}
				{$course_filter}
		";

		$summary = $this->wpdb->get_row( $query, ARRAY_A );

		$total = intval( $summary['total_enrollments'] ?? 0 );
		$completed = intval( $summary['completed_enrollments'] ?? 0 );
		$completion_rate = $total > 0 ? ( $completed / $total ) * 100 : 0;

		return array(
			'total_enrollments'     => $total,
			'total_students'        => intval( $summary['total_students'] ?? 0 ),
			'total_courses'         => intval( $summary['total_courses'] ?? 0 ),
			'completed_enrollments' => $completed,
			'active_enrollments'    => intval( $summary['active_enrollments'] ?? 0 ),
			'completion_rate'       => $this->format_percentage( $completion_rate ),
		);
	}

	/**
	 * Get progress data by course.
	 *
	 * @return array Progress data.
	 */
	private function get_progress_data() {
		$enrollments_table = $this->get_table( 'ts_course_enrollments' );
		$courses_table = $this->get_table( 'posts' );
		$lesson_progress_table = $this->get_table( 'ts_lesson_progress' );
		$lesson_order_table = $this->get_table( 'ts_lesson_order' );

		$date_filter = $this->build_date_filter( 'e.enrolled_at' );
		$course_filter = '';

		if ( ! empty( $this->filters['course_id'] ) ) {
			$course_filter = $this->build_in_filter( 'e.course_id', $this->filters['course_id'] );
		}

		$query = "
			SELECT 
				c.ID as course_id,
				c.post_title as course_name,
				COUNT(DISTINCT e.id) as enrollment_count,
				COUNT(DISTINCT CASE WHEN e.status = 'completed' THEN e.id END) as completed_count,
				COUNT(DISTINCT CASE WHEN e.status = 'active' THEN e.id END) as active_count,
				COUNT(DISTINCT lo.lesson_id) as total_lessons,
				AVG(
					CASE 
						WHEN e.completed_at IS NOT NULL 
						THEN TIMESTAMPDIFF(DAY, e.enrolled_at, e.completed_at)
						ELSE NULL
					END
				) as avg_completion_days,
				MIN(e.enrolled_at) as first_enrollment,
				MAX(e.enrolled_at) as last_enrollment
			FROM {$enrollments_table} e
			INNER JOIN {$courses_table} c ON e.course_id = c.ID
			LEFT JOIN {$lesson_order_table} lo ON c.ID = lo.course_id
			WHERE c.post_type = 'ts_course'
				AND c.post_status = 'publish'
				{$date_filter}
				{$course_filter}
			GROUP BY c.ID, c.post_title
			ORDER BY enrollment_count DESC
		";

		$results = $this->wpdb->get_results( $query, ARRAY_A );

		// Format results and calculate completion rate
		foreach ( $results as &$row ) {
			$row['course_id'] = intval( $row['course_id'] );
			$row['enrollment_count'] = intval( $row['enrollment_count'] );
			$row['completed_count'] = intval( $row['completed_count'] );
			$row['active_count'] = intval( $row['active_count'] );
			$row['total_lessons'] = intval( $row['total_lessons'] );
			
			$completion_rate = $row['enrollment_count'] > 0 
				? ( $row['completed_count'] / $row['enrollment_count'] ) * 100 
				: 0;
			$row['completion_rate'] = $this->format_percentage( $completion_rate );
			
			$row['avg_completion_days'] = $row['avg_completion_days'] 
				? number_format( (float) $row['avg_completion_days'], 1 ) 
				: 'N/A';

			// Get lesson completion stats for this course
			$row['lesson_stats'] = $this->get_lesson_stats( $row['course_id'] );
		}

		return $results;
	}

	/**
	 * Get lesson completion statistics for a course.
	 *
	 * @param int $course_id Course ID.
	 * @return array Lesson stats.
	 */
	private function get_lesson_stats( $course_id ) {
		$lesson_progress_table = $this->get_table( 'ts_lesson_progress' );

		$query = $this->wpdb->prepare(
			"SELECT 
				COUNT(DISTINCT CASE WHEN status = 'completed' THEN lesson_id END) as completed_lessons,
				COUNT(DISTINCT CASE WHEN status = 'in_progress' THEN lesson_id END) as in_progress_lessons,
				COUNT(DISTINCT user_id) as students_with_progress
			FROM {$lesson_progress_table}
			WHERE course_id = %d",
			$course_id
		);

		$stats = $this->wpdb->get_row( $query, ARRAY_A );

		return array(
			'completed_lessons'      => intval( $stats['completed_lessons'] ?? 0 ),
			'in_progress_lessons'    => intval( $stats['in_progress_lessons'] ?? 0 ),
			'students_with_progress' => intval( $stats['students_with_progress'] ?? 0 ),
		);
	}

	/**
	 * Validate and sanitize filters.
	 *
	 * @param array $filters Raw filters.
	 * @return array Validated filters.
	 */
	protected function validate_filters( $filters ) {
		$validated = array();

		// Date filters
		if ( ! empty( $filters['date_from'] ) ) {
			$validated['date_from'] = sanitize_text_field( $filters['date_from'] );
		}

		if ( ! empty( $filters['date_to'] ) ) {
			$validated['date_to'] = sanitize_text_field( $filters['date_to'] );
		}

		// Course filter
		if ( ! empty( $filters['course_id'] ) ) {
			$validated['course_id'] = array_map( 'intval', (array) $filters['course_id'] );
		}

		// Status filter
		if ( ! empty( $filters['status'] ) ) {
			$allowed_statuses = array( 'active', 'completed', 'suspended' );
			if ( in_array( $filters['status'], $allowed_statuses, true ) ) {
				$validated['status'] = $filters['status'];
			}
		}

		return $validated;
	}
}
