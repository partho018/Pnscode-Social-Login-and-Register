/**
 * TS LMS Reports - Admin JavaScript
 *
 * Handles AJAX interactions for the reports dashboard.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

(function($) {
	'use strict';

	const TSLMSReports = {
		/**
		 * Initialize the reports interface.
		 */
		init: function() {
			this.bindEvents();
			this.loadReport();
		},

		/**
		 * Bind event handlers.
		 */
		bindEvents: function() {
			$('#apply-filters').on('click', () => this.loadReport());
			$('#reset-filters').on('click', () => this.resetFilters());
			$('#export-csv').on('click', () => this.exportReport('csv'));
			$('#export-excel').on('click', () => this.exportReport('excel'));
		},

		/**
		 * Get current report type.
		 */
		getReportType: function() {
			return $('#current-report-type').val();
		},

		/**
		 * Get current filters.
		 */
		getFilters: function() {
			const filters = {};

			const dateFrom = $('#date-from').val();
			const dateTo = $('#date-to').val();
			const courseId = $('#course-filter').val();
			const instructorId = $('#instructor-filter').val();

			if (dateFrom) filters.date_from = dateFrom;
			if (dateTo) filters.date_to = dateTo;
			if (courseId) filters.course_id = courseId;
			if (instructorId) filters.instructor_id = instructorId;

			return filters;
		},

		/**
		 * Load report data via AJAX.
		 */
		loadReport: function() {
			const reportType = this.getReportType();
			const filters = this.getFilters();

			// Show loading state
			$('#report-summary').html(
				'<div class="loading-spinner">' +
				'<span class="spinner is-active"></span>' +
				'<p>' + tsLmsReports.i18n.loading + '</p>' +
				'</div>'
			);
			$('#report-table').html('');

			// AJAX request
			$.ajax({
				url: tsLmsReports.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_generate_report',
					nonce: tsLmsReports.nonce,
					report_type: reportType,
					filters: filters
				},
				success: (response) => {
					if (response.success) {
						this.renderReport(response.data);
					} else {
						this.showError(response.data.message || tsLmsReports.i18n.error);
					}
				},
				error: () => {
					this.showError(tsLmsReports.i18n.error);
				}
			});
		},

		/**
		 * Render report data.
		 */
		renderReport: function(data) {
			// Render summary
			this.renderSummary(data.summary);

			// Render table
			this.renderTable(data.data, data.columns);
		},

		/**
		 * Render summary cards.
		 */
		renderSummary: function(summary) {
			if (!summary || Object.keys(summary).length === 0) {
				$('#report-summary').html('<p>' + tsLmsReports.i18n.noData + '</p>');
				return;
			}

			let html = '<div class="summary-cards">';

            // Icon mapping based on keywords in the key
            const getIcon = (key) => {
                key = key.toLowerCase();
                if (key.includes('sales') || key.includes('earn') || key.includes('amount')) return 'dashicons-money-alt';
                if (key.includes('order')) return 'dashicons-cart';
                if (key.includes('student') || key.includes('user') || key.includes('enroll')) return 'dashicons-groups';
                if (key.includes('review') || key.includes('rating')) return 'dashicons-star-filled';
                if (key.includes('course')) return 'dashicons-welcome-learn-more';
                if (key.includes('complete')) return 'dashicons-yes-alt';
                if (key.includes('lesson')) return 'dashicons-welcome-edit-page';
                if (key.includes('quiz')) return 'dashicons-clipboard';
                return 'dashicons-chart-bar';
            };

			for (const [key, value] of Object.entries(summary)) {
				const label = this.formatLabel(key);
                const icon = getIcon(key);
				html += `
					<div class="summary-card">
                        <div class="summary-icon-bg dashicons ${icon}"></div>
						<div class="summary-value">${value}</div>
						<div class="summary-label">${label}</div>
					</div>
				`;
			}

			html += '</div>';
			$('#report-summary').html(html);
		},

		/**
		 * Render data table.
		 */
		renderTable: function(data, columns) {
			if (!data || data.length === 0) {
				$('#report-table').html('<p>' + tsLmsReports.i18n.noData + '</p>');
				return;
			}

			let html = '<table class="wp-list-table widefat fixed striped">';

			// Headers
			html += '<thead><tr>';
			for (const [key, label] of Object.entries(columns)) {
				html += `<th>${label}</th>`;
			}
			html += '</tr></thead>';

			// Body
			html += '<tbody>';
			data.forEach(row => {
				html += '<tr>';
				for (const key of Object.keys(columns)) {
					const value = row[key] !== undefined ? row[key] : '';
					html += `<td>${this.escapeHtml(value)}</td>`;
				}
				html += '</tr>';
			});
			html += '</tbody>';

			html += '</table>';
			$('#report-table').html(html);
		},

		/**
		 * Export report.
		 */
		exportReport: function(format) {
			const reportType = this.getReportType();
			const filters = this.getFilters();
			const $button = format === 'csv' ? $('#export-csv') : $('#export-excel');

			// Disable button and show loading
			$button.prop('disabled', true).text(tsLmsReports.i18n.exporting);

			// AJAX request
			$.ajax({
				url: tsLmsReports.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_export_report',
					nonce: tsLmsReports.nonce,
					report_type: reportType,
					format: format,
					filters: filters
				},
				success: (response) => {
					if (response.success) {
						// Download file
						window.location.href = response.data.download_url;
						
						// Show success message
						this.showNotice(tsLmsReports.i18n.exportReady, 'success');
					} else {
						this.showError(response.data.message || tsLmsReports.i18n.exportError);
					}
				},
				error: () => {
					this.showError(tsLmsReports.i18n.exportError);
				},
				complete: () => {
					// Re-enable button
					$button.prop('disabled', false);
					const buttonText = format === 'csv' ? 'Export CSV' : 'Export Excel';
					$button.html('<span class="dashicons dashicons-download"></span> ' + buttonText);
				}
			});
		},

		/**
		 * Reset filters.
		 */
		resetFilters: function() {
			$('.report-filter').val('');
			this.loadReport();
		},

		/**
		 * Show error message.
		 */
		showError: function(message) {
			$('#report-summary').html(
				'<div class="notice notice-error"><p>' + this.escapeHtml(message) + '</p></div>'
			);
		},

		/**
		 * Show notice message.
		 */
		showNotice: function(message, type = 'info') {
			const $notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + this.escapeHtml(message) + '</p></div>');
			$('.ts-lms-reports h1').after($notice);

			// Auto-dismiss after 5 seconds
			setTimeout(() => {
				$notice.fadeOut(() => $notice.remove());
			}, 5000);
		},

		/**
		 * Format label from key.
		 */
		formatLabel: function(key) {
			return key
				.replace(/_/g, ' ')
				.replace(/\b\w/g, l => l.toUpperCase());
		},

		/**
		 * Escape HTML.
		 */
		escapeHtml: function(text) {
			const map = {
				'&': '&amp;',
				'<': '&lt;',
				'>': '&gt;',
				'"': '&quot;',
				"'": '&#039;'
			};
			return String(text).replace(/[&<>"']/g, m => map[m]);
		}
	};

	// Initialize on document ready
	$(document).ready(() => {
		if ($('.ts-lms-reports-redesign').length) {
			TSLMSReports.init();
		}
	});

})(jQuery);
