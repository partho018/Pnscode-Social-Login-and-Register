<?php
/**
 * Reports Module
 *
 * Main module class for the Reports & Analytics system.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports;

use TS_LMS\Modules\Reports\Admin\ReportsPage;
use TS_LMS\Modules\Reports\Cache\CacheManager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Module class.
 */
class Module {

	/**
	 * Module instance.
	 *
	 * @var Module
	 */
	private static $instance = null;

	/**
	 * Get module instance.
	 *
	 * @return Module
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	private function init_hooks() {
		// Register autoloader
		Autoloader::register();

		// Initialize admin pages
		if ( is_admin() ) {
			// add_action( 'admin_menu', array( $this, 'register_admin_menu' ), 11 );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		}

		// Initialize AJAX handlers
		add_action( 'wp_ajax_ts_lms_generate_report', array( $this, 'ajax_generate_report' ) );
		add_action( 'wp_ajax_ts_lms_export_report', array( $this, 'ajax_export_report' ) );
		add_action( 'wp_ajax_ts_lms_download_export', array( $this, 'ajax_download_export' ) );

		// Cache invalidation hooks
		add_action( 'woocommerce_order_status_completed', array( $this, 'invalidate_sales_cache' ) );
		add_action( 'ts_lms_course_enrolled', array( $this, 'invalidate_progress_cache' ) );
		add_action( 'ts_lms_lesson_completed', array( $this, 'invalidate_progress_cache' ) );
		add_action( 'ts_lms_quiz_graded', array( $this, 'invalidate_quiz_cache' ) );

		// Cleanup scheduled task
		add_action( 'ts_lms_cleanup_exports', array( $this, 'cleanup_old_exports' ) );
	}

	/**
	 * Install module (create database tables).
	 *
	 * @return void
	 */
	public static function install() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$table_prefix = $wpdb->prefix;

		// Read schema file
		$schema_file = __DIR__ . '/database/schema.sql';
		if ( ! file_exists( $schema_file ) ) {
			return;
		}

		$schema = file_get_contents( $schema_file );
		$schema = str_replace( '{prefix}', $table_prefix, $schema );

		// Execute queries using dbDelta
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $schema );

		// Schedule cleanup task
		if ( ! wp_next_scheduled( 'ts_lms_cleanup_exports' ) ) {
			wp_schedule_event( time(), 'daily', 'ts_lms_cleanup_exports' );
		}
	}

	/**
	 * Register admin menu.
	 *
	 * @return void
	 */
	public function register_admin_menu() {
		add_submenu_page(
			'ts-lms',
			__( 'Reports & Analytics', 'ts-lms' ),
			__( 'Reports', 'ts-lms' ),
			'manage_options',
			'ts-lms-reports',
			array( ReportsPage::class, 'render' )
		);
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_admin_assets( $hook ) {
		// Only load on reports page
		if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'ts-lms-reports' ) {
			return;
		}

		// Enqueue CSS
		wp_enqueue_style(
			'ts-lms-reports',
			plugin_dir_url( __FILE__ ) . 'assets/css/admin-reports.css',
			array(),
			time()
		);

		// Enqueue JS
		wp_enqueue_script(
			'ts-lms-reports',
			plugin_dir_url( __FILE__ ) . 'assets/js/admin-reports.js',
			array( 'jquery' ),
			time(),
			true
		);

		// Localize script
		wp_localize_script(
			'ts-lms-reports',
			'tsLmsReports',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'ts_lms_reports' ),
				'i18n'    => array(
					'loading'      => __( 'Loading report...', 'ts-lms' ),
					'error'        => __( 'Error loading report. Please try again.', 'ts-lms' ),
					'noData'       => __( 'No data available for the selected filters.', 'ts-lms' ),
					'exporting'    => __( 'Generating export...', 'ts-lms' ),
					'exportError'  => __( 'Error generating export. Please try again.', 'ts-lms' ),
					'exportReady'  => __( 'Export ready! Downloading...', 'ts-lms' ),
				),
			)
		);
	}

	/**
	 * AJAX handler for generating reports.
	 *
	 * @return void
	 */
	public function ajax_generate_report() {
		check_ajax_referer( 'ts_lms_reports', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
		}

		$report_type = sanitize_text_field( $_POST['report_type'] ?? '' );
		$filters = isset( $_POST['filters'] ) ? $this->sanitize_filters( $_POST['filters'] ) : array();

		try {
			$report = $this->generate_report( $report_type, $filters );
			wp_send_json_success( $report );
		} catch ( \Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	/**
	 * AJAX handler for exporting reports.
	 *
	 * @return void
	 */
	public function ajax_export_report() {
		check_ajax_referer( 'ts_lms_reports', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
		}

		$report_type = sanitize_text_field( $_POST['report_type'] ?? '' );
		$format = sanitize_text_field( $_POST['format'] ?? 'csv' );
		$filters = isset( $_POST['filters'] ) ? $this->sanitize_filters( $_POST['filters'] ) : array();

		try {
			$export_manager = new \TS_LMS\Modules\Reports\Export\ExportManager();
			$export_id = $export_manager->create_export( $report_type, $format, $filters );

			wp_send_json_success( array(
				'export_id'    => $export_id,
				'download_url' => $export_manager->get_download_url( $export_id ),
			) );
		} catch ( \Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	/**
	 * AJAX handler for downloading exports.
	 *
	 * @return void
	 */
	public function ajax_download_export() {
		check_ajax_referer( 'ts_lms_reports', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'Permission denied.', 'ts-lms' ) );
		}

		$export_id = intval( $_GET['export_id'] ?? 0 );

		try {
			$export_manager = new \TS_LMS\Modules\Reports\Export\ExportManager();
			$export_manager->download_export( $export_id );
		} catch ( \Exception $e ) {
			wp_die( esc_html( $e->getMessage() ) );
		}
	}

	/**
	 * Generate a report.
	 *
	 * @param string $report_type Report type.
	 * @param array  $filters     Filters.
	 * @return array Report data.
	 * @throws \Exception If report type is invalid.
	 */
	private function generate_report( $report_type, $filters ) {
		$generator_map = array(
			'sales'               => 'TS_LMS\\Modules\\Reports\\Generators\\CourseSalesReport',
			'students'            => 'TS_LMS\\Modules\\Reports\\Generators\\StudentProgressReport',
			'courses'             => 'TS_LMS\\Modules\\Reports\\Generators\\CourseSalesReport',
			'reviews'             => 'TS_LMS\\Modules\\Reports\\Generators\\StudentProgressReport',
			'course_sales'        => 'TS_LMS\\Modules\\Reports\\Generators\\CourseSalesReport',
			'student_progress'    => 'TS_LMS\\Modules\\Reports\\Generators\\StudentProgressReport',
			'instructor_earnings' => 'TS_LMS\\Modules\\Reports\\Generators\\InstructorEarningsReport',
			'quiz_performance'    => 'TS_LMS\\Modules\\Reports\\Generators\\QuizPerformanceReport',
		);

		if ( ! isset( $generator_map[ $report_type ] ) ) {
			throw new \Exception( __( 'Invalid report type.', 'ts-lms' ) );
		}

		$generator_class = $generator_map[ $report_type ];
		$generator = new $generator_class();

		return $generator->generate( $filters );
	}

	/**
	 * Sanitize filters.
	 *
	 * @param array $filters Raw filters.
	 * @return array Sanitized filters.
	 */
	private function sanitize_filters( $filters ) {
		$sanitized = array();

		if ( isset( $filters['date_from'] ) ) {
			$sanitized['date_from'] = sanitize_text_field( $filters['date_from'] );
		}

		if ( isset( $filters['date_to'] ) ) {
			$sanitized['date_to'] = sanitize_text_field( $filters['date_to'] );
		}

		if ( isset( $filters['course_id'] ) ) {
			$sanitized['course_id'] = array_map( 'intval', (array) $filters['course_id'] );
		}

		if ( isset( $filters['instructor_id'] ) ) {
			$sanitized['instructor_id'] = array_map( 'intval', (array) $filters['instructor_id'] );
		}

		if ( isset( $filters['status'] ) ) {
			$sanitized['status'] = sanitize_text_field( $filters['status'] );
		}

		return $sanitized;
	}

	/**
	 * Invalidate sales report cache.
	 *
	 * @return void
	 */
	public function invalidate_sales_cache() {
		CacheManager::invalidate_by_type( 'course_sales' );
		CacheManager::invalidate_by_type( 'instructor_earnings' );
	}

	/**
	 * Invalidate progress report cache.
	 *
	 * @return void
	 */
	public function invalidate_progress_cache() {
		CacheManager::invalidate_by_type( 'student_progress' );
	}

	/**
	 * Invalidate quiz report cache.
	 *
	 * @return void
	 */
	public function invalidate_quiz_cache() {
		CacheManager::invalidate_by_type( 'quiz_performance' );
	}

	/**
	 * Cleanup old export files.
	 *
	 * @return void
	 */
	public function cleanup_old_exports() {
		$export_manager = new \TS_LMS\Modules\Reports\Export\ExportManager();
		$export_manager->cleanup_expired_exports();
	}
}
