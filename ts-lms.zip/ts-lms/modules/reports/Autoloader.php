<?php
/**
 * Autoloader for Reports Module
 *
 * PSR-4 compliant autoloader for the TS_LMS\Modules\Reports namespace.
 *
 * @package TS_LMS\Modules\Reports
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Reports;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Autoloader class.
 */
class Autoloader {

	/**
	 * Register the autoloader.
	 *
	 * @return void
	 */
	public static function register() {
		spl_autoload_register( array( __CLASS__, 'autoload' ) );
	}

	/**
	 * Autoload classes.
	 *
	 * @param string $class Class name.
	 * @return void
	 */
	public static function autoload( $class ) {
		// Check if the class is in our namespace
		$prefix = 'TS_LMS\\Modules\\Reports\\';
		$len = strlen( $prefix );

		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		// Get the relative class name
		$relative_class = substr( $class, $len );

		// Replace namespace separators with directory separators
		$file = __DIR__ . '/includes/' . str_replace( '\\', '/', $relative_class ) . '.php';

		// If the file exists, require it
		if ( file_exists( $file ) ) {
			require $file;
		}
	}
}
