-- TS LMS Reports & Analytics Database Schema
-- This file defines custom tables for the Reports module

-- Table: Report Cache
CREATE TABLE {prefix}ts_report_cache (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  cache_key varchar(255) NOT NULL,
  report_type varchar(50) NOT NULL,
  filters text DEFAULT NULL COMMENT 'JSON encoded filters',
  data longtext NOT NULL COMMENT 'JSON encoded report data',
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at datetime NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY cache_key (cache_key),
  KEY report_type (report_type),
  KEY expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: Report Exports
CREATE TABLE {prefix}ts_report_exports (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  user_id bigint(20) unsigned NOT NULL,
  report_type varchar(50) NOT NULL,
  file_name varchar(255) NOT NULL,
  file_path varchar(500) NOT NULL,
  file_size bigint(20) unsigned DEFAULT NULL,
  format varchar(20) NOT NULL DEFAULT 'csv',
  download_count int(11) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at datetime NOT NULL,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  KEY report_type (report_type),
  KEY expires_at (expires_at),
  KEY created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add optimized indexes for reporting queries on existing tables
-- Note: These are ALTER TABLE statements to add indexes to existing tables

-- Optimize course enrollments for reporting
-- ALTER TABLE `{prefix}ts_course_enrollments` ADD INDEX `idx_reporting` (`course_id`, `status`, `enrolled_at`);
-- ALTER TABLE `{prefix}ts_course_enrollments` ADD INDEX `idx_completion` (`status`, `completed_at`);

-- Optimize quiz attempts for reporting
-- ALTER TABLE `{prefix}ts_quiz_attempts` ADD INDEX `idx_reporting` (`quiz_id`, `user_id`, `completed_at`);
-- ALTER TABLE `{prefix}ts_quiz_attempts` ADD INDEX `idx_course_reporting` (`course_id`, `status`, `completed_at`);

-- Optimize lesson progress for reporting
-- ALTER TABLE `{prefix}ts_lesson_progress` ADD INDEX `idx_reporting` (`course_id`, `status`, `completed_at`);
-- ALTER TABLE `{prefix}ts_lesson_progress` ADD INDEX `idx_user_progress` (`user_id`, `status`, `last_accessed`);

-- Optimize quiz grades for reporting
-- ALTER TABLE `{prefix}ts_quiz_grades` ADD INDEX `idx_reporting` (`course_id`, `passed`, `graded_at`);
-- ALTER TABLE `{prefix}ts_quiz_grades` ADD INDEX `idx_user_grades` (`user_id`, `quiz_id`, `graded_at`);
