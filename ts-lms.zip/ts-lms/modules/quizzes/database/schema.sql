-- TS LMS Quiz Engine Database Schema
-- This file defines custom tables for the Quiz Engine module

-- Table: Quiz Questions (Quiz-Question Relationship)
CREATE TABLE {prefix}ts_quiz_questions (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  quiz_id bigint(20) unsigned NOT NULL,
  question_id bigint(20) unsigned NOT NULL,
  order_index int(11) NOT NULL DEFAULT 0,
  points decimal(10,2) NOT NULL DEFAULT 1.00,
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY quiz_id (quiz_id),
  KEY question_id (question_id),
  KEY order_index (order_index),
  UNIQUE KEY quiz_question (quiz_id, question_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: Quiz Attempts
CREATE TABLE {prefix}ts_quiz_attempts (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  quiz_id bigint(20) unsigned NOT NULL,
  user_id bigint(20) unsigned NOT NULL,
  course_id bigint(20) unsigned DEFAULT NULL,
  started_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at datetime DEFAULT NULL,
  status varchar(50) NOT NULL DEFAULT 'in_progress',
  score decimal(10,2) DEFAULT NULL,
  max_score decimal(10,2) DEFAULT NULL,
  percentage decimal(5,2) DEFAULT NULL,
  passed tinyint(1) DEFAULT NULL,
  time_spent int(11) DEFAULT NULL COMMENT 'Time in seconds',
  ip_address varchar(45) DEFAULT NULL,
  PRIMARY KEY (id),
  KEY quiz_id (quiz_id),
  KEY user_id (user_id),
  KEY course_id (course_id),
  KEY status (status),
  KEY completed_at (completed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: Quiz Responses (Individual Question Answers)
CREATE TABLE {prefix}ts_quiz_responses (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  attempt_id bigint(20) unsigned NOT NULL,
  question_id bigint(20) unsigned NOT NULL,
  response_text text DEFAULT NULL,
  is_correct tinyint(1) DEFAULT NULL,
  points_earned decimal(10,2) DEFAULT NULL,
  points_available decimal(10,2) NOT NULL DEFAULT 1.00,
  graded_by bigint(20) unsigned DEFAULT NULL,
  graded_at datetime DEFAULT NULL,
  feedback text DEFAULT NULL,
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY attempt_id (attempt_id),
  KEY question_id (question_id),
  KEY is_correct (is_correct),
  KEY graded_by (graded_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: Quiz Grades (Gradebook Entries)
CREATE TABLE {prefix}ts_quiz_grades (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  user_id bigint(20) unsigned NOT NULL,
  course_id bigint(20) unsigned DEFAULT NULL,
  quiz_id bigint(20) unsigned NOT NULL,
  attempt_id bigint(20) unsigned NOT NULL,
  grade decimal(10,2) NOT NULL,
  max_grade decimal(10,2) NOT NULL,
  percentage decimal(5,2) NOT NULL,
  status varchar(50) NOT NULL DEFAULT 'graded',
  passed tinyint(1) NOT NULL DEFAULT 0,
  graded_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY user_id (user_id),
  KEY course_id (course_id),
  KEY quiz_id (quiz_id),
  KEY attempt_id (attempt_id),
  KEY status (status),
  KEY passed (passed),
  UNIQUE KEY attempt_grade (attempt_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
