<?php
/**
 * Quiz Engine Module
 *
 * Main module class that bootstraps the Quiz Engine.
 *
 * @package TS_LMS\Modules\Quizzes
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Quizzes;

use TS_LMS\Modules\Quizzes\Database\Installer;
use TS_LMS\Modules\Quizzes\PostTypes\Question;
use TS_LMS\Modules\Quizzes\PostTypes\QuizEnhancement;
use TS_LMS\Modules\Quizzes\API\QuizzesController;
use TS_LMS\Modules\Quizzes\API\GradebookController;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Module class.
 */
class Module {

    /**
     * Module version.
     *
     * @var string
     */
    const VERSION = '1.0.0';

    /**
     * Singleton instance.
     *
     * @var Module
     */
    private static $instance = null;

    /**
     * Get singleton instance.
     *
     * @return Module
     */
    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->init();
    }

    /**
     * Initialize the module.
     *
     * @return void
     */
    private function init() {
        // Initialize post types
        Question::init();
        QuizEnhancement::init();

        // Register REST API routes
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

        // Add admin notices
        add_action( 'admin_notices', array( $this, 'admin_notices' ) );

        // Add admin menu
        // add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 13 );
    }

    /**
     * Register REST API routes.
     *
     * @return void
     */
    public function register_rest_routes() {
        $quizzes_controller = new QuizzesController();
        $quizzes_controller->register_routes();

        $gradebook_controller = new GradebookController();
        $gradebook_controller->register_routes();
    }

    /**
     * Install the module.
     *
     * @return void
     */
    public static function install() {
        // Install database tables
        Installer::install();

        // Flush rewrite rules
        flush_rewrite_rules();

        error_log( 'TS LMS Quiz Engine: Module installed successfully.' );
    }

    /**
     * Uninstall the module.
     *
     * @return void
     */
    public static function uninstall() {
        // Optionally remove database tables
        // Installer::uninstall();

        // Flush rewrite rules
        flush_rewrite_rules();

        error_log( 'TS LMS Quiz Engine: Module uninstalled.' );
    }

    /**
     * Display admin notices.
     *
     * @return void
     */
    public function admin_notices() {
        // Check if database tables exist
        if ( ! Installer::tables_exist() ) {
            // Attempt to install automatically if missing
            Installer::install();
            
            // Re-check after attempt
            if ( ! Installer::tables_exist() ) {
                ?>
                <div class="notice notice-warning">
                    <p>
                        <strong><?php esc_html_e( 'TS LMS Quiz Engine:', 'ts-lms' ); ?></strong>
                        <?php esc_html_e( 'Database tables are still missing. Please ensure your database user has CREATE TABLE permissions.', 'ts-lms' ); ?>
                    </p>
                </div>
                <?php
            } else {
                ?>
                <div class="notice notice-success is-dismissible">
                    <p>
                        <strong><?php esc_html_e( 'TS LMS Quiz Engine:', 'ts-lms' ); ?></strong>
                        <?php esc_html_e( 'Database tables were missing but have been automatically created.', 'ts-lms' ); ?>
                    </p>
                </div>
                <?php
            }
        }
    }

    /**
     * Add admin menu items.
     *
     * @return void
     */
    public function add_admin_menu() {
        // Add Gradebook as a submenu
        add_submenu_page(
            'ts-lms',
            __( 'Gradebook', 'ts-lms' ),
            __( 'Gradebook', 'ts-lms' ),
            'edit_ts_courses',
            'ts-lms-gradebook',
            array( $this, 'render_gradebook_page' )
        );
    }

    /**
     * Render gradebook page.
     *
     * @return void
     */
    public function render_gradebook_page() {
        $current_user = wp_get_current_user();
        $is_admin = current_user_can( 'manage_options' );
        $is_instructor = current_user_can( 'edit_ts_courses' );

        ?>
        <div class="wrap">
            <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

            <div class="ts-lms-gradebook">
                <p>
                    <?php esc_html_e( 'Use the REST API endpoints to access gradebook data:', 'ts-lms' ); ?>
                </p>

                <h2><?php esc_html_e( 'Available Endpoints', 'ts-lms' ); ?></h2>

                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Endpoint', 'ts-lms' ); ?></th>
                            <th><?php esc_html_e( 'Description', 'ts-lms' ); ?></th>
                            <th><?php esc_html_e( 'Access', 'ts-lms' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>GET /wp-json/ts-lms/v1/gradebook/student/{user_id}</code></td>
                            <td><?php esc_html_e( 'Get student grades', 'ts-lms' ); ?></td>
                            <td><?php esc_html_e( 'Student, Instructor, Admin', 'ts-lms' ); ?></td>
                        </tr>
                        <tr>
                            <td><code>GET /wp-json/ts-lms/v1/gradebook/course/{course_id}</code></td>
                            <td><?php esc_html_e( 'Get course gradebook', 'ts-lms' ); ?></td>
                            <td><?php esc_html_e( 'Instructor, Admin', 'ts-lms' ); ?></td>
                        </tr>
                        <?php if ( $is_instructor || $is_admin ) : ?>
                        <tr>
                            <td><code>GET /wp-json/ts-lms/v1/gradebook/instructor</code></td>
                            <td><?php esc_html_e( 'Get instructor gradebook', 'ts-lms' ); ?></td>
                            <td><?php esc_html_e( 'Instructor, Admin', 'ts-lms' ); ?></td>
                        </tr>
                        <tr>
                            <td><code>GET /wp-json/ts-lms/v1/gradebook/pending-reviews</code></td>
                            <td><?php esc_html_e( 'Get pending reviews', 'ts-lms' ); ?></td>
                            <td><?php esc_html_e( 'Instructor, Admin', 'ts-lms' ); ?></td>
                        </tr>
                        <tr>
                            <td><code>POST /wp-json/ts-lms/v1/gradebook/grade-response</code></td>
                            <td><?php esc_html_e( 'Grade a response manually', 'ts-lms' ); ?></td>
                            <td><?php esc_html_e( 'Instructor, Admin', 'ts-lms' ); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if ( $is_admin ) : ?>
                        <tr>
                            <td><code>GET /wp-json/ts-lms/v1/gradebook/admin</code></td>
                            <td><?php esc_html_e( 'Get admin gradebook with filters', 'ts-lms' ); ?></td>
                            <td><?php esc_html_e( 'Admin', 'ts-lms' ); ?></td>
                        </tr>
                        <tr>
                            <td><code>GET /wp-json/ts-lms/v1/gradebook/export</code></td>
                            <td><?php esc_html_e( 'Export gradebook to CSV', 'ts-lms' ); ?></td>
                            <td><?php esc_html_e( 'Admin', 'ts-lms' ); ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <h2><?php esc_html_e( 'Quiz Endpoints', 'ts-lms' ); ?></h2>

                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Endpoint', 'ts-lms' ); ?></th>
                            <th><?php esc_html_e( 'Description', 'ts-lms' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>GET /wp-json/ts-lms/v1/quizzes</code></td>
                            <td><?php esc_html_e( 'List all quizzes', 'ts-lms' ); ?></td>
                        </tr>
                        <tr>
                            <td><code>GET /wp-json/ts-lms/v1/quizzes/{id}</code></td>
                            <td><?php esc_html_e( 'Get quiz details', 'ts-lms' ); ?></td>
                        </tr>
                        <tr>
                            <td><code>POST /wp-json/ts-lms/v1/quizzes/{id}/start</code></td>
                            <td><?php esc_html_e( 'Start quiz attempt', 'ts-lms' ); ?></td>
                        </tr>
                        <tr>
                            <td><code>POST /wp-json/ts-lms/v1/quizzes/{id}/submit</code></td>
                            <td><?php esc_html_e( 'Submit quiz attempt', 'ts-lms' ); ?></td>
                        </tr>
                        <tr>
                            <td><code>GET /wp-json/ts-lms/v1/quizzes/{id}/attempts</code></td>
                            <td><?php esc_html_e( 'Get user attempts', 'ts-lms' ); ?></td>
                        </tr>
                        <tr>
                            <td><code>POST /wp-json/ts-lms/v1/quizzes/{id}/questions</code></td>
                            <td><?php esc_html_e( 'Add question to quiz', 'ts-lms' ); ?></td>
                        </tr>
                    </tbody>
                </table>

                <p class="description">
                    <?php esc_html_e( 'Note: A dedicated gradebook UI will be added in a future update. For now, use the REST API endpoints or build a custom interface.', 'ts-lms' ); ?>
                </p>
            </div>
        </div>
        <?php
    }

    /**
     * Get module version.
     *
     * @return string Module version.
     */
    public static function get_version() {
        return self::VERSION;
    }

    /**
     * Get module info.
     *
     * @return array Module information.
     */
    public static function get_info() {
        return array(
            'name'        => 'Quiz Engine',
            'version'     => self::VERSION,
            'description' => 'Quiz and gradebook management module',
            'author'      => 'Raju',
            'status'      => Installer::tables_exist() ? 'active' : 'incomplete',
        );
    }
}
