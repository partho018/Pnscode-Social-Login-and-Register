<?php
/**
 * Quiz Engine Module Tests
 *
 * Basic tests to verify quiz engine functionality.
 *
 * @package TS_LMS\Modules\Quizzes\Tests
 * @since 1.0.0
 */

// Load WordPress
require_once dirname( dirname( dirname( dirname( __DIR__ ) ) ) ) . '/wp-load.php';

// Load Quiz module
require_once dirname( __DIR__ ) . '/Autoloader.php';
require_once dirname( __DIR__ ) . '/Module.php';

use TS_LMS\Modules\Quizzes\Database\Installer;
use TS_LMS\Modules\Quizzes\Managers\QuizManager;
use TS_LMS\Modules\Quizzes\Managers\AttemptManager;
use TS_LMS\Modules\Quizzes\Managers\GradeCalculator;
use TS_LMS\Modules\Quizzes\Managers\GradebookManager;

echo "=== TS LMS Quiz Engine Tests ===\n\n";

// Test 1: Database Installation
echo "Test 1: Database Installation\n";
echo "------------------------------\n";

$tables_exist = Installer::tables_exist();
echo "Tables exist: " . ( $tables_exist ? "YES ✓" : "NO ✗" ) . "\n";

if ( $tables_exist ) {
    global $wpdb;
    
    $tables = array(
        'ts_quiz_questions',
        'ts_quiz_attempts',
        'ts_quiz_responses',
        'ts_quiz_grades',
    );
    
    foreach ( $tables as $table ) {
        $table_name = $wpdb->prefix . $table;
        $count = $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );
        echo "  - {$table}: {$count} rows\n";
    }
}

echo "\n";

// Test 2: Module Info
echo "Test 2: Module Info\n";
echo "-------------------\n";

$info = \TS_LMS\Modules\Quizzes\Module::get_info();
echo "Name: {$info['name']}\n";
echo "Version: {$info['version']}\n";
echo "Status: {$info['status']}\n";
echo "Description: {$info['description']}\n";

echo "\n";

// Test 3: Create Test Quiz
echo "Test 3: Create Test Quiz\n";
echo "------------------------\n";

$quiz_id = wp_insert_post( array(
    'post_type'   => 'ts_quiz',
    'post_title'  => 'Test Quiz - ' . date( 'Y-m-d H:i:s' ),
    'post_content' => 'This is a test quiz created by the verification script.',
    'post_status' => 'publish',
) );

if ( $quiz_id ) {
    echo "Quiz created: ID {$quiz_id} ✓\n";
    
    // Set quiz settings
    update_post_meta( $quiz_id, '_timer_minutes', 10 );
    update_post_meta( $quiz_id, '_attempt_limit', 3 );
    update_post_meta( $quiz_id, '_pass_percentage', 70 );
    update_post_meta( $quiz_id, '_is_public', 1 );
    
    echo "Quiz settings saved ✓\n";
} else {
    echo "Failed to create quiz ✗\n";
}

echo "\n";

// Test 4: Create Test Questions
echo "Test 4: Create Test Questions\n";
echo "-----------------------------\n";

// MCQ Question
$mcq_id = wp_insert_post( array(
    'post_type'   => 'ts_question',
    'post_title'  => 'What is 2 + 2?',
    'post_content' => 'Select the correct answer.',
    'post_status' => 'publish',
) );

if ( $mcq_id ) {
    update_post_meta( $mcq_id, '_question_type', 'mcq' );
    update_post_meta( $mcq_id, '_options', array( '2', '3', '4', '5' ) );
    update_post_meta( $mcq_id, '_correct_answer', '4' );
    update_post_meta( $mcq_id, '_points', 1 );
    echo "MCQ Question created: ID {$mcq_id} ✓\n";
}

// True/False Question
$tf_id = wp_insert_post( array(
    'post_type'   => 'ts_question',
    'post_title'  => 'WordPress is a CMS',
    'post_content' => 'True or False?',
    'post_status' => 'publish',
) );

if ( $tf_id ) {
    update_post_meta( $tf_id, '_question_type', 'true_false' );
    update_post_meta( $tf_id, '_correct_answer', 'true' );
    update_post_meta( $tf_id, '_points', 1 );
    echo "True/False Question created: ID {$tf_id} ✓\n";
}

// Short Answer Question
$sa_id = wp_insert_post( array(
    'post_type'   => 'ts_question',
    'post_title'  => 'Explain MVC pattern',
    'post_content' => 'Briefly explain the MVC design pattern.',
    'post_status' => 'publish',
) );

if ( $sa_id ) {
    update_post_meta( $sa_id, '_question_type', 'short_answer' );
    update_post_meta( $sa_id, '_points', 2 );
    echo "Short Answer Question created: ID {$sa_id} ✓\n";
}

echo "\n";

// Test 5: Add Questions to Quiz
echo "Test 5: Add Questions to Quiz\n";
echo "-----------------------------\n";

if ( $quiz_id && $mcq_id && $tf_id && $sa_id ) {
    $result1 = QuizManager::add_question_to_quiz( $quiz_id, $mcq_id, 1, 1 );
    $result2 = QuizManager::add_question_to_quiz( $quiz_id, $tf_id, 1, 2 );
    $result3 = QuizManager::add_question_to_quiz( $quiz_id, $sa_id, 2, 3 );
    
    echo "Questions added to quiz:\n";
    echo "  - MCQ: " . ( $result1 ? "✓" : "✗" ) . "\n";
    echo "  - True/False: " . ( $result2 ? "✓" : "✗" ) . "\n";
    echo "  - Short Answer: " . ( $result3 ? "✓" : "✗" ) . "\n";
    
    $questions = QuizManager::get_quiz_questions( $quiz_id );
    echo "Total questions in quiz: " . count( $questions ) . "\n";
}

echo "\n";

// Test 6: Quiz Settings
echo "Test 6: Quiz Settings\n";
echo "--------------------\n";

if ( $quiz_id ) {
    $settings = QuizManager::get_quiz_settings( $quiz_id );
    echo "Timer: {$settings['timer_minutes']} minutes\n";
    echo "Attempt Limit: {$settings['attempt_limit']}\n";
    echo "Pass Percentage: {$settings['pass_percentage']}%\n";
    echo "Is Public: " . ( $settings['is_public'] ? 'Yes' : 'No' ) . "\n";
}

echo "\n";

// Test 7: REST API Endpoints
echo "Test 7: REST API Endpoints\n";
echo "--------------------------\n";

$endpoints = array(
    'GET /wp-json/ts-lms/v1/quizzes',
    'GET /wp-json/ts-lms/v1/quizzes/{id}',
    'POST /wp-json/ts-lms/v1/quizzes/{id}/start',
    'POST /wp-json/ts-lms/v1/quizzes/{id}/submit',
    'GET /wp-json/ts-lms/v1/quizzes/{id}/attempts',
    'GET /wp-json/ts-lms/v1/gradebook/student/{user_id}',
    'GET /wp-json/ts-lms/v1/gradebook/course/{course_id}',
    'GET /wp-json/ts-lms/v1/gradebook/instructor',
    'GET /wp-json/ts-lms/v1/gradebook/admin',
);

echo "Available REST API endpoints:\n";
foreach ( $endpoints as $endpoint ) {
    echo "  ✓ {$endpoint}\n";
}

echo "\n";

// Test Summary
echo "=== Test Summary ===\n";
echo "Database: " . ( $tables_exist ? "✓ PASS" : "✗ FAIL" ) . "\n";
echo "Quiz Creation: " . ( $quiz_id ? "✓ PASS" : "✗ FAIL" ) . "\n";
echo "Question Creation: " . ( $mcq_id && $tf_id && $sa_id ? "✓ PASS" : "✗ FAIL" ) . "\n";
echo "\n";

if ( $quiz_id ) {
    echo "Test Quiz ID: {$quiz_id}\n";
    echo "View Quiz: " . get_permalink( $quiz_id ) . "\n";
    echo "Edit Quiz: " . get_edit_post_link( $quiz_id, 'raw' ) . "\n";
}

echo "\n=== Tests Complete ===\n";
