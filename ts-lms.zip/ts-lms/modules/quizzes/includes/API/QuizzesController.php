<?php
/**
 * Quizzes REST API Controller
 *
 * Handles quiz-related REST API endpoints.
 *
 * @package TS_LMS\Modules\Quizzes\API
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Quizzes\API;

use TS_LMS\Modules\Quizzes\Managers\QuizManager;
use TS_LMS\Modules\Quizzes\Managers\AttemptManager;
use WP_REST_Controller;
use WP_REST_Server;
use WP_Error;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * QuizzesController class.
 */
class QuizzesController extends WP_REST_Controller {

    /**
     * Namespace.
     *
     * @var string
     */
    protected $namespace = 'ts-lms/v1';

    /**
     * Rest base.
     *
     * @var string
     */
    protected $rest_base = 'quizzes';

    /**
     * Register routes.
     *
     * @return void
     */
    public function register_routes() {
        // List quizzes
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base,
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_items' ),
                    'permission_callback' => array( $this, 'get_items_permissions_check' ),
                    'args'                => $this->get_collection_params(),
                ),
            )
        );

        // Get single quiz
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_item' ),
                    'permission_callback' => array( $this, 'get_item_permissions_check' ),
                    'args'                => array(
                        'id' => array(
                            'description' => __( 'Quiz ID', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                    ),
                ),
            )
        );

        // Start quiz attempt
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)/start',
            array(
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array( $this, 'start_attempt' ),
                    'permission_callback' => array( $this, 'create_item_permissions_check' ),
                    'args'                => array(
                        'id' => array(
                            'description' => __( 'Quiz ID', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                    ),
                ),
            )
        );

        // Submit quiz attempt
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)/submit',
            array(
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array( $this, 'submit_attempt' ),
                    'permission_callback' => array( $this, 'create_item_permissions_check' ),
                    'args'                => array(
                        'id' => array(
                            'description' => __( 'Quiz ID', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                        'attempt_id' => array(
                            'description' => __( 'Attempt ID', 'ts-lms' ),
                            'type'        => 'integer',
                            'required'    => true,
                        ),
                        'responses' => array(
                            'description' => __( 'Quiz responses', 'ts-lms' ),
                            'type'        => 'array',
                            'required'    => true,
                        ),
                    ),
                ),
            )
        );

        // Get user attempts
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)/attempts',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_attempts' ),
                    'permission_callback' => array( $this, 'get_items_permissions_check' ),
                    'args'                => array(
                        'id' => array(
                            'description' => __( 'Quiz ID', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                    ),
                ),
            )
        );

        // Add question to quiz
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)/questions',
            array(
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array( $this, 'add_question' ),
                    'permission_callback' => array( $this, 'update_item_permissions_check' ),
                    'args'                => array(
                        'id' => array(
                            'description' => __( 'Quiz ID', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                        'question_id' => array(
                            'description' => __( 'Question ID', 'ts-lms' ),
                            'type'        => 'integer',
                            'required'    => true,
                        ),
                        'points' => array(
                            'description' => __( 'Points for this question', 'ts-lms' ),
                            'type'        => 'number',
                            'default'     => 1,
                        ),
                        'order_index' => array(
                            'description' => __( 'Order index', 'ts-lms' ),
                            'type'        => 'integer',
                            'default'     => 0,
                        ),
                    ),
                ),
            )
        );
    }

    /**
     * Get quizzes.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response Response object.
     */
    public function get_items( $request ) {
        $args = array(
            'post_type'      => 'ts_quiz',
            'post_status'    => 'publish',
            'posts_per_page' => $request->get_param( 'per_page' ) ?: 10,
            'paged'          => $request->get_param( 'page' ) ?: 1,
        );

        if ( $request->get_param( 'course_id' ) ) {
            $args['meta_query'] = array(
                array(
                    'key'   => '_course_id',
                    'value' => $request->get_param( 'course_id' ),
                ),
            );
        }

        $query = new \WP_Query( $args );
        $quizzes = array();

        foreach ( $query->posts as $post ) {
            $quizzes[] = $this->prepare_item_for_response( $post, $request );
        }

        return rest_ensure_response( $quizzes );
    }

    /**
     * Get single quiz.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response|\WP_Error Response object or error.
     */
    public function get_item( $request ) {
        $quiz_id = $request->get_param( 'id' );
        $quiz = get_post( $quiz_id );

        if ( ! $quiz || $quiz->post_type !== 'ts_quiz' ) {
            return new WP_Error( 'quiz_not_found', __( 'Quiz not found.', 'ts-lms' ), array( 'status' => 404 ) );
        }

        $user_id = get_current_user_id();
        
        // Check access
        if ( ! QuizManager::is_quiz_accessible( $quiz_id, $user_id ) ) {
            return new WP_Error( 'quiz_access_denied', __( 'You do not have access to this quiz.', 'ts-lms' ), array( 'status' => 403 ) );
        }

        $data = $this->prepare_item_for_response( $quiz, $request );

        // Include questions if requested
        if ( $request->get_param( 'include_questions' ) ) {
            $settings = QuizManager::get_quiz_settings( $quiz_id );
            $data['questions'] = QuizManager::get_quiz_questions( $quiz_id, false );
            
            // Remove correct answers for students
            if ( ! current_user_can( 'edit_post', $quiz_id ) ) {
                foreach ( $data['questions'] as &$question ) {
                    unset( $question['correct_answer'] );
                }
            }
        }

        return rest_ensure_response( $data );
    }

    /**
     * Start quiz attempt.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response|\WP_Error Response object or error.
     */
    public function start_attempt( $request ) {
        $quiz_id = $request->get_param( 'id' );
        $user_id = get_current_user_id();

        if ( ! $user_id ) {
            return new WP_Error( 'not_logged_in', __( 'You must be logged in to attempt quizzes.', 'ts-lms' ), array( 'status' => 401 ) );
        }

        // Check if user can attempt
        $can_attempt = QuizManager::can_user_attempt( $quiz_id, $user_id );
        
        if ( ! $can_attempt['can_attempt'] ) {
            return new WP_Error( 'cannot_attempt', $can_attempt['message'], array( 'status' => 403 ) );
        }

        // Get course ID from quiz settings
        $settings = QuizManager::get_quiz_settings( $quiz_id );
        $course_id = $settings['course_id'] ?: null;

        // Start attempt
        $attempt_id = AttemptManager::start_attempt( $quiz_id, $user_id, $course_id );

        if ( ! $attempt_id ) {
            return new WP_Error( 'attempt_failed', __( 'Failed to start quiz attempt.', 'ts-lms' ), array( 'status' => 500 ) );
        }

        // Get questions
        $questions = QuizManager::get_quiz_questions( $quiz_id, $settings['randomize_questions'] );

        // Remove correct answers
        foreach ( $questions as &$question ) {
            unset( $question['correct_answer'] );
        }

        return rest_ensure_response( array(
            'attempt_id' => $attempt_id,
            'quiz_id'    => $quiz_id,
            'questions'  => $questions,
            'settings'   => $settings,
        ) );
    }

    /**
     * Submit quiz attempt.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response|\WP_Error Response object or error.
     */
    public function submit_attempt( $request ) {
        $attempt_id = $request->get_param( 'attempt_id' );
        $responses = $request->get_param( 'responses' );
        $user_id = get_current_user_id();

        // Verify attempt belongs to user
        $attempt = AttemptManager::get_attempt( $attempt_id );
        
        if ( ! $attempt || $attempt['user_id'] != $user_id ) {
            return new WP_Error( 'invalid_attempt', __( 'Invalid attempt.', 'ts-lms' ), array( 'status' => 403 ) );
        }

        // Save responses
        foreach ( $responses as $response ) {
            AttemptManager::save_response(
                $attempt_id,
                $response['question_id'],
                $response['answer']
            );
        }

        // Submit attempt
        $success = AttemptManager::submit_attempt( $attempt_id );

        if ( ! $success ) {
            return new WP_Error( 'submit_failed', __( 'Failed to submit quiz.', 'ts-lms' ), array( 'status' => 500 ) );
        }

        // Get updated attempt with results
        $attempt = AttemptManager::get_attempt_details( $attempt_id );

        return rest_ensure_response( array(
            'success' => true,
            'attempt' => $attempt,
        ) );
    }

    /**
     * Get user attempts.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response Response object.
     */
    public function get_attempts( $request ) {
        $quiz_id = $request->get_param( 'id' );
        $user_id = get_current_user_id();

        $attempts = AttemptManager::get_user_attempts( $quiz_id, $user_id );

        return rest_ensure_response( $attempts );
    }

    /**
     * Add question to quiz.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response|\WP_Error Response object or error.
     */
    public function add_question( $request ) {
        $quiz_id = $request->get_param( 'id' );
        $question_id = $request->get_param( 'question_id' );
        $points = $request->get_param( 'points' );
        $order_index = $request->get_param( 'order_index' );

        $result = QuizManager::add_question_to_quiz( $quiz_id, $question_id, $points, $order_index );

        if ( ! $result ) {
            return new WP_Error( 'add_failed', __( 'Failed to add question to quiz.', 'ts-lms' ), array( 'status' => 500 ) );
        }

        return rest_ensure_response( array(
            'success' => true,
            'id'      => $result,
        ) );
    }

    /**
     * Prepare item for response.
     *
     * @param \WP_Post         $post    Post object.
     * @param \WP_REST_Request $request Request object.
     * @return array Item data.
     */
    public function prepare_item_for_response( $post, $request ) {
        $settings = QuizManager::get_quiz_settings( $post->ID );

        return array(
            'id'                  => $post->ID,
            'title'               => $post->post_title,
            'content'             => $post->post_content,
            'timer_minutes'       => $settings['timer_minutes'],
            'attempt_limit'       => $settings['attempt_limit'],
            'pass_percentage'     => $settings['pass_percentage'],
            'is_public'           => (bool) $settings['is_public'],
            'randomize_questions' => (bool) $settings['randomize_questions'],
            'show_correct_answers' => (bool) $settings['show_correct_answers'],
            'course_id'           => $settings['course_id'],
        );
    }

    /**
     * Check permissions for getting items.
     *
     * @param \WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function get_items_permissions_check( $request ) {
        return true; // Public endpoint
    }

    /**
     * Check permissions for getting item.
     *
     * @param \WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function get_item_permissions_check( $request ) {
        return true; // Access checked in get_item method
    }

    /**
     * Check permissions for creating item.
     *
     * @param \WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function create_item_permissions_check( $request ) {
        return is_user_logged_in();
    }

    /**
     * Check permissions for updating item.
     *
     * @param \WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function update_item_permissions_check( $request ) {
        $quiz_id = $request->get_param( 'id' );
        return current_user_can( 'edit_post', $quiz_id );
    }

    /**
     * Get collection parameters.
     *
     * @return array Collection parameters.
     */
    public function get_collection_params() {
        return array(
            'page' => array(
                'description' => __( 'Page number', 'ts-lms' ),
                'type'        => 'integer',
                'default'     => 1,
            ),
            'per_page' => array(
                'description' => __( 'Items per page', 'ts-lms' ),
                'type'        => 'integer',
                'default'     => 10,
            ),
            'course_id' => array(
                'description' => __( 'Filter by course ID', 'ts-lms' ),
                'type'        => 'integer',
            ),
        );
    }
}
