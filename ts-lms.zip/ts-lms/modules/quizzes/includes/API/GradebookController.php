<?php
/**
 * Gradebook REST API Controller
 *
 * Handles gradebook-related REST API endpoints.
 *
 * @package TS_LMS\Modules\Quizzes\API
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Quizzes\API;

use TS_LMS\Modules\Quizzes\Managers\GradebookManager;
use TS_LMS\Modules\Quizzes\Managers\GradeCalculator;
use WP_REST_Controller;
use WP_REST_Server;
use WP_Error;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * GradebookController class.
 */
class GradebookController extends WP_REST_Controller {

    /**
     * Namespace.
     *
     * @var string
     */
    protected $namespace = 'ts-lms/v1';

    /**
     * Rest base.
     *
     * @var string
     */
    protected $rest_base = 'gradebook';

    /**
     * Register routes.
     *
     * @return void
     */
    public function register_routes() {
        // Get student grades
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/student/(?P<user_id>[\d]+)',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_student_grades' ),
                    'permission_callback' => array( $this, 'student_permissions_check' ),
                    'args'                => array(
                        'user_id' => array(
                            'description' => __( 'Student user ID', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                        'course_id' => array(
                            'description' => __( 'Filter by course ID', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                    ),
                ),
            )
        );

        // Get course gradebook
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/course/(?P<course_id>[\d]+)',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_course_gradebook' ),
                    'permission_callback' => array( $this, 'course_permissions_check' ),
                    'args'                => array(
                        'course_id' => array(
                            'description' => __( 'Course ID', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                    ),
                ),
            )
        );

        // Get instructor gradebook
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/instructor',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_instructor_gradebook' ),
                    'permission_callback' => array( $this, 'instructor_permissions_check' ),
                ),
            )
        );

        // Get admin gradebook
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/admin',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_admin_gradebook' ),
                    'permission_callback' => array( $this, 'admin_permissions_check' ),
                    'args'                => $this->get_collection_params(),
                ),
            )
        );

        // Manual grading endpoint
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/grade-response',
            array(
                array(
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => array( $this, 'grade_response' ),
                    'permission_callback' => array( $this, 'instructor_permissions_check' ),
                    'args'                => array(
                        'response_id' => array(
                            'description' => __( 'Response ID', 'ts-lms' ),
                            'type'        => 'integer',
                            'required'    => true,
                        ),
                        'points' => array(
                            'description' => __( 'Points earned', 'ts-lms' ),
                            'type'        => 'number',
                            'required'    => true,
                        ),
                        'feedback' => array(
                            'description' => __( 'Feedback text', 'ts-lms' ),
                            'type'        => 'string',
                            'default'     => '',
                        ),
                    ),
                ),
            )
        );

        // Get pending reviews
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/pending-reviews',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_pending_reviews' ),
                    'permission_callback' => array( $this, 'instructor_permissions_check' ),
                ),
            )
        );

        // Export gradebook
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/export',
            array(
                array(
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'export_gradebook' ),
                    'permission_callback' => array( $this, 'admin_permissions_check' ),
                    'args'                => $this->get_collection_params(),
                ),
            )
        );
    }

    /**
     * Get student grades.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response Response object.
     */
    public function get_student_grades( $request ) {
        $user_id = $request->get_param( 'user_id' );
        $course_id = $request->get_param( 'course_id' );

        $grades = GradebookManager::get_student_grades( $user_id, $course_id );

        return rest_ensure_response( array(
            'user_id' => $user_id,
            'grades'  => $grades,
        ) );
    }

    /**
     * Get course gradebook.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response Response object.
     */
    public function get_course_gradebook( $request ) {
        $course_id = $request->get_param( 'course_id' );

        $gradebook = GradebookManager::get_course_grades( $course_id );

        return rest_ensure_response( array(
            'course_id' => $course_id,
            'students'  => $gradebook,
        ) );
    }

    /**
     * Get instructor gradebook.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response Response object.
     */
    public function get_instructor_gradebook( $request ) {
        $instructor_id = get_current_user_id();

        $gradebook = GradebookManager::get_instructor_gradebook( $instructor_id );

        return rest_ensure_response( array(
            'instructor_id' => $instructor_id,
            'courses'       => $gradebook,
        ) );
    }

    /**
     * Get admin gradebook.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response Response object.
     */
    public function get_admin_gradebook( $request ) {
        $filters = array(
            'course_id'       => $request->get_param( 'course_id' ),
            'user_id'         => $request->get_param( 'user_id' ),
            'quiz_id'         => $request->get_param( 'quiz_id' ),
            'status'          => $request->get_param( 'status' ),
            'passed'          => $request->get_param( 'passed' ),
            'order_by'        => $request->get_param( 'order_by' ),
            'order_direction' => $request->get_param( 'order_direction' ),
            'limit'           => $request->get_param( 'limit' ),
        );

        // Remove null values
        $filters = array_filter( $filters, function( $value ) {
            return $value !== null;
        } );

        $grades = GradebookManager::get_admin_gradebook( $filters );
        $stats = GradebookManager::get_gradebook_stats( $filters );

        return rest_ensure_response( array(
            'grades' => $grades,
            'stats'  => $stats,
        ) );
    }

    /**
     * Grade a response manually.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response|\WP_Error Response object or error.
     */
    public function grade_response( $request ) {
        $response_id = $request->get_param( 'response_id' );
        $points = $request->get_param( 'points' );
        $feedback = $request->get_param( 'feedback' );
        $grader_id = get_current_user_id();

        $success = GradeCalculator::manual_grade_response( $response_id, $points, $feedback, $grader_id );

        if ( ! $success ) {
            return new WP_Error( 'grading_failed', __( 'Failed to grade response.', 'ts-lms' ), array( 'status' => 500 ) );
        }

        return rest_ensure_response( array(
            'success' => true,
            'message' => __( 'Response graded successfully.', 'ts-lms' ),
        ) );
    }

    /**
     * Get pending reviews.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response Response object.
     */
    public function get_pending_reviews( $request ) {
        $instructor_id = get_current_user_id();

        // Admins can see all pending reviews
        if ( current_user_can( 'manage_options' ) ) {
            $instructor_id = null;
        }

        $pending = GradeCalculator::get_pending_reviews( $instructor_id );

        return rest_ensure_response( array(
            'pending_reviews' => $pending,
            'count'           => count( $pending ),
        ) );
    }

    /**
     * Export gradebook to CSV.
     *
     * @param \WP_REST_Request $request Request object.
     * @return \WP_REST_Response Response object.
     */
    public function export_gradebook( $request ) {
        $filters = array(
            'course_id' => $request->get_param( 'course_id' ),
            'user_id'   => $request->get_param( 'user_id' ),
            'quiz_id'   => $request->get_param( 'quiz_id' ),
            'status'    => $request->get_param( 'status' ),
            'passed'    => $request->get_param( 'passed' ),
        );

        // Remove null values
        $filters = array_filter( $filters, function( $value ) {
            return $value !== null;
        } );

        $csv = GradebookManager::export_to_csv( $filters );

        return rest_ensure_response( array(
            'csv' => $csv,
        ) );
    }

    /**
     * Check student permissions.
     *
     * @param \WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function student_permissions_check( $request ) {
        $user_id = $request->get_param( 'user_id' );
        $current_user_id = get_current_user_id();

        // User can view their own grades
        if ( $current_user_id === $user_id ) {
            return true;
        }

        // Instructors and admins can view student grades
        return current_user_can( 'manage_options' ) || current_user_can( 'edit_ts_courses' );
    }

    /**
     * Check course permissions.
     *
     * @param \WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function course_permissions_check( $request ) {
        $course_id = $request->get_param( 'course_id' );
        $user_id = get_current_user_id();

        // Admins can view all
        if ( current_user_can( 'manage_options' ) ) {
            return true;
        }

        // Check if user is instructor for this course
        global $wpdb;
        $instructors_table = $wpdb->prefix . 'ts_course_instructors';
        
        $is_instructor = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$instructors_table} WHERE course_id = %d AND instructor_id = %d",
            $course_id,
            $user_id
        ) );

        return (bool) $is_instructor;
    }

    /**
     * Check instructor permissions.
     *
     * @param \WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function instructor_permissions_check( $request ) {
        return current_user_can( 'edit_ts_courses' ) || current_user_can( 'manage_options' );
    }

    /**
     * Check admin permissions.
     *
     * @param \WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function admin_permissions_check( $request ) {
        return current_user_can( 'manage_options' );
    }

    /**
     * Get collection parameters.
     *
     * @return array Collection parameters.
     */
    public function get_collection_params() {
        return array(
            'course_id' => array(
                'description' => __( 'Filter by course ID', 'ts-lms' ),
                'type'        => 'integer',
            ),
            'user_id' => array(
                'description' => __( 'Filter by user ID', 'ts-lms' ),
                'type'        => 'integer',
            ),
            'quiz_id' => array(
                'description' => __( 'Filter by quiz ID', 'ts-lms' ),
                'type'        => 'integer',
            ),
            'status' => array(
                'description' => __( 'Filter by status', 'ts-lms' ),
                'type'        => 'string',
                'enum'        => array( 'graded', 'pending_review' ),
            ),
            'passed' => array(
                'description' => __( 'Filter by pass status', 'ts-lms' ),
                'type'        => 'string',
                'enum'        => array( 'yes', 'no' ),
            ),
            'order_by' => array(
                'description' => __( 'Order by field', 'ts-lms' ),
                'type'        => 'string',
                'enum'        => array( 'graded_at', 'percentage', 'grade', 'user_id', 'quiz_id' ),
                'default'     => 'graded_at',
            ),
            'order_direction' => array(
                'description' => __( 'Order direction', 'ts-lms' ),
                'type'        => 'string',
                'enum'        => array( 'ASC', 'DESC' ),
                'default'     => 'DESC',
            ),
            'limit' => array(
                'description' => __( 'Limit results', 'ts-lms' ),
                'type'        => 'integer',
                'default'     => 100,
            ),
        );
    }
}
