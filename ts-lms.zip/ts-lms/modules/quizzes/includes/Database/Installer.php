<?php
/**
 * Database Installer for Quiz Engine
 *
 * Handles database table creation and management.
 *
 * @package TS_LMS\Modules\Quizzes\Database
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Quizzes\Database;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Installer class.
 */
class Installer {

    /**
     * Table names.
     *
     * @var array
     */
    private static $tables = array(
        'ts_quiz_questions',
        'ts_quiz_attempts',
        'ts_quiz_responses',
        'ts_quiz_grades',
    );

    /**
     * Install database tables.
     *
     * @return void
     */
    public static function install() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();
        $schema_file = dirname( dirname( __DIR__ ) ) . '/database/schema.sql';

        if ( ! file_exists( $schema_file ) ) {
            error_log( 'TS LMS Quiz Engine: Schema file not found at ' . $schema_file );
            return;
        }

        // Read schema file
        $schema = file_get_contents( $schema_file );

        // Replace placeholder with actual prefix
        $schema = str_replace( '{prefix}', $wpdb->prefix, $schema );

        // Execute queries using dbDelta
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $schema );

        // Set installation flag
        update_option( 'ts_lms_quiz_engine_db_version', '1.0.0' );

        error_log( 'TS LMS Quiz Engine: Database tables installed successfully.' );
    }

    /**
     * Check if all tables exist.
     *
     * @return bool True if all tables exist, false otherwise.
     */
    public static function tables_exist() {
        global $wpdb;

        foreach ( self::$tables as $table ) {
            $table_name = $wpdb->prefix . $table;
            $result = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) );

            if ( $result !== $table_name ) {
                return false;
            }
        }

        return true;
    }

    /**
     * Uninstall database tables.
     *
     * @return void
     */
    public static function uninstall() {
        global $wpdb;

        foreach ( self::$tables as $table ) {
            $table_name = $wpdb->prefix . $table;
            $wpdb->query( "DROP TABLE IF EXISTS `{$table_name}`" );
        }

        delete_option( 'ts_lms_quiz_engine_db_version' );

        error_log( 'TS LMS Quiz Engine: Database tables removed.' );
    }

    /**
     * Get table name with prefix.
     *
     * @param string $table Table name without prefix.
     * @return string Full table name with prefix.
     */
    public static function get_table_name( $table ) {
        global $wpdb;
        return $wpdb->prefix . $table;
    }
}
