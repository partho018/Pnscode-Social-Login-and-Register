<?php
/**
 * Attempt Manager
 *
 * Handles quiz attempt tracking and management.
 *
 * @package TS_LMS\Modules\Quizzes\Managers
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Quizzes\Managers;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * AttemptManager class.
 */
class AttemptManager {

    /**
     * Start a new quiz attempt.
     *
     * @param int      $quiz_id   Quiz ID.
     * @param int      $user_id   User ID.
     * @param int|null $course_id Course ID (optional).
     * @return int|false Attempt ID on success, false on failure.
     */
    public static function start_attempt( $quiz_id, $user_id, $course_id = null ) {
        global $wpdb;

        // Verify user can attempt
        $can_attempt = QuizManager::can_user_attempt( $quiz_id, $user_id );
        if ( ! $can_attempt['can_attempt'] ) {
            return false;
        }

        // Get quiz settings to calculate max score
        $questions = QuizManager::get_quiz_questions( $quiz_id );
        $max_score = array_sum( array_column( $questions, 'points' ) );

        $attempts_table = $wpdb->prefix . 'ts_quiz_attempts';

        $result = $wpdb->insert(
            $attempts_table,
            array(
                'quiz_id'    => $quiz_id,
                'user_id'    => $user_id,
                'course_id'  => $course_id,
                'status'     => 'in_progress',
                'max_score'  => $max_score,
                'ip_address' => self::get_user_ip(),
            ),
            array( '%d', '%d', '%d', '%s', '%f', '%s' )
        );

        if ( $result ) {
            do_action( 'ts_lms_quiz_attempt_started', $wpdb->insert_id, $quiz_id, $user_id );
            return $wpdb->insert_id;
        }

        return false;
    }

    /**
     * Save a response to a question.
     *
     * @param int    $attempt_id   Attempt ID.
     * @param int    $question_id  Question ID.
     * @param string $response     User's response.
     * @return int|false Response ID on success, false on failure.
     */
    public static function save_response( $attempt_id, $question_id, $response ) {
        global $wpdb;

        // Verify attempt is in progress
        $attempt = self::get_attempt( $attempt_id );
        if ( ! $attempt || $attempt['status'] !== 'in_progress' ) {
            return false;
        }

        // Get question points
        $quiz_questions_table = $wpdb->prefix . 'ts_quiz_questions';
        $points_available = $wpdb->get_var( $wpdb->prepare(
            "SELECT points FROM {$quiz_questions_table} WHERE quiz_id = %d AND question_id = %d",
            $attempt['quiz_id'],
            $question_id
        ) );

        if ( $points_available === null ) {
            return false;
        }

        $responses_table = $wpdb->prefix . 'ts_quiz_responses';

        // Check if response already exists
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$responses_table} WHERE attempt_id = %d AND question_id = %d",
            $attempt_id,
            $question_id
        ) );

        if ( $existing ) {
            // Update existing response
            $wpdb->update(
                $responses_table,
                array(
                    'response_text'     => $response,
                    'is_correct'        => null,
                    'points_earned'     => null,
                    'graded_by'         => null,
                    'graded_at'         => null,
                ),
                array( 'id' => $existing ),
                array( '%s', '%d', '%f', '%d', '%s' ),
                array( '%d' )
            );
            return $existing;
        } else {
            // Insert new response
            $result = $wpdb->insert(
                $responses_table,
                array(
                    'attempt_id'        => $attempt_id,
                    'question_id'       => $question_id,
                    'response_text'     => $response,
                    'points_available'  => $points_available,
                ),
                array( '%d', '%d', '%s', '%f' )
            );

            return $result ? $wpdb->insert_id : false;
        }
    }

    /**
     * Submit quiz attempt.
     *
     * @param int $attempt_id Attempt ID.
     * @return bool True on success, false on failure.
     */
    public static function submit_attempt( $attempt_id ) {
        global $wpdb;

        // Get attempt
        $attempt = self::get_attempt( $attempt_id );
        if ( ! $attempt || $attempt['status'] !== 'in_progress' ) {
            return false;
        }

        // Calculate time spent
        $started_at = strtotime( $attempt['started_at'] );
        $time_spent = time() - $started_at;

        // Update attempt status
        $attempts_table = $wpdb->prefix . 'ts_quiz_attempts';
        
        $wpdb->update(
            $attempts_table,
            array(
                'completed_at' => current_time( 'mysql' ),
                'status'       => 'completed',
                'time_spent'   => $time_spent,
            ),
            array( 'id' => $attempt_id ),
            array( '%s', '%s', '%d' ),
            array( '%d' )
        );

        // Trigger auto-grading
        GradeCalculator::auto_grade_attempt( $attempt_id );

        do_action( 'ts_lms_quiz_attempt_submitted', $attempt_id, $attempt['quiz_id'], $attempt['user_id'] );

        return true;
    }

    /**
     * Get attempt details.
     *
     * @param int $attempt_id Attempt ID.
     * @return array|null Attempt data or null if not found.
     */
    public static function get_attempt( $attempt_id ) {
        global $wpdb;

        $attempts_table = $wpdb->prefix . 'ts_quiz_attempts';

        $attempt = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$attempts_table} WHERE id = %d",
            $attempt_id
        ), ARRAY_A );

        return $attempt;
    }

    /**
     * Get attempt with responses.
     *
     * @param int $attempt_id Attempt ID.
     * @return array|null Attempt data with responses or null if not found.
     */
    public static function get_attempt_details( $attempt_id ) {
        $attempt = self::get_attempt( $attempt_id );
        
        if ( ! $attempt ) {
            return null;
        }

        // Get responses
        global $wpdb;
        $responses_table = $wpdb->prefix . 'ts_quiz_responses';

        $responses = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$responses_table} WHERE attempt_id = %d",
            $attempt_id
        ), ARRAY_A );

        $attempt['responses'] = $responses;

        return $attempt;
    }

    /**
     * Get user attempts for a quiz.
     *
     * @param int $quiz_id Quiz ID.
     * @param int $user_id User ID.
     * @return array Array of attempts.
     */
    public static function get_user_attempts( $quiz_id, $user_id ) {
        global $wpdb;

        $attempts_table = $wpdb->prefix . 'ts_quiz_attempts';

        $attempts = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$attempts_table} WHERE quiz_id = %d AND user_id = %d ORDER BY started_at DESC",
            $quiz_id,
            $user_id
        ), ARRAY_A );

        return $attempts;
    }

    /**
     * Get all attempts for a quiz.
     *
     * @param int $quiz_id Quiz ID.
     * @return array Array of attempts.
     */
    public static function get_quiz_attempts( $quiz_id ) {
        global $wpdb;

        $attempts_table = $wpdb->prefix . 'ts_quiz_attempts';

        $attempts = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$attempts_table} WHERE quiz_id = %d ORDER BY started_at DESC",
            $quiz_id
        ), ARRAY_A );

        return $attempts;
    }

    /**
     * Abandon an in-progress attempt.
     *
     * @param int $attempt_id Attempt ID.
     * @return bool True on success, false on failure.
     */
    public static function abandon_attempt( $attempt_id ) {
        global $wpdb;

        $attempts_table = $wpdb->prefix . 'ts_quiz_attempts';

        $result = $wpdb->update(
            $attempts_table,
            array( 'status' => 'abandoned' ),
            array( 'id' => $attempt_id ),
            array( '%s' ),
            array( '%d' )
        );

        return $result !== false;
    }

    /**
     * Get user's IP address.
     *
     * @return string IP address.
     */
    private static function get_user_ip() {
        if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
            return sanitize_text_field( wp_unslash( $_SERVER['HTTP_CLIENT_IP'] ) );
        } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            return sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
        } else {
            return sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) );
        }
    }
}
