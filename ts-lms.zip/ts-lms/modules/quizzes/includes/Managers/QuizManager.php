<?php
/**
 * Quiz Manager
 *
 * Handles quiz business logic and data access.
 *
 * @package TS_LMS\Modules\Quizzes\Managers
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Quizzes\Managers;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * QuizManager class.
 */
class QuizManager {

    /**
     * Get quiz questions with ordering.
     *
     * @param int  $quiz_id Quiz ID.
     * @param bool $randomize Whether to randomize questions.
     * @return array Array of question data.
     */
    public static function get_quiz_questions( $quiz_id, $randomize = false ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'ts_quiz_questions';

        $order_by = $randomize ? 'RAND()' : 'order_index ASC';

        $results = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE quiz_id = %d ORDER BY {$order_by}",
            $quiz_id
        ) );

        $questions = array();

        foreach ( $results as $row ) {
            $question_post = get_post( $row->question_id );
            
            if ( ! $question_post || $question_post->post_status !== 'publish' ) {
                continue;
            }

            $questions[] = array(
                'id'             => $row->question_id,
                'title'          => $question_post->post_title,
                'content'        => $question_post->post_content,
                'type'           => get_post_meta( $row->question_id, '_question_type', true ),
                'options'        => get_post_meta( $row->question_id, '_options', true ),
                'explanation'    => get_post_meta( $row->question_id, '_explanation', true ),
                'points'         => $row->points,
                'order_index'    => $row->order_index,
            );
        }

        return $questions;
    }

    /**
     * Add question to quiz.
     *
     * @param int   $quiz_id     Quiz ID.
     * @param int   $question_id Question ID.
     * @param float $points      Points for this question.
     * @param int   $order_index Order index.
     * @return bool|int Insert ID on success, false on failure.
     */
    public static function add_question_to_quiz( $quiz_id, $question_id, $points = 1.0, $order_index = 0 ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'ts_quiz_questions';

        // Check if already exists
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table_name} WHERE quiz_id = %d AND question_id = %d",
            $quiz_id,
            $question_id
        ) );

        if ( $exists ) {
            return false;
        }

        // If order_index is 0, get the next available index
        if ( $order_index === 0 ) {
            $max_order = $wpdb->get_var( $wpdb->prepare(
                "SELECT MAX(order_index) FROM {$table_name} WHERE quiz_id = %d",
                $quiz_id
            ) );
            $order_index = ( $max_order !== null ) ? $max_order + 1 : 1;
        }

        $result = $wpdb->insert(
            $table_name,
            array(
                'quiz_id'     => $quiz_id,
                'question_id' => $question_id,
                'points'      => $points,
                'order_index' => $order_index,
            ),
            array( '%d', '%d', '%f', '%d' )
        );

        return $result ? $wpdb->insert_id : false;
    }

    /**
     * Remove question from quiz.
     *
     * @param int $quiz_id     Quiz ID.
     * @param int $question_id Question ID.
     * @return bool True on success, false on failure.
     */
    public static function remove_question_from_quiz( $quiz_id, $question_id ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'ts_quiz_questions';

        $result = $wpdb->delete(
            $table_name,
            array(
                'quiz_id'     => $quiz_id,
                'question_id' => $question_id,
            ),
            array( '%d', '%d' )
        );

        return $result !== false;
    }

    /**
     * Get quiz settings.
     *
     * @param int $quiz_id Quiz ID.
     * @return array Quiz settings.
     */
    public static function get_quiz_settings( $quiz_id ) {
        return array(
            'timer_minutes'       => get_post_meta( $quiz_id, '_timer_minutes', true ) ?: 0,
            'attempt_limit'       => get_post_meta( $quiz_id, '_attempt_limit', true ) ?: 0,
            'pass_percentage'     => get_post_meta( $quiz_id, '_pass_percentage', true ) ?: 70,
            'is_public'           => get_post_meta( $quiz_id, '_is_public', true ) ?: 0,
            'randomize_questions' => get_post_meta( $quiz_id, '_randomize_questions', true ) ?: 0,
            'show_correct_answers' => get_post_meta( $quiz_id, '_show_correct_answers', true ) ?: 1,
            'course_id'           => get_post_meta( $quiz_id, '_course_id', true ),
        );
    }

    /**
     * Check if user can attempt quiz.
     *
     * @param int $quiz_id Quiz ID.
     * @param int $user_id User ID.
     * @return array Array with 'can_attempt' (bool) and 'message' (string).
     */
    public static function can_user_attempt( $quiz_id, $user_id ) {
        global $wpdb;

        // Check if quiz exists and is published
        $quiz = get_post( $quiz_id );
        if ( ! $quiz || $quiz->post_type !== 'ts_quiz' || $quiz->post_status !== 'publish' ) {
            return array(
                'can_attempt' => false,
                'message'     => __( 'Quiz not found or not available.', 'ts-lms' ),
            );
        }

        // Check access control
        if ( ! self::is_quiz_accessible( $quiz_id, $user_id ) ) {
            return array(
                'can_attempt' => false,
                'message'     => __( 'You do not have access to this quiz.', 'ts-lms' ),
            );
        }

        // Check attempt limit
        $settings = self::get_quiz_settings( $quiz_id );
        
        if ( $settings['attempt_limit'] > 0 ) {
            $attempts_table = $wpdb->prefix . 'ts_quiz_attempts';
            
            $attempt_count = $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$attempts_table} WHERE quiz_id = %d AND user_id = %d AND status = 'completed'",
                $quiz_id,
                $user_id
            ) );

            if ( $attempt_count >= $settings['attempt_limit'] ) {
                return array(
                    'can_attempt' => false,
                    'message'     => sprintf(
                        __( 'You have reached the maximum number of attempts (%d).', 'ts-lms' ),
                        $settings['attempt_limit']
                    ),
                );
            }
        }

        // Check for in-progress attempt
        $attempts_table = $wpdb->prefix . 'ts_quiz_attempts';
        $in_progress = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$attempts_table} WHERE quiz_id = %d AND user_id = %d AND status = 'in_progress'",
            $quiz_id,
            $user_id
        ) );

        if ( $in_progress ) {
            return array(
                'can_attempt' => false,
                'message'     => __( 'You have an in-progress attempt. Please complete or abandon it first.', 'ts-lms' ),
                'attempt_id'  => $in_progress,
            );
        }

        return array(
            'can_attempt' => true,
            'message'     => __( 'You can attempt this quiz.', 'ts-lms' ),
        );
    }

    /**
     * Check if quiz is accessible to user.
     *
     * @param int $quiz_id Quiz ID.
     * @param int $user_id User ID.
     * @return bool True if accessible, false otherwise.
     */
    public static function is_quiz_accessible( $quiz_id, $user_id ) {
        $settings = self::get_quiz_settings( $quiz_id );

        // If public, allow access
        if ( $settings['is_public'] ) {
            return true;
        }

        // If not logged in, deny access
        if ( ! $user_id ) {
            return false;
        }

        // If admin or instructor, allow access
        $user = get_userdata( $user_id );
        if ( $user && ( in_array( 'administrator', $user->roles ) || in_array( 'ts_instructor', $user->roles ) ) ) {
            return true;
        }

        // If linked to a course, check enrollment
        if ( $settings['course_id'] ) {
            global $wpdb;
            $enrollments_table = $wpdb->prefix . 'ts_course_enrollments';
            
            $enrolled = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$enrollments_table} WHERE course_id = %d AND user_id = %d AND status = 'active'",
                $settings['course_id'],
                $user_id
            ) );

            return (bool) $enrolled;
        }

        // Default: deny access
        return false;
    }

    /**
     * Get quiz statistics.
     *
     * @param int $quiz_id Quiz ID.
     * @return array Quiz statistics.
     */
    public static function get_quiz_stats( $quiz_id ) {
        global $wpdb;

        $attempts_table = $wpdb->prefix . 'ts_quiz_attempts';

        $stats = $wpdb->get_row( $wpdb->prepare(
            "SELECT 
                COUNT(*) as total_attempts,
                COUNT(DISTINCT user_id) as unique_users,
                AVG(percentage) as average_score,
                MAX(percentage) as highest_score,
                MIN(percentage) as lowest_score,
                SUM(CASE WHEN passed = 1 THEN 1 ELSE 0 END) as passed_count
            FROM {$attempts_table}
            WHERE quiz_id = %d AND status = 'completed'",
            $quiz_id
        ), ARRAY_A );

        return $stats;
    }
}
