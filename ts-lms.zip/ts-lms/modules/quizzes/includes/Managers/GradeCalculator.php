<?php
/**
 * Grade Calculator
 *
 * Handles grading logic for quiz attempts.
 *
 * @package TS_LMS\Modules\Quizzes\Managers
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Quizzes\Managers;

use TS_LMS\Modules\Quizzes\PostTypes\Question;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * GradeCalculator class.
 */
class GradeCalculator {

    /**
     * Auto-grade an attempt (MCQ and True/False only).
     *
     * @param int $attempt_id Attempt ID.
     * @return bool True on success, false on failure.
     */
    public static function auto_grade_attempt( $attempt_id ) {
        global $wpdb;

        $attempt = AttemptManager::get_attempt( $attempt_id );
        if ( ! $attempt ) {
            return false;
        }

        $responses_table = $wpdb->prefix . 'ts_quiz_responses';

        // Get all responses for this attempt
        $responses = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$responses_table} WHERE attempt_id = %d",
            $attempt_id
        ), ARRAY_A );

        foreach ( $responses as $response ) {
            // Get question data
            $question_data = Question::get_question_data( $response['question_id'] );
            
            if ( ! $question_data ) {
                continue;
            }

            // Only auto-grade MCQ and True/False
            if ( in_array( $question_data['type'], array( 'mcq', 'true_false' ) ) ) {
                $is_correct = self::check_answer( $question_data, $response['response_text'] );
                $points_earned = $is_correct ? $response['points_available'] : 0;

                // Update response
                $wpdb->update(
                    $responses_table,
                    array(
                        'is_correct'    => $is_correct ? 1 : 0,
                        'points_earned' => $points_earned,
                        'graded_at'     => current_time( 'mysql' ),
                    ),
                    array( 'id' => $response['id'] ),
                    array( '%d', '%f', '%s' ),
                    array( '%d' )
                );
            }
        }

        // Calculate final score
        self::calculate_final_score( $attempt_id );

        return true;
    }

    /**
     * Manually grade a response (for short answers).
     *
     * @param int    $response_id Response ID.
     * @param float  $points      Points earned.
     * @param string $feedback    Feedback text.
     * @param int    $grader_id   Grader user ID.
     * @return bool True on success, false on failure.
     */
    public static function manual_grade_response( $response_id, $points, $feedback = '', $grader_id = null ) {
        global $wpdb;

        if ( $grader_id === null ) {
            $grader_id = get_current_user_id();
        }

        $responses_table = $wpdb->prefix . 'ts_quiz_responses';

        // Get response to verify points_available
        $response = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$responses_table} WHERE id = %d",
            $response_id
        ), ARRAY_A );

        if ( ! $response ) {
            return false;
        }

        // Ensure points don't exceed available points
        $points = min( $points, $response['points_available'] );
        $points = max( 0, $points );

        $is_correct = $points >= $response['points_available'];

        $result = $wpdb->update(
            $responses_table,
            array(
                'is_correct'    => $is_correct ? 1 : 0,
                'points_earned' => $points,
                'feedback'      => $feedback,
                'graded_by'     => $grader_id,
                'graded_at'     => current_time( 'mysql' ),
            ),
            array( 'id' => $response_id ),
            array( '%d', '%f', '%s', '%d', '%s' ),
            array( '%d' )
        );

        if ( $result !== false ) {
            // Recalculate final score
            self::calculate_final_score( $response['attempt_id'] );
            
            do_action( 'ts_lms_quiz_response_graded', $response_id, $response['attempt_id'], $grader_id );
        }

        return $result !== false;
    }

    /**
     * Calculate final score for an attempt.
     *
     * @param int $attempt_id Attempt ID.
     * @return bool True on success, false on failure.
     */
    public static function calculate_final_score( $attempt_id ) {
        global $wpdb;

        $attempt = AttemptManager::get_attempt( $attempt_id );
        if ( ! $attempt ) {
            return false;
        }

        $responses_table = $wpdb->prefix . 'ts_quiz_responses';

        // Calculate total score
        $score_data = $wpdb->get_row( $wpdb->prepare(
            "SELECT 
                SUM(points_earned) as total_earned,
                SUM(points_available) as total_available,
                COUNT(*) as total_responses,
                SUM(CASE WHEN points_earned IS NULL THEN 1 ELSE 0 END) as ungraded_count
            FROM {$responses_table}
            WHERE attempt_id = %d",
            $attempt_id
        ), ARRAY_A );

        $score = $score_data['total_earned'] ?? 0;
        $max_score = $score_data['total_available'] ?? $attempt['max_score'];
        $percentage = $max_score > 0 ? ( $score / $max_score ) * 100 : 0;

        // Get quiz settings for pass percentage
        $settings = QuizManager::get_quiz_settings( $attempt['quiz_id'] );
        $passed = $percentage >= $settings['pass_percentage'];

        // Determine status
        $status = 'completed';
        if ( $score_data['ungraded_count'] > 0 ) {
            $status = 'pending_review';
        }

        // Update attempt
        $attempts_table = $wpdb->prefix . 'ts_quiz_attempts';
        
        $wpdb->update(
            $attempts_table,
            array(
                'score'      => $score,
                'max_score'  => $max_score,
                'percentage' => $percentage,
                'passed'     => $passed ? 1 : 0,
                'status'     => $status,
            ),
            array( 'id' => $attempt_id ),
            array( '%f', '%f', '%f', '%d', '%s' ),
            array( '%d' )
        );

        // Update gradebook if fully graded
        if ( $status === 'completed' ) {
            self::update_gradebook( $attempt_id );
        }

        do_action( 'ts_lms_quiz_score_calculated', $attempt_id, $score, $max_score, $percentage, $passed );

        return true;
    }

    /**
     * Update gradebook entry.
     *
     * @param int $attempt_id Attempt ID.
     * @return bool True on success, false on failure.
     */
    public static function update_gradebook( $attempt_id ) {
        global $wpdb;

        $attempt = AttemptManager::get_attempt( $attempt_id );
        if ( ! $attempt ) {
            return false;
        }

        $grades_table = $wpdb->prefix . 'ts_quiz_grades';

        // Check if grade entry exists
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$grades_table} WHERE attempt_id = %d",
            $attempt_id
        ) );

        $grade_data = array(
            'user_id'    => $attempt['user_id'],
            'course_id'  => $attempt['course_id'],
            'quiz_id'    => $attempt['quiz_id'],
            'attempt_id' => $attempt_id,
            'grade'      => $attempt['score'],
            'max_grade'  => $attempt['max_score'],
            'percentage' => $attempt['percentage'],
            'status'     => 'graded',
            'passed'     => $attempt['passed'],
            'graded_at'  => current_time( 'mysql' ),
        );

        if ( $existing ) {
            // Update existing grade
            $result = $wpdb->update(
                $grades_table,
                $grade_data,
                array( 'id' => $existing ),
                array( '%d', '%d', '%d', '%d', '%f', '%f', '%f', '%s', '%d', '%s' ),
                array( '%d' )
            );
        } else {
            // Insert new grade
            $result = $wpdb->insert(
                $grades_table,
                $grade_data,
                array( '%d', '%d', '%d', '%d', '%f', '%f', '%f', '%s', '%d', '%s' )
            );
        }

        do_action( 'ts_lms_quiz_gradebook_updated', $attempt_id, $attempt['user_id'], $attempt['quiz_id'] );

        return $result !== false;
    }

    /**
     * Check if an answer is correct.
     *
     * @param array  $question_data Question data.
     * @param string $response      User's response.
     * @return bool True if correct, false otherwise.
     */
    private static function check_answer( $question_data, $response ) {
        $correct_answer = $question_data['correct_answer'];
        $response = trim( $response );

        // Normalize for comparison
        $correct_answer = strtolower( trim( $correct_answer ) );
        $response = strtolower( $response );

        return $correct_answer === $response;
    }

    /**
     * Get pending reviews for an instructor.
     *
     * @param int $instructor_id Instructor user ID.
     * @return array Array of responses pending review.
     */
    public static function get_pending_reviews( $instructor_id = null ) {
        global $wpdb;

        $responses_table = $wpdb->prefix . 'ts_quiz_responses';
        $attempts_table = $wpdb->prefix . 'ts_quiz_attempts';

        $query = "SELECT r.*, a.quiz_id, a.user_id 
                  FROM {$responses_table} r
                  INNER JOIN {$attempts_table} a ON r.attempt_id = a.id
                  WHERE r.points_earned IS NULL 
                  AND a.status = 'pending_review'
                  ORDER BY r.created_at ASC";

        $pending = $wpdb->get_results( $query, ARRAY_A );

        // Filter by instructor's courses if specified
        if ( $instructor_id ) {
            $pending = array_filter( $pending, function( $item ) use ( $instructor_id ) {
                // Check if instructor teaches the course
                $quiz_settings = QuizManager::get_quiz_settings( $item['quiz_id'] );
                if ( ! $quiz_settings['course_id'] ) {
                    return false;
                }

                // Check instructor assignment
                global $wpdb;
                $instructors_table = $wpdb->prefix . 'ts_course_instructors';
                $is_instructor = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$instructors_table} WHERE course_id = %d AND instructor_id = %d",
                    $quiz_settings['course_id'],
                    $instructor_id
                ) );

                return (bool) $is_instructor;
            } );
        }

        return $pending;
    }
}
