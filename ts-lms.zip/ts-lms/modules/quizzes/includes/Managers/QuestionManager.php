<?php
/**
 * Question Manager
 *
 * Handles question-related operations and business logic.
 *
 * @package TS_LMS\Modules\Quizzes
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Quizzes\Managers;

use TS_LMS\Modules\Quizzes\PostTypes\Question;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * QuestionManager class.
 */
class QuestionManager {

    /**
     * Create a new question.
     *
     * @param array $data Question data.
     * @return int|WP_Error Question ID on success, WP_Error on failure.
     */
    public static function create_question( $data ) {
        // Validate required fields
        if ( empty( $data['title'] ) ) {
            return new \WP_Error( 'missing_title', __( 'Question title is required.', 'ts-lms' ) );
        }

        // Prepare post data
        $post_data = array(
            'post_title'   => sanitize_text_field( $data['title'] ),
            'post_content' => wp_kses_post( $data['content'] ?? '' ),
            'post_status'  => 'publish', // Auto-publish questions
            'post_type'    => Question::POST_TYPE,
            'post_author'  => get_current_user_id(),
        );

        // Insert post
        $question_id = wp_insert_post( $post_data, true );

        if ( is_wp_error( $question_id ) ) {
            return $question_id;
        }

        // Save meta data
        self::update_meta( $question_id, $data );

        return $question_id;
    }

    /**
     * Update a question.
     *
     * @param int   $question_id Question ID.
     * @param array $data        Question data.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function update_question( $question_id, $data ) {
        // Check if question exists
        $question = get_post( $question_id );
        if ( ! $question || $question->post_type !== Question::POST_TYPE ) {
            return new \WP_Error( 'invalid_question', __( 'Invalid question ID.', 'ts-lms' ) );
        }

        // Prepare post data
        $post_data = array( 'ID' => $question_id );

        if ( isset( $data['title'] ) ) {
            $post_data['post_title'] = sanitize_text_field( $data['title'] );
        }

        if ( isset( $data['content'] ) ) {
            $post_data['post_content'] = wp_kses_post( $data['content'] );
        }

        // Update post
        $result = wp_update_post( $post_data, true );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        // Update meta data
        self::update_meta( $question_id, $data );

        return true;
    }

    /**
     * Update question meta data.
     *
     * @param int   $question_id Question ID.
     * @param array $data        Question data.
     * @return void
     */
    private static function update_meta( $question_id, $data ) {
        if ( isset( $data['type'] ) ) {
            update_post_meta( $question_id, '_question_type', sanitize_text_field( $data['type'] ) );
        }

        if ( isset( $data['options'] ) ) { // Array of options
             update_post_meta( $question_id, '_options', $data['options'] );
        }

        if ( isset( $data['correct_answer'] ) ) {
            update_post_meta( $question_id, '_correct_answer', sanitize_text_field( $data['correct_answer'] ) );
        }

        if ( isset( $data['points'] ) ) {
            update_post_meta( $question_id, '_points', floatval( $data['points'] ) );
        }

        if ( isset( $data['explanation'] ) ) {
            update_post_meta( $question_id, '_explanation', wp_kses_post( $data['explanation'] ) );
        }
    }

    /**
     * Delete a question.
     *
     * @param int  $question_id Question ID.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function delete_question( $question_id ) {
        $result = wp_delete_post( $question_id, true );
        
        if ( ! $result ) {
             return new \WP_Error( 'delete_failed', __( 'Failed to delete question.', 'ts-lms' ) );
        }

        return true;
    }
}
