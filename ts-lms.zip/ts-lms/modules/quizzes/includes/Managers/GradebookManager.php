<?php
/**
 * Gradebook Manager
 *
 * Handles gradebook data access and reporting.
 *
 * @package TS_LMS\Modules\Quizzes\Managers
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Quizzes\Managers;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * GradebookManager class.
 */
class GradebookManager {

    /**
     * Get student grades.
     *
     * @param int      $user_id   Student user ID.
     * @param int|null $course_id Optional course ID to filter by.
     * @return array Array of grade entries.
     */
    public static function get_student_grades( $user_id, $course_id = null ) {
        global $wpdb;

        $grades_table = $wpdb->prefix . 'ts_quiz_grades';

        $where = $wpdb->prepare( 'user_id = %d', $user_id );
        
        if ( $course_id ) {
            $where .= $wpdb->prepare( ' AND course_id = %d', $course_id );
        }

        $grades = $wpdb->get_results(
            "SELECT * FROM {$grades_table} WHERE {$where} ORDER BY graded_at DESC",
            ARRAY_A
        );

        // Enrich with quiz and course data
        foreach ( $grades as &$grade ) {
            $quiz = get_post( $grade['quiz_id'] );
            $grade['quiz_title'] = $quiz ? $quiz->post_title : __( 'Unknown Quiz', 'ts-lms' );

            if ( $grade['course_id'] ) {
                $course = get_post( $grade['course_id'] );
                $grade['course_title'] = $course ? $course->post_title : __( 'Unknown Course', 'ts-lms' );
            } else {
                $grade['course_title'] = __( 'Standalone Quiz', 'ts-lms' );
            }
        }

        return $grades;
    }

    /**
     * Get course gradebook (all students).
     *
     * @param int $course_id Course ID.
     * @return array Array of student grades grouped by student.
     */
    public static function get_course_grades( $course_id ) {
        global $wpdb;

        $grades_table = $wpdb->prefix . 'ts_quiz_grades';

        $grades = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$grades_table} WHERE course_id = %d ORDER BY user_id, graded_at DESC",
            $course_id
        ), ARRAY_A );

        // Group by student
        $gradebook = array();

        foreach ( $grades as $grade ) {
            $user_id = $grade['user_id'];
            
            if ( ! isset( $gradebook[ $user_id ] ) ) {
                $user = get_userdata( $user_id );
                $gradebook[ $user_id ] = array(
                    'user_id'      => $user_id,
                    'user_name'    => $user ? $user->display_name : __( 'Unknown User', 'ts-lms' ),
                    'user_email'   => $user ? $user->user_email : '',
                    'grades'       => array(),
                    'total_quizzes' => 0,
                    'passed_quizzes' => 0,
                    'average_score' => 0,
                );
            }

            $quiz = get_post( $grade['quiz_id'] );
            $grade['quiz_title'] = $quiz ? $quiz->post_title : __( 'Unknown Quiz', 'ts-lms' );

            $gradebook[ $user_id ]['grades'][] = $grade;
            $gradebook[ $user_id ]['total_quizzes']++;
            
            if ( $grade['passed'] ) {
                $gradebook[ $user_id ]['passed_quizzes']++;
            }
        }

        // Calculate averages
        foreach ( $gradebook as &$student ) {
            if ( $student['total_quizzes'] > 0 ) {
                $total_percentage = array_sum( array_column( $student['grades'], 'percentage' ) );
                $student['average_score'] = $total_percentage / $student['total_quizzes'];
            }
        }

        return array_values( $gradebook );
    }

    /**
     * Get instructor gradebook (all courses taught by instructor).
     *
     * @param int $instructor_id Instructor user ID.
     * @return array Array of courses with gradebook data.
     */
    public static function get_instructor_gradebook( $instructor_id ) {
        global $wpdb;

        // Get courses taught by instructor
        $instructors_table = $wpdb->prefix . 'ts_course_instructors';
        
        $course_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT course_id FROM {$instructors_table} WHERE instructor_id = %d",
            $instructor_id
        ) );

        if ( empty( $course_ids ) ) {
            return array();
        }

        $gradebook = array();

        foreach ( $course_ids as $course_id ) {
            $course = get_post( $course_id );
            
            if ( ! $course ) {
                continue;
            }

            $gradebook[] = array(
                'course_id'    => $course_id,
                'course_title' => $course->post_title,
                'students'     => self::get_course_grades( $course_id ),
            );
        }

        return $gradebook;
    }

    /**
     * Get admin gradebook (system-wide view).
     *
     * @param array $filters Optional filters (course_id, user_id, quiz_id, status).
     * @return array Array of grade entries.
     */
    public static function get_admin_gradebook( $filters = array() ) {
        global $wpdb;

        $grades_table = $wpdb->prefix . 'ts_quiz_grades';

        $where_clauses = array( '1=1' );
        $where_values = array();

        if ( ! empty( $filters['course_id'] ) ) {
            $where_clauses[] = 'course_id = %d';
            $where_values[] = $filters['course_id'];
        }

        if ( ! empty( $filters['user_id'] ) ) {
            $where_clauses[] = 'user_id = %d';
            $where_values[] = $filters['user_id'];
        }

        if ( ! empty( $filters['quiz_id'] ) ) {
            $where_clauses[] = 'quiz_id = %d';
            $where_values[] = $filters['quiz_id'];
        }

        if ( ! empty( $filters['status'] ) ) {
            $where_clauses[] = 'status = %s';
            $where_values[] = $filters['status'];
        }

        if ( ! empty( $filters['passed'] ) ) {
            $where_clauses[] = 'passed = %d';
            $where_values[] = $filters['passed'] === 'yes' ? 1 : 0;
        }

        $where = implode( ' AND ', $where_clauses );

        if ( ! empty( $where_values ) ) {
            $where = $wpdb->prepare( $where, $where_values );
        }

        $order_by = 'graded_at DESC';
        $limit = '';

        if ( ! empty( $filters['order_by'] ) ) {
            $allowed_order = array( 'graded_at', 'percentage', 'grade', 'user_id', 'quiz_id' );
            if ( in_array( $filters['order_by'], $allowed_order ) ) {
                $order_direction = ! empty( $filters['order_direction'] ) && $filters['order_direction'] === 'ASC' ? 'ASC' : 'DESC';
                $order_by = $filters['order_by'] . ' ' . $order_direction;
            }
        }

        if ( ! empty( $filters['limit'] ) ) {
            $limit = $wpdb->prepare( 'LIMIT %d', absint( $filters['limit'] ) );
        }

        $query = "SELECT * FROM {$grades_table} WHERE {$where} ORDER BY {$order_by} {$limit}";

        $grades = $wpdb->get_results( $query, ARRAY_A );

        // Enrich with user, quiz, and course data
        foreach ( $grades as &$grade ) {
            $user = get_userdata( $grade['user_id'] );
            $grade['user_name'] = $user ? $user->display_name : __( 'Unknown User', 'ts-lms' );
            $grade['user_email'] = $user ? $user->user_email : '';

            $quiz = get_post( $grade['quiz_id'] );
            $grade['quiz_title'] = $quiz ? $quiz->post_title : __( 'Unknown Quiz', 'ts-lms' );

            if ( $grade['course_id'] ) {
                $course = get_post( $grade['course_id'] );
                $grade['course_title'] = $course ? $course->post_title : __( 'Unknown Course', 'ts-lms' );
            } else {
                $grade['course_title'] = __( 'Standalone Quiz', 'ts-lms' );
            }
        }

        return $grades;
    }

    /**
     * Get gradebook statistics.
     *
     * @param array $filters Optional filters.
     * @return array Statistics data.
     */
    public static function get_gradebook_stats( $filters = array() ) {
        global $wpdb;

        $grades_table = $wpdb->prefix . 'ts_quiz_grades';

        $where_clauses = array( '1=1' );
        $where_values = array();

        if ( ! empty( $filters['course_id'] ) ) {
            $where_clauses[] = 'course_id = %d';
            $where_values[] = $filters['course_id'];
        }

        if ( ! empty( $filters['quiz_id'] ) ) {
            $where_clauses[] = 'quiz_id = %d';
            $where_values[] = $filters['quiz_id'];
        }

        $where = implode( ' AND ', $where_clauses );

        if ( ! empty( $where_values ) ) {
            $where = $wpdb->prepare( $where, $where_values );
        }

        $stats = $wpdb->get_row(
            "SELECT 
                COUNT(*) as total_grades,
                COUNT(DISTINCT user_id) as unique_students,
                AVG(percentage) as average_percentage,
                MAX(percentage) as highest_percentage,
                MIN(percentage) as lowest_percentage,
                SUM(CASE WHEN passed = 1 THEN 1 ELSE 0 END) as total_passed,
                SUM(CASE WHEN passed = 0 THEN 1 ELSE 0 END) as total_failed
            FROM {$grades_table}
            WHERE {$where}",
            ARRAY_A
        );

        return $stats;
    }

    /**
     * Export gradebook to CSV.
     *
     * @param array $filters Optional filters.
     * @return string CSV content.
     */
    public static function export_to_csv( $filters = array() ) {
        $grades = self::get_admin_gradebook( $filters );

        $csv = array();
        
        // Header
        $csv[] = array(
            'Student Name',
            'Student Email',
            'Course',
            'Quiz',
            'Grade',
            'Max Grade',
            'Percentage',
            'Status',
            'Passed',
            'Graded At',
        );

        // Data rows
        foreach ( $grades as $grade ) {
            $csv[] = array(
                $grade['user_name'],
                $grade['user_email'],
                $grade['course_title'],
                $grade['quiz_title'],
                $grade['grade'],
                $grade['max_grade'],
                $grade['percentage'] . '%',
                $grade['status'],
                $grade['passed'] ? 'Yes' : 'No',
                $grade['graded_at'],
            );
        }

        // Convert to CSV string
        $output = '';
        foreach ( $csv as $row ) {
            $output .= implode( ',', array_map( function( $field ) {
                return '"' . str_replace( '"', '""', $field ) . '"';
            }, $row ) ) . "\n";
        }

        return $output;
    }
}
