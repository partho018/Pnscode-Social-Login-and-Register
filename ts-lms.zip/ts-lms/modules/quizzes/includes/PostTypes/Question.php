<?php
/**
 * Question Post Type
 *
 * Registers and manages the Question custom post type.
 *
 * @package TS_LMS\Modules\Quizzes\PostTypes
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Quizzes\PostTypes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Question class.
 */
class Question {

    /**
     * Post type name.
     *
     * @var string
     */
    const POST_TYPE = 'ts_question';

    /**
     * Initialize the post type.
     *
     * @return void
     */
    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_post_type' ) );
        add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
        add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save_meta' ), 10, 2 );
    }

    /**
     * Register the post type.
     *
     * @return void
     */
    public static function register_post_type() {
        $labels = array(
            'name'                  => __( 'Questions', 'ts-lms' ),
            'singular_name'         => __( 'Question', 'ts-lms' ),
            'menu_name'             => __( 'Questions', 'ts-lms' ),
            'add_new'               => __( 'Add New', 'ts-lms' ),
            'add_new_item'          => __( 'Add New Question', 'ts-lms' ),
            'edit_item'             => __( 'Edit Question', 'ts-lms' ),
            'new_item'              => __( 'New Question', 'ts-lms' ),
            'view_item'             => __( 'View Question', 'ts-lms' ),
            'search_items'          => __( 'Search Questions', 'ts-lms' ),
            'not_found'             => __( 'No questions found', 'ts-lms' ),
            'not_found_in_trash'    => __( 'No questions found in trash', 'ts-lms' ),
            'all_items'             => __( 'All Questions', 'ts-lms' ),
        );

        $args = array(
            'labels'              => $labels,
            'public'              => false,
            'show_ui'             => true,
            'show_in_menu'        => 'edit.php?post_type=ts_quiz',
            'show_in_rest'        => true,
            'capability_type'     => 'post',
            'hierarchical'        => false,
            'supports'            => array( 'title', 'editor', 'author' ),
            'has_archive'         => false,
            'rewrite'             => false,
            'query_var'           => false,
        );

        register_post_type( self::POST_TYPE, $args );
    }

    /**
     * Add meta boxes.
     *
     * @return void
     */
    public static function add_meta_boxes() {
        add_meta_box(
            'ts_question_settings',
            __( 'Question Settings', 'ts-lms' ),
            array( __CLASS__, 'render_settings_meta_box' ),
            self::POST_TYPE,
            'normal',
            'high'
        );
    }

    /**
     * Render settings meta box.
     *
     * @param \WP_Post $post Post object.
     * @return void
     */
    public static function render_settings_meta_box( $post ) {
        wp_nonce_field( 'ts_question_meta', 'ts_question_meta_nonce' );

        $question_type = get_post_meta( $post->ID, '_question_type', true ) ?: 'mcq';
        $options = get_post_meta( $post->ID, '_options', true ) ?: array();
        $correct_answer = get_post_meta( $post->ID, '_correct_answer', true );
        $explanation = get_post_meta( $post->ID, '_explanation', true );
        $points = get_post_meta( $post->ID, '_points', true ) ?: 1;

        ?>
        <div class="ts-question-settings">
            <p>
                <label for="question_type"><strong><?php esc_html_e( 'Question Type', 'ts-lms' ); ?></strong></label><br>
                <select name="question_type" id="question_type" style="width: 100%; max-width: 300px;">
                    <option value="mcq" <?php selected( $question_type, 'mcq' ); ?>><?php esc_html_e( 'Multiple Choice', 'ts-lms' ); ?></option>
                    <option value="true_false" <?php selected( $question_type, 'true_false' ); ?>><?php esc_html_e( 'True/False', 'ts-lms' ); ?></option>
                    <option value="short_answer" <?php selected( $question_type, 'short_answer' ); ?>><?php esc_html_e( 'Short Answer', 'ts-lms' ); ?></option>
                </select>
            </p>

            <div id="mcq-options" style="<?php echo $question_type !== 'mcq' ? 'display:none;' : ''; ?>">
                <p><strong><?php esc_html_e( 'Answer Options (one per line)', 'ts-lms' ); ?></strong></p>
                <textarea name="options" rows="6" style="width: 100%;"><?php echo esc_textarea( is_array( $options ) ? implode( "\n", $options ) : $options ); ?></textarea>
                <p class="description"><?php esc_html_e( 'Enter each option on a new line.', 'ts-lms' ); ?></p>
            </div>

            <div id="correct-answer-field" style="<?php echo $question_type === 'short_answer' ? 'display:none;' : ''; ?>">
                <p>
                    <label for="correct_answer"><strong><?php esc_html_e( 'Correct Answer', 'ts-lms' ); ?></strong></label><br>
                    <?php if ( $question_type === 'true_false' ) : ?>
                        <select name="correct_answer" id="correct_answer" style="width: 100%; max-width: 300px;">
                            <option value="true" <?php selected( $correct_answer, 'true' ); ?>><?php esc_html_e( 'True', 'ts-lms' ); ?></option>
                            <option value="false" <?php selected( $correct_answer, 'false' ); ?>><?php esc_html_e( 'False', 'ts-lms' ); ?></option>
                        </select>
                    <?php else : ?>
                        <input type="text" name="correct_answer" id="correct_answer" value="<?php echo esc_attr( $correct_answer ); ?>" style="width: 100%;" placeholder="<?php esc_attr_e( 'Enter the correct answer', 'ts-lms' ); ?>">
                    <?php endif; ?>
                </p>
            </div>

            <p>
                <label for="explanation"><strong><?php esc_html_e( 'Explanation (Optional)', 'ts-lms' ); ?></strong></label><br>
                <textarea name="explanation" id="explanation" rows="3" style="width: 100%;"><?php echo esc_textarea( $explanation ); ?></textarea>
                <span class="description"><?php esc_html_e( 'Shown to students after answering.', 'ts-lms' ); ?></span>
            </p>

            <p>
                <label for="points"><strong><?php esc_html_e( 'Points', 'ts-lms' ); ?></strong></label><br>
                <input type="number" name="points" id="points" value="<?php echo esc_attr( $points ); ?>" min="0" step="0.5" style="width: 100px;">
            </p>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('#question_type').on('change', function() {
                var type = $(this).val();
                
                if (type === 'mcq') {
                    $('#mcq-options').show();
                    $('#correct-answer-field').show();
                } else if (type === 'true_false') {
                    $('#mcq-options').hide();
                    $('#correct-answer-field').show();
                } else {
                    $('#mcq-options').hide();
                    $('#correct-answer-field').hide();
                }
            });
        });
        </script>
        <?php
    }

    /**
     * Save meta data.
     *
     * @param int      $post_id Post ID.
     * @param \WP_Post $post    Post object.
     * @return void
     */
    public static function save_meta( $post_id, $post ) {
        // Verify nonce
        if ( ! isset( $_POST['ts_question_meta_nonce'] ) || ! wp_verify_nonce( $_POST['ts_question_meta_nonce'], 'ts_question_meta' ) ) {
            return;
        }

        // Check autosave
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // Check permissions
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // Save question type
        if ( isset( $_POST['question_type'] ) ) {
            update_post_meta( $post_id, '_question_type', sanitize_text_field( $_POST['question_type'] ) );
        }

        // Save options (for MCQ)
        if ( isset( $_POST['options'] ) ) {
            $options = array_filter( array_map( 'trim', explode( "\n", $_POST['options'] ) ) );
            update_post_meta( $post_id, '_options', $options );
        }

        // Save correct answer
        if ( isset( $_POST['correct_answer'] ) ) {
            update_post_meta( $post_id, '_correct_answer', sanitize_text_field( $_POST['correct_answer'] ) );
        }

        // Save explanation
        if ( isset( $_POST['explanation'] ) ) {
            update_post_meta( $post_id, '_explanation', sanitize_textarea_field( $_POST['explanation'] ) );
        }

        // Save points
        if ( isset( $_POST['points'] ) ) {
            update_post_meta( $post_id, '_points', floatval( $_POST['points'] ) );
        }
    }

    /**
     * Get question data.
     *
     * @param int $question_id Question ID.
     * @return array|null Question data or null if not found.
     */
    public static function get_question_data( $question_id ) {
        $post = get_post( $question_id );

        if ( ! $post || $post->post_type !== self::POST_TYPE ) {
            return null;
        }

        return array(
            'id'             => $post->ID,
            'title'          => $post->post_title,
            'content'        => $post->post_content,
            'type'           => get_post_meta( $post->ID, '_question_type', true ),
            'options'        => get_post_meta( $post->ID, '_options', true ),
            'correct_answer' => get_post_meta( $post->ID, '_correct_answer', true ),
            'explanation'    => get_post_meta( $post->ID, '_explanation', true ),
            'points'         => get_post_meta( $post->ID, '_points', true ) ?: 1,
        );
    }
}
