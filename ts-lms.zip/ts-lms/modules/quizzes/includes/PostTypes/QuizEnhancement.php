<?php
/**
 * Quiz Enhancement
 *
 * Adds meta boxes and functionality to the Quiz post type.
 *
 * @package TS_LMS\Modules\Quizzes\PostTypes
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Quizzes\PostTypes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * QuizEnhancement class.
 */
class QuizEnhancement {

    /**
     * Post type name.
     *
     * @var string
     */
    const POST_TYPE = 'ts_quiz';

    /**
     * Initialize enhancements.
     *
     * @return void
     */
    public static function init() {
        add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
        add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save_meta' ), 10, 2 );
    }

    /**
     * Add meta boxes.
     *
     * @return void
     */
    public static function add_meta_boxes() {
        add_meta_box(
            'ts_quiz_settings',
            __( 'Quiz Settings', 'ts-lms' ),
            array( __CLASS__, 'render_settings_meta_box' ),
            self::POST_TYPE,
            'normal',
            'high'
        );

        add_meta_box(
            'ts_quiz_questions',
            __( 'Quiz Questions', 'ts-lms' ),
            array( __CLASS__, 'render_questions_meta_box' ),
            self::POST_TYPE,
            'normal',
            'high'
        );
    }

    /**
     * Render settings meta box.
     *
     * @param \WP_Post $post Post object.
     * @return void
     */
    public static function render_settings_meta_box( $post ) {
        wp_nonce_field( 'ts_quiz_settings_meta', 'ts_quiz_settings_nonce' );

        $timer_minutes = get_post_meta( $post->ID, '_timer_minutes', true ) ?: 0;
        $attempt_limit = get_post_meta( $post->ID, '_attempt_limit', true ) ?: 0;
        $pass_percentage = get_post_meta( $post->ID, '_pass_percentage', true ) ?: 70;
        $is_public = get_post_meta( $post->ID, '_is_public', true ) ?: 0;
        $randomize_questions = get_post_meta( $post->ID, '_randomize_questions', true ) ?: 0;
        $show_correct_answers = get_post_meta( $post->ID, '_show_correct_answers', true ) ?: 1;
        $course_id = get_post_meta( $post->ID, '_course_id', true );

        ?>
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="course_id"><?php esc_html_e( 'Associated Course', 'ts-lms' ); ?></label>
                </th>
                <td>
                    <?php
                    $courses = get_posts( array(
                        'post_type' => 'ts_course',
                        'posts_per_page' => -1,
                        'orderby' => 'title',
                        'order' => 'ASC',
                    ) );
                    ?>
                    <select name="course_id" id="course_id" style="width: 100%; max-width: 400px;">
                        <option value=""><?php esc_html_e( 'None (Standalone Quiz)', 'ts-lms' ); ?></option>
                        <?php foreach ( $courses as $course ) : ?>
                            <option value="<?php echo esc_attr( $course->ID ); ?>" <?php selected( $course_id, $course->ID ); ?>>
                                <?php echo esc_html( $course->post_title ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php esc_html_e( 'Link this quiz to a course (optional).', 'ts-lms' ); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="timer_minutes"><?php esc_html_e( 'Time Limit (Minutes)', 'ts-lms' ); ?></label>
                </th>
                <td>
                    <input type="number" name="timer_minutes" id="timer_minutes" value="<?php echo esc_attr( $timer_minutes ); ?>" min="0" step="1" style="width: 100px;">
                    <p class="description"><?php esc_html_e( 'Set to 0 for no time limit.', 'ts-lms' ); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="attempt_limit"><?php esc_html_e( 'Attempt Limit', 'ts-lms' ); ?></label>
                </th>
                <td>
                    <input type="number" name="attempt_limit" id="attempt_limit" value="<?php echo esc_attr( $attempt_limit ); ?>" min="0" step="1" style="width: 100px;">
                    <p class="description"><?php esc_html_e( 'Maximum number of attempts allowed. Set to 0 for unlimited.', 'ts-lms' ); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="pass_percentage"><?php esc_html_e( 'Pass Percentage', 'ts-lms' ); ?></label>
                </th>
                <td>
                    <input type="number" name="pass_percentage" id="pass_percentage" value="<?php echo esc_attr( $pass_percentage ); ?>" min="0" max="100" step="1" style="width: 100px;">%
                    <p class="description"><?php esc_html_e( 'Minimum percentage required to pass.', 'ts-lms' ); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <?php esc_html_e( 'Quiz Options', 'ts-lms' ); ?>
                </th>
                <td>
                    <label>
                        <input type="checkbox" name="is_public" value="1" <?php checked( $is_public, 1 ); ?>>
                        <?php esc_html_e( 'Public (accessible without enrollment)', 'ts-lms' ); ?>
                    </label><br>
                    <label>
                        <input type="checkbox" name="randomize_questions" value="1" <?php checked( $randomize_questions, 1 ); ?>>
                        <?php esc_html_e( 'Randomize question order', 'ts-lms' ); ?>
                    </label><br>
                    <label>
                        <input type="checkbox" name="show_correct_answers" value="1" <?php checked( $show_correct_answers, 1 ); ?>>
                        <?php esc_html_e( 'Show correct answers after submission', 'ts-lms' ); ?>
                    </label>
                </td>
            </tr>
        </table>
        <?php
    }

    /**
     * Render questions meta box.
     *
     * @param \WP_Post $post Post object.
     * @return void
     */
    public static function render_questions_meta_box( $post ) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'ts_quiz_questions';
        
        // Get assigned questions
        $assigned_questions = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE quiz_id = %d ORDER BY order_index ASC",
            $post->ID
        ) );

        // Get all available questions
        $questions = get_posts( array(
            'post_type' => 'ts_question',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ) );

        ?>
        <div id="ts-quiz-questions">
            <p>
                <strong><?php esc_html_e( 'Add Questions to Quiz', 'ts-lms' ); ?></strong>
            </p>
            
            <div id="assigned-questions">
                <?php if ( ! empty( $assigned_questions ) ) : ?>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'Order', 'ts-lms' ); ?></th>
                                <th><?php esc_html_e( 'Question', 'ts-lms' ); ?></th>
                                <th><?php esc_html_e( 'Type', 'ts-lms' ); ?></th>
                                <th><?php esc_html_e( 'Points', 'ts-lms' ); ?></th>
                                <th><?php esc_html_e( 'Action', 'ts-lms' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $assigned_questions as $aq ) : 
                                $question = get_post( $aq->question_id );
                                if ( ! $question ) continue;
                                $type = get_post_meta( $question->ID, '_question_type', true );
                            ?>
                                <tr>
                                    <td><?php echo esc_html( $aq->order_index ); ?></td>
                                    <td><?php echo esc_html( $question->post_title ); ?></td>
                                    <td><?php echo esc_html( ucwords( str_replace( '_', ' ', $type ) ) ); ?></td>
                                    <td><?php echo esc_html( $aq->points ); ?></td>
                                    <td>
                                        <a href="<?php echo esc_url( get_edit_post_link( $question->ID ) ); ?>" target="_blank"><?php esc_html_e( 'Edit', 'ts-lms' ); ?></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <p><em><?php esc_html_e( 'No questions assigned yet.', 'ts-lms' ); ?></em></p>
                <?php endif; ?>
            </div>

            <hr>

            <p>
                <strong><?php esc_html_e( 'Manage Questions', 'ts-lms' ); ?></strong><br>
                <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=ts_question' ) ); ?>" class="button" target="_blank">
                    <?php esc_html_e( 'Create New Question', 'ts-lms' ); ?>
                </a>
            </p>

            <p class="description">
                <?php esc_html_e( 'To add questions to this quiz, use the Quiz Builder interface or REST API after publishing.', 'ts-lms' ); ?>
            </p>
        </div>
        <?php
    }

    /**
     * Save meta data.
     *
     * @param int      $post_id Post ID.
     * @param \WP_Post $post    Post object.
     * @return void
     */
    public static function save_meta( $post_id, $post ) {
        // Verify nonce
        if ( ! isset( $_POST['ts_quiz_settings_nonce'] ) || ! wp_verify_nonce( $_POST['ts_quiz_settings_nonce'], 'ts_quiz_settings_meta' ) ) {
            return;
        }

        // Check autosave
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // Check permissions
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // Save course ID
        if ( isset( $_POST['course_id'] ) ) {
            update_post_meta( $post_id, '_course_id', absint( $_POST['course_id'] ) );
        }

        // Save timer
        if ( isset( $_POST['timer_minutes'] ) ) {
            update_post_meta( $post_id, '_timer_minutes', absint( $_POST['timer_minutes'] ) );
        }

        // Save attempt limit
        if ( isset( $_POST['attempt_limit'] ) ) {
            update_post_meta( $post_id, '_attempt_limit', absint( $_POST['attempt_limit'] ) );
        }

        // Save pass percentage
        if ( isset( $_POST['pass_percentage'] ) ) {
            $percentage = min( 100, max( 0, absint( $_POST['pass_percentage'] ) ) );
            update_post_meta( $post_id, '_pass_percentage', $percentage );
        }

        // Save checkboxes
        update_post_meta( $post_id, '_is_public', isset( $_POST['is_public'] ) ? 1 : 0 );
        update_post_meta( $post_id, '_randomize_questions', isset( $_POST['randomize_questions'] ) ? 1 : 0 );
        update_post_meta( $post_id, '_show_correct_answers', isset( $_POST['show_correct_answers'] ) ? 1 : 0 );
    }
}
