<?php
/**
 * WooCommerce Integration
 *
 * Handles WooCommerce integration for course purchases and enrollment.
 *
 * @package TS_LMS\Modules\Courses\Integration
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Integration;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WooIntegration class.
 */
class WooIntegration {

	/**
	 * Initialize the integration.
	 *
	 * @return void
	 */
	public static function init() {
		// Check if WooCommerce is active
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		// Hook into WooCommerce order completion
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'handle_order_completed' ), 10, 1 );
		
		// Hook into WooCommerce order status change
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'handle_order_status_change' ), 10, 3 );
		
		// Add course product meta box
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_product_meta_box' ) );
		
		// Save course product meta
		add_action( 'save_post', array( __CLASS__, 'save_product_meta' ), 10, 2 );
		
		// Hide course products from shop page if setting is enabled
		add_action( 'pre_get_posts', array( __CLASS__, 'hide_course_products_from_shop' ), 99 );
		add_action( 'woocommerce_product_query', array( __CLASS__, 'hide_course_products_from_shop' ), 99 );
		add_filter( 'woocommerce_product_is_visible', array( __CLASS__, 'course_product_visibility_filter' ), 10, 2 );
		
		// Clear cache when product-course links are updated
		add_action( 'updated_post_meta', array( __CLASS__, 'clear_product_cache_on_meta_update' ), 10, 4 );
		add_action( 'added_post_meta', array( __CLASS__, 'clear_product_cache_on_meta_update' ), 10, 4 );
		add_action( 'deleted_post_meta', array( __CLASS__, 'clear_product_cache_on_meta_update' ), 10, 4 );
		
		// Add admin column to highlight course products
		add_filter( 'manage_edit-product_columns', array( __CLASS__, 'add_course_product_column' ) );
		add_action( 'manage_product_posts_custom_column', array( __CLASS__, 'render_course_product_column' ), 10, 2 );
		add_action( 'admin_head', array( __CLASS__, 'add_course_product_badge_styles' ) );
	}

	/**
	 * Handle order completion.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public static function handle_order_completed( $order_id ) {
		if ( ! $order_id ) {
			error_log( 'TS LMS WooIntegration: No order ID provided' );
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			error_log( 'TS LMS WooIntegration: Order not found - ID: ' . $order_id );
			return;
		}

		$user_id = $order->get_user_id();
		if ( ! $user_id ) {
			error_log( 'TS LMS WooIntegration: No user ID for order - Order ID: ' . $order_id );
			return;
		}

		// Get order items
		$items = $order->get_items();
		
		error_log( 'TS LMS WooIntegration: Processing order #' . $order_id . ' for user #' . $user_id . ' with ' . count( $items ) . ' items' );
		
		foreach ( $items as $item ) {
			$product_id = $item->get_product_id();
			
			if ( ! $product_id ) {
				continue;
			}
			
			// Method 1: Check if product has _linked_course meta
			$linked_id = get_post_meta( $product_id, '_linked_course', true );
			
			// Method 2: If not found, check reverse - find course or bundle with this product_id
			if ( ! $linked_id ) {
				global $wpdb;
				$linked_id = $wpdb->get_var( $wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta} 
					WHERE meta_key IN ('_course_product_id', '_bundle_product_id') 
					AND meta_value = %d 
					LIMIT 1",
					$product_id
				) );
			}
			
			if ( ! $linked_id ) {
				error_log( 'TS LMS WooIntegration: No course or bundle found for product #' . $product_id );
				continue;
			}

			$post_type = get_post_type( $linked_id );

			// Handle Single Course
			if ( $post_type === 'ts_course' ) {
				error_log( 'TS LMS WooIntegration: Found course #' . $linked_id . ' linked to product #' . $product_id );
				
				$enroll_args = array();
				$price_type = get_post_meta( $linked_id, '_course_price_type', true );
				
				if ( $price_type === 'subscription' ) {
					$plan_type = get_post_meta( $linked_id, '_subscription_plan_type', true );
					$duration = MONTH_IN_SECONDS; // Default
					
					switch( $plan_type ) {
						case 'weekly': $duration = WEEK_IN_SECONDS; break;
						case 'monthly': $duration = MONTH_IN_SECONDS; break;
						case 'yearly': $duration = YEAR_IN_SECONDS; break;
					}
					
					$enroll_args['expires_at'] = date( 'Y-m-d H:i:s', time() + $duration );
					$enroll_args['subscription_type'] = $plan_type;
					$enroll_args['subscription_id'] = 'wc_ord_' . $order_id;
				}
				
				$enrollment_result = self::enroll_user( $user_id, $linked_id, $order_id, $enroll_args );
				
				if ( $enrollment_result ) {
					error_log( 'TS LMS WooIntegration: Successfully enrolled user #' . $user_id . ' in course #' . $linked_id );
				} else {
					error_log( 'TS LMS WooIntegration: Failed to enroll user #' . $user_id . ' in course #' . $linked_id . ' (may already be enrolled)' );
				}
			} 
			// Handle Course Bundle
			elseif ( $post_type === 'ts_bundle' ) {
				error_log( 'TS LMS WooIntegration: Found bundle #' . $linked_id . ' linked to product #' . $product_id );
				
				if ( class_exists( 'TS_LMS\Modules\Courses\Managers\BundleManager' ) ) {
					$bundle_results = \TS_LMS\Modules\Courses\Managers\BundleManager::enroll_user_in_bundle( $linked_id, $user_id );
					
					if ( ! is_wp_error( $bundle_results ) ) {
						error_log( 'TS LMS WooIntegration: Successfully enrolled user #' . $user_id . ' in bundle #' . $linked_id . '. Courses: ' . count($bundle_results['success'] ?? []) );
					} else {
						error_log( 'TS LMS WooIntegration: Failed to enroll user #' . $user_id . ' in bundle #' . $linked_id . '. Error: ' . $bundle_results->get_error_message() );
					}
				}
			} else {
				error_log( 'TS LMS WooIntegration: Linked ID #' . $linked_id . ' is neither a course nor a bundle.' );
			}
		}
	}

	/**
	 * Handle payment completion.
	 * This provides immediate enrollment when payment is completed,
	 * even before order status is manually marked as "Completed".
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public static function handle_payment_complete( $order_id ) {
		error_log( 'TS LMS WooIntegration: Payment completed for order #' . $order_id );
		
		// Process enrollment immediately on payment
		self::handle_order_completed( $order_id );
	}

	/**
	 * Enroll user in a course.
	 *
	 * @return bool True on success, false on failure.
	 */
	private static function enroll_user( $user_id, $course_id, $order_id = 0, $args = array() ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . 'ts_course_enrollments';
		
		// Check if table exists
		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table_name}'" ) !== $table_name ) {
			error_log( 'TS LMS WooIntegration: Enrollments table does not exist!' );
			return false;
		}
		
		// Check if already enrolled
		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table_name} WHERE user_id = %d AND course_id = %d",
			$user_id,
			$course_id
		) );
		
		if ( $existing ) {
			// If already enrolled but inactive/cancelled, reactivate
			$update_data = array( 
				'status' => 'active',
				'order_id' => $order_id 
			);
			
			// Extend expiry if provided
			if ( ! empty( $args['expires_at'] ) ) {
				$update_data['expires_at'] = $args['expires_at'];
			}
			
			$wpdb->update(
				$table_name,
				$update_data,
				array( 'id' => $existing )
			);
			
			error_log( 'TS LMS WooIntegration: Reactivated/Updated enrollment for user #' . $user_id . ' in course #' . $course_id );
			return true; 
		}
		
		// Insert enrollment
		$insert_data = array(
			'user_id'       => $user_id,
			'course_id'     => $course_id,
			'enrolled_at'   => current_time( 'mysql' ),
			'status'        => 'active',
			'order_id'      => $order_id,
		);
		$format = array( '%d', '%d', '%s', '%s', '%d' );
		
		if ( ! empty( $args['expires_at'] ) ) {
			$insert_data['expires_at'] = $args['expires_at'];
			$format[] = '%s';
		}
		if ( ! empty( $args['subscription_type'] ) ) {
			$insert_data['subscription_type'] = $args['subscription_type'];
			$format[] = '%s';
		}
		if ( ! empty( $args['subscription_id'] ) ) {
			$insert_data['subscription_id'] = $args['subscription_id'];
			$format[] = '%s';
		}
		
		$result = $wpdb->insert( $table_name, $insert_data, $format );
		
		if ( $result === false ) {
			error_log( 'TS LMS WooIntegration: Database error - ' . $wpdb->last_error );
			return false;
		}
		
		if ( $result ) {
			error_log( 'TS LMS WooIntegration: New enrollment created - User #' . $user_id . ' in Course #' . $course_id );
			
			// Fire action for other plugins/modules to hook into
			do_action( 'ts_lms_user_enrolled', $user_id, $course_id, $order_id );
			return true;
		}
		
		return false;
	}

	/**
	 * Handle order status change.
	 *
	 * @param int    $order_id   Order ID.
	 * @param string $old_status Old status.
	 * @param string $new_status New status.
	 * @return void
	 */
	public static function handle_order_status_change( $order_id, $old_status, $new_status ) {
		if ( ! $order_id ) return;

		// Statuses that should remove access
		$remove_access_statuses = array( 'cancelled', 'refunded', 'failed' );
		
		// Statuses that should grant access
		$grant_access_statuses = array( 'completed' );

		if ( in_array( $new_status, $remove_access_statuses ) ) {
			self::update_enrollment_status( $order_id, 'cancelled' );
			error_log( "TS LMS WooIntegration: Order #{$order_id} status changed to {$new_status}. Enrollment cancelled." );
		} elseif ( in_array( $new_status, $grant_access_statuses ) ) {
			// First try to activate existing enrollment
			self::update_enrollment_status( $order_id, 'active' );
			
			// Then ensure enrollment exists (this will create if not exists, or reactivate if exists)
			// This handles the case where admin manually marks order as completed
			self::handle_order_completed( $order_id );
			
			error_log( "TS LMS WooIntegration: Order #{$order_id} status changed to {$new_status}. Enrollment processed." );
		}
	}

	/**
	 * Update enrollment status by order ID.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $status   New status.
	 * @return void
	 */
	private static function update_enrollment_status( $order_id, $status ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'ts_course_enrollments';
		
		$wpdb->update(
			$table_name,
			array( 'status' => $status ),
			array( 'order_id' => $order_id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Add product meta box for course linking.
	 *
	 * @return void
	 */
	public static function add_product_meta_box() {
		add_meta_box(
			'ts_lms_product_course',
			__( 'TS LMS Course', 'ts-lms' ),
			array( __CLASS__, 'render_product_meta_box' ),
			'product',
			'side',
			'default'
		);
	}

	/**
	 * Render product meta box.
	 *
	 * @param \WP_Post $post Post object.
	 * @return void
	 */
	public static function render_product_meta_box( $post ) {
		$linked_course = get_post_meta( $post->ID, '_linked_course', true );
		
		// Get all courses
		$courses = get_posts( array(
			'post_type'      => 'ts_course',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'orderby'        => 'title',
			'order'          => 'ASC',
		) );
		
		wp_nonce_field( 'ts_lms_product_course_nonce', 'ts_lms_product_course_nonce' );
		?>
		<p>
			<label for="ts_lms_linked_course"><?php esc_html_e( 'Link to Course:', 'ts-lms' ); ?></label>
			<select name="ts_lms_linked_course" id="ts_lms_linked_course" style="width: 100%;">
				<option value=""><?php esc_html_e( '-- Select Course --', 'ts-lms' ); ?></option>
				<?php foreach ( $courses as $course ) : ?>
					<option value="<?php echo esc_attr( $course->ID ); ?>" <?php selected( $linked_course, $course->ID ); ?>>
						<?php echo esc_html( $course->post_title ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</p>
		<p class="description">
			<?php esc_html_e( 'Select a course to automatically enroll users when they purchase this product.', 'ts-lms' ); ?>
		</p>
		<?php
	}

	/**
	 * Save product meta.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 * @return void
	 */
	public static function save_product_meta( $post_id, $post ) {
		// Check if this is a product
		if ( 'product' !== $post->post_type ) {
			return;
		}
		
		// Verify nonce
		if ( ! isset( $_POST['ts_lms_product_course_nonce'] ) || 
		     ! wp_verify_nonce( $_POST['ts_lms_product_course_nonce'], 'ts_lms_product_course_nonce' ) ) {
			return;
		}
		
		// Check autosave
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		
		// Check permissions
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		
		// Save linked course
		if ( isset( $_POST['ts_lms_linked_course'] ) ) {
			$course_id = absint( $_POST['ts_lms_linked_course'] );
			
			if ( $course_id > 0 ) {
				update_post_meta( $post_id, '_linked_course', $course_id );
			} else {
				delete_post_meta( $post_id, '_linked_course' );
			}
		}
	}

	/**
	 * Get course product ID.
	 * Supports bidirectional linking: checks both _course_product_id and _linked_course
	 *
	 * @param int $course_id Course ID.
	 * @return int|false Product ID or false if not found.
	 */
	public static function get_course_product_id( $course_id ) {
		// First, check if course has a direct link to product (_course_product_id)
		$product_id = get_post_meta( $course_id, '_course_product_id', true );
		
		if ( $product_id && get_post_type( $product_id ) === 'product' ) {
			return absint( $product_id );
		}
		
		// Fall back to reverse lookup (product has _linked_course)
		global $wpdb;
		$product_id = $wpdb->get_var( $wpdb->prepare(
			"SELECT post_id FROM {$wpdb->postmeta} 
			WHERE meta_key = '_linked_course' 
			AND meta_value = %d 
			LIMIT 1",
			$course_id
		) );
		
		return $product_id ? absint( $product_id ) : false;
	}
	
	/**
	 * Create a WooCommerce product for a course.
	 *
	 * @param int $course_id Course ID.
	 * @param array $args Optional. Product arguments.
	 * @return int|WP_Error Product ID on success, WP_Error on failure.
	 */
	public static function create_product_for_course( $course_id, $args = array() ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return new \WP_Error( 'woocommerce_not_active', __( 'WooCommerce is not active.', 'ts-lms' ) );
		}
		
		$course = get_post( $course_id );
		if ( ! $course || $course->post_type !== 'ts_course' ) {
			return new \WP_Error( 'invalid_course', __( 'Invalid course ID.', 'ts-lms' ) );
		}
		
		// Check if product already exists
		$existing_product_id = self::get_course_product_id( $course_id );
		if ( $existing_product_id ) {
			return new \WP_Error( 'product_exists', __( 'A product already exists for this course.', 'ts-lms' ) );
		}
		
		// Get course price
		$price_type = get_post_meta( $course_id, '_course_price_type', true );
		$price = ( $price_type === 'subscription' ) 
			? get_post_meta( $course_id, '_subscription_price', true ) 
			: get_post_meta( $course_id, '_course_price', true );
		
		// Prepare product data
		$product_data = wp_parse_args( $args, array(
			'post_title'   => $course->post_title,
			'post_content' => $course->post_content,
			'post_status'  => 'publish',
			'post_type'    => 'product',
		) );
		
		// Create the product
		$product_id = wp_insert_post( $product_data );
		
		if ( is_wp_error( $product_id ) ) {
			return $product_id;
		}
		
		// Set product as simple product
		wp_set_object_terms( $product_id, 'simple', 'product_type' );
		
		// Set price
		if ( $price ) {
			update_post_meta( $product_id, '_regular_price', $price );
			update_post_meta( $product_id, '_price', $price );
		}
		
		// Set as virtual product
		update_post_meta( $product_id, '_virtual', 'yes' );
		
		// Link product to course (bidirectional)
		update_post_meta( $product_id, '_linked_course', $course_id );
		update_post_meta( $course_id, '_course_product_id', $product_id );
		
		// Copy featured image
		$thumbnail_id = get_post_thumbnail_id( $course_id );
		if ( $thumbnail_id ) {
			set_post_thumbnail( $product_id, $thumbnail_id );
		}
		
		do_action( 'ts_lms_product_created_for_course', $product_id, $course_id );
		
		return $product_id;
	}
	
	/**
	 * Get the course ID linked to a product.
	 *
	 * @param int $product_id Product ID.
	 * @return int|false Course ID or false if not found.
	 */
	public static function get_product_course_id( $product_id ) {
		$course_id = get_post_meta( $product_id, '_linked_course', true );
		
		if ( $course_id && get_post_type( $course_id ) === 'ts_course' ) {
			return absint( $course_id );
		}
		
		return false;
	}
	
	/**
	 * Sync product and course data.
	 *
	 * @param int $course_id Course ID.
	 * @return bool True on success, false on failure.
	 */
	public static function sync_product_data( $course_id ) {
		$product_id = self::get_course_product_id( $course_id );
		
		if ( ! $product_id ) {
			return false;
		}
		
		$course = get_post( $course_id );
		$price_type = get_post_meta( $course_id, '_course_price_type', true );
		$price = ( $price_type === 'subscription' ) 
			? get_post_meta( $course_id, '_subscription_price', true ) 
			: get_post_meta( $course_id, '_course_price', true );
		
		// Update product title and content
		wp_update_post( array(
			'ID'           => $product_id,
			'post_title'   => $course->post_title,
			'post_content' => $course->post_content,
		) );
		
		// Update price
		if ( $price ) {
			update_post_meta( $product_id, '_regular_price', $price );
			update_post_meta( $product_id, '_price', $price );
		}
		
		return true;
	}

	/**
	 * Check if course is in cart.
	 *
	 * @param int $course_id Course ID.
	 * @return bool True if in cart, false otherwise.
	 */
	public static function is_course_in_cart( $course_id ) {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return false;
		}
		
		$product_id = self::get_course_product_id( $course_id );
		
		if ( ! $product_id ) {
			return false;
		}
		
		foreach ( WC()->cart->get_cart() as $cart_item ) {
			if ( $cart_item['product_id'] === $product_id ) {
				return true;
			}
		}
		
		return false;
	}

	/**
	 * Hide course products from WooCommerce shop page.
	 *
	 * @param WP_Query $query Query object.
	 * @return void
	 */
	public static function hide_course_products_from_shop( $query ) {
		// Only apply on frontend
		if ( is_admin() ) {
			return;
		}

		// Check if the setting is enabled (default is enabled)
		$settings = \TS_LMS\Admin\Settings::get_settings();
		$hide_products = isset( $settings['hide_course_products_shop'] ) ? $settings['hide_course_products_shop'] : 1;

		// If setting is disabled, don't filter
		if ( ! $hide_products ) {
			return;
		}

		// Target WooCommerce queries and product queries on frontend
		$post_type = $query->get( 'post_type' );
		$is_product_query = $post_type === 'product' || 
							( is_array( $post_type ) && in_array( 'product', $post_type ) );

		// If it's not a product-related query on the frontend, bail
		if ( ! $is_product_query ) {
			return;
		}

		// Don't filter single product pages
		if ( is_singular( 'product' ) && $query->is_main_query() ) {
			return;
		}

		// Get all product IDs that are linked to courses (with caching)
		$all_course_products = self::get_all_course_product_ids();

		// If there are course products, exclude them from the query
		if ( ! empty( $all_course_products ) ) {
			$post_not_in = (array) $query->get( 'post__not_in' );
			$query->set( 'post__not_in', array_unique( array_merge( $post_not_in, array_map( 'absint', $all_course_products ) ) ) );
		}
	}

	/**
	 * Filter product visibility to ensure they are hidden even if query filter fails.
	 *
	 * @param bool $visible Whether the product is visible.
	 * @param int  $product_id Product ID.
	 * @return bool
	 */
	public static function course_product_visibility_filter( $visible, $product_id ) {
		if ( is_admin() || ! $visible ) {
			return $visible;
		}

		$settings = \TS_LMS\Admin\Settings::get_settings();
		$hide_products = isset( $settings['hide_course_products_shop'] ) ? $settings['hide_course_products_shop'] : 1;

		if ( ! $hide_products ) {
			return $visible;
		}

		// Don't hide on the single product page itself
		if ( is_singular( 'product' ) && get_the_ID() == $product_id ) {
			return $visible;
		}

		$course_products = self::get_all_course_product_ids();
		if ( in_array( (string)$product_id, $course_products ) || in_array( (int)$product_id, $course_products ) ) {
			return false;
		}

		return $visible;
	}

	/**
	 * Get all product IDs that are linked to courses.
	 * Uses transient caching to improve performance.
	 *
	 * @return array Array of product IDs.
	 */
	private static function get_all_course_product_ids() {
		// Try to get from cache first
		$cache_key = 'ts_lms_course_product_ids';
		$cached_ids = get_transient( $cache_key );

		if ( false !== $cached_ids ) {
			return $cached_ids;
		}

		global $wpdb;
		
		// Method 1: Products with _linked_course meta
		$linked_products = $wpdb->get_col(
			"SELECT post_id FROM {$wpdb->postmeta} 
			WHERE meta_key = '_linked_course' 
			AND meta_value != '' 
			AND meta_value != '0'"
		);

		// Method 2: Get courses with _course_product_id and extract the product IDs
		$course_products = $wpdb->get_col(
			"SELECT meta_value FROM {$wpdb->postmeta} 
			WHERE meta_key = '_course_product_id' 
			AND meta_value != '' 
			AND meta_value != '0'"
		);

		// Merge both arrays and get unique product IDs
		$all_course_products = array_unique( array_merge( $linked_products, $course_products ) );

		// Cache for 1 hour
		set_transient( $cache_key, $all_course_products, HOUR_IN_SECONDS );

		return $all_course_products;
	}

	/**
	 * Clear product cache when course-product links are updated.
	 *
	 * @param int    $meta_id    ID of updated metadata entry.
	 * @param int    $object_id  Post ID.
	 * @param string $meta_key   Meta key.
	 * @param mixed  $meta_value Meta value.
	 * @return void
	 */
	public static function clear_product_cache_on_meta_update( $meta_id, $object_id, $meta_key, $meta_value ) {
		// Only clear cache if the meta key is related to course-product linking
		if ( in_array( $meta_key, array( '_linked_course', '_course_product_id' ) ) ) {
			delete_transient( 'ts_lms_course_product_ids' );
		}
	}

	/**
	 * Add custom column to product list table.
	 *
	 * @param array $columns Existing columns.
	 * @return array Modified columns.
	 */
	public static function add_course_product_column( $columns ) {
		// Insert after the product name column
		$new_columns = array();
		foreach ( $columns as $key => $value ) {
			$new_columns[ $key ] = $value;
			if ( $key === 'name' ) {
				$new_columns['ts_lms_course'] = __( 'Course Product', 'ts-lms' );
			}
		}
		return $new_columns;
	}

	/**
	 * Render custom column content.
	 *
	 * @param string $column  Column name.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public static function render_course_product_column( $column, $post_id ) {
		if ( $column === 'ts_lms_course' ) {
			$course_id = get_post_meta( $post_id, '_linked_course', true );
			
			if ( $course_id ) {
				$course = get_post( $course_id );
				if ( $course ) {
					echo '<span class="ts-lms-course-badge">';
					echo '<span class="dashicons dashicons-welcome-learn-more"></span> ';
					echo esc_html( $course->post_title );
					echo '</span>';
				}
			}
		}
	}

	/**
	 * Add custom styles for course product badge.
	 *
	 * @return void
	 */
	public static function add_course_product_badge_styles() {
		$screen = get_current_screen();
		if ( ! $screen || $screen->id !== 'edit-product' ) {
			return;
		}
		?>
		<style>
			.ts-lms-course-badge {
				display: inline-flex;
				align-items: center;
				gap: 4px;
				padding: 4px 8px;
				background: #e8f5e9;
				color: #2e7d32;
				border-radius: 4px;
				font-size: 12px;
				font-weight: 500;
				white-space: nowrap;
			}
			.ts-lms-course-badge .dashicons {
				width: 16px;
				height: 16px;
				font-size: 16px;
			}
			.column-ts_lms_course {
				width: 200px;
			}
		</style>
		<?php
	}
}
