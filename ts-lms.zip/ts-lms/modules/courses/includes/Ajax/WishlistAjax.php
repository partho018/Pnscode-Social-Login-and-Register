<?php
/**
 * Wishlist AJAX Handler
 *
 * @package TS_LMS\Modules\Courses\Ajax
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Ajax;

use TS_LMS\Modules\Courses\Managers\WishlistManager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * WishlistAjax class.
 */
class WishlistAjax {

    /**
     * Initialize the class.
     */
    public static function init() {
        add_action( 'wp_ajax_ts_lms_toggle_wishlist', array( __CLASS__, 'toggle_wishlist' ) );
        add_action( 'wp_ajax_nopriv_ts_lms_toggle_wishlist', array( __CLASS__, 'toggle_wishlist' ) );
    }

    /**
     * Toggle wishlist status via AJAX.
     */
    public static function toggle_wishlist() {
        check_ajax_referer( 'ts_lms_nonce', 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => __( 'Please login to add to wishlist.', 'ts-lms' ) ) );
        }

        $course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
        $user_id   = get_current_user_id();

        if ( ! $course_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid course ID.', 'ts-lms' ) ) );
        }

        $status = WishlistManager::toggle_wishlist( $course_id, $user_id );

        wp_send_json_success( array(
            'status'  => $status,
            'message' => $status === 'added' ? __( 'Added to wishlist!', 'ts-lms' ) : __( 'Removed from wishlist!', 'ts-lms' )
        ) );
    }
}
