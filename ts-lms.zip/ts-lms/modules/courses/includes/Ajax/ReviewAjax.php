<?php
/**
 * Review AJAX Handler
 *
 * Handles AJAX requests for course reviews.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Ajax;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use TS_LMS\Modules\Courses\Managers\CourseManager;

/**
 * ReviewAjax class.
 */
class ReviewAjax {

    /**
     * Initialize AJAX handlers.
     *
     * @return void
     */
    public static function init() {
        add_action( 'wp_ajax_ts_submit_review', array( __CLASS__, 'submit_review' ) );
    }

    /**
     * Handle review submission.
     *
     * @return void
     */
    public static function submit_review() {
        // Check nonce
        if ( ! isset( $_POST['review_nonce'] ) || ! wp_verify_nonce( $_POST['review_nonce'], 'ts_review_nonce' ) ) {
            wp_send_json_error( array(
                'message' => __( 'Security check failed.', 'ts-lms' )
            ) );
        }

        // Check if user is logged in
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array(
                'message' => __( 'You must be logged in to submit a review.', 'ts-lms' )
            ) );
        }

        $user_id    = get_current_user_id();
        $course_id  = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
        $rating     = isset( $_POST['rating'] ) ? absint( $_POST['rating'] ) : 0;
        $title      = isset( $_POST['review_title'] ) ? sanitize_text_field( $_POST['review_title'] ) : '';
        $content    = isset( $_POST['review_content'] ) ? sanitize_textarea_field( $_POST['review_content'] ) : '';

        // Validation
        if ( ! $course_id ) {
            wp_send_json_error( array(
                'message' => __( 'Invalid course.', 'ts-lms' )
            ) );
        }

        if ( $rating < 1 || $rating > 5 ) {
            wp_send_json_error( array(
                'message' => __( 'Please select a rating between 1 and 5.', 'ts-lms' )
            ) );
        }

        if ( empty( $title ) || empty( $content ) ) {
            wp_send_json_error( array(
                'message' => __( 'Please fill in all fields.', 'ts-lms' )
            ) );
        }

        // Check if user is enrolled
        $is_enrolled = CourseManager::is_enrolled( $course_id, $user_id );
        if ( ! $is_enrolled ) {
            wp_send_json_error( array(
                'message' => __( 'You must be enrolled in this course to submit a review.', 'ts-lms' )
            ) );
        }

        global $wpdb;

        // Check if user already reviewed
        $existing_review = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ts_course_reviews WHERE course_id = %d AND user_id = %d",
            $course_id,
            $user_id
        ) );

        if ( $existing_review ) {
            wp_send_json_error( array(
                'message' => __( 'You have already submitted a review for this course.', 'ts-lms' )
            ) );
        }

        // Insert review
        $inserted = $wpdb->insert(
            $wpdb->prefix . 'ts_course_reviews',
            array(
                'course_id'  => $course_id,
                'user_id'    => $user_id,
                'rating'     => $rating,
                'title'      => $title,
                'content'    => $content,
                'status'     => 'approved', // Auto-approve reviews, you can change this to 'pending' for moderation
                'created_at' => current_time( 'mysql' ),
            ),
            array( '%d', '%d', '%d', '%s', '%s', '%s', '%s' )
        );

        if ( $inserted ) {
            wp_send_json_success( array(
                'message' => __( 'Thank you! Your review has been submitted successfully.', 'ts-lms' )
            ) );
        } else {
            wp_send_json_error( array(
                'message' => __( 'Failed to submit review. Please try again.', 'ts-lms' )
            ) );
        }
    }
}
