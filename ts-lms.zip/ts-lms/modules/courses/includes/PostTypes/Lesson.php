<?php
/**
 * Lesson Post Type
 *
 * Registers and manages the Lesson custom post type.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\PostTypes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Lesson class.
 */
class Lesson {

    /**
     * Post type name.
     *
     * @var string
     */
    const POST_TYPE = 'ts_lesson';

    /**
     * Initialize the lesson post type.
     *
     * @return void
     */
    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_post_type' ) );
        add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save_meta' ), 10, 2 );
    }

    /**
     * Register the lesson post type.
     *
     * @return void
     */
    public static function register_post_type() {
        $labels = array(
            'name'                  => _x( 'Lessons', 'Post type general name', 'ts-lms' ),
            'singular_name'         => _x( 'Lesson', 'Post type singular name', 'ts-lms' ),
            'menu_name'             => _x( 'Lessons', 'Admin Menu text', 'ts-lms' ),
            'name_admin_bar'        => _x( 'Lesson', 'Add New on Toolbar', 'ts-lms' ),
            'add_new'               => __( 'Add New', 'ts-lms' ),
            'add_new_item'          => __( 'Add New Lesson', 'ts-lms' ),
            'new_item'              => __( 'New Lesson', 'ts-lms' ),
            'edit_item'             => __( 'Edit Lesson', 'ts-lms' ),
            'view_item'             => __( 'View Lesson', 'ts-lms' ),
            'all_items'             => __( 'All Lessons', 'ts-lms' ),
            'search_items'          => __( 'Search Lessons', 'ts-lms' ),
            'parent_item_colon'     => __( 'Parent Lessons:', 'ts-lms' ),
            'not_found'             => __( 'No lessons found.', 'ts-lms' ),
            'not_found_in_trash'    => __( 'No lessons found in Trash.', 'ts-lms' ),
            'featured_image'        => _x( 'Lesson Image', 'Overrides the "Featured Image" phrase', 'ts-lms' ),
            'set_featured_image'    => _x( 'Set lesson image', 'Overrides the "Set featured image" phrase', 'ts-lms' ),
            'remove_featured_image' => _x( 'Remove lesson image', 'Overrides the "Remove featured image" phrase', 'ts-lms' ),
            'use_featured_image'    => _x( 'Use as lesson image', 'Overrides the "Use as featured image" phrase', 'ts-lms' ),
            'archives'              => _x( 'Lesson archives', 'The post type archive label', 'ts-lms' ),
            'insert_into_item'      => _x( 'Insert into lesson', 'Overrides the "Insert into post" phrase', 'ts-lms' ),
            'uploaded_to_this_item' => _x( 'Uploaded to this lesson', 'Overrides the "Uploaded to this post" phrase', 'ts-lms' ),
            'filter_items_list'     => _x( 'Filter lessons list', 'Screen reader text', 'ts-lms' ),
            'items_list_navigation' => _x( 'Lessons list navigation', 'Screen reader text', 'ts-lms' ),
            'items_list'            => _x( 'Lessons list', 'Screen reader text', 'ts-lms' ),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => false, // Hide from admin menu
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'ts-lesson', 'with_front' => false ),
            'capability_type'    => array( 'ts_lesson', 'ts_lessons' ),
            'map_meta_cap'       => true,
            'has_archive'        => true,
            'hierarchical'       => false,
            'supports'           => array( 'title', 'editor', 'thumbnail', 'custom-fields', 'author' ),
            'show_in_rest'       => true,
        );

        register_post_type( self::POST_TYPE, $args );
    }

    /**
     * Save lesson meta data.
     *
     * @param int     $post_id Post ID.
     * @param WP_Post $post    Post object.
     * @return void
     */
    public static function save_meta( $post_id, $post ) {
        // Check if this is an autosave
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // Check user permissions
        if ( ! current_user_can( 'edit_ts_lesson', $post_id ) ) {
            return;
        }

        // Save lesson type
        if ( isset( $_POST['_lesson_type'] ) ) {
            $type = sanitize_text_field( $_POST['_lesson_type'] );
            update_post_meta( $post_id, '_lesson_type', $type );
        }

        // Save course ID
        if ( isset( $_POST['_lesson_course_id'] ) ) {
            $course_id = absint( $_POST['_lesson_course_id'] );
            update_post_meta( $post_id, '_lesson_course_id', $course_id );
        }

        // Save lesson duration
        if ( isset( $_POST['_lesson_duration'] ) ) {
            $duration = absint( $_POST['_lesson_duration'] );
            update_post_meta( $post_id, '_lesson_duration', $duration );
        }

        // Save video URL
        if ( isset( $_POST['_lesson_video_url'] ) ) {
            $video_url = esc_url_raw( $_POST['_lesson_video_url'] );
            update_post_meta( $post_id, '_lesson_video_url', $video_url );
        }

        // Save video type
        if ( isset( $_POST['_lesson_video_type'] ) ) {
            $video_type = sanitize_text_field( $_POST['_lesson_video_type'] );
            update_post_meta( $post_id, '_lesson_video_type', $video_type );
        }

        // Save drip type
        if ( isset( $_POST['_lesson_drip_type'] ) ) {
            $drip_type = sanitize_text_field( $_POST['_lesson_drip_type'] );
            update_post_meta( $post_id, '_lesson_drip_type', $drip_type );
        }

        // Save drip days
        if ( isset( $_POST['_lesson_drip_days'] ) ) {
            $drip_days = absint( $_POST['_lesson_drip_days'] );
            update_post_meta( $post_id, '_lesson_drip_days', $drip_days );
        }

        // Save drip prerequisite
        if ( isset( $_POST['_lesson_drip_prerequisite'] ) ) {
            $prerequisite = absint( $_POST['_lesson_drip_prerequisite'] );
            update_post_meta( $post_id, '_lesson_drip_prerequisite', $prerequisite );
        }

        // Save attachments
        if ( isset( $_POST['_lesson_attachments'] ) && is_array( $_POST['_lesson_attachments'] ) ) {
            $attachments = array_map( 'absint', $_POST['_lesson_attachments'] );
            update_post_meta( $post_id, '_lesson_attachments', $attachments );
        }

        // Fire action hook
        do_action( 'ts_lms_lesson_saved', $post_id, $post );
    }

    /**
     * Get available lesson types.
     *
     * @return array Lesson types.
     */
    public static function get_types() {
        $types = array(
            'video'      => __( 'Video', 'ts-lms' ),
            'text'       => __( 'Text', 'ts-lms' ),
            'quiz'       => __( 'Quiz', 'ts-lms' ),
            'assignment' => __( 'Assignment', 'ts-lms' ),
            'live_class' => __( 'Live Class', 'ts-lms' ),
        );

        return apply_filters( 'ts_lms_lesson_types', $types );
    }

    /**
     * Get available video types.
     *
     * @return array Video types.
     */
    public static function get_video_types() {
        $types = array(
            'youtube'     => __( 'YouTube', 'ts-lms' ),
            'vimeo'       => __( 'Vimeo', 'ts-lms' ),
            'self_hosted' => __( 'Self Hosted', 'ts-lms' ),
        );

        return apply_filters( 'ts_lms_video_types', $types );
    }

    /**
     * Get available drip types.
     *
     * @return array Drip types.
     */
    public static function get_drip_types() {
        $types = array(
            'none'           => __( 'No Drip', 'ts-lms' ),
            'time_based'     => __( 'Time Based', 'ts-lms' ),
            'progress_based' => __( 'Progress Based', 'ts-lms' ),
        );

        return apply_filters( 'ts_lms_drip_types', $types );
    }
}
