<?php
/**
 * Quiz Post Type (Stub)
 *
 * Basic registration for Quiz custom post type.
 * Full implementation to be added in future versions.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\PostTypes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Quiz class.
 */
class Quiz {

    /**
     * Post type name.
     *
     * @var string
     */
    const POST_TYPE = 'ts_quiz';

    /**
     * Initialize the quiz post type.
     *
     * @return void
     */
    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_post_type' ) );
    }

    /**
     * Register the quiz post type.
     *
     * @return void
     */
    public static function register_post_type() {
        $labels = array(
            'name'                  => _x( 'Quizzes', 'Post type general name', 'ts-lms' ),
            'singular_name'         => _x( 'Quiz', 'Post type singular name', 'ts-lms' ),
            'menu_name'             => _x( 'Quizzes', 'Admin Menu text', 'ts-lms' ),
            'name_admin_bar'        => _x( 'Quiz', 'Add New on Toolbar', 'ts-lms' ),
            'add_new'               => __( 'Add New', 'ts-lms' ),
            'add_new_item'          => __( 'Add New Quiz', 'ts-lms' ),
            'new_item'              => __( 'New Quiz', 'ts-lms' ),
            'edit_item'             => __( 'Edit Quiz', 'ts-lms' ),
            'view_item'             => __( 'View Quiz', 'ts-lms' ),
            'all_items'             => __( 'All Quizzes', 'ts-lms' ),
            'search_items'          => __( 'Search Quizzes', 'ts-lms' ),
            'not_found'             => __( 'No quizzes found.', 'ts-lms' ),
            'not_found_in_trash'    => __( 'No quizzes found in Trash.', 'ts-lms' ),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => false, // Hide from admin menu
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'ts-quiz', 'with_front' => false ),
            'capability_type'    => array( 'ts_quiz', 'ts_quizzes' ),
            'map_meta_cap'       => true,
            'has_archive'        => true,
            'hierarchical'       => false,

            'supports'           => array( 'title', 'editor' ),
            'show_in_rest'       => true,
        );

        register_post_type( self::POST_TYPE, $args );
    }
}
