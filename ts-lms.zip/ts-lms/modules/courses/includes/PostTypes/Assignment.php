<?php
/**
 * Assignment Post Type (Stub)
 *
 * Basic registration for Assignment custom post type.
 * Full implementation to be added in future versions.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\PostTypes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Assignment class.
 */
class Assignment {

    /**
     * Post type name.
     *
     * @var string
     */
    const POST_TYPE = 'ts_assignment';

    /**
     * Initialize the assignment post type.
     *
     * @return void
     */
    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_post_type' ) );
    }

    /**
     * Register the assignment post type.
     *
     * @return void
     */
    public static function register_post_type() {
        $labels = array(
            'name'                  => _x( 'Assignments', 'Post type general name', 'ts-lms' ),
            'singular_name'         => _x( 'Assignment', 'Post type singular name', 'ts-lms' ),
            'menu_name'             => _x( 'Assignments', 'Admin Menu text', 'ts-lms' ),
            'name_admin_bar'        => _x( 'Assignment', 'Add New on Toolbar', 'ts-lms' ),
            'add_new'               => __( 'Add New', 'ts-lms' ),
            'add_new_item'          => __( 'Add New Assignment', 'ts-lms' ),
            'new_item'              => __( 'New Assignment', 'ts-lms' ),
            'edit_item'             => __( 'Edit Assignment', 'ts-lms' ),
            'view_item'             => __( 'View Assignment', 'ts-lms' ),
            'all_items'             => __( 'All Assignments', 'ts-lms' ),
            'search_items'          => __( 'Search Assignments', 'ts-lms' ),
            'not_found'             => __( 'No assignments found.', 'ts-lms' ),
            'not_found_in_trash'    => __( 'No assignments found in Trash.', 'ts-lms' ),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => false, // Hide from admin menu
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'ts-assignment', 'with_front' => false ),
            'capability_type'    => array( 'ts_assignment', 'ts_assignments' ),
            'map_meta_cap'       => true,
            'has_archive'        => true,
            'hierarchical'       => false,

            'supports'           => array( 'title', 'editor' ),
            'show_in_rest'       => true,
        );

        register_post_type( self::POST_TYPE, $args );
    }
}
