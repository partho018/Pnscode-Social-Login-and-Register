<?php
/**
 * Course Post Type
 *
 * Registers and manages the Course custom post type.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\PostTypes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Course class.
 */
class Course {

    /**
     * Post type name.
     *
     * @var string
     */
    const POST_TYPE = 'ts_course';

    /**
     * Initialize the course post type.
     *
     * @return void
     */
    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_post_type' ) );
        add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save_meta' ), 10, 2 );
        add_action( 'admin_init', array( __CLASS__, 'redirect_to_custom_page' ) );
    }


    /**
     * Redirect from default WordPress edit.php page to custom course list page.
     *
     * @return void
     */
    public static function redirect_to_custom_page() {
        global $pagenow;
        
        // Return early if we are on Category or Tag pages
        if ( isset( $_GET['taxonomy'] ) ) {
            return;
        }

        // ONLY redirect if we are EXACTLY on edit.php for ts_course
        if ( 'edit.php' === $pagenow && isset( $_GET['post_type'] ) && self::POST_TYPE === $_GET['post_type'] ) {
            // Redirect to custom course list page
            wp_safe_redirect( admin_url( 'admin.php?page=ts-lms-course' ) );
            exit;
        }
    }

    /**
     * Register the course post type.
     *
     * @return void
     */
    public static function register_post_type() {
        $labels = array(
            'name'                  => _x( 'Courses', 'Post type general name', 'ts-lms' ),
            'singular_name'         => _x( 'Course', 'Post type singular name', 'ts-lms' ),
            'menu_name'             => _x( 'Courses', 'Admin Menu text', 'ts-lms' ),
            'name_admin_bar'        => _x( 'Course', 'Add New on Toolbar', 'ts-lms' ),
            'add_new'               => __( 'Add New', 'ts-lms' ),
            'add_new_item'          => __( 'Add New Course', 'ts-lms' ),
            'new_item'              => __( 'New Course', 'ts-lms' ),
            'edit_item'             => __( 'Edit Course', 'ts-lms' ),
            'view_item'             => __( 'View Course', 'ts-lms' ),
            'all_items'             => __( 'All Courses', 'ts-lms' ),
            'search_items'          => __( 'Search Courses', 'ts-lms' ),
            'parent_item_colon'     => __( 'Parent Courses:', 'ts-lms' ),
            'not_found'             => __( 'No courses found.', 'ts-lms' ),
            'not_found_in_trash'    => __( 'No courses found in Trash.', 'ts-lms' ),
            'featured_image'        => _x( 'Course Cover Image', 'Overrides the "Featured Image" phrase', 'ts-lms' ),
            'set_featured_image'    => _x( 'Set cover image', 'Overrides the "Set featured image" phrase', 'ts-lms' ),
            'remove_featured_image' => _x( 'Remove cover image', 'Overrides the "Remove featured image" phrase', 'ts-lms' ),
            'use_featured_image'    => _x( 'Use as cover image', 'Overrides the "Use as featured image" phrase', 'ts-lms' ),
            'archives'              => _x( 'Course archives', 'The post type archive label', 'ts-lms' ),
            'insert_into_item'      => _x( 'Insert into course', 'Overrides the "Insert into post" phrase', 'ts-lms' ),
            'uploaded_to_this_item' => _x( 'Uploaded to this course', 'Overrides the "Uploaded to this post" phrase', 'ts-lms' ),
            'filter_items_list'     => _x( 'Filter courses list', 'Screen reader text', 'ts-lms' ),
            'items_list_navigation' => _x( 'Courses list navigation', 'Screen reader text', 'ts-lms' ),
            'items_list'            => _x( 'Courses list', 'Screen reader text', 'ts-lms' ),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => false, // Keep false to hide from sidebar, but show_ui allows backend access
            'show_in_nav_menus'  => true,
            'query_var'          => true,
            'rewrite'            => array( 
                'slug'       => 'course',
                'with_front' => false,
            ),
            'capability_type'    => array( 'ts_course', 'ts_courses' ),
            'map_meta_cap'       => true,
            'has_archive'        => false,
            'hierarchical'       => false,
            'menu_icon'          => 'dashicons-welcome-learn-more',
            		'supports'           => array( 'title', 'thumbnail', 'excerpt', 'custom-fields', 'author' ),
		'show_in_rest'       => false,
        );

        register_post_type( self::POST_TYPE, $args );
    }

    /**
     * Save course meta data.
     *
     * @param int     $post_id Post ID.
     * @param WP_Post $post    Post object.
     * @return void
     */
    public static function save_meta( $post_id, $post ) {
        // Check if this is an autosave
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // Check user permissions
        if ( ! current_user_can( 'edit_ts_course', $post_id ) ) {
            return;
        }

        // Save course status
        if ( isset( $_POST['_course_status'] ) ) {
            $status = sanitize_text_field( $_POST['_course_status'] );
            update_post_meta( $post_id, '_course_status', $status );
        }

        // Save course duration
        if ( isset( $_POST['_course_duration'] ) ) {
            $duration = absint( $_POST['_course_duration'] );
            update_post_meta( $post_id, '_course_duration', $duration );
        }

        // Save course level
        if ( isset( $_POST['_course_level'] ) ) {
            $level = sanitize_text_field( $_POST['_course_level'] );
            update_post_meta( $post_id, '_course_level', $level );
        }

        // Save max students
        if ( isset( $_POST['_course_max_students'] ) ) {
            $max_students = absint( $_POST['_course_max_students'] );
            update_post_meta( $post_id, '_course_max_students', $max_students );
        }

        // Save start date
        if ( isset( $_POST['_course_start_date'] ) ) {
            $start_date = sanitize_text_field( $_POST['_course_start_date'] );
            update_post_meta( $post_id, '_course_start_date', $start_date );
        }

        // Save end date
        if ( isset( $_POST['_course_end_date'] ) ) {
            $end_date = sanitize_text_field( $_POST['_course_end_date'] );
            update_post_meta( $post_id, '_course_end_date', $end_date );
        }

        // Save Video URL
        if ( isset( $_POST['ts_course_video_url'] ) ) {
            $video_url = esc_url_raw( $_POST['ts_course_video_url'] );
            update_post_meta( $post_id, '_course_intro_video_url', $video_url );
            if ( ! empty( $video_url ) ) {
                update_post_meta( $post_id, '_course_intro_video_source', 'url' );
            } else {
                // If empty, maybe check if we should revert to upload or none? 
                // For now, if url is cleared, we don't necessarily clear source unless we know upload is empty too.
                // But let's assume if url is cleared, source might not be url anymore.
                // update_post_meta( $post_id, '_course_intro_video_source', '' ); 
            }
        }

        // Fire action hook
        do_action( 'ts_lms_course_saved', $post_id, $post );
    }

    /**
     * Get available course statuses.
     *
     * @return array Course statuses.
     */
    public static function get_statuses() {
        $statuses = array(
            'upcoming'  => __( 'Upcoming', 'ts-lms' ),
            'active'    => __( 'Active', 'ts-lms' ),
            'completed' => __( 'Completed', 'ts-lms' ),
        );

        return apply_filters( 'ts_lms_course_statuses', $statuses );
    }

    /**
     * Get available course levels.
     *
     * @return array Course levels.
     */
    public static function get_levels() {
        $levels = array(
            'beginner'     => __( 'Beginner', 'ts-lms' ),
            'intermediate' => __( 'Intermediate', 'ts-lms' ),
            'advanced'     => __( 'Advanced', 'ts-lms' ),
        );

        return apply_filters( 'ts_lms_course_levels', $levels );
    }

    /**
     * Get course requirements.
     *
     * @param int $course_id Course ID.
     * @return array Course requirements.
     */
    public static function get_requirements( $course_id ) {
        if ( empty( $course_id ) ) {
            return array();
        }

        $requirements = get_post_meta( $course_id, '_course_requirements', true );
        
        if ( ! is_array( $requirements ) ) {
            $requirements = array();
        }

        return apply_filters( 'ts_lms_course_requirements', $requirements, $course_id );
    }

    /**
     * Get course learning outcomes.
     *
     * @param int $course_id Course ID.
     * @return array Course learning outcomes.
     */
    public static function get_outcomes( $course_id ) {
        if ( empty( $course_id ) ) {
            return array();
        }

        $outcomes = get_post_meta( $course_id, '_course_outcomes', true );
        
        if ( ! is_array( $outcomes ) ) {
            $outcomes = array();
        }

        return apply_filters( 'ts_lms_course_outcomes', $outcomes, $course_id );
    }

    /**
     * Get course intro video data.
     *
     * @param int $course_id Course ID.
     * @return array Video data with keys: source (upload|url), id, url.
     */
    public static function get_intro_video( $course_id ) {
        $default = array(
            'source' => '',
            'id'     => '',
            'url'    => '',
        );

        if ( empty( $course_id ) ) {
            return $default;
        }

        // Get video source type
        $source = get_post_meta( $course_id, '_course_intro_video_source', true );
        
        if ( 'upload' === $source ) {
            $video_id = get_post_meta( $course_id, '_course_intro_video_id', true );
            $video_url = $video_id ? wp_get_attachment_url( $video_id ) : '';
            
            return array(
                'source' => 'upload',
                'id'     => $video_id,
                'url'    => $video_url,
            );
        } elseif ( 'url' === $source ) {
            $video_url = get_post_meta( $course_id, '_course_intro_video_url', true );
            
            return array(
                'source' => 'url',
                'id'     => '',
                'url'    => $video_url,
            );
        }

        return $default;
    }
}
