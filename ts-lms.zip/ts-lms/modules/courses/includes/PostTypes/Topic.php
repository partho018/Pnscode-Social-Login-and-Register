<?php
/**
 * Topic Post Type
 *
 * Registers and manages the Topic custom post type.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\PostTypes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Topic class.
 */
class Topic {

    /**
     * Post type name.
     *
     * @var string
     */
    const POST_TYPE = 'ts_topic';

    /**
     * Initialize the topic post type.
     *
     * @return void
     */
    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_post_type' ) );
        add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save_meta' ), 10, 2 );
    }

    /**
     * Register the topic post type.
     *
     * @return void
     */
    public static function register_post_type() {
        $labels = array(
            'name'                  => _x( 'Topics', 'Post type general name', 'ts-lms' ),
            'singular_name'         => _x( 'Topic', 'Post type singular name', 'ts-lms' ),
            'menu_name'             => _x( 'Topics', 'Admin Menu text', 'ts-lms' ),
            'add_new'               => __( 'Add New', 'ts-lms' ),
            'add_new_item'          => __( 'Add New Topic', 'ts-lms' ),
            'new_item'              => __( 'New Topic', 'ts-lms' ),
            'edit_item'             => __( 'Edit Topic', 'ts-lms' ),
            'view_item'             => __( 'View Topic', 'ts-lms' ),
            'all_items'             => __( 'All Topics', 'ts-lms' ),
            'search_items'          => __( 'Search Topics', 'ts-lms' ),
            'parent_item_colon'     => __( 'Parent Topics:', 'ts-lms' ),
            'not_found'             => __( 'No topics found.', 'ts-lms' ),
            'not_found_in_trash'    => __( 'No topics found in Trash.', 'ts-lms' ),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => false,
            'publicly_queryable' => false,
            'show_ui'            => true,
            'show_in_menu'       => false,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'topics' ),
            'capability_type'    => 'post',
            'has_archive'        => false,
            'hierarchical'       => false,
            'supports'           => array( 'title', 'editor', 'page-attributes', 'author' ),
            'show_in_rest'       => true,
        );

        register_post_type( self::POST_TYPE, $args );
    }

    /**
     * Save topic meta data.
     *
     * @param int     $post_id Post ID.
     * @param WP_Post $post    Post object.
     * @return void
     */
    public static function save_meta( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // Save course ID if provided
        if ( isset( $_POST['_topic_course_id'] ) ) {
            update_post_meta( $post_id, '_topic_course_id', absint( $_POST['_topic_course_id'] ) );
        }
    }
}
