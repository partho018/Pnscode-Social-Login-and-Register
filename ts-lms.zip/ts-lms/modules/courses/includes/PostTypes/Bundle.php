<?php
/**
 * Bundle Post Type
 *
 * Registers and manages the Course Bundle custom post type.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\PostTypes;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bundle class.
 */
class Bundle {

	/**
	 * Post type name.
	 *
	 * @var string
	 */
	const POST_TYPE = 'ts_bundle';

	/**
	 * Initialize the bundle post type.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'save_meta' ), 10, 2 );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
		
		// Fix permalink generation
		add_filter( 'post_type_link', array( __CLASS__, 'fix_bundle_permalink' ), 10, 2 );
	}

	/**
	 * Force bundle permalinks to use 'bundle' slug prefix.
	 */
	public static function fix_bundle_permalink( $post_link, $post ) {
		if ( self::POST_TYPE === $post->post_type ) {
			return home_url( 'bundle/' . $post->post_name . '/' );
		}
		return $post_link;
	}

	/**
	 * Register the bundle post type.
	 *
	 * @return void
	 */
	public static function register_post_type() {
		$labels = array(
			'name'                  => _x( 'Courses', 'Post type general name', 'ts-lms' ),
			'singular_name'         => _x( 'Course', 'Post type singular name', 'ts-lms' ),
			'menu_name'             => _x( 'Courses', 'Admin Menu text', 'ts-lms' ),
			'name_admin_bar'        => _x( 'Course', 'Add New on Toolbar', 'ts-lms' ),
			'add_new'               => __( 'Add New', 'ts-lms' ),
			'add_new_item'          => __( 'Add New Bundle', 'ts-lms' ),
			'new_item'              => __( 'New Bundle', 'ts-lms' ),
			'edit_item'             => __( 'Edit Bundle', 'ts-lms' ),
			'view_item'             => __( 'View Bundle', 'ts-lms' ),
			'all_items'             => __( 'All Bundles', 'ts-lms' ),
			'search_items'          => __( 'Search Courses', 'ts-lms' ),
			'parent_item_colon'     => __( 'Parent Courses:', 'ts-lms' ),
			'not_found'             => __( 'No courses found.', 'ts-lms' ),
			'not_found_in_trash'    => __( 'No bundles found in Trash.', 'ts-lms' ),
			'featured_image'        => _x( 'Bundle Image', 'Overrides the "Featured Image" phrase', 'ts-lms' ),
			'set_featured_image'    => _x( 'Set bundle image', 'Overrides the "Set featured image" phrase', 'ts-lms' ),
			'remove_featured_image' => _x( 'Remove bundle image', 'Overrides the "Remove featured image" phrase', 'ts-lms' ),
			'use_featured_image'    => _x( 'Use as bundle image', 'Overrides the "Use as featured image" phrase', 'ts-lms' ),
			'archives'              => _x( 'Bundle archives', 'The post type archive label', 'ts-lms' ),
			'insert_into_item'      => _x( 'Insert into bundle', 'Overrides the "Insert into post" phrase', 'ts-lms' ),
			'uploaded_to_this_item' => _x( 'Uploaded to this bundle', 'Overrides the "Uploaded to this post" phrase', 'ts-lms' ),
			'filter_items_list'     => _x( 'Filter bundles list', 'Screen reader text', 'ts-lms' ),
			'items_list_navigation' => _x( 'Bundles list navigation', 'Screen reader text', 'ts-lms' ),
			'items_list'            => _x( 'Bundles list', 'Screen reader text', 'ts-lms' ),
		);

		$args = array(
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => false,
			'query_var'          => true,
			'rewrite'            => array( 
				'slug'       => 'bundle',
				'with_front' => false,
			),
			'capability_type'    => array( 'ts_bundle', 'ts_bundles' ),
			'map_meta_cap'       => true,
			'has_archive'        => false,
			'hierarchical'       => false,
			'menu_position'      => null,
			'menu_icon'          => 'dashicons-portfolio',
			'supports'           => array( 'title', 'editor', 'thumbnail' ),
			'show_in_rest'       => true,
		);

		register_post_type( self::POST_TYPE, $args );
	}

	/**
	 * Add meta boxes.
	 *
	 * @return void
	 */
	public static function add_meta_boxes() {
		add_meta_box(
			'ts_bundle_details',
			__( 'Bundle Details', 'ts-lms' ),
			array( __CLASS__, 'render_details_meta_box' ),
			self::POST_TYPE,
			'normal',
			'high'
		);

		add_meta_box(
			'ts_bundle_courses',
			__( 'Bundle Courses', 'ts-lms' ),
			array( __CLASS__, 'render_courses_meta_box' ),
			self::POST_TYPE,
			'normal',
			'high'
		);
	}

	/**
	 * Render bundle details meta box.
	 *
	 * @param WP_Post $post Post object.
	 * @return void
	 */
	public static function render_details_meta_box( $post ) {
		wp_nonce_field( 'ts_bundle_meta', 'ts_bundle_meta_nonce' );

		$price      = get_post_meta( $post->ID, '_bundle_price', true );
		$status     = get_post_meta( $post->ID, '_bundle_status', true );
		$woo_id     = get_post_meta( $post->ID, '_bundle_woo_product_id', true );
		?>
		<table class="form-table">
			<tr>
				<th scope="row">
					<label for="bundle_price"><?php esc_html_e( 'Bundle Price', 'ts-lms' ); ?></label>
				</th>
				<td>
					<input type="number" id="bundle_price" name="_bundle_price" value="<?php echo esc_attr( $price ); ?>" step="0.01" min="0" class="regular-text" />
					<p class="description"><?php esc_html_e( 'Total price for this bundle.', 'ts-lms' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="bundle_status"><?php esc_html_e( 'Bundle Status', 'ts-lms' ); ?></label>
				</th>
				<td>
					<select id="bundle_status" name="_bundle_status">
						<option value="active" <?php selected( $status, 'active' ); ?>><?php esc_html_e( 'Active', 'ts-lms' ); ?></option>
						<option value="inactive" <?php selected( $status, 'inactive' ); ?>><?php esc_html_e( 'Inactive', 'ts-lms' ); ?></option>
					</select>
					<p class="description"><?php esc_html_e( 'Set bundle availability status.', 'ts-lms' ); ?></p>
				</td>
			</tr>
			<?php if ( $woo_id ) : ?>
			<tr>
				<th scope="row">
					<?php esc_html_e( 'WooCommerce Product', 'ts-lms' ); ?>
				</th>
				<td>
					<p>
						<?php
						printf(
							/* translators: %s: WooCommerce product edit URL */
							__( 'Linked to <a href="%s" target="_blank">WooCommerce Product #%d</a>', 'ts-lms' ),
							esc_url( admin_url( 'post.php?post=' . $woo_id . '&action=edit' ) ),
							absint( $woo_id )
						);
						?>
					</p>
				</td>
			</tr>
			<?php endif; ?>
		</table>
		<?php
	}

	/**
	 * Render bundle courses meta box.
	 *
	 * @param WP_Post $post Post object.
	 * @return void
	 */
	public static function render_courses_meta_box( $post ) {
		// Get all available courses
		$courses = get_posts( array(
			'post_type'      => Course::POST_TYPE,
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'orderby'        => 'title',
			'order'          => 'ASC',
		) );

		// Get bundle courses
		global $wpdb;
		$table = $wpdb->prefix . 'ts_bundle_courses';
		$bundle_courses = array();
		
		if ( $post->ID ) {
			$results = $wpdb->get_results( $wpdb->prepare(
				"SELECT course_id, course_price, order_index FROM {$table} WHERE bundle_id = %d ORDER BY order_index ASC",
				$post->ID
			) );
			
			foreach ( $results as $row ) {
				$bundle_courses[ $row->course_id ] = array(
					'price' => $row->course_price,
					'order' => $row->order_index,
				);
			}
		}
		?>
		<div id="ts-bundle-courses">
			<p><?php esc_html_e( 'Select courses to include in this bundle and set their individual prices for commission calculation.', 'ts-lms' ); ?></p>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Include', 'ts-lms' ); ?></th>
						<th><?php esc_html_e( 'Course', 'ts-lms' ); ?></th>
						<th><?php esc_html_e( 'Course Price', 'ts-lms' ); ?></th>
						<th><?php esc_html_e( 'Order', 'ts-lms' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $courses as $course ) : ?>
					<?php
					$is_included = isset( $bundle_courses[ $course->ID ] );
					$course_price = $is_included ? $bundle_courses[ $course->ID ]['price'] : '';
					$order_index = $is_included ? $bundle_courses[ $course->ID ]['order'] : '';
					?>
					<tr>
						<td>
							<input type="checkbox" name="bundle_courses[]" value="<?php echo esc_attr( $course->ID ); ?>" <?php checked( $is_included ); ?> />
						</td>
						<td><?php echo esc_html( $course->post_title ); ?></td>
						<td>
							<input type="number" name="course_price_<?php echo esc_attr( $course->ID ); ?>" value="<?php echo esc_attr( $course_price ); ?>" step="0.01" min="0" style="width: 100px;" />
						</td>
						<td>
							<input type="number" name="course_order_<?php echo esc_attr( $course->ID ); ?>" value="<?php echo esc_attr( $order_index ); ?>" min="0" style="width: 60px;" />
						</td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Save bundle meta data.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public static function save_meta( $post_id, $post ) {
		// Check if this is an autosave
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Verify nonce
		if ( ! isset( $_POST['ts_bundle_meta_nonce'] ) || ! wp_verify_nonce( $_POST['ts_bundle_meta_nonce'], 'ts_bundle_meta' ) ) {
			return;
		}

		// Check user permissions
		if ( ! current_user_can( 'edit_ts_bundle', $post_id ) ) {
			return;
		}

		// Save bundle price
		if ( isset( $_POST['_bundle_price'] ) ) {
			$price = floatval( $_POST['_bundle_price'] );
			update_post_meta( $post_id, '_bundle_price', $price );
		}

		// Save bundle status
		if ( isset( $_POST['_bundle_status'] ) ) {
			$status = sanitize_text_field( $_POST['_bundle_status'] );
			update_post_meta( $post_id, '_bundle_status', $status );
		}

		// Save bundle courses
		if ( isset( $_POST['bundle_courses'] ) && is_array( $_POST['bundle_courses'] ) ) {
			global $wpdb;
			$table = $wpdb->prefix . 'ts_bundle_courses';

			// Delete existing relationships
			$wpdb->delete( $table, array( 'bundle_id' => $post_id ), array( '%d' ) );

			// Insert new relationships
			foreach ( $_POST['bundle_courses'] as $course_id ) {
				$course_id = absint( $course_id );
				$course_price = isset( $_POST[ 'course_price_' . $course_id ] ) ? floatval( $_POST[ 'course_price_' . $course_id ] ) : 0;
				$order_index = isset( $_POST[ 'course_order_' . $course_id ] ) ? absint( $_POST[ 'course_order_' . $course_id ] ) : 0;

				$wpdb->insert(
					$table,
					array(
						'bundle_id'    => $post_id,
						'course_id'    => $course_id,
						'course_price' => $course_price,
						'order_index'  => $order_index,
						'created_at'   => current_time( 'mysql' ),
					),
					array( '%d', '%d', '%f', '%d', '%s' )
				);
			}
		} else {
			// No courses selected, delete all relationships
			global $wpdb;
			$table = $wpdb->prefix . 'ts_bundle_courses';
			$wpdb->delete( $table, array( 'bundle_id' => $post_id ), array( '%d' ) );
		}

		// Fire action hook
		do_action( 'ts_lms_bundle_saved', $post_id, $post );
	}

	/**
	 * Get available bundle statuses.
	 *
	 * @return array Bundle statuses.
	 */
	public static function get_statuses() {
		$statuses = array(
			'active'   => __( 'Active', 'ts-lms' ),
			'inactive' => __( 'Inactive', 'ts-lms' ),
		);

		return apply_filters( 'ts_lms_bundle_statuses', $statuses );
	}
}
