<?php
/**
 * Certificate Generator Class
 * 
 * Generates certificates for course completion with dynamic data
 */

namespace TS_LMS\Courses;

use TS_LMS\Admin\Settings;

class CertificateGenerator {

	/**
	 * Generate certificate for a user and course
	 * 
	 * @param int $user_id User ID
	 * @param int $course_id Course ID
	 * @return string|false Certificate HTML or false on failure
	 */
	public static function generate_certificate( $user_id, $course_id ) {
		// Get course certificate template
		$template_id = get_post_meta( $course_id, '_selected_certificate', true );
		
		if ( empty( $template_id ) || $template_id === 'none' ) {
			return false;
		}

		// Get user data
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		// Get course data
		$course = get_post( $course_id );
		if ( ! $course ) {
			return false;
		}

		// Get admin certificate settings
		$cert_auth_name = Settings::get_setting( 'cert_auth_name', '' );
		$cert_auth_company = Settings::get_setting( 'cert_auth_company', '' );
		$cert_signature = Settings::get_setting( 'cert_signature', '' );
		$cert_show_instructor = Settings::get_setting( 'cert_show_instructor', false );

		// Get instructor data if enabled
		$instructor_name = '';
		if ( $cert_show_instructor ) {
			$instructor = get_userdata( $course->post_author );
			if ( $instructor ) {
				$instructor_name = $instructor->display_name;
			}
		}

		// Get completion date
		$completion_meta = get_user_meta( $user_id, '_ts_course_completed_' . $course_id, true );
		$completion_date = $completion_meta ? date_i18n( get_option( 'date_format' ), $completion_meta ) : date_i18n( get_option( 'date_format' ) );

		// Generate certificate HTML based on template
		$certificate_html = self::get_template_html( $template_id, array(
			'student_name'     => $user->display_name,
			'course_name'      => $course->post_title,
			'completion_date'  => $completion_date,
			'auth_name'        => $cert_auth_name,
			'auth_company'     => $cert_auth_company,
			'signature_url'    => $cert_signature,
			'instructor_name'  => $instructor_name,
			'cert_id'          => uniqid( 'cert_' )
		) );

		return $certificate_html;
	}

	/**
	 * Get certificate template HTML
	 * 
	 * @param string $template_id Template ID
	 * @param array $data Certificate data
	 * @param bool $is_preview Whether this is for admin preview
	 * @return string Certificate HTML
	 */
	private static function get_template_html( $template_id, $data, $is_preview = false ) {
		ob_start();
		?>
		<!DOCTYPE html>
		<html style="overflow: hidden;">
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<title><?php echo esc_html( $data['student_name'] ); ?> - Certificate</title>
			<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&family=Quicksand:wght@500;700&family=Dancing+Script:wght@700&family=Orbitron:wght@700&display=swap" rel="stylesheet">
			<style>
				* { margin: 0; padding: 0; box-sizing: border-box; }
				body {
					font-family: 'Montserrat', sans-serif;
					background: <?php echo $is_preview ? 'transparent' : '#f0f2f5'; ?>;
					padding: <?php echo $is_preview ? '10px' : '60px 20px'; ?>;
					display: flex;
					justify-content: center;
					align-items: center;
					min-height: <?php echo $is_preview ? '100%' : '100vh'; ?>;
					overflow: <?php echo $is_preview ? 'hidden' : 'auto'; ?>;
				}
				.certificate-container {
					max-width: 1120px;
					width: 100%;
					background: white;
					box-shadow: 0 30px 60px <?php echo $is_preview ? 'rgba(0,0,0,0.05)' : 'rgba(0,0,0,0.12)'; ?>;
					position: relative;
					overflow: hidden;
					<?php if ($is_preview): ?>
					transform: scale(0.92);
					transform-origin: center center;
					margin: 0 auto;
					<?php endif; ?>
				}
				@media (max-width: 1400px) {
					.certificate-container { transform: <?php echo $is_preview ? 'scale(0.75)' : 'none'; ?>; }
				}
				@media (max-width: 1200px) {
					.certificate-container { transform: <?php echo $is_preview ? 'scale(0.65)' : 'none'; ?>; }
				}
				@media (max-width: 1000px) {
					.certificate-container { transform: <?php echo $is_preview ? 'scale(0.5)' : 'none'; ?>; }
				}
				@media print {
					body { background: white; padding: 0; }
					.certificate-container { box-shadow: none; max-width: 100%; transform: none !important; }
				}
			</style>
			<?php echo self::get_template_styles( $template_id ); ?>
		</head>
		<body>
			<div class="certificate-container">
				<?php echo self::get_template_content( $template_id, $data ); ?>
			</div>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}

	/**
	 * Get template-specific styles
	 * 
	 * @param string $template_id Template ID
	 * @return string CSS styles
	 */
	private static function get_template_styles( $template_id ) {
		$styles = array(
			'cert-1' => '
				<style>
					.certificate { 
						padding: 60px 80px; 
						background: linear-gradient(135deg, #f5f0e8 0%, #fef9f3 100%);
						border: 20px solid #d4af37;
						border-image: linear-gradient(45deg, #d4af37, #f4e5b8, #d4af37) 1;
						position: relative;
					}
					.certificate::before {
						content: "";
						position: absolute;
						top: 30px; left: 30px; right: 30px; bottom: 30px;
						border: 2px solid #d4af37;
						pointer-events: none;
					}
					.ornament { position: absolute; font-size: 60px; color: #d4af37; opacity: 0.3; }
					.ornament-tl { top: 40px; left: 40px; }
					.ornament-tr { top: 40px; right: 40px; transform: scaleX(-1); }
					.ornament-bl { bottom: 40px; left: 40px; transform: scaleY(-1); }
					.ornament-br { bottom: 40px; right: 40px; transform: scale(-1); }
					.cert-title { text-align: center; font-family: "Playfair Display", serif; font-size: 52px; font-weight: bold; color: #2c1810; margin-bottom: 15px; letter-spacing: 4px; }
					.cert-subtitle { text-align: center; font-size: 28px; color: #5d4e37; margin-bottom: 50px; letter-spacing: 2px; }
					.cert-text { text-align: center; font-size: 18px; color: #4a3f35; margin-bottom: 30px; }
					.cert-name { text-align: center; font-family: "Dancing Script", cursive; font-size: 56px; font-weight: bold; color: #2c1810; margin: 30px 0; padding: 20px; border-bottom: 3px solid #d4af37; display: inline-block; width: 70%; margin-left: 15%; }
					.cert-course { text-align: center; font-size: 24px; color: #5d4e37; margin: 30px 0; }
					.cert-footer { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 80px; padding: 0 40px; }
					.cert-signature { text-align: center; flex: 1; }
					.signature-img { max-width: 200px; height: 80px; margin-bottom: 2px; display: block; margin-left: auto; margin-right: auto; }
					.signature-line { border-top: 2px solid #2c1810; padding-top: 10px; margin: 0 auto 10px; max-width: 250px; }
					.signature-text { font-size: 16px; color: #4a3f35; margin: 5px 0; line-height: 1.4; }
					.signature-label { font-size: 14px; color: #8b7355; line-height: 1.4; }
				</style>
			',
			'cert-2' => '
				<style>
					.certificate { 
						padding: 60px 80px; 
						background: linear-gradient(135deg, #ffffff 0%, #e8f4f8 100%);
						border: 8px solid #1e3a5f;
						position: relative;
					}
					.geometric-accent { 
						position: absolute; 
						width: 100px; 
						height: 100px; 
						background: linear-gradient(135deg, #1e3a5f, #3d7ab7);
						clip-path: polygon(0 0, 100% 0, 50% 100%);
					}
					.geo-tl { top: -4px; left: -4px; }
					.geo-tr { top: -4px; right: -4px; transform: rotate(90deg); }
					.geo-bl { bottom: -4px; left: -4px; transform: rotate(-90deg); }
					.geo-br { bottom: -4px; right: -4px; transform: rotate(180deg); }
					.cert-title { text-align: center; font-family: "Montserrat", sans-serif; font-size: 48px; font-weight: bold; color: #1e3a5f; margin-bottom: 10px; letter-spacing: 3px; }
					.cert-subtitle { text-align: center; font-family: "Montserrat", sans-serif; font-size: 22px; color: #3d7ab7; margin-bottom: 60px; letter-spacing: 2px; }
					.cert-text { text-align: center; font-size: 16px; color: #4a5568; margin-bottom: 25px; }
					.cert-name { text-align: center; font-size: 38px; font-weight: 600; color: #1e3a5f; margin: 25px 0; padding: 15px; background: rgba(30, 58, 95, 0.05); border-left: 5px solid #3d7ab7; }
					.cert-course { text-align: center; font-size: 20px; color: #4a5568; margin: 25px 0; }
					.cert-footer { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-top: 70px; padding-top: 30px; border-top: 2px solid #1e3a5f; align-items: flex-end; }
					.cert-signature { text-align: center; }
					.signature-img { max-width: 180px; height: 70px; margin-bottom: 2px; display: block; margin-left: auto; margin-right: auto; }
					.signature-line { border-top: 1px solid #1e3a5f; padding-top: 8px; margin: 0 auto 8px; max-width: 200px; }
					.signature-text { font-size: 14px; color: #1e3a5f; margin: 3px 0; font-weight: 600; line-height: 1.4; }
					.signature-label { font-size: 12px; color: #718096; line-height: 1.4; }
				</style>
			',
			'cert-3' => '
				<style>
					.certificate { 
						padding: 60px 70px; 
						background: linear-gradient(135deg, #ffffff 0%, #f9f5ff 100%);
						border: 3px solid #d8b4fe;
						position: relative;
					}
					.floral-corner { 
						position: absolute; 
						width: 180px; 
						height: 180px; 
						background: url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 100\'%3E%3Ccircle cx=\'20\' cy=\'20\' r=\'15\' fill=\'%23d8b4fe\' opacity=\'0.3\'/%3E%3Ccircle cx=\'40\' cy=\'30\' r=\'12\' fill=\'%23c084fc\' opacity=\'0.3\'/%3E%3Ccircle cx=\'30\' cy=\'45\' r=\'10\' fill=\'%23e9d5ff\' opacity=\'0.3\'/%3E%3C/svg%3E");
						background-size: contain;
						background-repeat: no-repeat;
					}
					.floral-tl { top: 20px; left: 20px; }
					.floral-tr { top: 20px; right: 20px; transform: scaleX(-1); }
					.floral-bl { bottom: 20px; left: 20px; transform: scaleY(-1); }
					.floral-br { bottom: 20px; right: 20px; transform: scale(-1); }
					.cert-title { text-align: center; font-family: "Brush Script MT", cursive; font-size: 50px; color: #7c3aed; margin-bottom: 12px; }
					.cert-subtitle { text-align: center; font-size: 24px; color: #a78bfa; margin-bottom: 55px; font-style: italic; }
					.cert-text { text-align: center; font-size: 17px; color: #6b7280; margin-bottom: 28px; }
					.cert-name { text-align: center; font-size: 40px; font-weight: 600; color: #7c3aed; margin: 28px 0; padding: 18px; border-bottom: 2px dashed #c084fc; width: 75%; margin-left: 12.5%; }
					.cert-course { text-align: center; font-size: 22px; color: #6b7280; margin: 28px 0; font-style: italic; }
					.cert-footer { display: flex; justify-content: space-around; align-items: flex-end; margin-top: 75px; }
					.cert-signature { text-align: center; flex: 1; }
					.signature-img { max-width: 190px; height: 75px; margin-bottom: 2px; display: block; margin-left: auto; margin-right: auto; }
					.signature-line { border-top: 2px dotted #c084fc; padding-top: 10px; margin: 0 auto 10px; max-width: 220px; }
					.signature-text { font-size: 15px; color: #7c3aed; margin: 5px 0; line-height: 1.4; }
					.signature-label { font-size: 13px; color: #9ca3af; font-style: italic; line-height: 1.4; }
				</style>
			',
			'cert-4' => '
				<style>
					.certificate { 
						padding: 60px 75px; 
						background: linear-gradient(135deg, #ffffff 0%, #fef3c7 100%);
						border: 6px solid #14b8a6;
						position: relative;
						overflow: hidden;
					}
					.abstract-shape {
						position: absolute;
						width: 150px;
						height: 150px;
						background: linear-gradient(135deg, #14b8a6, #f97316);
						opacity: 0.1;
						clip-path: polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%);
					}
					.shape-1 { top: -50px; left: -50px; }
					.shape-2 { top: -50px; right: -50px; transform: rotate(45deg); }
					.shape-3 { bottom: -50px; left: -50px; transform: rotate(-45deg); }
					.shape-4 { bottom: -50px; right: -50px; transform: rotate(90deg); }
					.cert-title { text-align: center; font-family: "Arial Black", sans-serif; font-size: 46px; font-weight: 900; color: #134e4a; margin-bottom: 10px; letter-spacing: 2px; text-transform: uppercase; }
					.cert-subtitle { text-align: center; font-family: "Arial", sans-serif; font-size: 20px; color: #14b8a6; margin-bottom: 50px; letter-spacing: 4px; text-transform: uppercase; }
					.cert-text { text-align: center; font-size: 16px; color: #4b5563; margin-bottom: 25px; font-weight: 600; }
					.cert-name { text-align: center; font-size: 36px; font-weight: 700; color: #f97316; margin: 25px 0; padding: 20px; background: rgba(249, 115, 22, 0.1); border-radius: 10px; }
					.cert-course { text-align: center; font-size: 20px; color: #4b5563; margin: 25px 0; font-weight: 500; }
					.cert-footer { display: grid; grid-template-columns: repeat(2, 1fr); gap: 40px; margin-top: 60px; padding: 30px; background: rgba(20, 184, 166, 0.05); align-items: flex-end; }
					.cert-signature { text-align: center; }
					.signature-img { max-width: 180px; height: 70px; margin-bottom: 2px; display: block; margin-left: auto; margin-right: auto; }
					.signature-line { border-top: 3px solid #14b8a6; padding-top: 10px; margin: 0 auto 10px; max-width: 220px; }
					.signature-text { font-size: 14px; color: #134e4a; margin: 5px 0; font-weight: 700; line-height: 1.4; }
					.signature-label { font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 1px; line-height: 1.4; }
				</style>
			',
			'cert-5' => '
				<style>
					.certificate { 
						padding: 70px 80px; 
						background: linear-gradient(135deg, #f5f3e8 0%, #fcf9f0 100%);
						border: 15px solid #1e5128;
						border-image: repeating-linear-gradient(45deg, #1e5128, #1e5128 10px, #4e9f3d 10px, #4e9f3d 20px) 1;
						position: relative;
					}
					.academic-seal {
						position: absolute;
						top: 30px;
						left: 50%;
						transform: translateX(-50%);
						width: 120px;
						height: 120px;
						border-radius: 50%;
						background: linear-gradient(135deg, #1e5128, #4e9f3d);
						border: 5px solid #d4af37;
						display: flex;
						align-items: center;
						justify-content: center;
						color: white;
						font-size: 14px;
						font-weight: bold;
						box-shadow: 0 5px 20px rgba(0,0,0,0.2);
					}
					.cert-badge-corner {
						position: absolute;
						width: 80px;
						height: 80px;
						background: #1e5128;
						border-radius: 50%;
						border: 3px solid #d4af37;
					}
					.badge-tl { top: 40px; left: 40px; }
					.badge-tr { top: 40px; right: 40px; }
					.badge-bl { bottom: 40px; left: 40px; }
					.badge-br { bottom: 40px; right: 40px; }
					.cert-title { text-align: center; font-family: "Georgia", serif; font-size: 50px; font-weight: bold; color: #1e5128; margin-top: 80px; margin-bottom: 15px; letter-spacing: 3px; }
					.cert-subtitle { text-align: center; font-size: 26px; color: #4e9f3d; margin-bottom: 60px; letter-spacing: 2px; }
					.cert-text { text-align: center; font-size: 18px; color: #3e3e3e; margin-bottom: 30px; font-weight: 500; }
					.cert-name { text-align: center; font-size: 40px; font-weight: 700; color: #1e5128; margin: 30px 0; padding: 20px; border: 3px double #d4af37; width: 70%; margin-left: 15%; }
					.cert-course { text-align: center; font-size: 22px; color: #4e9f3d; margin: 30px 0; }
					.cert-footer { display: flex; justify-content: space-around; align-items: flex-end; margin-top: 80px; padding-top: 20px; border-top: 3px double #d4af37; }
					.cert-signature { text-align: center; flex: 1; }
					.signature-img { max-width: 200px; height: 80px; margin-bottom: 2px; display: block; margin-left: auto; margin-right: auto; }
					.signature-line { border-top: 2px solid #1e5128; padding-top: 10px; margin: 0 auto 10px; max-width: 230px; }
					.signature-text { font-size: 16px; color: #1e5128; margin: 5px 0; font-weight: 600; line-height: 1.4; }
					.signature-label { font-size: 14px; color: #6b7280; text-transform: uppercase; letter-spacing: 1px; line-height: 1.4; }
				</style>
			',
			'cert-6' => '
				<style>
					.certificate { 
						padding: 60px 70px; 
						background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%);
						border: 4px solid #00d9ff;
						position: relative;
						color: white;
					}
					.circuit-pattern {
						position: absolute;
						width: 200px;
						height: 200px;
						background: url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 100\'%3E%3Cpath d=\'M10 10 L40 10 L40 40 L70 40\' stroke=\'%2300d9ff\' fill=\'none\' stroke-width=\'2\'/%3E%3Ccircle cx=\'70\' cy=\'40\' r=\'5\' fill=\'%2300d9ff\'/%3E%3C/svg%3E");
						background-repeat: no-repeat;
						opacity: 0.3;
					}
					.circuit-tl { top: 30px; left: 30px; }
					.circuit-tr { top: 30px; right: 30px; transform: scaleX(-1); }
					.circuit-bl { bottom: 30px; left: 30px; transform: scaleY(-1); }
					.circuit-br { bottom: 30px; right: 30px; transform: scale(-1); }
					.cert-title { text-align: center; font-family: "Arial", sans-serif; font-size: 44px; font-weight: 900; color: #00d9ff; margin-bottom: 10px; letter-spacing: 4px; text-transform: uppercase; text-shadow: 0 0 20px rgba(0, 217, 255, 0.5); }
					.cert-subtitle { text-align: center; font-size: 20px; color: #ffffff; margin-bottom: 50px; letter-spacing: 3px; opacity: 0.9; }
					.cert-text { text-align: center; font-size: 16px; color: #a0a0a0; margin-bottom: 25px; }
					.cert-name { text-align: center; font-size: 36px; font-weight: 700; color: #ffffff; margin: 25px 0; padding: 20px; background: rgba(0, 217, 255, 0.1); border: 2px solid #00d9ff; box-shadow: 0 0 20px rgba(0, 217, 255, 0.3); }
					.cert-course { text-align: center; font-size: 20px; color: #a0a0a0; margin: 25px 0; }
					.cert-footer { display: grid; grid-template-columns: repeat(2, 1fr); gap: 30px; margin-top: 70px; padding-top: 30px; border-top: 1px solid #00d9ff; align-items: flex-end; }
					.cert-signature { text-align: center; }
					.signature-img { max-width: 180px; height: 70px; margin-bottom: 2px; filter: brightness(0) invert(1); display: block; margin-left: auto; margin-right: auto; }
					.signature-line { border-top: 1px solid #00d9ff; padding-top: 10px; margin: 0 auto 10px; max-width: 220px; }
					.signature-text { font-size: 14px; color: #ffffff; margin: 5px 0; font-weight: 600; line-height: 1.4; }
					.signature-label { font-size: 12px; color: #a0a0a0; text-transform: uppercase; line-height: 1.4; }
				</style>
			',
			'cert-7' => '
				<style>
					.certificate { 
						padding: 60px 75px; 
						background: linear-gradient(135deg, #ff6b6b 0%, #feca57 50%, #fff8e7 100%);
						border: 5px solid #ee5a6f;
						position: relative;
						overflow: hidden;
					}
					.bokeh-circle {
						position: absolute;
						border-radius: 50%;
						background: radial-gradient(circle, rgba(255,255,255,0.4), transparent);
					}
					.bokeh-1 { width: 150px; height: 150px; top: 20px; left: 10%; }
					.bokeh-2 { width: 120px; height: 120px; top: 50%; right: 15%; }
					.bokeh-3 { width: 100px; height: 100px; bottom: 30px; left: 20%; }
					.bokeh-4 { width: 130px; height: 130px; top: 40%; left: 5%; }
					.cert-title { text-align: center; font-family: "Georgia", serif; font-size: 48px; font-weight: bold; color: #5a1a1a; margin-bottom: 12px; letter-spacing: 3px; }
					.cert-subtitle { text-align: center; font-size: 24px; color: #7a3a3a; margin-bottom: 55px; letter-spacing: 2px; }
					.cert-text { text-align: center; font-size: 17px; color: #8a4a4a; margin-bottom: 28px; }
					.cert-name { text-align: center; font-size: 38px; font-weight: 700; color: #5a1a1a; margin: 28px 0; padding: 18px; background: rgba(255, 255, 255, 0.6); border-radius: 50px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
					.cert-course { text-align: center; font-size: 21px; color: #7a3a3a; margin: 28px 0; }
					.cert-footer { display: flex; justify-content: space-around; align-items: flex-end; margin-top: 70px; background: rgba(255, 255, 255, 0.5); padding: 25px; border-radius: 20px; }
					.cert-signature { text-align: center; flex: 1; }
					.signature-img { max-width: 190px; height: 75px; margin-bottom: 2px; display: block; margin-left: auto; margin-right: auto; }
					.signature-line { border-top: 2px solid #ee5a6f; padding-top: 10px; margin: 0 auto 10px; max-width: 220px; }
					.signature-text { font-size: 15px; color: #5a1a1a; margin: 5px 0; font-weight: 600; line-height: 1.4; }
					.signature-label { font-size: 13px; color: #8a4a4a; line-height: 1.4; }
				</style>
			',
			'cert-8' => '
				<style>
					.certificate { 
						padding: 60px 75px; 
						background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
						border: 6px solid #ffffff;
						position: relative;
						color: white;
					}
					.gradient-accent {
						position: absolute;
						width: 150px;
						height: 150px;
						background: radial-gradient(circle, rgba(255,255,255,0.3), transparent);
						border-radius: 50%;
					}
					.accent-1 { top: -50px; left: -50px; }
					.accent-2 { top: -50px; right: -50px; }
					.accent-3 { bottom: -50px; left: -50px; }
					.accent-4 { bottom: -50px; right: -50px; }
					.cert-title { text-align: center; font-family: "Arial", sans-serif; font-size: 46px; font-weight: 900; color: #ffffff; margin-bottom: 10px; letter-spacing: 3px; text-shadow: 0 4px 10px rgba(0,0,0,0.2); }
					.cert-subtitle { text-align: center; font-size: 22px; color: #f0f0f0; margin-bottom: 52px; letter-spacing: 2px; }
					.cert-text { text-align: center; font-size: 16px; color: #f0f0f0; margin-bottom: 26px; }
					.cert-name { text-align: center; font-size: 37px; font-weight: 700; color: #ffffff; margin: 26px 0; padding: 19px; background: rgba(255, 255, 255, 0.2); border: 2px solid rgba(255, 255, 255, 0.5); border-radius: 10px; backdrop-filter: blur(10px); }
					.cert-course { text-align: center; font-size: 21px; color: #f0f0f0; margin: 26px 0; }
					.cert-footer { display: grid; grid-template-columns: repeat(2, 1fr); gap: 35px; margin-top: 68px; padding-top: 28px; border-top: 2px solid rgba(255, 255, 255, 0.5); align-items: flex-end; }
					.cert-signature { text-align: center; }
					.signature-img { max-width: 185px; height: 73px; margin-bottom: 2px; filter: brightness(0) invert(1); display: block; margin-left: auto; margin-right: auto; }
					.signature-line { border-top: 2px solid rgba(255, 255, 255, 0.5); padding-top: 9px; margin: 0 auto 9px; max-width: 215px; }
					.signature-text { font-size: 15px; color: #ffffff; margin: 4px 0; font-weight: 600; line-height: 1.4; }
					.signature-label { font-size: 13px; color: #e0e0e0; line-height: 1.4; }
				</style>
			'
		);

		return isset( $styles[$template_id] ) ? $styles[$template_id] : $styles['cert-1'];
	}

	/**
	 * Get template content HTML
	 * 
	 * @param string $template_id Template ID
	 * @param array $data Certificate data
	 * @return string HTML content
	 */
	private static function get_template_content( $template_id, $data ) {
		// Common elements
		$has_signature = ! empty( $data['signature_url'] );
		$has_auth_info = ! empty( $data['auth_name'] ) || ! empty( $data['auth_company'] );
		$has_instructor = ! empty( $data['instructor_name'] );

		ob_start();
		?>
		<div class="certificate">
			<?php
			// Template-specific decorative elements
			switch ( $template_id ) {
				case 'cert-1':
					echo '<div class="ornament ornament-tl">❦</div>';
					echo '<div class="ornament ornament-tr">❦</div>';
					echo '<div class="ornament ornament-bl">❦</div>';
					echo '<div class="ornament ornament-br">❦</div>';
					break;
				case 'cert-2':
					echo '<div class="geometric-accent geo-tl"></div>';
					echo '<div class="geometric-accent geo-tr"></div>';
					echo '<div class="geometric-accent geo-bl"></div>';
					echo '<div class="geometric-accent geo-br"></div>';
					break;
				case 'cert-3':
					echo '<div class="floral-corner floral-tl"></div>';
					echo '<div class="floral-corner floral-tr"></div>';
					echo '<div class="floral-corner floral-bl"></div>';
					echo '<div class="floral-corner floral-br"></div>';
					break;
				case 'cert-4':
					echo '<div class="abstract-shape shape-1"></div>';
					echo '<div class="abstract-shape shape-2"></div>';
					echo '<div class="abstract-shape shape-3"></div>';
					echo '<div class="abstract-shape shape-4"></div>';
					break;
				case 'cert-5':
					echo '<div class="academic-seal">Excellence<br>In<br>Learning</div>';
					echo '<div class="cert-badge-corner badge-tl"></div>';
					echo '<div class="cert-badge-corner badge-tr"></div>';
					echo '<div class="cert-badge-corner badge-bl"></div>';
					echo '<div class="cert-badge-corner badge-br"></div>';
					break;
				case 'cert-6':
					echo '<div class="circuit-pattern circuit-tl"></div>';
					echo '<div class="circuit-pattern circuit-tr"></div>';
					echo '<div class="circuit-pattern circuit-bl"></div>';
					echo '<div class="circuit-pattern circuit-br"></div>';
					break;
				case 'cert-7':
					echo '<div class="bokeh-circle bokeh-1"></div>';
					echo '<div class="bokeh-circle bokeh-2"></div>';
					echo '<div class="bokeh-circle bokeh-3"></div>';
					echo '<div class="bokeh-circle bokeh-4"></div>';
					break;
				case 'cert-8':
					echo '<div class="gradient-accent accent-1"></div>';
					echo '<div class="gradient-accent accent-2"></div>';
					echo '<div class="gradient-accent accent-3"></div>';
					echo '<div class="gradient-accent accent-4"></div>';
					break;
			}
			?>
			
			<div class="cert-title">CERTIFICATE</div>
			<div class="cert-subtitle">OF COMPLETION</div>
			
			<div class="cert-text">This certificate is proudly presented to:</div>
			
			<div class="cert-name"><?php echo esc_html( $data['student_name'] ); ?></div>
			
			<div class="cert-text">For successfully completing the course:</div>
			
			<div class="cert-course"><?php echo esc_html( $data['course_name'] ); ?></div>
			
			<div class="cert-footer">
				<?php if ( $has_signature || $has_auth_info ) : ?>
					<div class="cert-signature">
						<?php if ( $has_signature ) : ?>
							<img src="<?php echo esc_url( $data['signature_url'] ); ?>" alt="Signature" class="signature-img" style="object-fit: contain;">
						<?php endif; ?>
						<div class="signature-line">
							<?php if ( ! empty( $data['auth_name'] ) ) : ?>
								<div class="signature-text"><?php echo esc_html( $data['auth_name'] ); ?></div>
							<?php endif; ?>
							<?php if ( ! empty( $data['auth_company'] ) ) : ?>
								<div class="signature-label"><?php echo esc_html( $data['auth_company'] ); ?></div>
							<?php else : ?>
								<div class="signature-label">Authorised Signatory</div>
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>
				
				
				
				<div class="cert-signature">
					<div class="signature-line">
						<div class="signature-text"><?php echo esc_html( $data['completion_date'] ); ?></div>
						<div class="signature-label">Date of Completion</div>
					</div>
				</div>
				
				<?php if ( ! $has_instructor && ! $has_auth_info ) : ?>
					<div class="cert-signature">
						<div class="signature-line">
							<div class="signature-text"><?php echo esc_html( $data['cert_id'] ); ?></div>
							<div class="signature-label">Certificate ID</div>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Get certificate download URL
	 * 
	 * @param int $user_id User ID
	 * @param int $course_id Course ID
	 * @return string Download URL
	 */
	public static function get_certificate_url( $user_id, $course_id ) {
		return add_query_arg( array(
			'ts_cert' => 1,
			'user' => $user_id,
			'course' => $course_id,
			'key' => wp_create_nonce( 'ts_cert_' . $user_id . '_' . $course_id )
		), home_url() );
	}

	/**
	 * Handle certificate download request
	 */
	public static function handle_certificate_request() {
		if ( ! isset( $_GET['ts_cert'] ) ) {
			return;
		}

		$user_id = isset( $_GET['user'] ) ? intval( $_GET['user'] ) : 0;
		$course_id = isset( $_GET['course'] ) ? intval( $_GET['course'] ) : 0;
		$key = isset( $_GET['key'] ) ? sanitize_text_field( $_GET['key'] ) : '';

		// Verify nonce
		if ( ! wp_verify_nonce( $key, 'ts_cert_' . $user_id . '_' . $course_id ) ) {
			wp_die( 'Invalid certificate request.' );
		}

		// Generate certificate
		$certificate_html = self::generate_certificate( $user_id, $course_id );

		if ( ! $certificate_html ) {
			wp_die( 'Certificate not available.' );
		}

		// Output certificate
		echo $certificate_html;
		exit;
	}

	/**
	 * AJAX handler for certificate preview
	 */
	public static function ajax_get_cert_preview() {
		check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

		if ( ! current_user_can( 'edit_ts_courses' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'ts-lms' ) ) );
		}

		$template_id = isset( $_POST['cert_id'] ) ? sanitize_text_field( $_POST['cert_id'] ) : '';
		
		if ( empty( $template_id ) || $template_id === 'none' ) {
			wp_send_json_error( array( 'message' => __( 'Invalid template ID', 'ts-lms' ) ) );
		}

		// Get admin certificate settings for the preview
		$cert_auth_name = Settings::get_setting( 'cert_auth_name', 'Authorized Signatory' );
		$cert_auth_company = Settings::get_setting( 'cert_auth_company', 'Your Academy Name' );
		$cert_signature = Settings::get_setting( 'cert_signature', '' );
		
		// Create mock data for the preview
		$data = array(
			'student_name'     => 'John Doe',
			'course_name'      => 'Advanced Web Development Masterclass',
			'completion_date'  => date_i18n( get_option( 'date_format' ) ),
			'auth_name'        => $cert_auth_name,
			'auth_company'     => $cert_auth_company,
			'signature_url'    => $cert_signature,
			'instructor_name'  => 'Professor Smith',
			'cert_id'          => 'PREVIEW-' . strtoupper( $template_id )
		);

		// Generate HTML with preview flag set to true
		$html = self::get_template_html( $template_id, $data, true );

		if ( $html ) {
			wp_send_json_success( array( 'html' => $html ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Could not generate preview', 'ts-lms' ) ) );
		}
	}
}

// Hooks
add_action( 'template_redirect', array( 'TS_LMS\Courses\CertificateGenerator', 'handle_certificate_request' ) );
add_action( 'wp_ajax_ts_lms_get_cert_preview', array( 'TS_LMS\Courses\CertificateGenerator', 'ajax_get_cert_preview' ) );
