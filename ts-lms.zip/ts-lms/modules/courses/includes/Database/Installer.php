<?php
/**
 * Database Installer
 *
 * Handles database table creation and updates for the Course Engine module.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Database;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Installer class.
 */
class Installer {

    /**
     * Database schema version.
     *
     * @var string
     */
    const SCHEMA_VERSION = '1.0.0';

    /**
     * Install database tables.
     *
     * @return void
     */
    public static function install() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();
        $table_prefix    = $wpdb->prefix;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Get schema SQL
        $schema = self::get_schema();
        
        // Replace placeholder with actual prefix
        $schema = str_replace( '{prefix}', $wpdb->prefix, $schema );

        // Execute queries using dbDelta
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $schema );

        // Update schema version
        update_option( 'ts_lms_courses_schema_version', self::SCHEMA_VERSION );
        
        // Log installation
        error_log( 'TS LMS Course Engine: Database tables installed successfully.' );
    }

    /**
     * Get database schema.
     *
     * @return string SQL schema.
     */
    public static function get_schema() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $schema = "
        CREATE TABLE {prefix}ts_course_instructors (
          id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
          course_id bigint(20) unsigned NOT NULL,
          instructor_id bigint(20) unsigned NOT NULL,
          role varchar(50) NOT NULL DEFAULT 'instructor',
          created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY  (id),
          KEY course_id (course_id),
          KEY instructor_id (instructor_id),
          UNIQUE KEY course_instructor (course_id, instructor_id)
        ) $charset_collate;

        CREATE TABLE {prefix}ts_lesson_order (
          id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
          course_id bigint(20) unsigned NOT NULL,
          lesson_id bigint(20) unsigned NOT NULL,
          parent_lesson_id bigint(20) unsigned DEFAULT NULL,
          order_index int(11) NOT NULL DEFAULT 0,
          created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY  (id),
          KEY course_id (course_id),
          KEY lesson_id (lesson_id),
          KEY parent_lesson_id (parent_lesson_id),
          UNIQUE KEY course_lesson (course_id, lesson_id)
        ) $charset_collate;

        CREATE TABLE {prefix}ts_course_enrollments (
          id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
          course_id bigint(20) unsigned NOT NULL,
          user_id bigint(20) unsigned NOT NULL,
          enrolled_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          status varchar(50) NOT NULL DEFAULT 'active',
          completed_at datetime DEFAULT NULL,
          order_id bigint(20) unsigned DEFAULT NULL,
          source_type varchar(50) DEFAULT NULL,
          source_id bigint(20) unsigned DEFAULT NULL,
          subscription_id varchar(100) DEFAULT NULL,
          subscription_type varchar(50) DEFAULT NULL,
          expires_at datetime DEFAULT NULL,
          grace_period_ends datetime DEFAULT NULL,
          PRIMARY KEY  (id),
          KEY course_id (course_id),
          KEY user_id (user_id),
          KEY status (status),
          KEY order_id (order_id),
          KEY source_type (source_type),
          KEY source_id (source_id),
          KEY subscription_id (subscription_id),
          UNIQUE KEY course_user (course_id, user_id)
        ) $charset_collate;

        CREATE TABLE {prefix}ts_lesson_progress (
          id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
          lesson_id bigint(20) unsigned NOT NULL,
          user_id bigint(20) unsigned NOT NULL,
          course_id bigint(20) unsigned NOT NULL,
          status varchar(50) NOT NULL DEFAULT 'not_started',
          completed_at datetime DEFAULT NULL,
          last_accessed datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY  (id),
          KEY lesson_id (lesson_id),
          KEY user_id (user_id),
          KEY course_id (course_id),
          KEY status (status),
          UNIQUE KEY lesson_user (lesson_id, user_id)
        ) $charset_collate;

        CREATE TABLE {prefix}ts_bundle_courses (
          id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
          bundle_id bigint(20) unsigned NOT NULL,
          course_id bigint(20) unsigned NOT NULL,
          course_price decimal(10,2) NOT NULL DEFAULT 0.00,
          order_index int(11) NOT NULL DEFAULT 0,
          created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY  (id),
          KEY bundle_id (bundle_id),
          KEY course_id (course_id),
          UNIQUE KEY bundle_course (bundle_id, course_id)
        ) $charset_collate;

        CREATE TABLE {prefix}ts_course_reviews (
          id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
          course_id bigint(20) unsigned NOT NULL,
          user_id bigint(20) unsigned NOT NULL,
          rating tinyint(1) NOT NULL,
          title varchar(255) DEFAULT NULL,
          content text,
          status varchar(20) NOT NULL DEFAULT 'approved',
          created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY  (id),
          KEY course_id (course_id),
          KEY user_id (user_id),
          KEY status (status),
          KEY rating (rating)
        ) $charset_collate;

        CREATE TABLE {prefix}ts_lms_notifications (
          id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
          user_id bigint(20) unsigned NOT NULL,
          item_id varchar(100) NOT NULL,
          data text DEFAULT NULL,
          is_read tinyint(1) NOT NULL DEFAULT 0,
          created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY  (id),
          KEY user_id (user_id),
          KEY item_id (item_id),
          KEY is_read (is_read)
        ) $charset_collate;
        ";

        return $schema;
    }

    /**
     * Uninstall database tables.
     *
     * @return void
     */
    public static function uninstall() {
        global $wpdb;

        $table_prefix = $wpdb->prefix;

        $tables = array(
            "{$table_prefix}ts_course_instructors",
            "{$table_prefix}ts_lesson_order",
            "{$table_prefix}ts_course_enrollments",
            "{$table_prefix}ts_lesson_progress",
            "{$table_prefix}ts_bundle_courses",
            "{$table_prefix}ts_course_reviews",
            "{$table_prefix}ts_lms_notifications",
        );

        foreach ( $tables as $table ) {
            $wpdb->query( "DROP TABLE IF EXISTS {$table}" );
        }

        delete_option( 'ts_lms_courses_schema_version' );
        
        error_log( 'TS LMS Course Engine: Database tables uninstalled.' );
    }

    /**
     * Check if tables exist.
     *
     * @return bool True if all tables exist.
     */
    public static function tables_exist() {
        global $wpdb;

        $table_prefix = $wpdb->prefix;

        $tables = array(
            "{$table_prefix}ts_course_instructors",
            "{$table_prefix}ts_lesson_order",
            "{$table_prefix}ts_course_enrollments",
            "{$table_prefix}ts_lesson_progress",
            "{$table_prefix}ts_bundle_courses",
            "{$table_prefix}ts_course_reviews",
        );


        foreach ( $tables as $table ) {
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) !== $table ) {
                return false;
            }
        }

        return true;
    }
}
