<?php
/**
 * Database Migration: Add order_id to enrollments table
 *
 * This migration adds the order_id column to the ts_course_enrollments table
 * if it doesn't already exist.
 *
 * @package TS_LMS\Modules\Courses\Database
 * @since 1.0.1
 */

namespace TS_LMS\Modules\Courses\Database;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Migration class for adding order_id column.
 */
class Migration_Add_Order_Id {

	/**
	 * Run the migration.
	 *
	 * @return bool True on success, false on failure.
	 */
	public static function run() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'ts_course_enrollments';

		// Check if table exists
		$table_exists = $wpdb->get_var( "SHOW TABLES LIKE '{$table_name}'" ) === $table_name;

		if ( ! $table_exists ) {
			error_log( 'TS LMS Migration: Table ' . $table_name . ' does not exist. Skipping migration.' );
			return false;
		}

		// Check if order_id column already exists
		$column_exists = $wpdb->get_results(
			$wpdb->prepare(
				"SHOW COLUMNS FROM {$table_name} LIKE %s",
				'order_id'
			)
		);

		if ( ! empty( $column_exists ) ) {
			error_log( 'TS LMS Migration: Column order_id already exists in ' . $table_name . '. Skipping.' );
			return true;
		}

		// Add order_id column
		$sql = "ALTER TABLE {$table_name} 
				ADD COLUMN order_id bigint(20) unsigned DEFAULT NULL AFTER completed_at,
				ADD KEY order_id (order_id)";

		$result = $wpdb->query( $sql );

		if ( false === $result ) {
			error_log( 'TS LMS Migration: Failed to add order_id column to ' . $table_name );
			error_log( 'TS LMS Migration Error: ' . $wpdb->last_error );
			return false;
		}

		error_log( 'TS LMS Migration: Successfully added order_id column to ' . $table_name );
		
		// Update migration version
		update_option( 'ts_lms_courses_migration_order_id', '1.0.1' );

		return true;
	}

	/**
	 * Check if migration has been run.
	 *
	 * @return bool True if already run, false otherwise.
	 */
	public static function has_run() {
		return (bool) get_option( 'ts_lms_courses_migration_order_id', false );
	}

	/**
	 * Rollback the migration.
	 *
	 * @return bool True on success, false on failure.
	 */
	public static function rollback() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'ts_course_enrollments';

		// Check if column exists before trying to drop
		$column_exists = $wpdb->get_results(
			$wpdb->prepare(
				"SHOW COLUMNS FROM {$table_name} LIKE %s",
				'order_id'
			)
		);

		if ( empty( $column_exists ) ) {
			error_log( 'TS LMS Migration Rollback: Column order_id does not exist. Nothing to rollback.' );
			return true;
		}

		// Drop order_id column and its index
		$sql = "ALTER TABLE {$table_name} 
				DROP COLUMN order_id";

		$result = $wpdb->query( $sql );

		if ( false === $result ) {
			error_log( 'TS LMS Migration Rollback: Failed to drop order_id column from ' . $table_name );
			return false;
		}

		error_log( 'TS LMS Migration Rollback: Successfully removed order_id column from ' . $table_name );
		
		// Remove migration version
		delete_option( 'ts_lms_courses_migration_order_id' );

		return true;
	}
}
