<?php
/**
 * Taxonomies
 *
 * Registers custom taxonomies for courses and lessons.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Taxonomies;

use TS_LMS\Modules\Courses\PostTypes\Course;
use TS_LMS\Modules\Courses\PostTypes\Lesson;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Taxonomies class.
 */
class Taxonomies {

    /**
     * Initialize taxonomies.
     *
     * @return void
     */
    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_taxonomies' ) );
    }

    /**
     * Register custom taxonomies.
     *
     * @return void
     */
    public static function register_taxonomies() {
        self::register_course_category();
        self::register_course_tag();
    }

    /**
     * Register course category taxonomy.
     *
     * @return void
     */
    private static function register_course_category() {
        $labels = array(
            'name'                       => _x( 'Course Categories', 'taxonomy general name', 'ts-lms' ),
            'singular_name'              => _x( 'Course Category', 'taxonomy singular name', 'ts-lms' ),
            'search_items'               => __( 'Search Course Categories', 'ts-lms' ),
            'popular_items'              => __( 'Popular Course Categories', 'ts-lms' ),
            'all_items'                  => __( 'All Course Categories', 'ts-lms' ),
            'parent_item'                => __( 'Parent Course Category', 'ts-lms' ),
            'parent_item_colon'          => __( 'Parent Course Category:', 'ts-lms' ),
            'edit_item'                  => __( 'Edit Course Category', 'ts-lms' ),
            'update_item'                => __( 'Update Course Category', 'ts-lms' ),
            'add_new_item'               => __( 'Add New Course Category', 'ts-lms' ),
            'new_item_name'              => __( 'New Course Category Name', 'ts-lms' ),
            'separate_items_with_commas' => __( 'Separate course categories with commas', 'ts-lms' ),
            'add_or_remove_items'        => __( 'Add or remove course categories', 'ts-lms' ),
            'choose_from_most_used'      => __( 'Choose from the most used course categories', 'ts-lms' ),
            'not_found'                  => __( 'No course categories found.', 'ts-lms' ),
            'menu_name'                  => __( 'Course Categories', 'ts-lms' ),
        );

        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true, // Keep true for proper initialization, redirect handles access
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'course-category' ),
            'show_in_rest'      => true,
            'capabilities'      => array(
                'manage_terms' => 'edit_ts_courses',
                'edit_terms'   => 'edit_ts_courses',
                'delete_terms' => 'edit_ts_courses',
                'assign_terms' => 'edit_ts_courses',
            ),
        );

        register_taxonomy( 'ts_course_category', array( Course::POST_TYPE ), $args );
    }

    /**
     * Register course tag taxonomy.
     *
     * @return void
     */
    private static function register_course_tag() {
        $labels = array(
            'name'                       => _x( 'Course Tags', 'taxonomy general name', 'ts-lms' ),
            'singular_name'              => _x( 'Course Tag', 'taxonomy singular name', 'ts-lms' ),
            'search_items'               => __( 'Search Course Tags', 'ts-lms' ),
            'popular_items'              => __( 'Popular Course Tags', 'ts-lms' ),
            'all_items'                  => __( 'All Course Tags', 'ts-lms' ),
            'edit_item'                  => __( 'Edit Course Tag', 'ts-lms' ),
            'update_item'                => __( 'Update Course Tag', 'ts-lms' ),
            'add_new_item'               => __( 'Add New Course Tag', 'ts-lms' ),
            'new_item_name'              => __( 'New Course Tag Name', 'ts-lms' ),
            'separate_items_with_commas' => __( 'Separate course tags with commas', 'ts-lms' ),
            'add_or_remove_items'        => __( 'Add or remove course tags', 'ts-lms' ),
            'choose_from_most_used'      => __( 'Choose from the most used course tags', 'ts-lms' ),
            'not_found'                  => __( 'No course tags found.', 'ts-lms' ),
            'menu_name'                  => __( 'Course Tags', 'ts-lms' ),
        );

        $args = array(
            'hierarchical'      => false,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'course-tag' ),
            'show_in_rest'      => true,
        );

        register_taxonomy( 'ts_course_tag', array( Course::POST_TYPE ), $args );
    }
}
