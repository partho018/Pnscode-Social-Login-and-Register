<?php
/**
 * Access Control
 *
 * Manages content access logic including drip content and prerequisites.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Access;

use TS_LMS\Modules\Courses\Managers\CourseManager;
use TS_LMS\Modules\Courses\Managers\LessonManager;
use TS_LMS\Modules\Courses\PostTypes\Course;
use TS_LMS\Modules\Courses\PostTypes\Lesson;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * AccessControl class.
 */
class AccessControl {

    /**
     * Initialize access control.
     *
     * @return void
     */
    public static function init() {
        add_filter( 'the_content', array( __CLASS__, 'filter_lesson_content' ), 10 );
    }

    /**
     * Check if user can access a course.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID (default: current user).
     * @return bool True if user can access, false otherwise.
     */
    public static function can_access_course( $course_id, $user_id = null ) {
        if ( $user_id === null ) {
            $user_id = get_current_user_id();
        }

        // Check if user is logged in
        if ( ! $user_id ) {
            return apply_filters( 'ts_lms_can_access_course', false, $course_id, $user_id, 'not_logged_in' );
        }

        // Administrators can access everything
        if ( user_can( $user_id, 'manage_options' ) ) {
            return apply_filters( 'ts_lms_can_access_course', true, $course_id, $user_id, 'administrator' );
        }

        // Check if user is an instructor
        $instructors = CourseManager::get_instructors( $course_id );
        foreach ( $instructors as $instructor ) {
            if ( $instructor['id'] == $user_id ) {
                return apply_filters( 'ts_lms_can_access_course', true, $course_id, $user_id, 'instructor' );
            }
        }

        // Check if user is enrolled
        $is_enrolled = CourseManager::is_enrolled( $course_id, $user_id );
        
        return apply_filters( 'ts_lms_can_access_course', $is_enrolled, $course_id, $user_id, 'enrollment' );
    }

    /**
     * Check if user can access a lesson.
     *
     * @param int $lesson_id Lesson ID.
     * @param int $user_id   User ID (default: current user).
     * @return bool|WP_Error True if user can access, WP_Error with reason if not.
     */
    public static function can_access_lesson( $lesson_id, $user_id = null ) {
        if ( $user_id === null ) {
            $user_id = get_current_user_id();
        }

        // Check if lesson preview is enabled - allow access to everyone
        $is_preview = get_post_meta( $lesson_id, '_lesson_preview', true );
        if ( $is_preview ) {
            return apply_filters( 'ts_lms_can_access_lesson', true, $lesson_id, $user_id );
        }

        // Check if user is logged in
        if ( ! $user_id ) {
            return new \WP_Error( 'not_logged_in', __( 'You must be logged in to access this lesson.', 'ts-lms' ) );
        }

        // Get lesson course
        $course_id = get_post_meta( $lesson_id, '_lesson_course_id', true );
        if ( ! $course_id ) {
            return new \WP_Error( 'no_course', __( 'This lesson is not assigned to a course.', 'ts-lms' ) );
        }

        // Check course access
        if ( ! self::can_access_course( $course_id, $user_id ) ) {
            return new \WP_Error( 'no_course_access', __( 'You do not have access to this course.', 'ts-lms' ) );
        }

        // Administrators can access everything
        if ( user_can( $user_id, 'manage_options' ) ) {
            return apply_filters( 'ts_lms_can_access_lesson', true, $lesson_id, $user_id );
        }

        // Check drip access
        $drip_check = self::check_drip_access( $lesson_id, $user_id );
        if ( is_wp_error( $drip_check ) ) {
            return $drip_check;
        }

        return apply_filters( 'ts_lms_can_access_lesson', true, $lesson_id, $user_id );
    }

    /**
     * Check drip access for a lesson.
     *
     * @param int $lesson_id Lesson ID.
     * @param int $user_id   User ID.
     * @return bool|WP_Error True if accessible, WP_Error if not.
     */
    public static function check_drip_access( $lesson_id, $user_id ) {
        $drip_type = get_post_meta( $lesson_id, '_lesson_drip_type', true );

        // No drip restriction
        if ( empty( $drip_type ) || $drip_type === 'none' ) {
            return true;
        }

        // Time-based drip
        if ( $drip_type === 'time_based' ) {
            return self::check_time_based_drip( $lesson_id, $user_id );
        }

        // Progress-based drip
        if ( $drip_type === 'progress_based' ) {
            return self::check_progress_based_drip( $lesson_id, $user_id );
        }

        return apply_filters( 'ts_lms_drip_access_check', true, $lesson_id, $user_id, $drip_type );
    }

    /**
     * Check time-based drip access.
     *
     * @param int $lesson_id Lesson ID.
     * @param int $user_id   User ID.
     * @return bool|WP_Error True if accessible, WP_Error if not.
     */
    public static function check_time_based_drip( $lesson_id, $user_id ) {
        $drip_days = get_post_meta( $lesson_id, '_lesson_drip_days', true );
        
        if ( empty( $drip_days ) ) {
            return true;
        }

        // Get enrollment date
        $course_id = get_post_meta( $lesson_id, '_lesson_course_id', true );
        
        global $wpdb;
        $table = $wpdb->prefix . 'ts_course_enrollments';
        
        $enrollment = $wpdb->get_row( $wpdb->prepare(
            "SELECT enrolled_at FROM {$table} WHERE course_id = %d AND user_id = %d",
            $course_id,
            $user_id
        ) );

        if ( ! $enrollment ) {
            return new \WP_Error( 'not_enrolled', __( 'You are not enrolled in this course.', 'ts-lms' ) );
        }

        // Calculate available date
        $enrolled_date = strtotime( $enrollment->enrolled_at );
        $available_date = $enrolled_date + ( $drip_days * DAY_IN_SECONDS );
        $current_time = current_time( 'timestamp' );

        if ( $current_time < $available_date ) {
            $days_remaining = ceil( ( $available_date - $current_time ) / DAY_IN_SECONDS );
            return new \WP_Error(
                'drip_locked',
                sprintf(
                    __( 'This lesson will be available in %d days.', 'ts-lms' ),
                    $days_remaining
                )
            );
        }

        return true;
    }

    /**
     * Check progress-based drip access.
     *
     * @param int $lesson_id Lesson ID.
     * @param int $user_id   User ID.
     * @return bool|WP_Error True if accessible, WP_Error if not.
     */
    public static function check_progress_based_drip( $lesson_id, $user_id ) {
        $prerequisite_id = get_post_meta( $lesson_id, '_lesson_drip_prerequisite', true );
        
        if ( empty( $prerequisite_id ) ) {
            return true;
        }

        // Check if prerequisite is completed
        $progress = LessonManager::get_progress( $prerequisite_id, $user_id );

        if ( ! $progress || $progress['status'] !== 'completed' ) {
            $prerequisite = get_post( $prerequisite_id );
            $prerequisite_title = $prerequisite ? $prerequisite->post_title : __( 'the previous lesson', 'ts-lms' );
            
            return new \WP_Error(
                'prerequisite_not_met',
                sprintf(
                    __( 'You must complete "%s" before accessing this lesson.', 'ts-lms' ),
                    $prerequisite_title
                )
            );
        }

        return true;
    }

    /**
     * Check if user has a specific capability for a post.
     *
     * @param string $capability Capability to check.
     * @param int    $user_id    User ID.
     * @param int    $post_id    Post ID.
     * @return bool True if user has capability, false otherwise.
     */
    public static function has_capability( $capability, $user_id, $post_id = 0 ) {
        if ( $post_id > 0 ) {
            return user_can( $user_id, $capability, $post_id );
        }

        return user_can( $user_id, $capability );
    }

    /**
     * Filter lesson content based on access.
     *
     * @param string $content Post content.
     * @return string Filtered content.
     */
    public static function filter_lesson_content( $content ) {
        if ( ! is_singular( Lesson::POST_TYPE ) ) {
            return $content;
        }

        $lesson_id = get_the_ID();
        $user_id = get_current_user_id();

        $can_access = self::can_access_lesson( $lesson_id, $user_id );

        if ( is_wp_error( $can_access ) ) {
            $message = '<div class="ts-lms-access-denied">';
            $message .= '<h3>' . __( 'Access Restricted', 'ts-lms' ) . '</h3>';
            $message .= '<p>' . esc_html( $can_access->get_error_message() ) . '</p>';
            $message .= '</div>';

            return $message;
        }

        return $content;
    }

    /**
     * Get access status for a lesson.
     *
     * @param int $lesson_id Lesson ID.
     * @param int $user_id   User ID.
     * @return array Access status information.
     */
    public static function get_access_status( $lesson_id, $user_id = null ) {
        if ( $user_id === null ) {
            $user_id = get_current_user_id();
        }

        $can_access = self::can_access_lesson( $lesson_id, $user_id );

        $status = array(
            'can_access' => ! is_wp_error( $can_access ),
            'reason'     => '',
            'message'    => '',
        );

        if ( is_wp_error( $can_access ) ) {
            $status['reason'] = $can_access->get_error_code();
            $status['message'] = $can_access->get_error_message();
        }

        return $status;
    }
}
