<?php
/**
 * Instructor Access Control
 *
 * Handles access control and content ownership verification for instructors.
 *
 * @package TS_LMS\Modules\Courses\Access
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Access;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * InstructorAccess class.
 */
class InstructorAccess {
    
    /**
     * Initialize hooks.
     */
    public static function init() {
        // Filter post edit capabilities
        add_filter( 'map_meta_cap', array( __CLASS__, 'map_instructor_caps' ), 10, 4 );
        
        // Restrict admin access - Disabled
        // add_action( 'admin_init', array( __CLASS__, 'restrict_admin_access' ) );
        
        // Filter course queries
        add_action( 'pre_get_posts', array( __CLASS__, 'filter_instructor_courses' ) );
        
        // Prevent URL-based bypass
        add_action( 'load-post.php', array( __CLASS__, 'verify_post_access' ) );
        add_action( 'load-post-new.php', array( __CLASS__, 'verify_post_access' ) );
    }
    
    /**
     * Map meta capabilities for instructors.
     * FIXED: Simplified to prevent memory issues
     */
    public static function map_instructor_caps( $caps, $cap, $user_id, $args ) {
        // Get user object safely
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return $caps;
        }

        // Only apply to instructors (not admins)
        // Check roles directly to avoid infinite recursion from user_can()
        $is_instructor = in_array( 'instructor', $user->roles );
        $is_admin = in_array( 'administrator', $user->roles );

        if ( ! $is_instructor || $is_admin ) {
            return $caps;
        }
        
        // Course post types
        $course_types = array( 'ts_course', 'ts_lesson', 'ts_quiz', 'ts_assignment' );
        
        // Check if editing/deleting post
        if ( in_array( $cap, array( 'edit_post', 'delete_post' ) ) ) {
            $post_id = isset( $args[0] ) ? $args[0] : 0;
            $post = get_post( $post_id );
            
            if ( $post && in_array( $post->post_type, $course_types ) ) {
                // Check if instructor owns this content
                if ( self::is_instructor_content( $user_id, $post_id ) ) {
                    // Allow - use standard capability
                    $caps = array( 'edit_posts' );
                } else {
                    // Deny
                    $caps = array( 'do_not_allow' );
                }
            }
        }
        
        return $caps;
    }
    
    /**
     * Static cache for content ownership.
     * @var array
     */
    private static $ownership_cache = array();

    /**
     * Check if instructor owns the content.
     */
    public static function is_instructor_content( $user_id, $post_id ) {
        $cache_key = "{$user_id}_{$post_id}";
        if ( isset( self::$ownership_cache[ $cache_key ] ) ) {
            return self::$ownership_cache[ $cache_key ];
        }

        $post = get_post( $post_id );
        
        if ( ! $post ) {
            return self::$ownership_cache[ $cache_key ] = false;
        }
        
        // Check direct authorship
        if ( $post->post_author == $user_id ) {
            return self::$ownership_cache[ $cache_key ] = true;
        }
        
        // Check course_instructors table
        global $wpdb;
        $table = $wpdb->prefix . 'ts_course_instructors';
        
        $is_instructor = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE course_id = %d AND instructor_id = %d",
            $post_id,
            $user_id
        ) );
        
        return self::$ownership_cache[ $cache_key ] = ( $is_instructor > 0 );
    }
    
    /**
     * Restrict admin panel access for instructors.
     */
    public static function restrict_admin_access() {
        $settings = \TS_LMS\Admin\Settings::get_settings();
        $restrict = isset( $settings['restrict_instructor_admin'] ) && $settings['restrict_instructor_admin'];
        
        if ( ! $restrict ) {
            return;
        }
        
        // Allow AJAX requests
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
            return;
        }
        
        // Check if instructor (not admin)
        if ( in_array( 'instructor', (array) wp_get_current_user()->roles ) && ! current_user_can( 'manage_options' ) ) {
            wp_redirect( home_url( '/dashboard/' ) );
            exit;
        }
    }
    
    /**
     * Filter courses in admin to show only instructor's courses.
     */
    public static function filter_instructor_courses( $query ) {
        if ( ! is_admin() || ! $query->is_main_query() ) {
            return;
        }
        
        // Only for instructors
        if ( ! in_array( 'instructor', (array) wp_get_current_user()->roles ) || current_user_can( 'manage_options' ) ) {
            return;
        }
        
        $screen = get_current_screen();
        if ( ! $screen || ! in_array( $screen->post_type, array( 'ts_course', 'ts_lesson', 'ts_quiz', 'ts_assignment' ) ) ) {
            return;
        }
        
        // Filter to show only own posts
        $query->set( 'author', get_current_user_id() );
    }
    
    /**
     * Verify post access on edit screen.
     */
    public static function verify_post_access() {
        if ( ! in_array( 'instructor', (array) wp_get_current_user()->roles ) || current_user_can( 'manage_options' ) ) {
            return;
        }
        
        $post_id = isset( $_GET['post'] ) ? intval( $_GET['post'] ) : 0;
        
        if ( ! $post_id ) {
            return;
        }
        
        // Check ownership
        if ( ! self::is_instructor_content( get_current_user_id(), $post_id ) ) {
            wp_die( __( 'You do not have permission to edit this content.', 'ts-lms' ) );
        }
    }
}
