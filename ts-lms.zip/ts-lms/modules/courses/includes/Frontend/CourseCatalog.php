<?php
/**
 * Course Catalog Class
 *
 * Handles the course catalog grid display.
 *
 * @package TS_LMS\Modules\Courses\Frontend
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Frontend;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CourseCatalog {

    /**
     * Initialize the class.
     */
    public static function init() {
        $instance = new self();
        add_shortcode( 'ts_course_catalog', array( $instance, 'render_catalog' ) );
    }

    /**
     * Render the course catalog.
     *
     * @param array $atts Shortcode attributes.
     * @return string
     */
    public function render_catalog( $atts ) {
        wp_enqueue_style( 'ts-course-catalog', TS_LMS_PLUGIN_URL . 'assets/css/course-catalog.css', array(), TS_LMS_VERSION );
        wp_enqueue_script( 'ts-course-catalog', TS_LMS_PLUGIN_URL . 'assets/js/course-catalog.js', array( 'jquery' ), TS_LMS_VERSION, true );
        
        // Fetch categories and tags for filters
        $categories = get_terms( array( 'taxonomy' => 'ts_course_category', 'hide_empty' => true ) );
        $tags       = get_terms( array( 'taxonomy' => 'ts_course_tag', 'hide_empty' => true ) );
        
        // Get settings for filter visibility
        $settings = get_option( 'ts_lms_settings', array() );
        $show_filters  = !isset( $settings['course_filter'] ) || $settings['course_filter'];
        $show_sorting  = !isset( $settings['course_sorting'] ) || $settings['course_sorting'];
        $show_search   = !isset( $settings['catalog_show_search'] ) || $settings['catalog_show_search'];
        $show_type     = !isset( $settings['catalog_show_type'] ) || $settings['catalog_show_type'];
        $show_category = !isset( $settings['catalog_show_category'] ) || $settings['catalog_show_category'];
        $show_tag      = !isset( $settings['catalog_show_tag'] ) || $settings['catalog_show_tag'];
        $show_level    = !isset( $settings['catalog_show_level'] ) || $settings['catalog_show_level'];
        $show_price    = !isset( $settings['catalog_show_price'] ) || $settings['catalog_show_price'];

        ob_start();
        ?>
        <div class="ts-course-catalog-container">
            <button class="ts-mobile-filter-toggle">
                <span class="dashicons dashicons-filter"></span>
                <?php esc_html_e( 'Filter Courses', 'ts-lms' ); ?>
                <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
            </button>
            <div class="ts-course-catalog-wrap<?php echo !$show_filters ? ' no-sidebar' : ''; ?>">
                <?php if ( $show_filters ) : ?>
                    <!-- Sidebar Filters -->
                    <aside class="ts-catalog-sidebar">
                        <div class="ts-mobile-filter-header">
                            <h3><?php esc_html_e( 'Filters', 'ts-lms' ); ?></h3>
                            <button class="ts-close-mobile-filters">&times;</button>
                        </div>
                <?php if ( $show_search ) : ?>
                    <div class="ts-search-box">
                        <span class="dashicons dashicons-search"></span>
                        <input type="text" placeholder="<?php esc_attr_e( 'Search courses...', 'ts-lms' ); ?>">
                    </div>
                <?php endif; ?>

                <?php if ( $show_type ) : ?>
                    <div class="ts-filter-section">
                        <h4 class="ts-filter-title"><?php esc_html_e( 'Type', 'ts-lms' ); ?></h4>
                        <div class="ts-filter-group">
                            <label class="ts-filter-item"><input type="checkbox" value="course"> <?php esc_html_e( 'Course', 'ts-lms' ); ?></label>
                            <label class="ts-filter-item"><input type="checkbox" value="bundle"> <?php esc_html_e( 'Bundle', 'ts-lms' ); ?></label>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ( $show_category ) : ?>
                    <div class="ts-filter-section">
                        <h4 class="ts-filter-title"><?php esc_html_e( 'Category', 'ts-lms' ); ?></h4>
                        <div class="ts-filter-group">
                            <?php if ( !empty( $categories ) ) : ?>
                                <?php foreach ( $categories as $cat ) : ?>
                                    <label class="ts-filter-item">
                                        <input type="checkbox" value="<?php echo esc_attr( $cat->slug ); ?>"> 
                                        <?php echo esc_html( $cat->name ); ?>
                                    </label>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <p style="font-size: 12px; color: #94a3b8; font-style: italic; margin: 0;">
                                    <?php esc_html_e( 'No categories yet', 'ts-lms' ); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ( $show_tag && !empty( $tags ) ) : ?>
                    <div class="ts-filter-section">
                        <h4 class="ts-filter-title"><?php esc_html_e( 'Tag', 'ts-lms' ); ?></h4>
                        <div class="ts-filter-group">
                            <?php foreach ( $tags as $tag ) : ?>
                                <label class="ts-filter-item">
                                    <input type="checkbox" value="<?php echo esc_attr( $tag->slug ); ?>"> 
                                    <?php echo esc_html( $tag->name ); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ( $show_level ) : ?>
                    <div class="ts-filter-section">
                        <h4 class="ts-filter-title"><?php esc_html_e( 'Level', 'ts-lms' ); ?></h4>
                        <div class="ts-filter-group">
                            <label class="ts-filter-item"><input type="checkbox" value="all"> <?php esc_html_e( 'All Levels', 'ts-lms' ); ?></label>
                            <label class="ts-filter-item"><input type="checkbox" value="beginner"> <?php esc_html_e( 'Beginner', 'ts-lms' ); ?></label>
                            <label class="ts-filter-item"><input type="checkbox" value="intermediate"> <?php esc_html_e( 'Intermediate', 'ts-lms' ); ?></label>
                            <label class="ts-filter-item"><input type="checkbox" value="expert"> <?php esc_html_e( 'Expert', 'ts-lms' ); ?></label>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ( $show_price ) : ?>
                    <div class="ts-filter-section">
                        <h4 class="ts-filter-title"><?php esc_html_e( 'Price', 'ts-lms' ); ?></h4>
                        <div class="ts-filter-group">
                            <label class="ts-filter-item"><input type="checkbox" value="free"> <?php esc_html_e( 'Free', 'ts-lms' ); ?></label>
                            <label class="ts-filter-item"><input type="checkbox" value="paid"> <?php esc_html_e( 'Paid', 'ts-lms' ); ?></label>
                        </div>
                    </div>
                <?php endif; ?>

                <button class="ts-clear-filters">
                    <span class="dashicons dashicons-no"></span>
                    <?php esc_html_e( 'Clear All Filters', 'ts-lms' ); ?>
                </button>
            </aside>
            <?php endif; ?>

            <!-- Main Catalog Content -->
            <main class="ts-catalog-main">
                <?php if ( $show_sorting ) : ?>
                    <div class="ts-catalog-top-bar">
                        <select class="ts-sort-select">
                            <option value="newest"><?php esc_html_e( 'Release Date (newest first)', 'ts-lms' ); ?></option>
                            <option value="oldest"><?php esc_html_e( 'Release Date (oldest first)', 'ts-lms' ); ?></option>
                            <option value="popular"><?php esc_html_e( 'Most Popular', 'ts-lms' ); ?></option>
                            <option value="rating"><?php esc_html_e( 'Highest Rated', 'ts-lms' ); ?></option>
                        </select>
                    </div>
                <?php endif; ?>

                <div class="ts-course-grid<?php 
                    $course_columns = isset( $settings['course_columns'] ) ? $settings['course_columns'] : 'three';
                    echo ' columns-' . esc_attr( $course_columns );
                ?>">
                    <?php
                    $courses_per_page = isset( $settings['courses_per_page'] ) ? intval( $settings['courses_per_page'] ) : 12;
                    $args = array(
                        'post_type'      => array( 'ts_course', 'ts_bundle' ),
                        'post_status'    => 'publish',
                        'posts_per_page' => $courses_per_page,
                    );
                    $query = new \WP_Query( $args );

                    if ( $query->have_posts() ) :
                        while ( $query->have_posts() ) : $query->the_post();
                            include TS_LMS_PLUGIN_DIR . 'modules/courses/templates/course-card.php';
                        endwhile;
                        wp_reset_postdata();
                    else :
                        echo '<p>' . esc_html__( 'No courses found.', 'ts-lms' ) . '</p>';
                    endif;
                    ?>
                </div>
            </main>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
