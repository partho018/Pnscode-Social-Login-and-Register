<?php
/**
 * Course Permalink Fix
 *
 * Ensures course permalinks are not redirected to product pages.
 *
 * @package TS_LMS\Modules\Courses\Includes\Hooks
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Hooks;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * CoursePermalinkFix class.
 */
class CoursePermalinkFix {

    /**
     * Initialize the permalink fix.
     *
     * @return void
     */
    public static function init() {
        // Prevent canonical redirects from courses to products
        add_filter( 'redirect_canonical', array( __CLASS__, 'prevent_course_redirect' ), 10, 2 );
        
        // Ensure course template is loaded for course post type
        add_filter( 'template_include', array( __CLASS__, 'load_course_template' ), 99 );

        // Automatically flush rewrite rules if they are missing for our post type
        add_action( 'init', array( __CLASS__, 'check_and_flush_rules' ), 999 );
    }

    /**
     * Check if rewrite rules for ts_course exist, if not flush them.
     */
    public static function check_and_flush_rules() {
        // Only run if we are NOT doing AJAX or Cron
        if ( ( defined( 'DOING_AJAX' ) && DOING_AJAX ) || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
            return;
        }

        $rules = get_option( 'rewrite_rules' );
        
        // If rules are entirely empty or missing our slug, flush
        $found = false;
        if ( is_array( $rules ) ) {
            foreach ( $rules as $key => $value ) {
                if ( strpos( $key, 'course/' ) !== false ) {
                    $found = true;
                    break;
                }
            }
        }

        if ( ! $found ) {
            // Force a HARD flush if rules are missing
            flush_rewrite_rules( true );
        }
    }

    /**
     * Prevent WordPress from redirecting course URLs to product URLs.
     *
     * @param string $redirect_url  The redirect URL.
     * @param string $requested_url The requested URL.
     * @return string|false Modified redirect URL or false to prevent redirect.
     */
    public static function prevent_course_redirect( $redirect_url, $requested_url ) {
        global $wp_query;
        
        // If we're viewing a course or bundle, don't redirect
        if ( is_singular( array( 'ts_course', 'ts_bundle' ) ) ) {
            return false;
        }
        
        // If the requested URL contains '/course/', don't redirect
        if ( strpos( $requested_url, '/course/' ) !== false ) {
            return false;
        }

        return $redirect_url;
    }

    /**
     * Ensure course template is loaded for course post type.
     *
     * @param string $template The path of the template to include.
     * @return string Modified template path.
     */
    public static function load_course_template( $template ) {
        if ( is_singular( 'ts_course' ) ) {
            // Let the TemplateManager handle this
            return $template;
        }
        
        return $template;
    }
}
