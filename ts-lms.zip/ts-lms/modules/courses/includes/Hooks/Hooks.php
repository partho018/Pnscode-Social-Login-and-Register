<?php
/**
 * Hooks
 *
 * Defines all action and filter hooks for the Course Engine module.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Hooks;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Hooks class.
 */
class Hooks {

    /**
     * Initialize hooks.
     *
     * @return void
     */
    public static function init() {
        // This class serves as documentation for available hooks
        // Actual hooks are fired from their respective classes
    }

    /**
     * Get all available action hooks.
     *
     * @return array Action hooks with descriptions.
     */
    public static function get_action_hooks() {
        return array(
            // Course hooks
            'ts_lms_course_created'  => array(
                'description' => 'Fired when a course is created.',
                'parameters'  => array(
                    'course_id' => 'int - The ID of the created course',
                    'data'      => 'array - The course data',
                ),
            ),
            'ts_lms_course_updated'  => array(
                'description' => 'Fired when a course is updated.',
                'parameters'  => array(
                    'course_id' => 'int - The ID of the updated course',
                    'data'      => 'array - The updated course data',
                ),
            ),
            'ts_lms_course_deleted'  => array(
                'description' => 'Fired when a course is deleted.',
                'parameters'  => array(
                    'course_id' => 'int - The ID of the deleted course',
                ),
            ),
            'ts_lms_course_saved'    => array(
                'description' => 'Fired when a course post is saved.',
                'parameters'  => array(
                    'post_id' => 'int - The ID of the course post',
                    'post'    => 'WP_Post - The course post object',
                ),
            ),

            // Lesson hooks
            'ts_lms_lesson_created'   => array(
                'description' => 'Fired when a lesson is created.',
                'parameters'  => array(
                    'lesson_id' => 'int - The ID of the created lesson',
                    'data'      => 'array - The lesson data',
                ),
            ),
            'ts_lms_lesson_updated'   => array(
                'description' => 'Fired when a lesson is updated.',
                'parameters'  => array(
                    'lesson_id' => 'int - The ID of the updated lesson',
                    'data'      => 'array - The updated lesson data',
                ),
            ),
            'ts_lms_lesson_deleted'   => array(
                'description' => 'Fired when a lesson is deleted.',
                'parameters'  => array(
                    'lesson_id' => 'int - The ID of the deleted lesson',
                ),
            ),
            'ts_lms_lesson_saved'     => array(
                'description' => 'Fired when a lesson post is saved.',
                'parameters'  => array(
                    'post_id' => 'int - The ID of the lesson post',
                    'post'    => 'WP_Post - The lesson post object',
                ),
            ),
            'ts_lms_lesson_completed' => array(
                'description' => 'Fired when a lesson is marked as completed.',
                'parameters'  => array(
                    'lesson_id' => 'int - The ID of the completed lesson',
                    'user_id'   => 'int - The ID of the user',
                ),
            ),

            // Enrollment hooks
            'ts_lms_student_enrolled'   => array(
                'description' => 'Fired when a student is enrolled in a course.',
                'parameters'  => array(
                    'course_id' => 'int - The ID of the course',
                    'user_id'   => 'int - The ID of the enrolled user',
                ),
            ),
            'ts_lms_student_unenrolled' => array(
                'description' => 'Fired when a student is unenrolled from a course.',
                'parameters'  => array(
                    'course_id' => 'int - The ID of the course',
                    'user_id'   => 'int - The ID of the unenrolled user',
                ),
            ),

            // Bundle hooks
            'ts_lms_bundle_created'             => array(
                'description' => 'Fired when a bundle is created.',
                'parameters'  => array(
                    'bundle_id' => 'int - The ID of the created bundle',
                    'data'      => 'array - The bundle data',
                ),
            ),
            'ts_lms_bundle_saved'               => array(
                'description' => 'Fired when a bundle post is saved.',
                'parameters'  => array(
                    'bundle_id' => 'int - The ID of the bundle post',
                    'bundle'    => 'WP_Post - The bundle post object',
                ),
            ),
            'ts_lms_course_added_to_bundle'     => array(
                'description' => 'Fired when a course is added to a bundle.',
                'parameters'  => array(
                    'bundle_id'    => 'int - The ID of the bundle',
                    'course_id'    => 'int - The ID of the course',
                    'course_price' => 'float - The course price for commission',
                ),
            ),
            'ts_lms_course_removed_from_bundle' => array(
                'description' => 'Fired when a course is removed from a bundle.',
                'parameters'  => array(
                    'bundle_id' => 'int - The ID of the bundle',
                    'course_id' => 'int - The ID of the course',
                ),
            ),
            'ts_lms_user_enrolled_in_bundle'    => array(
                'description' => 'Fired when a user is enrolled in all bundle courses.',
                'parameters'  => array(
                    'bundle_id' => 'int - The ID of the bundle',
                    'user_id'   => 'int - The ID of the user',
                    'results'   => 'array - Enrollment results (success, failed, skipped)',
                ),
            ),
            'ts_lms_bundle_purchased'           => array(
                'description' => 'Fired when a bundle is purchased via WooCommerce.',
                'parameters'  => array(
                    'bundle_id' => 'int - The ID of the bundle',
                    'user_id'   => 'int - The ID of the user',
                    'order_id'  => 'int - The WooCommerce order ID',
                    'results'   => 'array - Enrollment results',
                ),
            ),
        );
    }

    /**
     * Get all available filter hooks.
     *
     * @return array Filter hooks with descriptions.
     */
    public static function get_filter_hooks() {
        return array(
            // Course filters
            'ts_lms_course_data'     => array(
                'description' => 'Filter course data before saving.',
                'parameters'  => array(
                    'post_data' => 'array - The course post data',
                    'data'      => 'array - The original course data',
                ),
                'return'      => 'array - Modified course post data',
            ),
            'ts_lms_course_statuses' => array(
                'description' => 'Filter available course statuses.',
                'parameters'  => array(
                    'statuses' => 'array - Array of status => label pairs',
                ),
                'return'      => 'array - Modified statuses array',
            ),
            'ts_lms_course_levels'   => array(
                'description' => 'Filter available course levels.',
                'parameters'  => array(
                    'levels' => 'array - Array of level => label pairs',
                ),
                'return'      => 'array - Modified levels array',
            ),

            // Lesson filters
            'ts_lms_lesson_data'  => array(
                'description' => 'Filter lesson data before saving.',
                'parameters'  => array(
                    'post_data' => 'array - The lesson post data',
                    'data'      => 'array - The original lesson data',
                ),
                'return'      => 'array - Modified lesson post data',
            ),
            'ts_lms_lesson_types' => array(
                'description' => 'Filter available lesson types.',
                'parameters'  => array(
                    'types' => 'array - Array of type => label pairs',
                ),
                'return'      => 'array - Modified types array',
            ),
            'ts_lms_video_types'  => array(
                'description' => 'Filter available video types.',
                'parameters'  => array(
                    'types' => 'array - Array of type => label pairs',
                ),
                'return'      => 'array - Modified types array',
            ),
            'ts_lms_drip_types'   => array(
                'description' => 'Filter available drip types.',
                'parameters'  => array(
                    'types' => 'array - Array of type => label pairs',
                ),
                'return'      => 'array - Modified types array',
            ),

            // Access control filters
            'ts_lms_can_access_course' => array(
                'description' => 'Filter whether a user can access a course.',
                'parameters'  => array(
                    'can_access' => 'bool - Whether user can access',
                    'course_id'  => 'int - The course ID',
                    'user_id'    => 'int - The user ID',
                    'reason'     => 'string - The reason for access decision',
                ),
                'return'      => 'bool - Modified access decision',
            ),
            'ts_lms_can_access_lesson' => array(
                'description' => 'Filter whether a user can access a lesson.',
                'parameters'  => array(
                    'can_access' => 'bool - Whether user can access',
                    'lesson_id'  => 'int - The lesson ID',
                    'user_id'    => 'int - The user ID',
                ),
                'return'      => 'bool - Modified access decision',
            ),
            'ts_lms_drip_access_check' => array(
                'description' => 'Filter drip access check result.',
                'parameters'  => array(
                    'can_access' => 'bool - Whether drip allows access',
                    'lesson_id'  => 'int - The lesson ID',
                    'user_id'    => 'int - The user ID',
                    'drip_type'  => 'string - The drip type',
                ),
                'return'      => 'bool|WP_Error - Modified access decision',
            ),
        );
    }

    /**
     * Print hooks documentation.
     *
     * @return void
     */
    public static function print_documentation() {
        echo "=== TS LMS Course Engine Hooks Documentation ===\n\n";

        echo "ACTION HOOKS:\n";
        echo "-------------\n\n";
        foreach ( self::get_action_hooks() as $hook => $info ) {
            echo "Hook: {$hook}\n";
            echo "Description: {$info['description']}\n";
            echo "Parameters:\n";
            foreach ( $info['parameters'] as $param => $desc ) {
                echo "  - {$param}: {$desc}\n";
            }
            echo "\n";
        }

        echo "\nFILTER HOOKS:\n";
        echo "-------------\n\n";
        foreach ( self::get_filter_hooks() as $hook => $info ) {
            echo "Hook: {$hook}\n";
            echo "Description: {$info['description']}\n";
            echo "Parameters:\n";
            foreach ( $info['parameters'] as $param => $desc ) {
                echo "  - {$param}: {$desc}\n";
            }
            echo "Returns: {$info['return']}\n";
            echo "\n";
        }
    }
}
