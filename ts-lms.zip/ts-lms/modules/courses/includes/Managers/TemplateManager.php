<?php
/**
 * Template Manager
 *
 * Handles template loading for Course Engine post types.
 *
 * @package TS_LMS\Modules\Courses\Managers
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Managers;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * TemplateManager class.
 */
class TemplateManager {

    /**
     * Initialize template manager.
     *
     * @return void
     */
    public static function init() {
        add_filter( 'template_include', array( __CLASS__, 'load_template' ), 100 );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
    }

    /**
     * Load custom template.
     *
     * @param string $template Template path.
     * @return string Modified template path.
     */
    public static function load_template( $template ) {
        if ( is_singular( 'ts_course' ) ) {
            $custom_template = TS_LMS_PLUGIN_DIR . 'modules/courses/templates/single-course.php';
            if ( file_exists( $custom_template ) ) {
                return $custom_template;
            }
        } elseif ( is_singular( 'ts_bundle' ) ) {
            $custom_template = TS_LMS_PLUGIN_DIR . 'modules/courses/templates/single-bundle.php';
            if ( file_exists( $custom_template ) ) {
                return $custom_template;
            }
        } elseif ( is_singular( array('ts_lesson', 'ts_quiz', 'ts_assignment') ) ) {
            $custom_template = TS_LMS_PLUGIN_DIR . 'modules/courses/templates/single-lesson.php';
            if ( file_exists( $custom_template ) ) {
                return $custom_template;
            }
        } elseif ( is_author() ) {
            $custom_template = TS_LMS_PLUGIN_DIR . 'modules/courses/templates/public-profile.php';
            if ( file_exists( $custom_template ) ) {
                return $custom_template;
            }
        }

        return $template;
    }

    /**
     * Enqueue frontend scripts and styles.
     * 
     * @return void
     */
    public static function enqueue_scripts() {
        if ( is_singular( array( 'ts_course', 'ts_bundle' ) ) ) {
            wp_enqueue_style(
                'ts-lms-single-course',
                TS_LMS_PLUGIN_URL . 'modules/courses/assets/css/single-course.css',
                array(),
                TS_LMS_VERSION
            );
            
            // Add Dashicons if not already loaded
            wp_enqueue_style( 'dashicons' );
        } elseif ( is_singular( array('ts_lesson', 'ts_quiz', 'ts_assignment') ) ) {
            wp_enqueue_style(
                'ts-lms-course-player',
                TS_LMS_PLUGIN_URL . 'modules/courses/assets/css/course-player.css',
                array(),
                TS_LMS_VERSION
            );
            wp_enqueue_style( 'dashicons' );
        } elseif ( is_author() ) {
            wp_enqueue_style(
                'ts-lms-public-profile',
                TS_LMS_PLUGIN_URL . 'modules/courses/assets/css/public-profile.css',
                array(),
                TS_LMS_VERSION
            );
            wp_enqueue_style( 'dashicons' );
        }
    }
}
