<?php
/**
 * Bundle Manager
 *
 * Handles bundle-related operations and business logic.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Managers;

use TS_LMS\Modules\Courses\PostTypes\Bundle;
use TS_LMS\Modules\Courses\PostTypes\Course;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * BundleManager class.
 */
class BundleManager {

	/**
	 * Create a new bundle.
	 *
	 * @param array $data Bundle data.
	 * @return int|WP_Error Bundle ID on success, WP_Error on failure.
	 */
	public static function create_bundle( $data ) {
		// Validate required fields
		if ( empty( $data['title'] ) ) {
			return new \WP_Error( 'missing_title', __( 'Bundle title is required.', 'ts-lms' ) );
		}

		// Check user capability
		if ( ! current_user_can( 'edit_ts_bundles' ) ) {
			return new \WP_Error( 'permission_denied', __( 'You do not have permission to create bundles.', 'ts-lms' ) );
		}

		// Prepare post data
		$post_data = array(
			'post_title'   => sanitize_text_field( $data['title'] ),
			'post_content' => wp_kses_post( $data['content'] ?? '' ),
			'post_status'  => 'publish',
			'post_type'    => Bundle::POST_TYPE,
			'post_author'  => get_current_user_id(),
		);

		// Apply filter
		$post_data = apply_filters( 'ts_lms_bundle_data', $post_data, $data );

		// Insert post
		$bundle_id = wp_insert_post( $post_data, true );

		if ( is_wp_error( $bundle_id ) ) {
			return $bundle_id;
		}

		// Save meta data
		if ( isset( $data['price'] ) ) {
			update_post_meta( $bundle_id, '_bundle_price', floatval( $data['price'] ) );
		}

		if ( isset( $data['status'] ) ) {
			update_post_meta( $bundle_id, '_bundle_status', sanitize_text_field( $data['status'] ) );
		}

		// Fire action hook
		do_action( 'ts_lms_bundle_created', $bundle_id, $data );

		return $bundle_id;
	}

	/**
	 * Add a course to a bundle.
	 *
	 * @param int   $bundle_id    Bundle ID.
	 * @param int   $course_id    Course ID.
	 * @param float $course_price Course price for commission calculation.
	 * @param int   $order_index  Order index (optional).
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public static function add_course_to_bundle( $bundle_id, $course_id, $course_price, $order_index = 0 ) {
		global $wpdb;

		// Validate bundle
		$bundle = get_post( $bundle_id );
		if ( ! $bundle || $bundle->post_type !== Bundle::POST_TYPE ) {
			return new \WP_Error( 'invalid_bundle', __( 'Invalid bundle ID.', 'ts-lms' ) );
		}

		// Validate course
		$course = get_post( $course_id );
		if ( ! $course || $course->post_type !== Course::POST_TYPE ) {
			return new \WP_Error( 'invalid_course', __( 'Invalid course ID.', 'ts-lms' ) );
		}

		// Check if already exists
		$table = $wpdb->prefix . 'ts_bundle_courses';
		$exists = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE bundle_id = %d AND course_id = %d",
			$bundle_id,
			$course_id
		) );

		if ( $exists ) {
			// Update existing
			$wpdb->update(
				$table,
				array(
					'course_price' => floatval( $course_price ),
					'order_index'  => absint( $order_index ),
				),
				array(
					'bundle_id' => $bundle_id,
					'course_id' => $course_id,
				),
				array( '%f', '%d' ),
				array( '%d', '%d' )
			);
		} else {
			// Insert new
			$result = $wpdb->insert(
				$table,
				array(
					'bundle_id'    => $bundle_id,
					'course_id'    => $course_id,
					'course_price' => floatval( $course_price ),
					'order_index'  => absint( $order_index ),
					'created_at'   => current_time( 'mysql' ),
				),
				array( '%d', '%d', '%f', '%d', '%s' )
			);

			if ( $result === false ) {
				return new \WP_Error( 'insert_failed', __( 'Failed to add course to bundle.', 'ts-lms' ) );
			}
		}

		// Fire action hook
		do_action( 'ts_lms_course_added_to_bundle', $bundle_id, $course_id, $course_price );

		return true;
	}

	/**
	 * Remove a course from a bundle.
	 *
	 * @param int $bundle_id Bundle ID.
	 * @param int $course_id Course ID.
	 * @return bool True on success, false on failure.
	 */
	public static function remove_course_from_bundle( $bundle_id, $course_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_bundle_courses';

		$result = $wpdb->delete(
			$table,
			array(
				'bundle_id' => $bundle_id,
				'course_id' => $course_id,
			),
			array( '%d', '%d' )
		);

		if ( $result !== false ) {
			do_action( 'ts_lms_course_removed_from_bundle', $bundle_id, $course_id );
		}

		return $result !== false;
	}

	/**
	 * Get all courses in a bundle.
	 *
	 * @param int $bundle_id Bundle ID.
	 * @return array Array of course data with prices.
	 */
	public static function get_bundle_courses( $bundle_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_bundle_courses';

		$results = $wpdb->get_results( $wpdb->prepare(
			"SELECT course_id, course_price, order_index FROM {$table} WHERE bundle_id = %d ORDER BY order_index ASC",
			$bundle_id
		) );

		$courses = array();
		foreach ( $results as $row ) {
			$course = get_post( $row->course_id );
			if ( $course && $course->post_type === Course::POST_TYPE ) {
				$courses[] = array(
					'id'    => $course->ID,
					'title' => $course->post_title,
					'price' => floatval( $row->course_price ),
					'order' => absint( $row->order_index ),
				);
			}
		}

		return $courses;
	}

	/**
	 * Enroll a user in all courses within a bundle.
	 *
	 * @param int $bundle_id Bundle ID.
	 * @param int $user_id   User ID.
	 * @return array|WP_Error Array of enrollment results, WP_Error on failure.
	 */
	public static function enroll_user_in_bundle( $bundle_id, $user_id ) {
		// Validate bundle
		$bundle = get_post( $bundle_id );
		if ( ! $bundle || $bundle->post_type !== Bundle::POST_TYPE ) {
			return new \WP_Error( 'invalid_bundle', __( 'Invalid bundle ID.', 'ts-lms' ) );
		}

		// Validate user
		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return new \WP_Error( 'invalid_user', __( 'Invalid user ID.', 'ts-lms' ) );
		}

		// Get bundle courses
		$courses = self::get_bundle_courses( $bundle_id );

		if ( empty( $courses ) ) {
			return new \WP_Error( 'empty_bundle', __( 'Bundle has no courses.', 'ts-lms' ) );
		}

		$results = array(
			'success' => array(),
			'failed'  => array(),
			'skipped' => array(),
		);

		// Enroll in each course
		foreach ( $courses as $course ) {
			// Check if already enrolled
			if ( CourseManager::is_enrolled( $course['id'], $user_id ) ) {
				$results['skipped'][] = array(
					'course_id' => $course['id'],
					'reason'    => 'already_enrolled',
				);
				continue;
			}

			// Enroll student
			$enrollment = CourseManager::enroll_student( $course['id'], $user_id );

			if ( is_wp_error( $enrollment ) ) {
				$results['failed'][] = array(
					'course_id' => $course['id'],
					'error'     => $enrollment->get_error_message(),
				);
			} else {
				$results['success'][] = $course['id'];

				// Store bundle enrollment metadata
				global $wpdb;
				$table = $wpdb->prefix . 'ts_course_enrollments';
				$wpdb->update(
					$table,
					array(
						'source_type' => 'bundle',
						'source_id'   => $bundle_id,
					),
					array(
						'course_id' => $course['id'],
						'user_id'   => $user_id,
					),
					array( '%s', '%d' ),
					array( '%d', '%d' )
				);
			}
		}

		// Fire action hook
		do_action( 'ts_lms_user_enrolled_in_bundle', $bundle_id, $user_id, $results );

		return $results;
	}

	/**
	 * Calculate commission for a specific course in a bundle.
	 *
	 * @param int $bundle_id Bundle ID.
	 * @param int $course_id Course ID.
	 * @return float|WP_Error Commission amount, WP_Error on failure.
	 */
	public static function calculate_course_commission( $bundle_id, $course_id ) {
		global $wpdb;

		// Get bundle price
		$bundle_price = get_post_meta( $bundle_id, '_bundle_price', true );
		if ( ! $bundle_price || $bundle_price <= 0 ) {
			return new \WP_Error( 'invalid_price', __( 'Bundle price is not set or invalid.', 'ts-lms' ) );
		}

		// Get all course prices in bundle
		$table = $wpdb->prefix . 'ts_bundle_courses';
		$courses = $wpdb->get_results( $wpdb->prepare(
			"SELECT course_id, course_price FROM {$table} WHERE bundle_id = %d",
			$bundle_id
		) );

		if ( empty( $courses ) ) {
			return new \WP_Error( 'empty_bundle', __( 'Bundle has no courses.', 'ts-lms' ) );
		}

		// Calculate total course prices
		$total_course_price = 0;
		$course_price = 0;

		foreach ( $courses as $course ) {
			$total_course_price += floatval( $course->course_price );
			if ( $course->course_id == $course_id ) {
				$course_price = floatval( $course->course_price );
			}
		}

		// Prevent division by zero
		if ( $total_course_price <= 0 ) {
			return new \WP_Error( 'invalid_total', __( 'Total course prices must be greater than zero.', 'ts-lms' ) );
		}

		// Calculate weighted commission
		$commission = ( $bundle_price * ( $course_price / $total_course_price ) );

		return round( $commission, 2 );
	}

	/**
	 * Get bundle by WooCommerce product ID.
	 *
	 * @param int $product_id WooCommerce product ID.
	 * @return int|false Bundle ID on success, false on failure.
	 */
	public static function get_bundle_by_woo_product( $product_id ) {
		$args = array(
			'post_type'      => Bundle::POST_TYPE,
			'posts_per_page' => 1,
			'meta_query'     => array(
				array(
					'key'   => '_bundle_woo_product_id',
					'value' => absint( $product_id ),
				),
			),
			'fields'         => 'ids',
		);

		$bundles = get_posts( $args );

		return ! empty( $bundles ) ? $bundles[0] : false;
	}

	/**
	 * Get bundle data.
	 *
	 * @param int $bundle_id Bundle ID.
	 * @return array|WP_Error Bundle data on success, WP_Error on failure.
	 */
	public static function get_bundle( $bundle_id ) {
		$bundle = get_post( $bundle_id );

		if ( ! $bundle || $bundle->post_type !== Bundle::POST_TYPE ) {
			return new \WP_Error( 'invalid_bundle', __( 'Invalid bundle ID.', 'ts-lms' ) );
		}

		return array(
			'id'              => $bundle->ID,
			'title'           => $bundle->post_title,
			'content'         => $bundle->post_content,
			'price'           => get_post_meta( $bundle_id, '_bundle_price', true ),
			'status'          => get_post_meta( $bundle_id, '_bundle_status', true ),
			'woo_product_id'  => get_post_meta( $bundle_id, '_bundle_woo_product_id', true ),
			'courses'         => self::get_bundle_courses( $bundle_id ),
		);
	}
}
