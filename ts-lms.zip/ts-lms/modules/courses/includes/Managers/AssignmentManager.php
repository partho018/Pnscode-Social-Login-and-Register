<?php
/**
 * Assignment Manager
 *
 * Handles assignment-related operations and business logic.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Managers;

use TS_LMS\Modules\Courses\PostTypes\Assignment;
use TS_LMS\Modules\Courses\PostTypes\Course;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * AssignmentManager class.
 */
class AssignmentManager {

    /**
     * Create a new assignment.
     *
     * @param array $data Assignment data.
     * @return int|WP_Error Assignment ID on success, WP_Error on failure.
     */
    public static function create_assignment( $data ) {
        // Validate required fields
        if ( empty( $data['title'] ) ) {
            return new \WP_Error( 'missing_title', __( 'Assignment title is required.', 'ts-lms' ) );
        }

        // Check user capability
        if ( ! current_user_can( 'edit_ts_assignments' ) ) {
            return new \WP_Error( 'permission_denied', __( 'You do not have permission to create assignments.', 'ts-lms' ) );
        }

        // Prepare post data
        $post_data = array(
            'post_title'   => sanitize_text_field( $data['title'] ),
            'post_content' => wp_kses_post( $data['content'] ?? '' ),
            'post_status'  => 'draft',
            'post_type'    => Assignment::POST_TYPE,
            'post_author'  => get_current_user_id(),
        );

        if ( isset( $data['parent_id'] ) ) {
            $post_data['post_parent'] = absint( $data['parent_id'] );
        }

        // Apply filter
        $post_data = apply_filters( 'ts_lms_assignment_data', $post_data, $data );

        // Insert post
        $assignment_id = wp_insert_post( $post_data, true );

        if ( is_wp_error( $assignment_id ) ) {
            return $assignment_id;
        }

        // Save meta data
        self::save_assignment_meta( $assignment_id, $data );

        // Fire action hook
        do_action( 'ts_lms_assignment_created', $assignment_id, $data );

        return $assignment_id;
    }

    /**
     * Update an assignment.
     *
     * @param int   $assignment_id Assignment ID.
     * @param array $data          Assignment data.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function update_assignment( $assignment_id, $data ) {
        // Check if assignment exists
        $assignment = get_post( $assignment_id );
        if ( ! $assignment || $assignment->post_type !== Assignment::POST_TYPE ) {
            return new \WP_Error( 'invalid_assignment', __( 'Invalid assignment ID.', 'ts-lms' ) );
        }

        // Check user capability
        if ( ! current_user_can( 'edit_ts_assignment', $assignment_id ) ) {
            return new \WP_Error( 'permission_denied', __( 'You do not have permission to edit this assignment.', 'ts-lms' ) );
        }

        // Prepare post data
        $post_data = array( 'ID' => $assignment_id );

        if ( isset( $data['title'] ) ) {
            $post_data['post_title'] = sanitize_text_field( $data['title'] );
        }

        if ( isset( $data['content'] ) ) {
            $post_data['post_content'] = wp_kses_post( $data['content'] );
        }

        if ( isset( $data['parent_id'] ) ) {
            $post_data['post_parent'] = absint( $data['parent_id'] );
        }

        // Update post
        $result = wp_update_post( $post_data, true );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        // Update meta data
        self::save_assignment_meta( $assignment_id, $data );

        // Fire action hook
        do_action( 'ts_lms_assignment_updated', $assignment_id, $data );

        return true;
    }

    /**
     * Save Assignment Meta.
     *
     * @param int   $assignment_id Assignment ID.
     * @param array $data          Assignment data.
     */
    private static function save_assignment_meta( $assignment_id, $data ) {
        if ( isset( $data['course_id'] ) ) {
            update_post_meta( $assignment_id, '_assignment_course_id', absint( $data['course_id'] ) );
        }
        
        // Attachments
        if ( isset( $data['attachments'] ) && is_array( $data['attachments'] ) ) {
             $attachments = array_map( 'absint', $data['attachments'] );
             update_post_meta( $assignment_id, '_assignment_attachments', $attachments );
        }

        // Time Limit
        if ( isset( $data['time_limit'] ) ) update_post_meta( $assignment_id, '_assignment_time_limit', absint( $data['time_limit'] ) );
        if ( isset( $data['time_unit'] ) ) update_post_meta( $assignment_id, '_assignment_time_unit', sanitize_text_field( $data['time_unit'] ) );
        
        // Deadline
        if ( isset( $data['deadline_toggle'] ) ) update_post_meta( $assignment_id, '_assignment_deadline_toggle', filter_var( $data['deadline_toggle'], FILTER_VALIDATE_BOOLEAN ) );
        if ( isset( $data['deadline'] ) ) update_post_meta( $assignment_id, '_assignment_deadline', sanitize_text_field( $data['deadline'] ) ); // ISO date string

        // Points
        if ( isset( $data['total_points'] ) ) update_post_meta( $assignment_id, '_assignment_total_points', absint( $data['total_points'] ) );
        if ( isset( $data['min_points'] ) ) update_post_meta( $assignment_id, '_assignment_min_points', absint( $data['min_points'] ) );
        
        // Files
        if ( isset( $data['file_limit'] ) ) update_post_meta( $assignment_id, '_assignment_file_limit', absint( $data['file_limit'] ) );
        if ( isset( $data['file_size'] ) ) update_post_meta( $assignment_id, '_assignment_file_size', absint( $data['file_size'] ) );
        if ( isset( $data['file_size_unit'] ) ) update_post_meta( $assignment_id, '_assignment_file_size_unit', sanitize_text_field( $data['file_size_unit'] ) );
        
        // Resubmission
        if ( isset( $data['resubmission'] ) ) update_post_meta( $assignment_id, '_assignment_resubmission', filter_var( $data['resubmission'], FILTER_VALIDATE_BOOLEAN ) );
        if ( isset( $data['max_attempts'] ) ) update_post_meta( $assignment_id, '_assignment_max_attempts', absint( $data['max_attempts'] ) );
    }

    /**
     * Get an assignment.
     *
     * @param int $assignment_id Assignment ID.
     * @return array|WP_Error Assignment data on success, WP_Error on failure.
     */
    public static function get_assignment( $assignment_id ) {
        $assignment = get_post( $assignment_id );

        if ( ! $assignment || $assignment->post_type !== Assignment::POST_TYPE ) {
            return new \WP_Error( 'invalid_assignment', __( 'Invalid assignment ID.', 'ts-lms' ) );
        }

        // Get meta data
        $meta = array(
            'course_id'       => get_post_meta( $assignment_id, '_assignment_course_id', true ),
            'attachments'     => get_post_meta( $assignment_id, '_assignment_attachments', true ),
            'time_limit'      => get_post_meta( $assignment_id, '_assignment_time_limit', true ),
            'time_unit'       => get_post_meta( $assignment_id, '_assignment_time_unit', true ),
            'deadline_toggle' => get_post_meta( $assignment_id, '_assignment_deadline_toggle', true ),
            'deadline'        => get_post_meta( $assignment_id, '_assignment_deadline', true ),
            'total_points'    => get_post_meta( $assignment_id, '_assignment_total_points', true ),
            'min_points'      => get_post_meta( $assignment_id, '_assignment_min_points', true ),
            'file_limit'      => get_post_meta( $assignment_id, '_assignment_file_limit', true ),
            'file_size'       => get_post_meta( $assignment_id, '_assignment_file_size', true ),
            'file_size_unit'  => get_post_meta( $assignment_id, '_assignment_file_size_unit', true ),
            'resubmission'    => get_post_meta( $assignment_id, '_assignment_resubmission', true ),
            'max_attempts'    => get_post_meta( $assignment_id, '_assignment_max_attempts', true ),
        );

        return array(
            'id'      => $assignment->ID,
            'title'   => $assignment->post_title,
            'content' => $assignment->post_content,
            'status'  => $assignment->post_status,
            'meta'    => $meta,
        );
    }
}
