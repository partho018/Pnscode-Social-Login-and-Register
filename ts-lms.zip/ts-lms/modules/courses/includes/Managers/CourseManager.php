<?php
/**
 * Course Manager
 *
 * Handles course-related operations and business logic.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Managers;

use TS_LMS\Modules\Courses\PostTypes\Course;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * CourseManager class.
 */
class CourseManager {

    /**
     * Create a new course.
     *
     * @param array $data Course data.
     * @return int|WP_Error Course ID on success, WP_Error on failure.
     */
    public static function create_course( $data ) {
        // Validate required fields
        if ( empty( $data['title'] ) ) {
            return new \WP_Error( 'missing_title', __( 'Course title is required.', 'ts-lms' ) );
        }

        // Check user capability
        if ( ! current_user_can( 'edit_ts_courses' ) ) {
            return new \WP_Error( 'permission_denied', __( 'You do not have permission to create courses.', 'ts-lms' ) );
        }

        // Prepare post data
        $post_data = array(
            'post_title'   => sanitize_text_field( $data['title'] ),
            'post_content' => wp_kses_post( $data['content'] ?? '' ),
            'post_excerpt' => sanitize_textarea_field( $data['excerpt'] ?? '' ),
            'post_status'  => 'draft',
            'post_type'    => Course::POST_TYPE,
            'post_author'  => get_current_user_id(),
        );

        // Apply filter
        $post_data = apply_filters( 'ts_lms_course_data', $post_data, $data );

        // Insert post
        $course_id = wp_insert_post( $post_data, true );

        if ( is_wp_error( $course_id ) ) {
            return $course_id;
        }

        // Save meta data
        if ( isset( $data['status'] ) ) {
            update_post_meta( $course_id, '_course_status', sanitize_text_field( $data['status'] ) );
        }

        if ( isset( $data['duration'] ) ) {
            update_post_meta( $course_id, '_course_duration', absint( $data['duration'] ) );
        }

        if ( isset( $data['level'] ) ) {
            update_post_meta( $course_id, '_course_level', sanitize_text_field( $data['level'] ) );
        }

        if ( isset( $data['max_students'] ) ) {
            update_post_meta( $course_id, '_course_max_students', absint( $data['max_students'] ) );
        }

        // Fire action hook
        do_action( 'ts_lms_course_created', $course_id, $data );

        return $course_id;
    }

    /**
     * Update a course.
     *
     * @param int   $course_id Course ID.
     * @param array $data      Course data.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function update_course( $course_id, $data ) {
        // Check if course exists
        $course = get_post( $course_id );
        if ( ! $course || $course->post_type !== Course::POST_TYPE ) {
            return new \WP_Error( 'invalid_course', __( 'Invalid course ID.', 'ts-lms' ) );
        }

        // Check user capability
        if ( ! current_user_can( 'edit_ts_course', $course_id ) ) {
            return new \WP_Error( 'permission_denied', __( 'You do not have permission to edit this course.', 'ts-lms' ) );
        }

        // Prepare post data
        $post_data = array( 'ID' => $course_id );

        if ( isset( $data['title'] ) ) {
            $post_data['post_title'] = sanitize_text_field( $data['title'] );
        }

        if ( isset( $data['content'] ) ) {
            $post_data['post_content'] = wp_kses_post( $data['content'] );
        }

        if ( isset( $data['excerpt'] ) ) {
            $post_data['post_excerpt'] = sanitize_textarea_field( $data['excerpt'] );
        }

        // Update post
        $result = wp_update_post( $post_data, true );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        // Update meta data
        if ( isset( $data['status'] ) ) {
            update_post_meta( $course_id, '_course_status', sanitize_text_field( $data['status'] ) );
        }

        if ( isset( $data['duration'] ) ) {
            update_post_meta( $course_id, '_course_duration', absint( $data['duration'] ) );
        }

        if ( isset( $data['level'] ) ) {
            update_post_meta( $course_id, '_course_level', sanitize_text_field( $data['level'] ) );
        }

        if ( isset( $data['max_students'] ) ) {
            update_post_meta( $course_id, '_course_max_students', absint( $data['max_students'] ) );
        }

        // Fire action hook
        do_action( 'ts_lms_course_updated', $course_id, $data );

        return true;
    }

    /**
     * Delete a course.
     *
     * @param int  $course_id Course ID.
     * @param bool $force     Whether to force delete (bypass trash).
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function delete_course( $course_id, $force = false ) {
        // Check if course exists
        $course = get_post( $course_id );
        if ( ! $course || $course->post_type !== Course::POST_TYPE ) {
            return new \WP_Error( 'invalid_course', __( 'Invalid course ID.', 'ts-lms' ) );
        }

        // Check user capability
        if ( ! current_user_can( 'delete_ts_course', $course_id ) ) {
            return new \WP_Error( 'permission_denied', __( 'You do not have permission to delete this course.', 'ts-lms' ) );
        }

        // Delete post
        $result = wp_delete_post( $course_id, $force );

        if ( ! $result ) {
            return new \WP_Error( 'delete_failed', __( 'Failed to delete course.', 'ts-lms' ) );
        }

        // Fire action hook
        do_action( 'ts_lms_course_deleted', $course_id );

        return true;
    }

    /**
     * Get a course.
     *
     * @param int $course_id Course ID.
     * @return array|WP_Error Course data on success, WP_Error on failure.
     */
    public static function get_course( $course_id ) {
        $course = get_post( $course_id );

        if ( ! $course || $course->post_type !== Course::POST_TYPE ) {
            return new \WP_Error( 'invalid_course', __( 'Invalid course ID.', 'ts-lms' ) );
        }

        // Get meta data
        $meta = array(
            'status'       => get_post_meta( $course_id, '_course_status', true ),
            'duration'     => get_post_meta( $course_id, '_course_duration', true ),
            'level'        => get_post_meta( $course_id, '_course_level', true ),
            'max_students' => get_post_meta( $course_id, '_course_max_students', true ),
            'start_date'   => get_post_meta( $course_id, '_course_start_date', true ),
            'end_date'     => get_post_meta( $course_id, '_course_end_date', true ),
        );

        return array(
            'id'      => $course->ID,
            'title'   => $course->post_title,
            'content' => $course->post_content,
            'excerpt' => $course->post_excerpt,
            'status'  => $course->post_status,
            'meta'    => $meta,
        );
    }

    /**
     * Add an instructor to a course.
     *
     * @param int    $course_id     Course ID.
     * @param int    $instructor_id Instructor user ID.
     * @param string $role          Instructor role (default: 'instructor').
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function add_instructor( $course_id, $instructor_id, $role = 'instructor' ) {
        global $wpdb;

        // Validate course
        $course = get_post( $course_id );
        if ( ! $course || $course->post_type !== Course::POST_TYPE ) {
            return new \WP_Error( 'invalid_course', __( 'Invalid course ID.', 'ts-lms' ) );
        }

        // Validate user
        $user = get_user_by( 'id', $instructor_id );
        if ( ! $user ) {
            return new \WP_Error( 'invalid_user', __( 'Invalid instructor ID.', 'ts-lms' ) );
        }

        // Check if already exists
        $table = $wpdb->prefix . 'ts_course_instructors';
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table} WHERE course_id = %d AND instructor_id = %d",
            $course_id,
            $instructor_id
        ) );

        if ( $exists ) {
            // Update role
            $wpdb->update(
                $table,
                array( 'role' => sanitize_text_field( $role ) ),
                array(
                    'course_id'     => $course_id,
                    'instructor_id' => $instructor_id,
                ),
                array( '%s' ),
                array( '%d', '%d' )
            );
        } else {
            // Insert new
            $wpdb->insert(
                $table,
                array(
                    'course_id'     => $course_id,
                    'instructor_id' => $instructor_id,
                    'role'          => sanitize_text_field( $role ),
                    'created_at'    => current_time( 'mysql' ),
                ),
                array( '%d', '%d', '%s', '%s' )
            );
        }

        return true;
    }

    /**
     * Remove an instructor from a course.
     *
     * @param int $course_id     Course ID.
     * @param int $instructor_id Instructor user ID.
     * @return bool True on success, false on failure.
     */
    public static function remove_instructor( $course_id, $instructor_id ) {
        global $wpdb;

        $table = $wpdb->prefix . 'ts_course_instructors';

        $result = $wpdb->delete(
            $table,
            array(
                'course_id'     => $course_id,
                'instructor_id' => $instructor_id,
            ),
            array( '%d', '%d' )
        );

        return $result !== false;
    }

    /**
     * Get instructors for a course.
     *
     * @param int $course_id Course ID.
     * @return array Array of instructor data.
     */
    public static function get_instructors( $course_id ) {
        global $wpdb;

        $table = $wpdb->prefix . 'ts_course_instructors';

        $results = $wpdb->get_results( $wpdb->prepare(
            "SELECT instructor_id, role, created_at FROM {$table} WHERE course_id = %d",
            $course_id
        ) );

        $instructors = array();
        foreach ( $results as $row ) {
            $user = get_user_by( 'id', $row->instructor_id );
            if ( $user ) {
                $instructors[] = array(
                    'id'         => $user->ID,
                    'name'       => $user->display_name,
                    'email'      => $user->user_email,
                    'role'       => $row->role,
                    'created_at' => $row->created_at,
                );
            }
        }

        return $instructors;
    }

    /**
     * Enroll a student in a course.
     *
     * @param int   $course_id Course ID.
     * @param int   $user_id   User ID.
     * @param array $args      Optional arguments (subscription details).
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function enroll_student( $course_id, $user_id, $args = array() ) {
        global $wpdb;

        // Validate course
        $course = get_post( $course_id );
        if ( ! $course || $course->post_type !== Course::POST_TYPE ) {
            return new \WP_Error( 'invalid_course', __( 'Invalid course ID.', 'ts-lms' ) );
        }

        // Validate user
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) {
            return new \WP_Error( 'invalid_user', __( 'Invalid user ID.', 'ts-lms' ) );
        }

        // Check if already enrolled
        if ( self::is_enrolled( $course_id, $user_id ) ) {
            return new \WP_Error( 'already_enrolled', __( 'User is already enrolled in this course.', 'ts-lms' ) );
        }

        $defaults = array(
            'status'            => 'active',
            'subscription_id'   => null,
            'subscription_type' => null,
            'expires_at'        => null,
        );
        $args = wp_parse_args( $args, $defaults );

        // Insert enrollment
        $table = $wpdb->prefix . 'ts_course_enrollments';
        $data = array(
            'course_id'   => $course_id,
            'user_id'     => $user_id,
            'enrolled_at' => current_time( 'mysql' ),
            'status'      => $args['status'],
        );
        
        $format = array( '%d', '%d', '%s', '%s' );

        if ( ! empty( $args['subscription_id'] ) ) {
            $data['subscription_id'] = $args['subscription_id'];
            $format[] = '%s';
        }
        if ( ! empty( $args['subscription_type'] ) ) {
            $data['subscription_type'] = $args['subscription_type'];
            $format[] = '%s';
        }
        if ( ! empty( $args['expires_at'] ) ) {
            $data['expires_at'] = $args['expires_at'];
            $format[] = '%s';
        }

        $result = $wpdb->insert( $table, $data, $format );

        if ( $result === false ) {
            return new \WP_Error( 'enrollment_failed', __( 'Failed to enroll student.', 'ts-lms' ) );
        }

        // Fire action hook
        do_action( 'ts_lms_student_enrolled', $course_id, $user_id );

        return true;
    }

    /**
     * Create a subscription for a user.
     *
     * @param int    $user_id   User ID.
     * @param int    $course_id Course ID.
     * @param string $plan      Plan type (weekly, monthly, yearly).
     * @return bool|WP_Error
     */
    public static function create_subscription( $user_id, $course_id, $plan ) {
        $duration = 0;
        switch ( $plan ) {
            case 'weekly':
                $duration = WEEK_IN_SECONDS;
                break;
            case 'monthly':
                $duration = MONTH_IN_SECONDS;
                break;
            case 'yearly':
                $duration = YEAR_IN_SECONDS;
                break;
            default:
                $duration = MONTH_IN_SECONDS; // Fallback
        }

        $expires_at = date( 'Y-m-d H:i:s', time() + $duration );
        $sub_id = uniqid( 'sub_' );

        return self::enroll_student( $course_id, $user_id, array(
            'subscription_id'   => $sub_id,
            'subscription_type' => $plan,
            'expires_at'        => $expires_at,
        ) );
    }

    /**
     * Check and expire subscriptions.
     *
     * @return int Number of expired subscriptions.
     */
    public static function check_expired_subscriptions() {
        global $wpdb;
        $table = $wpdb->prefix . 'ts_course_enrollments';
        
        // Find expired active subscriptions
        $expired = $wpdb->get_results( "SELECT * FROM {$table} WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at < NOW()" );
        
        $count = 0;
        foreach ( $expired as $sub ) {
            $wpdb->update( 
                $table, 
                array( 'status' => 'expired' ), 
                array( 'id' => $sub->id ),
                array( '%s' ),
                array( '%d' )
            );
            $count++;
            
            // Notify or log?
            do_action( 'ts_lms_subscription_expired', $sub->course_id, $sub->user_id );
        }
        
        return $count;
    }

    /**
     * Unenroll a student from a course.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return bool True on success, false on failure.
     */
    public static function unenroll_student( $course_id, $user_id ) {
        global $wpdb;

        $table = $wpdb->prefix . 'ts_course_enrollments';

        $result = $wpdb->delete(
            $table,
            array(
                'course_id' => $course_id,
                'user_id'   => $user_id,
            ),
            array( '%d', '%d' )
        );

        if ( $result !== false ) {
            do_action( 'ts_lms_student_unenrolled', $course_id, $user_id );
        }

        return $result !== false;
    }

    /**
     * Check if a user is enrolled in a course.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return bool True if enrolled, false otherwise.
     */
    public static function is_enrolled( $course_id, $user_id ) {
        global $wpdb;

        $table = $wpdb->prefix . 'ts_course_enrollments';

        $count = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE course_id = %d AND user_id = %d AND status = 'active'",
            $course_id,
            $user_id
        ) );

        return $count > 0;
    }

    /**
     * Get courses by status.
     *
     * @param string $status Course status.
     * @return array Array of course IDs.
     */
    public static function get_courses_by_status( $status ) {
        $args = array(
            'post_type'      => Course::POST_TYPE,
            'posts_per_page' => -1,
            'meta_query'     => array(
                array(
                    'key'   => '_course_status',
                    'value' => $status,
                ),
            ),
            'fields'         => 'ids',
        );

        return get_posts( $args );
    }
    
    /**
     * Mark course as complete for a user.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return bool True on success, false on failure.
     */
    public static function complete_course( $course_id, $user_id ) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'ts_course_enrollments';
        
        $result = $wpdb->update(
            $table,
            array( 
                'status'       => 'completed',
                'completed_at' => current_time( 'mysql' )
            ),
            array(
                'course_id' => $course_id,
                'user_id'   => $user_id,
            ),
            array( '%s', '%s' ),
            array( '%d', '%d' )
        );
        
        if ( $result !== false ) {
            update_user_meta( $user_id, '_ts_course_completed_' . $course_id, time() );
            do_action( 'ts_lms_course_completed', $course_id, $user_id );
        }
        
        return $result !== false;
    }
    
    /**
     * Retake a course - reset all progress.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function retake_course( $course_id, $user_id ) {
        global $wpdb;
        
        // Check if course retake is enabled
        $course_retake = \TS_LMS\Admin\Settings::get_setting('course_retake');
        if ( !$course_retake ) {
            return new \WP_Error( 'retake_disabled', __( 'Course retake is not enabled.', 'ts-lms' ) );
        }
        
        // Check if user is enrolled
        if ( !self::is_enrolled( $course_id, $user_id ) ) {
            return new \WP_Error( 'not_enrolled', __( 'User is not enrolled in this course.', 'ts-lms' ) );
        }
        
        // Reset enrollment status
        $enrollments_table = $wpdb->prefix . 'ts_course_enrollments';
        $wpdb->update(
            $enrollments_table,
            array( 
                'status'       => 'active',
                'completed_at' => null
            ),
            array(
                'course_id' => $course_id,
                'user_id'   => $user_id,
            ),
            array( '%s', '%s' ),
            array( '%d', '%d' )
        );
        
        // Delete all lesson progress
        $progress_table = $wpdb->prefix . 'ts_lesson_progress';
        
        // Get all topics
        $topics = get_posts( array(
            'post_type'      => 'ts_topic',
            'posts_per_page' => -1,
            'post_parent'    => $course_id,
            'post_status'    => 'publish',
        ) );
        
        // Get all content items and delete their progress
        foreach ( $topics as $topic ) {
            $items = get_posts( array(
                'post_type'      => array( 'ts_lesson', 'ts_quiz', 'ts_assignment' ),
                'posts_per_page' => -1,
                'post_parent'    => $topic->ID,
                'post_status'    => 'publish',
                'fields'         => 'ids',
            ) );
            
            foreach ( $items as $item_id ) {
                $wpdb->delete(
                    $progress_table,
                    array(
                        'lesson_id' => $item_id,
                        'user_id'   => $user_id,
                    ),
                    array( '%d', '%d' )
                );
            }
        }
        
        do_action( 'ts_lms_course_retaken', $course_id, $user_id );
        
        return true;
    }
    /**
     * Get course progress percentage for a user.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return int Progress percentage (0-100).
     */
    public static function get_course_progress( $course_id, $user_id ) {
        if ( !$course_id || !$user_id ) return 0;
        
        global $wpdb;
        
        // 1. Get total content items (lessons, quizzes, assignments) in the course
        $topics = get_posts( array(
            'post_type'      => 'ts_topic',
            'posts_per_page' => -1,
            'post_parent'    => $course_id,
            'post_status'    => 'publish',
            'fields'         => 'ids'
        ) );

        if ( empty($topics) ) return 0;

        $items = get_posts( array(
            'post_type'      => array( 'ts_lesson', 'ts_quiz', 'ts_assignment' ),
            'posts_per_page' => -1,
            'post_parent__in' => $topics,
            'post_status'    => 'publish',
            'fields'         => 'ids'
        ) );

        $total_items = count($items);
        if ( $total_items === 0 ) return 0;

        // 2. Count completed items for the user from ts_lesson_progress
        $progress_table = $wpdb->prefix . 'ts_lesson_progress';
        $item_ids_string = implode(',', array_map('intval', $items));
        
        $completed_count = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(DISTINCT lesson_id) FROM $progress_table 
            WHERE user_id = %d AND status = 'completed' AND lesson_id IN ($item_ids_string)",
            $user_id
        ) );

        return floor( ($completed_count / $total_items) * 100 );
    }
}
