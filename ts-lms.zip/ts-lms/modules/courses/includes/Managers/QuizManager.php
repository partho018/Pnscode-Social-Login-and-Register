<?php
/**
 * Quiz Manager
 *
 * Handles quiz-related operations and business logic.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Managers;

use TS_LMS\Modules\Courses\PostTypes\Quiz;
use TS_LMS\Modules\Courses\PostTypes\Course;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * QuizManager class.
 */
class QuizManager {

    /**
     * Create a new quiz.
     *
     * @param array $data Quiz data.
     * @return int|WP_Error Quiz ID on success, WP_Error on failure.
     */
    public static function create_quiz( $data ) {
        // Validate required fields
        if ( empty( $data['title'] ) ) {
            return new \WP_Error( 'missing_title', __( 'Quiz title is required.', 'ts-lms' ) );
        }

        // Check user capability
        if ( ! current_user_can( 'edit_ts_quizzes' ) ) {
            return new \WP_Error( 'permission_denied', __( 'You do not have permission to create quizzes.', 'ts-lms' ) );
        }

        // Prepare post data
        $post_data = array(
            'post_title'   => sanitize_text_field( $data['title'] ),
            'post_content' => wp_kses_post( $data['content'] ?? '' ),
            'post_status'  => 'draft',
            'post_type'    => Quiz::POST_TYPE,
            'post_author'  => get_current_user_id(),
        );

        if ( isset( $data['parent_id'] ) ) {
            $post_data['post_parent'] = absint( $data['parent_id'] );
        }

        // Apply filter
        $post_data = apply_filters( 'ts_lms_quiz_data', $post_data, $data );

        // Insert post
        $quiz_id = wp_insert_post( $post_data, true );

        if ( is_wp_error( $quiz_id ) ) {
            return $quiz_id;
        }

        // Save meta data
        self::save_quiz_meta( $quiz_id, $data );

        // Fire action hook
        do_action( 'ts_lms_quiz_created', $quiz_id, $data );

        return $quiz_id;
    }

    /**
     * Update a quiz.
     *
     * @param int   $quiz_id Quiz ID.
     * @param array $data    Quiz data.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function update_quiz( $quiz_id, $data ) {
        // Check if quiz exists
        $quiz = get_post( $quiz_id );
        if ( ! $quiz || $quiz->post_type !== Quiz::POST_TYPE ) {
            return new \WP_Error( 'invalid_quiz', __( 'Invalid quiz ID.', 'ts-lms' ) );
        }

        // Check user capability
        if ( ! current_user_can( 'edit_ts_quiz', $quiz_id ) ) {
            return new \WP_Error( 'permission_denied', __( 'You do not have permission to edit this quiz.', 'ts-lms' ) );
        }

        // Prepare post data
        $post_data = array( 'ID' => $quiz_id );

        if ( isset( $data['title'] ) ) {
            $post_data['post_title'] = sanitize_text_field( $data['title'] );
        }

        if ( isset( $data['content'] ) ) {
            $post_data['post_content'] = wp_kses_post( $data['content'] );
        }

        if ( isset( $data['parent_id'] ) ) {
            $post_data['post_parent'] = absint( $data['parent_id'] );
        }

        // Update post
        $result = wp_update_post( $post_data, true );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        // Update meta data
        self::save_quiz_meta( $quiz_id, $data );

        // Fire action hook
        do_action( 'ts_lms_quiz_updated', $quiz_id, $data );

        return true;
    }

    /**
     * Save Quiz Meta.
     *
     * @param int   $quiz_id Quiz ID.
     * @param array $data    Quiz data.
     */
    private static function save_quiz_meta( $quiz_id, $data ) {
        if ( isset( $data['course_id'] ) ) {
            update_post_meta( $quiz_id, '_quiz_course_id', absint( $data['course_id'] ) );
        }
        
        // Time Settings
        if ( isset( $data['time_limit'] ) ) update_post_meta( $quiz_id, '_quiz_time_limit', absint( $data['time_limit'] ) );
        if ( isset( $data['time_unit'] ) ) update_post_meta( $quiz_id, '_quiz_time_unit', sanitize_text_field( $data['time_unit'] ) );
        if ( isset( $data['hide_time'] ) ) update_post_meta( $quiz_id, '_quiz_hide_time', filter_var( $data['hide_time'], FILTER_VALIDATE_BOOLEAN ) );
        
        // Settings
        if ( isset( $data['feedback_mode'] ) ) update_post_meta( $quiz_id, '_quiz_feedback_mode', sanitize_text_field( $data['feedback_mode'] ) );
        if ( isset( $data['attempts'] ) ) update_post_meta( $quiz_id, '_quiz_attempts', absint( $data['attempts'] ) );
        if ( isset( $data['passing_grade'] ) ) update_post_meta( $quiz_id, '_quiz_passing_grade', absint( $data['passing_grade'] ) );
        if ( isset( $data['max_questions'] ) ) update_post_meta( $quiz_id, '_quiz_max_questions', absint( $data['max_questions'] ) );
        
        // Advanced
        if ( isset( $data['auto_start'] ) ) update_post_meta( $quiz_id, '_quiz_auto_start', filter_var( $data['auto_start'], FILTER_VALIDATE_BOOLEAN ) );
        if ( isset( $data['question_layout'] ) ) update_post_meta( $quiz_id, '_quiz_question_layout', sanitize_text_field( $data['question_layout'] ) );
        if ( isset( $data['question_order'] ) ) update_post_meta( $quiz_id, '_quiz_question_order', sanitize_text_field( $data['question_order'] ) );
        if ( isset( $data['hide_question_number'] ) ) update_post_meta( $quiz_id, '_quiz_hide_question_number', filter_var( $data['hide_question_number'], FILTER_VALIDATE_BOOLEAN ) );
        if ( isset( $data['short_answer_limit'] ) ) update_post_meta( $quiz_id, '_quiz_short_answer_limit', absint( $data['short_answer_limit'] ) );
        if ( isset( $data['essay_limit'] ) ) update_post_meta( $quiz_id, '_quiz_essay_limit', absint( $data['essay_limit'] ) );
    }

    /**
     * Get a quiz.
     *
     * @param int $quiz_id Quiz ID.
     * @return array|WP_Error Quiz data on success, WP_Error on failure.
     */
    public static function get_quiz( $quiz_id ) {
        $quiz = get_post( $quiz_id );

        if ( ! $quiz || $quiz->post_type !== Quiz::POST_TYPE ) {
            return new \WP_Error( 'invalid_quiz', __( 'Invalid quiz ID.', 'ts-lms' ) );
        }

        // Get meta data
        $meta = array(
            'course_id'            => get_post_meta( $quiz_id, '_quiz_course_id', true ),
            'time_limit'           => get_post_meta( $quiz_id, '_quiz_time_limit', true ),
            'time_unit'            => get_post_meta( $quiz_id, '_quiz_time_unit', true ),
            'hide_time'            => get_post_meta( $quiz_id, '_quiz_hide_time', true ),
            'feedback_mode'        => get_post_meta( $quiz_id, '_quiz_feedback_mode', true ),
            'attempts'             => get_post_meta( $quiz_id, '_quiz_attempts', true ),
            'passing_grade'        => get_post_meta( $quiz_id, '_quiz_passing_grade', true ),
            'max_questions'        => get_post_meta( $quiz_id, '_quiz_max_questions', true ),
            'auto_start'           => get_post_meta( $quiz_id, '_quiz_auto_start', true ),
            'question_layout'      => get_post_meta( $quiz_id, '_quiz_question_layout', true ),
            'question_order'       => get_post_meta( $quiz_id, '_quiz_question_order', true ),
            'hide_question_number' => get_post_meta( $quiz_id, '_quiz_hide_question_number', true ),
            'short_answer_limit'   => get_post_meta( $quiz_id, '_quiz_short_answer_limit', true ),
            'essay_limit'          => get_post_meta( $quiz_id, '_quiz_essay_limit', true ),
        );

        return array(
            'id'      => $quiz->ID,
            'title'   => $quiz->post_title,
            'content' => $quiz->post_content,
            'status'  => $quiz->post_status,
            'meta'    => $meta,
        );
    }
}
