<?php
/**
 * Wishlist Manager
 *
 * Handles wishlist-related operations.
 *
 * @package TS_LMS\Modules\Courses\Managers
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Managers;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * WishlistManager class.
 */
class WishlistManager {

    /**
     * Add a course to user wishlist.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function add_to_wishlist( $course_id, $user_id ) {
        if ( ! $user_id ) {
            return new \WP_Error( 'not_logged_in', __( 'Please login to add to wishlist.', 'ts-lms' ) );
        }

        $wishlist = self::get_wishlist( $user_id );
        
        if ( in_array( $course_id, $wishlist ) ) {
            return true; // Already in wishlist
        }

        $wishlist[] = absint( $course_id );
        update_user_meta( $user_id, 'ts_lms_wishlist', array_values( array_unique( $wishlist ) ) );

        return true;
    }

    /**
     * Remove a course from user wishlist.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return bool True on success.
     */
    public static function remove_from_wishlist( $course_id, $user_id ) {
        if ( ! $user_id ) return false;

        $wishlist = self::get_wishlist( $user_id );
        $key = array_search( absint( $course_id ), $wishlist );

        if ( $key !== false ) {
            unset( $wishlist[$key] );
            update_user_meta( $user_id, 'ts_lms_wishlist', array_values( $wishlist ) );
        }

        return true;
    }

    /**
     * Get user wishlist.
     *
     * @param int $user_id User ID.
     * @return array Array of course IDs.
     */
    public static function get_wishlist( $user_id ) {
        if ( ! $user_id ) return array();
        
        $wishlist = get_user_meta( $user_id, 'ts_lms_wishlist', true );
        return is_array( $wishlist ) ? array_map( 'absint', $wishlist ) : array();
    }

    /**
     * Check if a course is in user wishlist.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return bool True if in wishlist, false otherwise.
     */
    public static function is_in_wishlist( $course_id, $user_id ) {
        if ( ! $user_id ) return false;
        
        $wishlist = self::get_wishlist( $user_id );
        return in_array( absint( $course_id ), $wishlist );
    }

    /**
     * Toggle wishlist status.
     *
     * @param int $course_id Course ID.
     * @param int $user_id   User ID.
     * @return string 'added' or 'removed'.
     */
    public static function toggle_wishlist( $course_id, $user_id ) {
        if ( self::is_in_wishlist( $course_id, $user_id ) ) {
            self::remove_from_wishlist( $course_id, $user_id );
            return 'removed';
        } else {
            self::add_to_wishlist( $course_id, $user_id );
            return 'added';
        }
    }
}
