<?php
/**
 * Lesson Manager
 *
 * Handles lesson-related operations and business logic.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Managers;

use TS_LMS\Modules\Courses\PostTypes\Lesson;
use TS_LMS\Modules\Courses\PostTypes\Course;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * LessonManager class.
 */
class LessonManager {

    /**
     * Create a new lesson.
     *
     * @param array $data Lesson data.
     * @return int|WP_Error Lesson ID on success, WP_Error on failure.
     */
    public static function create_lesson( $data ) {
        // Validate required fields
        if ( empty( $data['title'] ) ) {
            return new \WP_Error( 'missing_title', __( 'Lesson title is required.', 'ts-lms' ) );
        }

        // Check user capability
        if ( ! current_user_can( 'edit_ts_lessons' ) ) {
            return new \WP_Error( 'permission_denied', __( 'You do not have permission to create lessons.', 'ts-lms' ) );
        }

        // Prepare post data
        $post_data = array(
            'post_title'   => sanitize_text_field( $data['title'] ),
            'post_content' => wp_kses_post( $data['content'] ?? '' ),
            'post_status'  => 'publish',
            'post_type'    => Lesson::POST_TYPE,
            'post_author'  => get_current_user_id(),
        );

        if ( isset( $data['parent_id'] ) ) {
            $post_data['post_parent'] = absint( $data['parent_id'] );
        }

        // Apply filter
        $post_data = apply_filters( 'ts_lms_lesson_data', $post_data, $data );

        // Insert post
        $lesson_id = wp_insert_post( $post_data, true );

        if ( is_wp_error( $lesson_id ) ) {
            return $lesson_id;
        }

        // Save meta data
        if ( isset( $data['type'] ) ) {
            update_post_meta( $lesson_id, '_lesson_type', sanitize_text_field( $data['type'] ) );
        }

        if ( isset( $data['course_id'] ) ) {
            update_post_meta( $lesson_id, '_lesson_course_id', absint( $data['course_id'] ) );
            
            // Add to lesson order table
            if ( absint( $data['course_id'] ) > 0 ) {
                self::add_to_course( $lesson_id, absint( $data['course_id'] ) );
            }
        }

        if ( isset( $data['duration'] ) ) {
            update_post_meta( $lesson_id, '_lesson_duration', absint( $data['duration'] ) );
        }

        if ( isset( $data['video_url'] ) ) {
            update_post_meta( $lesson_id, '_lesson_video_url', esc_url_raw( $data['video_url'] ) );
        }

        if ( isset( $data['video_type'] ) ) {
            update_post_meta( $lesson_id, '_lesson_video_type', sanitize_text_field( $data['video_type'] ) );
        }

        if ( isset( $data['preview'] ) ) {
            // Convert to 1 or 0 for proper checkbox state persistence
            update_post_meta( $lesson_id, '_lesson_preview', filter_var( $data['preview'], FILTER_VALIDATE_BOOLEAN ) ? 1 : 0 );
        }

        if ( isset( $data['attachments'] ) && is_array( $data['attachments'] ) ) {
             $attachments = array_map( 'absint', $data['attachments'] );
             update_post_meta( $lesson_id, '_lesson_attachments', $attachments );
        }

        if ( isset( $data['featured_image'] ) ) {
            set_post_thumbnail( $lesson_id, absint( $data['featured_image'] ) );
        }

        // Fire action hook
        do_action( 'ts_lms_lesson_created', $lesson_id, $data );

        return $lesson_id;
    }

    /**
     * Update a lesson.
     *
     * @param int   $lesson_id Lesson ID.
     * @param array $data      Lesson data.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function update_lesson( $lesson_id, $data ) {
        // Check if lesson exists
        $lesson = get_post( $lesson_id );
        if ( ! $lesson || $lesson->post_type !== Lesson::POST_TYPE ) {
            return new \WP_Error( 'invalid_lesson', __( 'Invalid lesson ID.', 'ts-lms' ) );
        }

        // Check user capability
        if ( ! current_user_can( 'edit_ts_lesson', $lesson_id ) ) {
            return new \WP_Error( 'permission_denied', __( 'You do not have permission to edit this lesson.', 'ts-lms' ) );
        }

        // Prepare post data
        $post_data = array( 'ID' => $lesson_id );

        if ( isset( $data['title'] ) ) {
            $post_data['post_title'] = sanitize_text_field( $data['title'] );
        }

        if ( isset( $data['content'] ) ) {
            $post_data['post_content'] = wp_kses_post( $data['content'] );
        }

        if ( isset( $data['parent_id'] ) ) {
            $post_data['post_parent'] = absint( $data['parent_id'] );
        }

        // Update post
        $result = wp_update_post( $post_data, true );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        // Update meta data
        if ( isset( $data['type'] ) ) {
            update_post_meta( $lesson_id, '_lesson_type', sanitize_text_field( $data['type'] ) );
        }

        if ( isset( $data['course_id'] ) ) {
            $old_course_id = get_post_meta( $lesson_id, '_lesson_course_id', true );
            $new_course_id = absint( $data['course_id'] );
            
            update_post_meta( $lesson_id, '_lesson_course_id', $new_course_id );
            
            // Update lesson order if course changed
            if ( $old_course_id != $new_course_id ) {
                self::remove_from_course( $lesson_id, $old_course_id );
                if ( $new_course_id > 0 ) {
                    self::add_to_course( $lesson_id, $new_course_id );
                }
            }
        }

        if ( isset( $data['duration'] ) ) {
            update_post_meta( $lesson_id, '_lesson_duration', absint( $data['duration'] ) );
        }

        if ( isset( $data['video_url'] ) ) {
            update_post_meta( $lesson_id, '_lesson_video_url', esc_url_raw( $data['video_url'] ) );
        }

        if ( isset( $data['video_type'] ) ) {
            update_post_meta( $lesson_id, '_lesson_video_type', sanitize_text_field( $data['video_type'] ) );
        }

        if ( isset( $data['preview'] ) ) {
            // Convert to 1 or 0 for proper checkbox state persistence
            update_post_meta( $lesson_id, '_lesson_preview', filter_var( $data['preview'], FILTER_VALIDATE_BOOLEAN ) ? 1 : 0 );
        }

        if ( isset( $data['attachments'] ) && is_array( $data['attachments'] ) ) {
             // Sanitize array of IDs
             $attachments = array_map( 'absint', $data['attachments'] );
             update_post_meta( $lesson_id, '_lesson_attachments', $attachments );
        }

         if ( isset( $data['featured_image'] ) ) {
            set_post_thumbnail( $lesson_id, absint( $data['featured_image'] ) );
        }

        // Fire action hook
        do_action( 'ts_lms_lesson_updated', $lesson_id, $data );

        return true;
    }

    /**
     * Delete a lesson.
     *
     * @param int  $lesson_id Lesson ID.
     * @param bool $force     Whether to force delete (bypass trash).
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function delete_lesson( $lesson_id, $force = false ) {
        // Check if lesson exists
        $lesson = get_post( $lesson_id );
        if ( ! $lesson || $lesson->post_type !== Lesson::POST_TYPE ) {
            return new \WP_Error( 'invalid_lesson', __( 'Invalid lesson ID.', 'ts-lms' ) );
        }

        // Check user capability
        if ( ! current_user_can( 'delete_ts_lesson', $lesson_id ) ) {
            return new \WP_Error( 'permission_denied', __( 'You do not have permission to delete this lesson.', 'ts-lms' ) );
        }

        // Remove from course
        $course_id = get_post_meta( $lesson_id, '_lesson_course_id', true );
        if ( $course_id ) {
            self::remove_from_course( $lesson_id, $course_id );
        }

        // Delete post
        $result = wp_delete_post( $lesson_id, $force );

        if ( ! $result ) {
            return new \WP_Error( 'delete_failed', __( 'Failed to delete lesson.', 'ts-lms' ) );
        }

        // Fire action hook
        do_action( 'ts_lms_lesson_deleted', $lesson_id );

        return true;
    }

    /**
     * Get a lesson.
     *
     * @param int $lesson_id Lesson ID.
     * @return array|WP_Error Lesson data on success, WP_Error on failure.
     */
    public static function get_lesson( $lesson_id ) {
        $lesson = get_post( $lesson_id );

        if ( ! $lesson || $lesson->post_type !== Lesson::POST_TYPE ) {
            return new \WP_Error( 'invalid_lesson', __( 'Invalid lesson ID.', 'ts-lms' ) );
        }

        // Get meta data
        $meta = array(
            'type'              => get_post_meta( $lesson_id, '_lesson_type', true ),
            'course_id'         => get_post_meta( $lesson_id, '_lesson_course_id', true ),
            'duration'          => get_post_meta( $lesson_id, '_lesson_duration', true ),
            'video_url'         => get_post_meta( $lesson_id, '_lesson_video_url', true ),
            'video_type'        => get_post_meta( $lesson_id, '_lesson_video_type', true ),
            'preview'           => get_post_meta( $lesson_id, '_lesson_preview', true ),
            'featured_image'    => get_post_thumbnail_id( $lesson_id ),
            'drip_type'         => get_post_meta( $lesson_id, '_lesson_drip_type', true ),
            'drip_days'         => get_post_meta( $lesson_id, '_lesson_drip_days', true ),
            'drip_prerequisite' => get_post_meta( $lesson_id, '_lesson_drip_prerequisite', true ),
            'attachments'       => get_post_meta( $lesson_id, '_lesson_attachments', true ),
        );

        return array(
            'id'      => $lesson->ID,
            'title'   => $lesson->post_title,
            'content' => $lesson->post_content,
            'status'  => $lesson->post_status,
            'meta'    => $meta,
        );
    }

    /**
     * Add lesson to course order table.
     *
     * @param int $lesson_id Lesson ID.
     * @param int $course_id Course ID.
     * @param int $order     Order index (optional).
     * @return bool True on success, false on failure.
     */
    private static function add_to_course( $lesson_id, $course_id, $order = null ) {
        global $wpdb;

        $table = $wpdb->prefix . 'ts_lesson_order';

        // Get next order if not specified
        if ( $order === null ) {
            $max_order = $wpdb->get_var( $wpdb->prepare(
                "SELECT MAX(order_index) FROM {$table} WHERE course_id = %d",
                $course_id
            ) );
            $order = $max_order !== null ? $max_order + 1 : 0;
        }

        // Check if already exists
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table} WHERE course_id = %d AND lesson_id = %d",
            $course_id,
            $lesson_id
        ) );

        if ( $exists ) {
            return true; // Already exists
        }

        // Insert
        $result = $wpdb->insert(
            $table,
            array(
                'course_id'   => $course_id,
                'lesson_id'   => $lesson_id,
                'order_index' => $order,
                'created_at'  => current_time( 'mysql' ),
            ),
            array( '%d', '%d', '%d', '%s' )
        );

        return $result !== false;
    }

    /**
     * Remove lesson from course order table.
     *
     * @param int $lesson_id Lesson ID.
     * @param int $course_id Course ID.
     * @return bool True on success, false on failure.
     */
    private static function remove_from_course( $lesson_id, $course_id ) {
        global $wpdb;

        $table = $wpdb->prefix . 'ts_lesson_order';

        $result = $wpdb->delete(
            $table,
            array(
                'course_id' => $course_id,
                'lesson_id' => $lesson_id,
            ),
            array( '%d', '%d' )
        );

        return $result !== false;
    }

    /**
     * Set lesson order in a course.
     *
     * @param int $course_id Course ID.
     * @param int $lesson_id Lesson ID.
     * @param int $order     Order index.
     * @return bool True on success, false on failure.
     */
    public static function set_lesson_order( $course_id, $lesson_id, $order ) {
        global $wpdb;

        $table = $wpdb->prefix . 'ts_lesson_order';

        $result = $wpdb->update(
            $table,
            array( 'order_index' => absint( $order ) ),
            array(
                'course_id' => $course_id,
                'lesson_id' => $lesson_id,
            ),
            array( '%d' ),
            array( '%d', '%d' )
        );

        return $result !== false;
    }

    /**
     * Get all lessons for a course.
     *
     * @param int  $course_id Course ID.
     * @param bool $ordered   Whether to order by order_index.
     * @return array Array of lesson IDs.
     */
    public static function get_course_lessons( $course_id, $ordered = true ) {
        global $wpdb;

        $table = $wpdb->prefix . 'ts_lesson_order';

        $order_by = $ordered ? 'ORDER BY order_index ASC' : '';

        $results = $wpdb->get_col( $wpdb->prepare(
            "SELECT lesson_id FROM {$table} WHERE course_id = %d {$order_by}",
            $course_id
        ) );

        return $results;
    }

    /**
     * Add attachment to lesson.
     *
     * @param int $lesson_id Lesson ID.
     * @param int $file_id   Attachment ID.
     * @return bool True on success, false on failure.
     */
    public static function add_attachment( $lesson_id, $file_id ) {
        $attachments = get_post_meta( $lesson_id, '_lesson_attachments', true );
        
        if ( ! is_array( $attachments ) ) {
            $attachments = array();
        }

        if ( ! in_array( $file_id, $attachments ) ) {
            $attachments[] = $file_id;
            update_post_meta( $lesson_id, '_lesson_attachments', $attachments );
        }

        return true;
    }

    /**
     * Remove attachment from lesson.
     *
     * @param int $lesson_id Lesson ID.
     * @param int $file_id   Attachment ID.
     * @return bool True on success, false on failure.
     */
    public static function remove_attachment( $lesson_id, $file_id ) {
        $attachments = get_post_meta( $lesson_id, '_lesson_attachments', true );
        
        if ( ! is_array( $attachments ) ) {
            return false;
        }

        $key = array_search( $file_id, $attachments );
        if ( $key !== false ) {
            unset( $attachments[ $key ] );
            update_post_meta( $lesson_id, '_lesson_attachments', array_values( $attachments ) );
            return true;
        }

        return false;
    }

    /**
     * Get lesson attachments.
     *
     * @param int $lesson_id Lesson ID.
     * @return array Array of attachment IDs.
     */
    public static function get_attachments( $lesson_id ) {
        $attachments = get_post_meta( $lesson_id, '_lesson_attachments', true );
        
        return is_array( $attachments ) ? $attachments : array();
    }

    /**
     * Mark lesson as completed for a user.
     *
     * @param int $lesson_id Lesson ID.
     * @param int $user_id   User ID.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function mark_complete( $lesson_id, $user_id ) {
        global $wpdb;

        // Get course ID
        $course_id = get_post_meta( $lesson_id, '_lesson_course_id', true );
        if ( ! $course_id ) {
            return new \WP_Error( 'no_course', __( 'Lesson is not assigned to a course.', 'ts-lms' ) );
        }

        $table = $wpdb->prefix . 'ts_lesson_progress';

        // Check if progress exists
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table} WHERE lesson_id = %d AND user_id = %d",
            $lesson_id,
            $user_id
        ) );

        if ( $exists ) {
            // Update existing
            $wpdb->update(
                $table,
                array(
                    'status'       => 'completed',
                    'completed_at' => current_time( 'mysql' ),
                ),
                array(
                    'lesson_id' => $lesson_id,
                    'user_id'   => $user_id,
                ),
                array( '%s', '%s' ),
                array( '%d', '%d' )
            );
        } else {
            // Insert new
            $wpdb->insert(
                $table,
                array(
                    'lesson_id'    => $lesson_id,
                    'user_id'      => $user_id,
                    'course_id'    => $course_id,
                    'status'       => 'completed',
                    'completed_at' => current_time( 'mysql' ),
                ),
                array( '%d', '%d', '%d', '%s', '%s' )
            );
        }

        // Fire action hook
        do_action( 'ts_lms_lesson_completed', $lesson_id, $user_id );

        return true;
    }

    /**
     * Get lesson progress for a user.
     *
     * @param int $lesson_id Lesson ID.
     * @param int $user_id   User ID.
     * @return array|null Progress data or null if not found.
     */
    public static function get_progress( $lesson_id, $user_id ) {
        global $wpdb;

        $table = $wpdb->prefix . 'ts_lesson_progress';

        $progress = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE lesson_id = %d AND user_id = %d",
            $lesson_id,
            $user_id
        ), ARRAY_A );

        return $progress;
    }
}
