<?php
/**
 * Curriculum AJAX Handlers
 *
 * Handles curriculum management via AJAX.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Admin;

use TS_LMS\Modules\Courses\PostTypes\Topic;
use TS_LMS\Modules\Courses\PostTypes\Lesson;
use TS_LMS\Modules\Courses\PostTypes\Quiz;
use TS_LMS\Modules\Courses\PostTypes\Assignment;
use TS_LMS\Modules\Courses\Managers\LessonManager;
use TS_LMS\Modules\Courses\Managers\QuizManager;
use TS_LMS\Modules\Courses\Managers\AssignmentManager;
use TS_LMS\Modules\Courses\Managers\CourseManager;
use TS_LMS\Modules\Quizzes\Managers\QuestionManager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * CurriculumAjax class.
 */
class CurriculumAjax {

    /**
     * Initialize AJAX handlers.
     *
     * @return void
     */
    public static function init() {
        add_action( 'wp_ajax_ts_lms_get_curriculum', array( __CLASS__, 'get_curriculum' ) );
        add_action( 'wp_ajax_ts_lms_save_topic', array( __CLASS__, 'save_topic' ) );
        add_action( 'wp_ajax_ts_lms_delete_topic', array( __CLASS__, 'delete_topic' ) );
        add_action( 'wp_ajax_ts_lms_save_item', array( __CLASS__, 'save_item' ) );
        add_action( 'wp_ajax_ts_lms_delete_item', array( __CLASS__, 'delete_item' ) );
        add_action( 'wp_ajax_ts_lms_get_item', array( __CLASS__, 'get_item' ) );
        add_action( 'wp_ajax_ts_lms_sort_curriculum', array( __CLASS__, 'sort_curriculum' ) );
        add_action( 'wp_ajax_ts_lms_duplicate_topic', array( __CLASS__, 'duplicate_topic' ) );
        add_action( 'wp_ajax_ts_lms_duplicate_item', array( __CLASS__, 'duplicate_item' ) );
        
        // Question Handlers
        add_action( 'wp_ajax_ts_lms_save_question', array( __CLASS__, 'save_question' ) );
        add_action( 'wp_ajax_ts_lms_delete_question', array( __CLASS__, 'delete_question' ) );
        add_action( 'wp_ajax_ts_lms_get_questions', array( __CLASS__, 'get_questions' ) );
        
        // Frontend Actions
        add_action( 'wp_ajax_ts_lms_complete_lesson', array( __CLASS__, 'complete_lesson' ) );
    }

    /**
     * Get curriculum data for a course.
     */
    public static function get_curriculum() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
        if ( ! $course_id ) {
            wp_send_json_error( array( 'message' => 'Invalid course ID' ) );
        }

        $topics = get_posts( array(
            'post_type'      => Topic::POST_TYPE,
            'posts_per_page' => -1,
            'post_parent'    => $course_id,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ) );

        $curriculum = array();

        foreach ( $topics as $topic ) {
            $items = get_posts( array(
                'post_type'      => array( Lesson::POST_TYPE, Quiz::POST_TYPE, Assignment::POST_TYPE ),
                'posts_per_page' => -1,
                'post_parent'    => $topic->ID,
                'orderby'        => 'menu_order',
                'order'          => 'ASC',
                'post_status'    => array( 'publish', 'draft', 'private', 'pending' ),
            ) );

            $topic_items = array();
            foreach ( $items as $item ) {
                $type = str_replace( 'ts_', '', $item->post_type );
                if ( $type === 'lesson' ) {
                    $lesson_type = get_post_meta( $item->ID, '_lesson_type', true );
                    if ( $lesson_type === 'meet' || $lesson_type === 'zoom' ) {
                        $type = $lesson_type;
                    }
                }
                
                $topic_items[] = array(
                    'id'    => $item->ID,
                    'title' => $item->post_title,
                    'type'  => $type,
                );
            }

            $curriculum[] = array(
                'id'          => $topic->ID,
                'title'       => $topic->post_title,
                'summary'     => $topic->post_content,
                'items'       => $topic_items,
            );
        }

        wp_send_json_success( array( 'curriculum' => $curriculum ) );
    }

    /**
     * Save/Update topic.
     */
    public static function save_topic() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
        $topic_id  = isset( $_POST['topic_id'] ) ? absint( $_POST['topic_id'] ) : 0;
        $title     = isset( $_POST['title'] ) ? sanitize_text_field( $_POST['title'] ) : '';
        $summary   = isset( $_POST['summary'] ) ? sanitize_textarea_field( $_POST['summary'] ) : '';

        // If no course ID, auto-create a draft course
        $new_course_created = false;
        if ( ! $course_id ) {
            $default_title = isset( $_POST['course_title'] ) && !empty($_POST['course_title']) ? sanitize_text_field( $_POST['course_title'] ) : __( 'Untitled Course', 'ts-lms' );
            $course_id = wp_insert_post( array(
                'post_title'  => $default_title,
                'post_type'   => 'ts_course',
                'post_status' => 'draft',
            ) );

            if ( is_wp_error( $course_id ) ) {
                wp_send_json_error( array( 'message' => 'Failed to auto-create course' ) );
            }
            $new_course_created = true;
        }

        $args = array(
            'ID'           => $topic_id,
            'post_title'   => $title,
            'post_content' => $summary,
            'post_type'    => Topic::POST_TYPE,
            'post_status'  => 'publish',
            'post_parent'  => $course_id,
        );

        if ( $topic_id ) {
            $id = wp_update_post( $args );
        } else {
            // Get last order
            $last_topic = get_posts( array(
                'post_type'      => Topic::POST_TYPE,
                'posts_per_page' => 1,
                'post_parent'    => $course_id,
                'orderby'        => 'menu_order',
                'order'          => 'DESC',
            ) );
            $order = ! empty( $last_topic ) ? $last_topic[0]->menu_order + 1 : 0;
            $args['menu_order'] = $order;
            $id = wp_insert_post( $args );
        }

        if ( is_wp_error( $id ) ) {
            wp_send_json_error( array( 'message' => $id->get_error_message() ) );
        }

        $response_data = array( 
            'topic_id' => $id, 
            'message' => 'Topic saved successfully' 
        );

        if ( $new_course_created ) {
            $response_data['course_id'] = $course_id;
        }

        wp_send_json_success( $response_data );
    }

    /**
     * Delete topic.
     */
    public static function delete_topic() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $topic_id = isset( $_POST['topic_id'] ) ? absint( $_POST['topic_id'] ) : 0;
        if ( ! $topic_id ) {
            wp_send_json_error( array( 'message' => 'Invalid topic ID' ) );
        }

        // Delete children first
        $items = get_posts( array(
            'post_type'      => array( Lesson::POST_TYPE, Quiz::POST_TYPE, Assignment::POST_TYPE ),
            'posts_per_page' => -1,
            'post_parent'    => $topic_id,
        ) );

        foreach ( $items as $item ) {
            wp_delete_post( $item->ID, true );
        }

        wp_delete_post( $topic_id, true );

        wp_send_json_success( array( 'message' => 'Topic deleted successfully' ) );
    }

    /**
     * Save/Update Item (Lesson/Quiz/Assignment).
     */
    public static function save_item() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
        $topic_id  = isset( $_POST['topic_id'] ) ? absint( $_POST['topic_id'] ) : 0;
        $item_id   = isset( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;
        $type      = isset( $_POST['type'] ) ? sanitize_text_field( $_POST['type'] ) : 'lesson';
        $title     = isset( $_POST['title'] ) ? sanitize_text_field( $_POST['title'] ) : '';

        // If no course ID, auto-create a draft course
        $new_course_created = false;
        if ( ! $course_id ) {
            $default_title = isset( $_POST['course_title'] ) && !empty($_POST['course_title']) ? sanitize_text_field( $_POST['course_title'] ) : __( 'Untitled Course', 'ts-lms' );
            $course_id = wp_insert_post( array(
                'post_title'  => $default_title,
                'post_type'   => 'ts_course',
                'post_status' => 'draft',
            ) );

            if ( is_wp_error( $course_id ) ) {
                wp_send_json_error( array( 'message' => 'Failed to auto-create course' ) );
            }
            $new_course_created = true;
        }

        if ( ! $topic_id && ! $item_id ) {
             wp_send_json_error( array( 'message' => 'Invalid parameters' ) );
        }

        $id = 0;

        // Use LessonManager for lessons
        if ( $type === 'lesson' ) {
            $data = array(
                'title'          => $title,
                'content'        => isset( $_POST['content'] ) ? wp_kses_post( $_POST['content'] ) : '',
                'type'           => $type,
                'course_id'      => $course_id,
                'parent_id'      => $topic_id,
                'duration'       => isset( $_POST['duration'] ) ? absint( $_POST['duration'] ) : 0,
                'preview'        => isset( $_POST['preview'] ) ? absint( $_POST['preview'] ) : 0,
                'featured_image' => isset( $_POST['featured_image'] ) ? absint( $_POST['featured_image'] ) : 0,
                'attachments'    => isset( $_POST['attachments'] ) ? $_POST['attachments'] : array(),
                'video_url'      => isset( $_POST['video_url'] ) ? esc_url_raw( $_POST['video_url'] ) : '',
                'video_type'     => isset( $_POST['video_type'] ) ? sanitize_text_field( $_POST['video_type'] ) : '',
            );
            if ( $item_id ) {
                $result = LessonManager::update_lesson( $item_id, $data );
                if ( is_wp_error( $result ) ) {
                    wp_send_json_error( array( 'message' => $result->get_error_message() ) );
                }
                $id = $item_id;
            } else {
                $result = LessonManager::create_lesson( $data );
                if ( is_wp_error( $result ) ) {
                    wp_send_json_error( array( 'message' => $result->get_error_message() ) );
                }
                $id = $result;
            }
        } elseif ( $type === 'meet' || $type === 'zoom' ) {
            // Live Lesson logic
            $meta = isset( $_POST['meta'] ) ? $_POST['meta'] : array();
            $data = array(
                'title'          => $title,
                'content'        => isset( $_POST['content'] ) ? wp_kses_post( $_POST['content'] ) : '',
                'type'           => $type,
                'course_id'      => $course_id,
                'parent_id'      => $topic_id,
            );

            if ( $item_id ) {
                $result = LessonManager::update_lesson( $item_id, $data );
                $id = $item_id;
            } else {
                // If it's a new meeting, we can try to call API here
                if ( $type === 'zoom' ) {
                    $zoom_result = self::create_zoom_meeting( array_merge( $data, $meta ) );
                    if ( ! is_wp_error( $zoom_result ) ) {
                        $meta['_zoom_meeting_id'] = $zoom_result['id'];
                        $meta['_zoom_join_url']   = $zoom_result['join_url'];
                    }
                } elseif ( $type === 'meet' ) {
                    $meet_result = self::create_google_meeting( array_merge( $data, $meta ) );
                    if ( ! is_wp_error( $meet_result ) ) {
                        $meta['_google_event_id']    = $meet_result['id'];
                        $meta['_google_meet_link']   = $meet_result['join_url'];
                    }
                }
                
                $result = LessonManager::create_lesson( $data );
                $id = $result;
            }

            if ( is_wp_error( $result ) ) {
                wp_send_json_error( array( 'message' => $result->get_error_message() ) );
            }

            // Save additional meta
            foreach ( $meta as $key => $value ) {
                update_post_meta( $id, $key, sanitize_text_field( $value ) );
            }
        } elseif ( $type === 'quiz' ) {
            // Quiz Logic
            $data = array(
                'title'           => $title,
                'content'         => isset( $_POST['content'] ) ? wp_kses_post( $_POST['content'] ) : '',
                'course_id'       => $course_id,
                'parent_id'       => $topic_id,
                'time_limit'      => isset( $_POST['time_limit'] ) ? absint( $_POST['time_limit'] ) : 0,
                'time_unit'       => isset( $_POST['time_unit'] ) ? sanitize_text_field( $_POST['time_unit'] ) : 'minutes',
                'hide_time'       => isset( $_POST['hide_time'] ) ? absint( $_POST['hide_time'] ) : 0,
                'feedback_mode'   => isset( $_POST['feedback_mode'] ) ? sanitize_text_field( $_POST['feedback_mode'] ) : 'default',
                'attempts'        => isset( $_POST['attempts'] ) ? absint( $_POST['attempts'] ) : 1,
                'passing_grade'   => isset( $_POST['passing_grade'] ) ? absint( $_POST['passing_grade'] ) : 80,
                'max_questions'   => isset( $_POST['max_questions'] ) ? absint( $_POST['max_questions'] ) : 10,
                'auto_start'      => isset( $_POST['auto_start'] ) ? absint( $_POST['auto_start'] ) : 0,
                'question_layout' => isset( $_POST['question_layout'] ) ? sanitize_text_field( $_POST['question_layout'] ) : 'single',
                'question_order'  => isset( $_POST['question_order'] ) ? sanitize_text_field( $_POST['question_order'] ) : 'random',
            );

            if ( $item_id ) {
                $result = QuizManager::update_quiz( $item_id, $data );
                if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ) ); }
                $id = $item_id;
            } else {
                $result = QuizManager::create_quiz( $data );
                if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ) ); }
                $id = $result;
            }
        
        } elseif ( $type === 'assignment' ) {
            // Assignment Logic
            $data = array(
                'title'           => $title,
                'content'         => isset( $_POST['content'] ) ? wp_kses_post( $_POST['content'] ) : '',
                'course_id'       => $course_id,
                'parent_id'       => $topic_id,
                'attachments'     => isset( $_POST['attachments'] ) ? $_POST['attachments'] : array(),
                'time_limit'      => isset( $_POST['time_limit'] ) ? absint( $_POST['time_limit'] ) : 0,
                'time_unit'       => isset( $_POST['time_unit'] ) ? sanitize_text_field( $_POST['time_unit'] ) : 'weeks',
                'deadline_toggle' => isset( $_POST['deadline_toggle'] ) ? absint( $_POST['deadline_toggle'] ) : 0,
                'deadline'        => isset( $_POST['deadline'] ) ? sanitize_text_field( $_POST['deadline'] ) : '',
                'total_points'    => isset( $_POST['total_points'] ) ? absint( $_POST['total_points'] ) : 10,
                'min_points'      => isset( $_POST['min_points'] ) ? absint( $_POST['min_points'] ) : 5,
                'file_limit'      => isset( $_POST['file_limit'] ) ? absint( $_POST['file_limit'] ) : 1,
                'file_size'       => isset( $_POST['file_size'] ) ? absint( $_POST['file_size'] ) : 2,
                'file_size_unit'  => isset( $_POST['file_size_unit'] ) ? sanitize_text_field( $_POST['file_size_unit'] ) : 'mb',
                'resubmission'    => isset( $_POST['resubmission'] ) ? absint( $_POST['resubmission'] ) : 0,
                'max_attempts'    => isset( $_POST['max_attempts'] ) ? absint( $_POST['max_attempts'] ) : 1,
            );

            if ( $item_id ) {
                $result = AssignmentManager::update_assignment( $item_id, $data );
                if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ) ); }
                $id = $item_id;
            } else {
                $result = AssignmentManager::create_assignment( $data );
                if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ) ); }
                $id = $result;
            }
        
        } else {
            // Fallback (should not happen if all types are covered)
             wp_send_json_error( array( 'message' => 'Invalid item type' ) );
        }

        // Fetch full item data to return?
        // Basic return for now
        $post = get_post( $id );
        $item_data = array(
            'id'    => $post->ID,
            'title' => $post->post_title,
            'type'  => str_replace( 'ts_', '', $post->post_type ),
        );

        $response_data = array( 'item_id' => $id, 'item' => $item_data, 'message' => ucfirst($type) . ' saved successfully' );
        if ( isset($new_course_created) && $new_course_created ) {
            $response_data['course_id'] = $course_id;
        }

        wp_send_json_success( $response_data );
    }

    /**
     * Delete item.
     */
    public static function delete_item() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $item_id = isset( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;
        if ( ! $item_id ) {
            wp_send_json_error( array( 'message' => 'Invalid item ID' ) );
        }

        wp_delete_post( $item_id, true );

        wp_send_json_success( array( 'message' => 'Item deleted successfully' ) );
    }

    /**
     * Sort curriculum.
     */
    public static function sort_curriculum() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $data = isset( $_POST['data'] ) ? $_POST['data'] : array();

        if ( empty( $data ) ) {
            wp_send_json_error( array( 'message' => 'No data provided' ) );
        }

        foreach ( $data as $topic_order => $topic_data ) {
            $topic_id = absint( $topic_data['id'] );
            wp_update_post( array(
                'ID'         => $topic_id,
                'menu_order' => $topic_order,
            ) );

            if ( ! empty( $topic_data['items'] ) ) {
                foreach ( $topic_data['items'] as $item_order => $item_data ) {
                    $item_id = absint( $item_data['id'] );
                    wp_update_post( array(
                        'ID'          => $item_id,
                        'post_parent' => $topic_id,
                        'menu_order'  => $item_order,
                    ) );
                }
            }
        }

        wp_send_json_success( array( 'message' => 'Curriculum sorted successfully' ) );
    }

    /**
     * Duplicate topic and its items.
     */
    public static function duplicate_topic() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $topic_id = isset( $_POST['topic_id'] ) ? absint( $_POST['topic_id'] ) : 0;
        if ( ! $topic_id ) {
            wp_send_json_error( array( 'message' => 'Invalid topic ID' ) );
        }

        $topic = get_post( $topic_id );
        if ( ! $topic || $topic->post_type !== Topic::POST_TYPE ) {
            wp_send_json_error( array( 'message' => 'Topic not found' ) );
        }

        // Duplicate Topic
        $new_topic_id = self::clone_post( $topic_id );

        if ( ! $new_topic_id ) {
            wp_send_json_error( array( 'message' => 'Failed to duplicate topic' ) );
        }

        // Append (Copy) to title
        wp_update_post( array(
            'ID'         => $new_topic_id,
            'post_title' => $topic->post_title . ' (' . __( 'Copy', 'ts-lms' ) . ')',
        ) );

        // Duplicate Items (Lessons/Quizzes/Assignments)
        $items = get_posts( array(
            'post_type'      => array( Lesson::POST_TYPE, Quiz::POST_TYPE, Assignment::POST_TYPE ),
            'posts_per_page' => -1,
            'post_parent'    => $topic_id,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ) );

        foreach ( $items as $item ) {
            self::clone_post( $item->ID, $new_topic_id );
        }

        wp_send_json_success( array( 'message' => 'Topic duplicated successfully' ) );
    }

    /**
     * Duplicate a curriculum item.
     */
    public static function duplicate_item() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $item_id = isset( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;
        if ( ! $item_id ) {
            wp_send_json_error( array( 'message' => 'Invalid item ID' ) );
        }

        $item = get_post( $item_id );
        if ( ! $item ) {
            wp_send_json_error( array( 'message' => 'Item not found' ) );
        }

        $new_item_id = self::clone_post( $item_id );

        if ( ! $new_item_id ) {
            wp_send_json_error( array( 'message' => 'Failed to duplicate item' ) );
        }

        // Append (Copy) to title
        wp_update_post( array(
            'ID'         => $new_item_id,
            'post_title' => $item->post_title . ' (' . __( 'Copy', 'ts-lms' ) . ')',
        ) );

        wp_send_json_success( array( 'message' => 'Item duplicated successfully' ) );
    }

    /**
     * Clone a post and its metadata.
     */
    private static function clone_post( $post_id, $new_parent = null ) {
        $post = get_post( $post_id );
        if ( ! $post ) return false;

        $args = array(
            'post_title'   => $post->post_title,
            'post_content' => $post->post_content,
            'post_excerpt' => $post->post_excerpt,
            'post_status'  => $post->post_status,
            'post_type'    => $post->post_type,
            'post_author'  => get_current_user_id(),
            'post_parent'  => $new_parent !== null ? $new_parent : $post->post_parent,
            'menu_order'   => $post->menu_order + 1,
        );

        $new_post_id = wp_insert_post( $args );

        if ( ! is_wp_error( $new_post_id ) ) {
            // Clone metadata
            $meta = get_post_custom( $post_id );
            foreach ( $meta as $key => $values ) {
                foreach ( $values as $value ) {
                    add_post_meta( $new_post_id, $key, maybe_unserialize( $value ) );
                }
            }

            // Clone questions if it's a quiz
            if ( $post->post_type === Quiz::POST_TYPE ) {
                $questions = get_posts( array(
                    'post_type'      => 'ts_question',
                    'posts_per_page' => -1,
                    'post_parent'    => $post_id,
                    'orderby'        => 'menu_order',
                    'order'          => 'ASC',
                ) );

                foreach ( $questions as $question ) {
                    self::clone_post( $question->ID, $new_post_id );
                }
            }

            return $new_post_id;
        }

        return false;
    }

    /**
     * Get item details.
     */
    public static function get_item() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $item_id = isset( $_GET['item_id'] ) ? absint( $_GET['item_id'] ) : 0;
        $type    = isset( $_GET['type'] ) ? sanitize_text_field( $_GET['type'] ) : 'lesson';

        if ( ! $item_id ) {
            wp_send_json_error( array( 'message' => 'Invalid item ID' ) );
        }

        if ( $type === 'lesson' ) {
            $data = LessonManager::get_lesson( $item_id );
            if ( is_wp_error( $data ) ) { wp_send_json_error( array( 'message' => $data->get_error_message() ) ); }
            wp_send_json_success( array( 'item' => $data ) );
        } elseif ( $type === 'quiz' ) {
            $data = QuizManager::get_quiz( $item_id );
            if ( is_wp_error( $data ) ) { wp_send_json_error( array( 'message' => $data->get_error_message() ) ); }
            wp_send_json_success( array( 'item' => $data ) );
        } elseif ( $type === 'assignment' ) {
            $data = AssignmentManager::get_assignment( $item_id );
            if ( is_wp_error( $data ) ) { wp_send_json_error( array( 'message' => $data->get_error_message() ) ); }
            wp_send_json_success( array( 'item' => $data ) );
        }

        // Fallback or error
        wp_send_json_error( array( 'message' => 'Fetching details not supported for this type yet' ) );
    }

    /**
     * Save/Update Question.
     */
    public static function save_question() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $quiz_id     = isset( $_POST['quiz_id'] ) ? absint( $_POST['quiz_id'] ) : 0;
        $question_id = isset( $_POST['question_id'] ) ? absint( $_POST['question_id'] ) : 0;
        $title       = isset( $_POST['title'] ) ? sanitize_text_field( $_POST['title'] ) : '';
        $type        = isset( $_POST['type'] ) ? sanitize_text_field( $_POST['type'] ) : 'single_choice';
        $points      = isset( $_POST['points'] ) ? floatval( $_POST['points'] ) : 1;

        if ( ! $quiz_id ) {
            wp_send_json_error( array( 'message' => 'Invalid quiz ID' ) );
        }

        $data = array(
            'title'          => $title,
            'type'           => $type,
            'points'         => $points,
            'options'        => isset( $_POST['options'] ) ? $_POST['options'] : array(),
            'correct_answer' => isset( $_POST['correct_answer'] ) ? sanitize_text_field( $_POST['correct_answer'] ) : '',
            'parent_id'      => $quiz_id,
        );

        if ( $question_id ) {
            $result = QuestionManager::update_question( $question_id, $data );
            $id = $question_id;
        } else {
            $result = QuestionManager::create_question( $data );
            $id = $result;
        }

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array( 'question_id' => $id, 'message' => 'Question saved successfully' ) );
    }

    /**
     * Delete Question.
     */
    public static function delete_question() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $question_id = isset( $_POST['question_id'] ) ? absint( $_POST['question_id'] ) : 0;
        if ( ! $question_id ) {
            wp_send_json_error( array( 'message' => 'Invalid question ID' ) );
        }

        $result = QuestionManager::delete_question( $question_id );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array( 'message' => 'Question deleted successfully' ) );
    }

    /**
     * Get Questions for a Quiz.
     */
    public static function get_questions() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied' ) );
        }
        check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

        $quiz_id = isset( $_GET['quiz_id'] ) ? absint( $_GET['quiz_id'] ) : 0;
        if ( ! $quiz_id ) {
           wp_send_json_error( array( 'message' => 'Invalid quiz ID' ) );
        }

        $questions_posts = get_posts( array(
            'post_type'      => 'ts_question',
            'posts_per_page' => -1,
            'post_parent'    => $quiz_id,
            'orderby'        => 'menu_order', 
            'order'          => 'ASC',
        ) );

        $questions = array();
        foreach ( $questions_posts as $post ) {
            $questions[] = array(
                'id'     => $post->ID,
                'title'  => $post->post_title,
                'type'   => get_post_meta( $post->ID, '_question_type', true ),
                'points' => get_post_meta( $post->ID, '_points', true ),
            );
        }

        wp_send_json_success( array( 'questions' => $questions ) );
    }

    /**
     * Mark Lesson as Complete
     */
    public static function complete_lesson() {
        // No nonce check for now or use a frontend nonce
        $lesson_id = isset( $_POST['lesson_id'] ) ? absint( $_POST['lesson_id'] ) : 0;
        $user_id   = get_current_user_id();

        if ( ! $lesson_id || ! $user_id ) {
            wp_send_json_error( array( 'message' => 'Invalid request' ) );
        }

        $result = LessonManager::mark_complete( $lesson_id, $user_id );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }
        
        // Auto Complete Course on All Lesson Completion
        $auto_complete_course = \TS_LMS\Admin\Settings::get_setting('auto_complete_course');
        if ( $auto_complete_course ) {
            // Get course ID from lesson
            $course_id = get_post_meta( $lesson_id, '_lesson_course_id', true );
            if ( !$course_id ) {
                $parent_id = wp_get_post_parent_id( $lesson_id );
                if ( $parent_id ) {
                    $course_id = wp_get_post_parent_id( $parent_id );
                }
            }
            
            if ( $course_id ) {
                // Check if all content is completed
                $all_completed = self::check_all_course_content_completed( $course_id, $user_id );
                if ( $all_completed ) {
                    CourseManager::complete_course( $course_id, $user_id );
                }
            }
        }

        wp_send_json_success( array( 'message' => 'Lesson completed!' ) );
    }
    
    /**
     * Check if all course content (lessons, quizzes, assignments) is completed
     */
    private static function check_all_course_content_completed( $course_id, $user_id ) {
        global $wpdb;
        
        // Get all topics
        $topics = get_posts( array(
            'post_type'      => 'ts_topic',
            'posts_per_page' => -1,
            'post_parent'    => $course_id,
            'post_status'    => 'publish',
        ) );
        
        if ( empty( $topics ) ) {
            return false;
        }
        
        // Get all content items
        $all_items = array();
        foreach ( $topics as $topic ) {
            $items = get_posts( array(
                'post_type'      => array( 'ts_lesson', 'ts_quiz', 'ts_assignment' ),
                'posts_per_page' => -1,
                'post_parent'    => $topic->ID,
                'post_status'    => 'publish',
            ) );
            $all_items = array_merge( $all_items, $items );
        }
        
        if ( empty( $all_items ) ) {
            return false;
        }
        
        // Check if all items are completed
        $progress_table = $wpdb->prefix . 'ts_lesson_progress';
        foreach ( $all_items as $item ) {
            $progress = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$progress_table} WHERE lesson_id = %d AND user_id = %d AND status = 'completed'",
                $item->ID,
                $user_id
            ) );
            
            if ( !$progress ) {
                return false; // Not all items are completed
            }
        }
        return true; // All items are completed
    }

    /**
     * Create Zoom Meeting using API
     */
    private static function create_zoom_meeting( $args ) {
        $account_id = get_option( 'ts_lms_zoom_account_id' );
        $client_id = get_option( 'ts_lms_zoom_client_id' );
        $client_secret = get_option( 'ts_lms_zoom_client_secret' );

        if ( ! $account_id || ! $client_id || ! $client_secret ) {
            // Return error but allow creating local record
            return new \WP_Error( 'zoom_not_configured', 'Zoom API is not configured.' );
        }

        // Get OAuth Token
        $response = wp_remote_post( "https://zoom.us/oauth/token?grant_type=account_credentials&account_id={$account_id}", array(
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode( $client_id . ':' . $client_secret ),
            ),
        ) );

        if ( is_wp_error( $response ) ) return $response;

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $body['access_token'] ) ) {
            return new \WP_Error( 'zoom_token_error', 'Failed to get Zoom access token.' );
        }

        $access_token = $body['access_token'];

        // Create meeting
        $api_url = "https://api.zoom.us/v2/users/me/meetings";
        $meeting_response = wp_remote_post( $api_url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $access_token,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode( array(
                'topic'      => $args['title'],
                'type'       => 2, // Scheduled
                'start_time' => ( !empty($args['_start_date']) && !empty($args['_start_time']) ) ? $args['_start_date'] . 'T' . $args['_start_time'] . ':00' : current_time('Y-m-d\TH:i:s'),
                'duration'   => 60,
                'timezone'   => isset($args['_timezone']) ? $args['_timezone'] : 'UTC',
                'agenda'     => $args['content'],
            ) ),
        ) );

        if ( is_wp_error( $meeting_response ) ) return $meeting_response;

        return json_decode( wp_remote_retrieve_body( $meeting_response ), true );
    }

    /**
     * Get valid Google Access Token.
     */
    private static function get_google_access_token() {
        $token = get_option( 'ts_lms_google_meet_token' );
        if ( ! $token || ! isset( $token['access_token'] ) ) return false;

        // Check if expired (expiring in less than 5 minutes)
        if ( ! isset( $token['created'] ) || ! isset( $token['expires_in'] ) || ( $token['created'] + $token['expires_in'] - 300 ) < time() ) {
            // Need refresh if refresh_token exists
            if ( empty( $token['refresh_token'] ) ) return false;

            $client_id = get_option( 'ts_lms_google_meet_client_id' );
            $client_secret = get_option( 'ts_lms_google_meet_client_secret' );
            
            $response = wp_remote_post( 'https://oauth2.googleapis.com/token', array(
                'body' => array(
                    'client_id'     => $client_id,
                    'client_secret' => $client_secret,
                    'refresh_token' => $token['refresh_token'],
                    'grant_type'    => 'refresh_token',
                ),
            ) );

            if ( is_wp_error( $response ) ) return false;

            $data = json_decode( wp_remote_retrieve_body( $response ), true );
            if ( isset( $data['access_token'] ) ) {
                $token['access_token'] = $data['access_token'];
                $token['created'] = time();
                if ( isset( $data['expires_in'] ) ) $token['expires_in'] = $data['expires_in'];
                update_option( 'ts_lms_google_meet_token', $token );
            } else {
                return false;
            }
        }

        return $token['access_token'];
    }

    /**
     * Create Google Meet meeting.
     */
    private static function create_google_meeting( $args ) {
        $access_token = self::get_google_access_token();
        if ( ! $access_token ) {
            return new \WP_Error( 'no_auth', 'Google account not authorized.' );
        }

        $start_date = isset( $args['start_date'] ) ? $args['start_date'] : date( 'Y-m-d' );
        $start_time = isset( $args['start_time'] ) ? $args['start_time'] : '10:00';
        $timezone = isset( $args['timezone'] ) ? $args['timezone'] : 'UTC';

        // Basic timezone cleaning (extract from (GMT+06:00) Dhaka format if needed)
        if ( preg_match('/\) ([^ ]+)$/', $timezone, $matches) ) {
            $timezone = $matches[1];
        }

        // Format: 2023-10-27T10:00:00
        $start_datetime = $start_date . 'T' . $start_time . ':00';
        
        $body = array(
            'summary'     => $args['title'],
            'description' => $args['content'],
            'start' => array(
                'dateTime' => $start_datetime,
                'timeZone' => $timezone,
            ),
            'end' => array(
                'dateTime' => date( 'Y-m-d\TH:i:s', strtotime( $start_datetime . ' + 1 hour' ) ),
                'timeZone' => $timezone,
            ),
            'conferenceData' => array(
                'createRequest' => array(
                    'requestId' => uniqid(),
                    'conferenceSolutionKey' => array(
                        'type' => 'hangoutsMeet',
                    ),
                ),
            ),
        );

        $response = wp_remote_post( 'https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $access_token,
                'Content-Type'  => 'application/json',
            ),
            'body' => json_encode( $body ),
        ) );

        if ( is_wp_error( $response ) ) return $response;

        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        
        if ( isset( $data['hangoutLink'] ) ) {
            return array(
                'id'        => $data['id'],
                'join_url'  => $data['hangoutLink'],
            );
        }

        return new \WP_Error( 'api_error', 'Failed to create Google Meet: ' . ( $data['error']['message'] ?? 'Unknown error' ) );
    }
}
