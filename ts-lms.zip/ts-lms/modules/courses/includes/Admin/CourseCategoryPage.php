<?php
/**
 * Course Category Page
 *
 * Custom admin page for managing course categories.
 *
 * @package TS_LMS\Modules\Courses\Admin
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * CourseCategoryPage class.
 */
class CourseCategoryPage {

    /**
     * Initialize the category page customization.
     *
     * @return void
     */
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'remove_default_category_page' ), 999 );
        add_action( 'admin_menu', array( __CLASS__, 'add_custom_category_page' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
        add_action( 'wp_ajax_ts_lms_add_category', array( __CLASS__, 'ajax_add_category' ) );
        add_action( 'wp_ajax_ts_lms_delete_category', array( __CLASS__, 'ajax_delete_category' ) );
        add_action( 'wp_ajax_ts_lms_get_categories', array( __CLASS__, 'ajax_get_categories' ) );
        add_action( 'admin_init', array( __CLASS__, 'handle_category_actions' ) );
        add_action( 'admin_init', array( __CLASS__, 'redirect_to_custom_page' ) );
    }

    /**
     * Remove default category page.
     *
     * @return void
     */
    public static function remove_default_category_page() {
        remove_submenu_page( 'edit.php?post_type=ts_course', 'edit-tags.php?taxonomy=ts_course_category&post_type=ts_course' );
    }

    /**
     * Add custom category page.
     *
     * @return void
     */
    public static function add_custom_category_page() {
        add_submenu_page(
            'edit.php?post_type=ts_course',
            __( 'Course Categories', 'ts-lms' ),
            __( 'Categories', 'ts-lms' ),
            'edit_ts_courses',
            'ts-course-categories',
            array( __CLASS__, 'render_page' )
        );
    }

    /**
     * Enqueue CSS and JS assets.
     *
     * @param string $hook Current admin page hook.
     * @return void
     */
    public static function enqueue_assets( $hook ) {
        if ( 'ts_course_page_ts-course-categories' !== $hook ) {
            return;
        }

        $asset_url = plugin_dir_url( dirname( __FILE__ ) ) . 'assets/';

        wp_enqueue_style(
            'ts-lms-category-page',
            $asset_url . 'css/category-page.css',
            array(),
            '1.0.0'
        );

        wp_enqueue_script(
            'ts-lms-category-page',
            $asset_url . 'js/category-page.js',
            array( 'jquery', 'wp-util' ),
            '1.0.0',
            true
        );

        wp_localize_script(
            'ts-lms-category-page',
            'tsLmsCategoryPage',
            array(
                'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
                'nonce'          => wp_create_nonce( 'ts_lms_category_nonce' ),
                'uploadTitle'    => __( 'Choose Category Image', 'ts-lms' ),
                'uploadButton'   => __( 'Use Image', 'ts-lms' ),
                'confirmDelete'  => __( 'Are you sure you want to delete this category?', 'ts-lms' ),
            )
        );

        // Enqueue media for image upload
        wp_enqueue_media();
    }

    /**
     * Render the custom category page.
     *
     * @return void
     */
    public static function render_page() {
        include dirname( __FILE__ ) . '/templates/course-categories.php';
    }

    /**
     * Handle category actions (add, edit, delete).
     *
     * @return void
     */
    public static function handle_category_actions() {
        if ( ! isset( $_GET['page'] ) || 'ts-course-categories' !== $_GET['page'] ) {
            return;
        }

        // Handle form submissions here if needed
    }

    /**
     * Redirect default taxonomy page to custom page.
     *
     * @return void
     */
    public static function redirect_to_custom_page() {
        global $pagenow;

        // Check if we're on the default taxonomy edit page
        if ( 'edit-tags.php' === $pagenow && isset( $_GET['taxonomy'] ) && 'ts_course_category' === $_GET['taxonomy'] ) {
            // Redirect to our custom page
            wp_safe_redirect( admin_url( 'edit.php?post_type=ts_course&page=ts-course-categories' ) );
            exit;
        }

        // Also handle term.php (edit single term)
        if ( 'term.php' === $pagenow && isset( $_GET['taxonomy'] ) && 'ts_course_category' === $_GET['taxonomy'] ) {
            // Redirect to our custom page
            wp_safe_redirect( admin_url( 'edit.php?post_type=ts_course&page=ts-course-categories' ) );
            exit;
        }
    }

    /**
     * AJAX handler for adding a category.
     *
     * @return void
     */
    public static function ajax_add_category() {
        check_ajax_referer( 'ts_lms_category_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_ts_courses' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
        }

        $name        = isset( $_POST['name'] ) ? sanitize_text_field( $_POST['name'] ) : '';
        $slug        = isset( $_POST['slug'] ) ? sanitize_title( $_POST['slug'] ) : '';
        $parent      = isset( $_POST['parent'] ) ? absint( $_POST['parent'] ) : 0;
        $description = isset( $_POST['description'] ) ? sanitize_textarea_field( $_POST['description'] ) : '';
        $thumbnail   = isset( $_POST['thumbnail'] ) ? absint( $_POST['thumbnail'] ) : 0;

        if ( empty( $name ) ) {
            wp_send_json_error( array( 'message' => __( 'Category name is required.', 'ts-lms' ) ) );
        }

        $args = array(
            'description' => $description,
            'parent'      => $parent,
        );

        if ( ! empty( $slug ) ) {
            $args['slug'] = $slug;
        }

        $result = wp_insert_term( $name, 'ts_course_category', $args );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        // Save thumbnail
        if ( $thumbnail ) {
            update_term_meta( $result['term_id'], 'thumbnail_id', $thumbnail );
        }

        wp_send_json_success( array(
            'message' => __( 'Category added successfully.', 'ts-lms' ),
            'term_id' => $result['term_id'],
        ) );
    }

    /**
     * AJAX handler for deleting a category.
     *
     * @return void
     */
    public static function ajax_delete_category() {
        check_ajax_referer( 'ts_lms_category_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_ts_courses' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
        }

        $term_id = isset( $_POST['term_id'] ) ? absint( $_POST['term_id'] ) : 0;

        if ( ! $term_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid category ID.', 'ts-lms' ) ) );
        }

        $result = wp_delete_term( $term_id, 'ts_course_category' );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array( 'message' => __( 'Category deleted successfully.', 'ts-lms' ) ) );
    }

    /**
     * AJAX handler for getting categories.
     *
     * @return void
     */
    public static function ajax_get_categories() {
        check_ajax_referer( 'ts_lms_category_nonce', 'nonce' );

        $terms = get_terms( array(
            'taxonomy'   => 'ts_course_category',
            'hide_empty' => false,
        ) );

        if ( is_wp_error( $terms ) ) {
            wp_send_json_error( array( 'message' => $terms->get_error_message() ) );
        }

        $categories = array();
        foreach ( $terms as $term ) {
            $thumbnail_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
            $thumbnail_url = '';
            
            if ( $thumbnail_id ) {
                $thumbnail_url = wp_get_attachment_image_url( $thumbnail_id, 'thumbnail' );
            }

            $categories[] = array(
                'id'          => $term->term_id,
                'name'        => $term->name,
                'slug'        => $term->slug,
                'description' => $term->description,
                'count'       => $term->count,
                'parent'      => $term->parent,
                'thumbnail'   => $thumbnail_url,
            );
        }

        wp_send_json_success( array( 'categories' => $categories ) );
    }
}
