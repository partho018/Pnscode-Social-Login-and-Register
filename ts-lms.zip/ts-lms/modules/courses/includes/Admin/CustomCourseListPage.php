<?php
/**
 * Custom Course List Page
 *
 * Completely custom admin page for listing courses.
 * Replaces the default WordPress post list table.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CustomCourseListPage class.
 */
class CustomCourseListPage {

	/**
	 * Page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'ts-lms-course';

	/**
	 * Items per page.
	 *
	 * @var int
	 */
	const PER_PAGE = 20;

	/**
	 * Initialize the custom course list page.
	 *
	 * @return void
	 */
	public static function init() {
		// Register admin menu - Handled by Menu.php
		// add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 20 );
		
		// Enqueue assets
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		
		// AJAX handlers
		add_action( 'wp_ajax_ts_lms_course_status_change', array( __CLASS__, 'ajax_status_change' ) );
		add_action( 'wp_ajax_ts_lms_course_bulk_action', array( __CLASS__, 'ajax_bulk_action' ) );
		add_action( 'wp_ajax_ts_lms_course_delete', array( __CLASS__, 'ajax_delete_course' ) );
	}

	/**
	 * Register admin menu.
	 *
	 * @return void
	 */
	public static function register_menu() {
		add_submenu_page(
			'ts-lms',
			__( 'Courses', 'ts-lms' ),
			__( 'Courses', 'ts-lms' ),
			'edit_ts_courses',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Enqueue page assets.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		// Only load on our custom page
		if ( strpos( $hook, self::PAGE_SLUG ) === false ) {
			return;
		}

		// Enqueue CSS
		wp_enqueue_style(
			'ts-lms-course-list',
			plugin_dir_url( __FILE__ ) . 'assets/css/course-list-page.css',
			array(),
			time()
		);

		// Enqueue modal CSS
		wp_enqueue_style(
			'ts-lms-course-modal',
			plugin_dir_url( __FILE__ ) . 'assets/css/course-modal.css',
			array(),
			'1.0.0'
		);

		// Enqueue JavaScript
		wp_enqueue_script(
			'ts-lms-course-list',
			plugin_dir_url( __FILE__ ) . 'assets/js/course-list-page.js',
			array( 'jquery' ),
			'1.0.0',
			true
		);

		// Localize script
		wp_localize_script(
			'ts-lms-course-list',
			'tsLmsCourseListPage',
			array(
				'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
				'nonce'          => wp_create_nonce( 'ts_lms_course_list_page' ),
				'confirmDelete'  => __( 'Are you sure you want to delete this course?', 'ts-lms' ),
				'confirmBulkDelete' => __( 'Are you sure you want to delete the selected courses?', 'ts-lms' ),
			)
		);
	}

	/**
	 * Render the custom course list page.
	 *
	 * @return void
	 */
	public static function render_page() {
		// Get current page number
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		
		// Get search query
		$search = isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '';
		
		// Get filter parameters
		$category = isset( $_GET['category'] ) ? sanitize_text_field( $_GET['category'] ) : '';
		$status = isset( $_GET['status'] ) ? sanitize_text_field( $_GET['status'] ) : '';
		$post_type_filter = isset( $_GET['post_type'] ) ? sanitize_text_field( $_GET['post_type'] ) : '';
		
		// Get sorting parameters
		$orderby = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'date';
		$order   = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC';
		
		// Build query args
		$target_post_types = array( 'ts_course', 'ts_bundle' );
		if ( ! empty( $post_type_filter ) && in_array( $post_type_filter, $target_post_types ) ) {
			$target_post_types = $post_type_filter;
		}

		$args = array(
			'post_type'      => $target_post_types,
			'posts_per_page' => self::PER_PAGE,
			'paged'          => $paged,
			'orderby'        => $orderby,
			'order'          => $order,
		);
		
		// Add search
		if ( ! empty( $search ) ) {
			$args['s'] = $search;
		}
		
		// Add status filter
		if ( ! empty( $status ) ) {
			$args['post_status'] = $status;
		} else {
			$args['post_status'] = array( 'publish', 'draft', 'pending' );
		}
		
		// Add category filter
		if ( ! empty( $category ) ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'ts_course_category',
					'field'    => 'slug',
					'terms'    => $category,
				),
			);
		}
		
		// Query courses
		$query = new \WP_Query( $args );
		
		// Get categories for filter
		$categories = get_terms( array(
			'taxonomy'   => 'ts_course_category',
			'hide_empty' => true,
		) );
		
		// Load template
		include __DIR__ . '/templates/course-list-page.php';
	}

	/**
	 * Get course metadata for display.
	 *
	 * @param int $course_id Course ID.
	 * @return array Course metadata.
	 */
	public static function get_course_metadata( $course_id ) {
		$post_type = get_post_type( $course_id );

		if ( 'ts_bundle' === $post_type ) {
			global $wpdb;
			$table = $wpdb->prefix . 'ts_bundle_courses';
			$course_count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE bundle_id = %d", $course_id ) );

			return array(
				'is_bundle' => true,
				'courses'   => absint( $course_count ),
				'lessons'   => 0,
				'quizzes'   => 0,
				'assignments' => 0,
				'topics'    => 0,
			);
		}

		// Get lesson count
		$lessons = get_posts( array(
			'post_type'      => 'ts_lesson',
			'posts_per_page' => -1,
			'meta_query'     => array(
				array(
					'key'   => '_lesson_course_id',
					'value' => $course_id,
				),
			),
			'fields'         => 'ids',
		) );
		
		// Get counts from meta
		$quiz_count = absint( get_post_meta( $course_id, '_course_quiz_count', true ) );
		$assignment_count = absint( get_post_meta( $course_id, '_course_assignment_count', true ) );
		
		// Get topic count (categories)
		$topics = wp_get_post_terms( $course_id, 'ts_course_category' );
		
		return array(
			'is_bundle'   => false,
			'topics'      => is_array( $topics ) ? count( $topics ) : 0,
			'lessons'     => count( $lessons ),
			'quizzes'     => $quiz_count,
			'assignments' => $assignment_count,
		);
	}

	/**
	 * Get course price.
	 *
	 * @param int $course_id Course ID.
	 * @return string Price HTML.
	 */
	public static function get_course_price( $course_id ) {
		$post_type = get_post_type( $course_id );

		if ( 'ts_bundle' === $post_type ) {
			$price = get_post_meta( $course_id, '_bundle_price', true );
			if ( $price && $price > 0 ) {
				$currency = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '$';
				return '<span class="ts-price-paid">' . esc_html( $price ) . ' ' . esc_html( $currency ) . '</span>';
			}
			return '<span class="ts-price-free">' . __( 'Free', 'ts-lms' ) . '</span>';
		}

		// Check if WooCommerce product is linked
		$product_id = get_post_meta( $course_id, '_course_product_id', true );
		
		// Also check legacy meta key for backward compatibility ...
		if ( ! $product_id ) {
			$product_id = get_post_meta( $course_id, '_linked_product_id', true );
		}
		
		// Validate that product ID is not empty and is a valid number
		if ( $product_id && is_numeric( $product_id ) && $product_id > 0 ) {
			// Verify the product actually exists
			if ( class_exists( 'WooCommerce' ) && function_exists( 'wc_get_product' ) ) {
				$product = wc_get_product( $product_id );
				if ( $product && $product->exists() ) {
					// Display "Paid" if a valid WooCommerce product is linked
					return '<span class="ts-price-paid">' . __( 'Paid', 'ts-lms' ) . '</span>';
				}
			}
		}
		
		return '<span class="ts-price-free">' . __( 'Free', 'ts-lms' ) . '</span>';
	}

	/**
	 * Handle AJAX status change.
	 *
	 * @return void
	 */
	public static function ajax_status_change() {
		check_ajax_referer( 'ts_lms_course_list_page', 'nonce' );
		
		$course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
		$new_status = isset( $_POST['status'] ) ? sanitize_text_field( $_POST['status'] ) : '';
		
		if ( ! $course_id || ! in_array( $new_status, array( 'draft', 'publish' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid parameters', 'ts-lms' ) ) );
		}

		$post_type = get_post_type( $course_id );
		$capability = ( 'ts_bundle' === $post_type ) ? 'edit_ts_bundles' : 'edit_ts_courses';

		if ( ! current_user_can( $capability ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'ts-lms' ) ) );
		}
		
		// Update post status
		$result = wp_update_post( array(
			'ID'          => $course_id,
			'post_status' => $new_status,
		) );
		
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		
		wp_send_json_success( array(
			'message'   => __( 'Status updated successfully', 'ts-lms' ),
			'status'    => $new_status,
			'permalink' => get_permalink( $course_id ),
		) );
	}

	/**
	 * Handle AJAX bulk action.
	 *
	 * @return void
	 */
	public static function ajax_bulk_action() {
		check_ajax_referer( 'ts_lms_course_list_page', 'nonce' );
		
		$action = isset( $_POST['bulk_action'] ) ? sanitize_text_field( $_POST['bulk_action'] ) : '';
		$course_ids = isset( $_POST['course_ids'] ) ? array_map( 'absint', $_POST['course_ids'] ) : array();
		
		if ( empty( $action ) || empty( $course_ids ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid parameters', 'ts-lms' ) ) );
		}
		
		$count = 0;
		
		foreach ( $course_ids as $course_id ) {
			$post_type = get_post_type( $course_id );
			$edit_cap = ( 'ts_bundle' === $post_type ) ? 'edit_ts_bundles' : 'edit_ts_courses';
			$delete_cap = ( 'ts_bundle' === $post_type ) ? 'delete_ts_bundles' : 'delete_ts_courses';

			switch ( $action ) {
				case 'delete':
					if ( current_user_can( $delete_cap ) && wp_delete_post( $course_id, true ) ) {
						$count++;
					}
					break;
					
				case 'publish':
				case 'draft':
					if ( current_user_can( $edit_cap ) && wp_update_post( array( 'ID' => $course_id, 'post_status' => $action ) ) ) {
						$count++;
					}
					break;
			}
		}

		$message = sprintf( __( '%d item(s) processed successfully', 'ts-lms' ), $count );
		wp_send_json_success( array( 'message' => $message, 'count' => $count ) );
	}

	/**
	 * Handle AJAX delete course.
	 *
	 * @return void
	 */
	public static function ajax_delete_course() {
		check_ajax_referer( 'ts_lms_course_list_page', 'nonce' );
		
		$course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
		
		if ( ! $course_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid item ID', 'ts-lms' ) ) );
		}

		$post_type = get_post_type( $course_id );
		$capability = ( 'ts_bundle' === $post_type ) ? 'delete_ts_bundles' : 'delete_ts_courses';
		
		if ( ! current_user_can( $capability ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'ts-lms' ) ) );
		}
		
		// Check if instructor is allowed to trash courses (for ts_course type)
		if ( 'ts_course' === $post_type ) {
			$current_user = wp_get_current_user();
			$is_instructor = in_array( 'instructor', (array) $current_user->roles ) && ! current_user_can( 'manage_options' );
			
			if ( $is_instructor ) {
				$settings = \TS_LMS\Admin\Settings::get_settings();
				$allow_trash = isset( $settings['allow_trash_courses'] ) && $settings['allow_trash_courses'];
				
				if ( ! $allow_trash ) {
					wp_send_json_error( array( 'message' => __( 'You do not have permission to delete courses. Please contact the administrator.', 'ts-lms' ) ) );
				}
			}
		}
		
		$result = wp_delete_post( $course_id, true );
		
		if ( ! $result ) {
			wp_send_json_error( array( 'message' => __( 'Failed to delete item', 'ts-lms' ) ) );
		}
		
		wp_send_json_success( array( 'message' => __( 'Item deleted successfully', 'ts-lms' ) ) );
	}
}
