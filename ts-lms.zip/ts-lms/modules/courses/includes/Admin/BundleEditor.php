<?php
/**
 * Custom Bundle Editor
 *
 * Handles the custom bundle creation and editing interface.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * BundleEditor class.
 */
class BundleEditor {

	/**
	 * Page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'ts-lms-bundle-editor';

	/**
	 * Initialize the bundle editor.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 99 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_ajax_ts_lms_save_bundle', array( __CLASS__, 'ajax_save_bundle' ) );
	}

	/**
	 * Register admin menu.
	 *
	 * @return void
	 */
	public static function register_menu() {
		add_submenu_page(
			null, // Hidden from menu
			__( 'Bundle Editor', 'ts-lms' ),
			__( 'Bundle Editor', 'ts-lms' ),
			'edit_ts_bundles',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Enqueue page assets.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( strpos( $hook, self::PAGE_SLUG ) === false ) {
			return;
		}

		// Enqueue WordPress media uploader
		wp_enqueue_media();

		// Enqueue CSS (reuse course editor styles)
		wp_enqueue_style(
			'ts-lms-bundle-editor',
			plugin_dir_url( __FILE__ ) . 'assets/css/course-editor.css',
			array(),
			'1.0.0'
		);

		// Enqueue Bundle List CSS
		wp_enqueue_style(
			'ts-lms-bundle-list',
			plugin_dir_url( __FILE__ ) . 'assets/css/course-list-page.css',
			array(),
			'1.0.0'
		);

		// Enqueue Bundle Editor specific CSS
		wp_enqueue_style(
			'ts-lms-bundle-editor-extra',
			plugin_dir_url( __FILE__ ) . 'assets/css/bundle-editor.css',
			array(),
			'1.0.0'
		);

		// Enqueue JavaScript
		wp_enqueue_script(
			'ts-lms-bundle-editor',
			plugin_dir_url( __FILE__ ) . 'assets/js/bundle-editor.js',
			array( 'jquery' ),
			'1.0.0',
			true
		);

		// Localize script
		wp_localize_script(
			'ts-lms-bundle-editor',
			'tsLmsBundleEditor',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'ts_lms_bundle_editor' ),
				'listUrl'    => admin_url( 'admin.php?page=ts-lms-course' ),
				'strings'    => array(
					'saving'       => __( 'Saving...', 'ts-lms' ),
					'saved'        => __( 'Bundle saved successfully!', 'ts-lms' ),
					'error'        => __( 'An error occurred. Please try again.', 'ts-lms' ),
					'confirmLeave' => __( 'You have unsaved changes. Are you sure you want to leave?', 'ts-lms' ),
				),
			)
		);
	}

	/**
	 * Render the bundle editor page.
	 *
	 * @return void
	 */
	public static function render_page() {
		// Get bundle ID if editing
		$bundle_id = isset( $_GET['bundle_id'] ) ? absint( $_GET['bundle_id'] ) : 0;
		$action    = isset( $_GET['action'] ) ? sanitize_text_field( $_GET['action'] ) : '';
		
		$bundle           = null;
		$bundle_data      = array();
		$selected_courses = array();
		$query            = null;

		if ( $bundle_id || 'new' === $action ) {
			if ( $bundle_id ) {
				$bundle = get_post( $bundle_id );
				
				if ( ! $bundle || 'ts_bundle' !== $bundle->post_type ) {
					wp_die( __( 'Invalid bundle ID.', 'ts-lms' ) );
				}

				// Get bundle metadata
				$bundle_data = array(
					'title'        => $bundle->post_title,
					'description'  => $bundle->post_content,
					'thumbnail_id' => get_post_thumbnail_id( $bundle_id ),
					'status'       => $bundle->post_status,
					'price'        => get_post_meta( $bundle_id, '_bundle_price', true ),
					'price_type'   => get_post_meta( $bundle_id, '_bundle_price_type', true ) ?: 'free',
					'product_id'   => get_post_meta( $bundle_id, '_bundle_product_id', true ),
					'sub_price'    => get_post_meta( $bundle_id, '_bundle_subscription_price', true ),
					'sub_plan'     => get_post_meta( $bundle_id, '_bundle_subscription_plan', true ) ?: 'monthly',
				);

				// Get selected courses
				global $wpdb;
				$table = $wpdb->prefix . 'ts_bundle_courses';
				$results = $wpdb->get_results( $wpdb->prepare(
					"SELECT course_id FROM {$table} WHERE bundle_id = %d",
					$bundle_id
				) );
				
				foreach ( $results as $row ) {
					$selected_courses[] = $row->course_id;
				}
			}

			// Get all available courses for selection
			$courses = get_posts( array(
				'post_type'      => 'ts_course',
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'orderby'        => 'title',
				'order'          => 'ASC',
			) );

		} else {
			// List View Logic
			$paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
			$search = isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '';
			
			$args = array(
				'post_type'      => 'ts_bundle',
				'posts_per_page' => 20,
				'paged'          => $paged,
				'orderby'        => 'date',
				'order'          => 'DESC',
			);

			if ( ! empty( $search ) ) {
				$args['s'] = $search;
			}
			
			$query = new \WP_Query( $args );
		}

		// Load template
		include __DIR__ . '/templates/bundle-editor.php';
	}

	/**
	 * Handle AJAX save bundle.
	 *
	 * @return void
	 */
	public static function ajax_save_bundle() {
		check_ajax_referer( 'ts_lms_bundle_editor', 'nonce' );

		if ( ! current_user_can( 'edit_ts_bundles' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'ts-lms' ) ) );
		}

		$bundle_id = isset( $_POST['bundle_id'] ) ? absint( $_POST['bundle_id'] ) : 0;
		$title = isset( $_POST['title'] ) ? sanitize_text_field( $_POST['title'] ) : '';
		$description = isset( $_POST['description'] ) ? wp_kses_post( $_POST['description'] ) : '';
		$status = isset( $_POST['status'] ) ? sanitize_text_field( $_POST['status'] ) : 'draft';
		$thumbnail_id = isset( $_POST['thumbnail_id'] ) ? absint( $_POST['thumbnail_id'] ) : 0;
		$price_type = isset( $_POST['price_type'] ) ? sanitize_text_field( $_POST['price_type'] ) : 'free';
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$sub_price = isset( $_POST['subscription_price'] ) ? floatval( $_POST['subscription_price'] ) : 0;
		$sub_plan = isset( $_POST['subscription_plan'] ) ? sanitize_text_field( $_POST['subscription_plan'] ) : 'monthly';
		$courses = isset( $_POST['courses'] ) ? array_map( 'absint', $_POST['courses'] ) : array();

		// Validate
		if ( empty( $title ) ) {
			wp_send_json_error( array( 'message' => __( 'Bundle title is required', 'ts-lms' ) ) );
		}

		if ( empty( $courses ) ) {
			wp_send_json_error( array( 'message' => __( 'Please select at least one course', 'ts-lms' ) ) );
		}

		// Prepare post data
		$post_data = array(
			'post_title'   => $title,
			'post_content' => $description,
			'post_status'  => $status,
			'post_type'    => 'ts_bundle',
			'post_author'  => get_current_user_id(),
		);

		// Update or create
		if ( $bundle_id ) {
			$post_data['ID'] = $bundle_id;
			$result = wp_update_post( $post_data, true );
		} else {
			$result = wp_insert_post( $post_data, true );
		}

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		$bundle_id = $result;

		// Set thumbnail
		if ( $thumbnail_id ) {
			set_post_thumbnail( $bundle_id, $thumbnail_id );
		}

		// Save price meta
		update_post_meta( $bundle_id, '_bundle_price_type', $price_type );
		update_post_meta( $bundle_id, '_bundle_product_id', $product_id );
		update_post_meta( $bundle_id, '_bundle_subscription_price', $sub_price );
		update_post_meta( $bundle_id, '_bundle_subscription_plan', $sub_plan );

		// Legacy/List Support: If it's a WooCommerce product, use the product's price for display
		$display_price = 0;
		if ( 'paid' === $price_type && $product_id ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				$display_price = $product->get_price();
			}
		} elseif ( 'subscription' === $price_type ) {
			$display_price = $sub_price;
		}

		update_post_meta( $bundle_id, '_bundle_price', $display_price );

		// Save bundle courses
		global $wpdb;
		$table = $wpdb->prefix . 'ts_bundle_courses';

		// Delete existing relationships
		$wpdb->delete( $table, array( 'bundle_id' => $bundle_id ), array( '%d' ) );

		// Insert new relationships
		foreach ( $courses as $index => $course_id ) {
			$wpdb->insert(
				$table,
				array(
					'bundle_id'    => $bundle_id,
					'course_id'    => $course_id,
					'course_price' => 0,
					'order_index'  => $index,
					'created_at'   => current_time( 'mysql' ),
				),
				array( '%d', '%d', '%f', '%d', '%s' )
			);
		}

		wp_send_json_success( array(
			'message'   => __( 'Bundle saved successfully', 'ts-lms' ),
			'bundle_id' => $bundle_id,
			'edit_url'  => admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&bundle_id=' . $bundle_id ),
		) );
	}
}
