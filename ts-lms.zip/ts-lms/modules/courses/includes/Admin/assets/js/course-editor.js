﻿/**
 * Course Editor V2 JavaScript
 *
 * @package TS_LMS
 * @version 2.1.0
 */

(function ($) {
	'use strict';

	/**
	 * Course Editor Module
	 */
	var CourseEditor = {
		currentStep: 1,
		hasUnsavedChanges: false,
		itemFrame: null,
		imageFrame: null,

		/**
		 * Initialize
		 */
		init: function () {
			this.bindEvents();
			this.trackChanges();
			this.initSidebar();
			this.initSlugGeneration();
			// this.initMediaUploader(); // Bound via events, but logic is added below
			
			// Load curriculum if course ID exists
			if ($('#course-id').val()) {
				this.loadCurriculum();
			}

			this.initDateTimePickers();

			console.log('TS LMS Course Editor V2.1 initialized');
		},

		/**
		 * Bind event handlers
		 */
		bindEvents: function () {
			var self = this;

			// Step navigation
			$(document).on('click', '.ts-step', this.handleStepClick.bind(this));

			// Option tabs (Options section)
			$(document).on('click', '.ts-modern-tab', function(e) {
				var target = $(this).data('target');
				$('.ts-modern-tab').removeClass('active');
				$(this).addClass('active');
				$('.ts-opt-content').removeClass('active');
				$('#opt-' + target).addClass('active');
			});

		// Vertical tabs (Options section - General, Content Drip, Enrollment)
		$(document).on('click', '.ts-vtab', function(e) {
			e.preventDefault();
			var tab = $(this).data('tab');
			$('.ts-vtab').removeClass('active');
			$(this).addClass('active');
			$('.ts-vtab-panel').removeClass('active');
			$('.ts-vtab-panel[data-panel="' + tab + '"]').addClass('active');
		});

			// Save/Publish
			$(document).on('click', '#ts-save-draft', this.saveDraft.bind(this));
			$(document).on('click', '#ts-publish-course', this.publishCourse.bind(this));

			/* --- Curriculum Events --- */
			$(document).on('click', '#ts-add-topic-btn, #ts-add-first-topic', this.addTopicAction.bind(this));
			$(document).on('click', '.ts-topic-edit', this.editTopicAction.bind(this));
			$(document).on('click', '.ts-topic-save-btn', this.saveTopicAction.bind(this));
			$(document).on('click', '.ts-topic-cancel-btn', this.cancelTopicAction.bind(this));
			
			$(document).on('click', '.ts-topic-toggle', function() {
				$(this).closest('.ts-topic-card').toggleClass('ts-collapsed');
			});
			$(document).on('click', '.ts-topic-delete', this.deleteTopicAction.bind(this));
			
			// Item creation
			$(document).on('click', '.ts-topic-item-add', this.addItemAction.bind(this));
			$(document).on('click', '.ts-item-delete', this.deleteItemAction.bind(this));
			$(document).on('click', '.ts-item-edit', this.editItemAction.bind(this));
			$(document).on('click', '.ts-topic-duplicate', this.duplicateTopicAction.bind(this));
			$(document).on('click', '.ts-item-duplicate', this.duplicateItemAction.bind(this));

			// Lesson Modal
			$(document).on('click', '.ts-lesson-btn-save', this.saveLessonModal.bind(this));
			$(document).on('click', '.ts-lesson-btn-cancel, .ts-lesson-modal-close', function() {
				$('#ts-lesson-modal').fadeOut(200);
			});

			// Modals (General)
			$(document).on('click', '.ts-modal-close, .ts-modal-overlay', function() {
				$(this).closest('.ts-modal, [id$="-modal"]').fadeOut(200);
			});


			// Toast close
			$(document).on('click', '#ts-toast', function() { $(this).fadeOut(); });

			// Media Uploads
			$(document).on('click', '#ts-lesson-image-upload .ts-upload-btn', this.openMediaUploader.bind(this));
			$(document).on('click', '#ts-lesson-remove-image', this.removeLessonImage.bind(this));
			$(document).on('click', '#ts-lesson-video-upload-btn', this.openLessonVideoUploader.bind(this));
			$(document).on('click', '#ts-lesson-video-url-btn', this.addLessonVideoUrl.bind(this));
			$(document).on('click', '#ts-video-url-add-btn', this.confirmLessonVideoUrl.bind(this));

			// Quiz & Assignment Modals
			$(document).on('click', '.ts-quiz-btn-ok', this.saveQuizModal.bind(this));
			$(document).on('click', '.ts-assignment-btn-save', this.saveAssignmentModal.bind(this));
			$(document).on('click', '.ts-quiz-btn-cancel, .ts-quiz-modal-close', function() { $('#ts-quiz-modal').fadeOut(200); });
			$(document).on('click', '.ts-assignment-btn-cancel, .ts-assignment-modal-close', function() { $('#ts-assignment-modal').fadeOut(200); });

			// Quiz Tabs
			$(document).on('click', '.ts-quiz-tab', function(e) {
				e.preventDefault();
				var tab = $(this).data('tab');
				$('.ts-quiz-tab').removeClass('ts-quiz-tab-active');
				$(this).addClass('ts-quiz-tab-active');
				$('.ts-quiz-tab-content').removeClass('ts-quiz-tab-content-active');
				$('.ts-quiz-tab-content[data-tab="' + tab + '"]').addClass('ts-quiz-tab-content-active');
			});

			// Add Question
			$(document).on('click', '#ts-add-question-btn', this.addQuestionUI.bind(this));

			// Warn before leaving
			$(window).on('beforeunload', this.warnBeforeLeave.bind(this));

			// Sidebar: Add Video from URL toggle
			$(document).on('click', '.ts-video-url', function(e) {
				e.preventDefault();
				$('#ts-video-url-input-area').slideToggle(200);
				// Focus if becoming visible
				if ($('#ts-video-url-input-area').is(':visible')) {
					$('#ts-course-video-url').focus();
				}
			});

			// Sidebar: Intro Video URL Add button
			$(document).on('click', '#ts-intro-video-url-add-btn', function(e) {
				e.preventDefault();
				self.handleVideoPreview();
			});

			// Auto-preview on input/paste
			$(document).on('input', '#ts-course-video-url', function() {
				var url = $(this).val().trim();
				// Only auto-preview if it looks like a full URL to avoid constant flickering
				if (url.length > 20) {
					self.handleVideoPreview(true); // silent
				}
			});

			// Schedule Live Class Buttons (Sidebar)
		$(document).on('click', '#ts-create-zoom-meeting', function(e) {
			e.preventDefault();
			e.stopPropagation();
			
			// Check if Zoom API is configured
		if (!tsLmsCourseEditor.hasZoomApi) {
			self.showApiWarning('zoom', tsLmsCourseEditor.zoomSettingsUrl);
			return;
		}
			
			var $btn = $(this);
			var $modal = $('#ts-zoom-modal');
			self.populateTopicSelector('ts-zoom-topic-id');
			$modal.find('.ts-topic-select-group').show();
			
			if (!$modal.parent().is('body')) {
				$('body').append($modal);
			}

			// Get button position
		var btnOffset = $btn.offset();
		var btnHeight = $btn.outerHeight();
		var btnWidth = $btn.outerWidth();
		
		// Show modal first to get its width
		$modal.css('display', 'flex');
		var modalWidth = $modal.find('.ts-modal-container').outerWidth() || 500;
		
		// Position modal to the left of the button
		$modal.css({
			position: 'absolute',
			top: btnOffset.top,
			left: btnOffset.left - modalWidth - 10, // 10px gap from button
			transform: 'none',
			zIndex: 1000001,
			display: 'flex'
		}).fadeIn(200);
	});

	$(document).on('click', '#ts-create-google-meet', function(e) {
		e.preventDefault();
		e.stopPropagation();
		
		// Check if Google Meet API is configured
		if (!tsLmsCourseEditor.hasMeetApi) {
			self.showApiWarning('meet', tsLmsCourseEditor.meetSettingsUrl);
			return;
		}
		
		var $btn = $(this);
		var $modal = $('#ts-meet-modal');
		self.populateTopicSelector('ts-meet-topic-id');
		$modal.find('.ts-topic-select-group').show();
		
		if (!$modal.parent().is('body')) {
			$('body').append($modal);
		}

		// Get button position
		var btnOffset = $btn.offset();
		var btnHeight = $btn.outerHeight();
		var btnWidth = $btn.outerWidth();
		
		// Show modal first to get its width
		$modal.css('display', 'flex');
		var modalWidth = $modal.find('.ts-modal-container').outerWidth() || 500;
		
		// Position modal to the left of the button
		$modal.css({
			position: 'absolute',
			top: btnOffset.top,
			left: btnOffset.left - modalWidth - 10, // 10px gap from button
			transform: 'none',
			zIndex: 1000001,
			display: 'flex'
		}).fadeIn(200);
	});


			// Handle removing preview
			$(document).on('click', '.ts-remove-video-preview', function(e) {
				e.preventDefault();
				$('#ts-video-preview-container').fadeOut(200);
				$('#ts-video-preview-content').empty();
				$('#ts-course-video-url').val('');
				$('#ts-video-url-input-area').slideDown(200);
			});

			// Topic Footer More Menu
			$(document).on('click', '.ts-topic-footer-more', this.toggleTopicContextMenu.bind(this));
			
			// Publish Dropdown Toggle
			$(document).on('click', '.ts-btn-publish-dropdown', function(e) {
				e.stopPropagation();
				$('.ts-publish-more-menu').fadeToggle(150);
			});

			$(document).on('click', function(e) {
				var $target = $(e.target);
				
				// Publish dropdown
				if (!$target.closest('.ts-publish-group').length) {
					$('.ts-publish-more-menu').fadeOut(100);
				}

				// Curriculum context menu and live lesson modals
				if (!$target.closest('.ts-topic-footer-more').length && 
					!$target.closest('.ts-context-menu').length && 
					!$target.closest('.ts-live-modal-container').length &&
					!$target.closest('.ui-datepicker').length) {
					$('.ts-context-menu').fadeOut(100, function() { $(this).remove(); });
					$('.ts-live-modal').fadeOut(100);
				}
			});

			// Initial check for existing intro video
			if ($('#ts-course-video-url').val()) {
				this.handleVideoPreview(true); // silent
			}

		// Meet Modal Actions
		$(document).on('click', '.ts-meet-btn-cancel, .ts-meet-modal-close', function(e) {
			e.preventDefault();
			$('#ts-meet-modal').fadeOut(200);
		});
		
		// Prevent modal container clicks from closing
		$(document).on('click', '#ts-meet-modal .ts-modal-container', function(e) {
			e.stopPropagation();
		});
		
		// Close Meet Modal on overlay click
		$(document).on('click', '#ts-meet-modal .ts-modal-overlay', function(e) {
			e.preventDefault();
			$('#ts-meet-modal').fadeOut(200);
		});
		
		$(document).on('click', '.ts-meet-btn-save', this.saveMeetModal.bind(this));

		// Zoom Modal Actions
		$(document).on('click', '.ts-zoom-btn-cancel, .ts-zoom-modal-close', function(e) {
			e.preventDefault();
			$('#ts-zoom-modal').fadeOut(200);
		});
		
		// Prevent modal container clicks from closing
		$(document).on('click', '#ts-zoom-modal .ts-modal-container', function(e) {
			e.stopPropagation();
		});
		
		// Close Zoom Modal on overlay click
		$(document).on('click', '#ts-zoom-modal .ts-modal-overlay', function(e) {
			e.preventDefault();
			$('#ts-zoom-modal').fadeOut(200);
		});
		
		$(document).on('click', '.ts-zoom-btn-save', this.saveZoomModal.bind(this));

			// Import Quiz Modal Actions
			$(document).on('click', '.ts-import-quiz-modal-close', function() {
				$('#ts-import-quiz-modal').fadeOut(200);
			});
			$(document).on('click', '.ts-import-item-btn', function() {
				var quizTitle = $(this).closest('.ts-import-item').find('.ts-import-item-title').text();
				self.showToast('Quiz "' + quizTitle + '" imported!', 'success');
				$('#ts-import-quiz-modal').fadeOut(200);
			});

			// Icon click trigger for date/time (Shared for live lessons)
			$(document).on('click', '.ts-live-input-with-icon .dashicons', function() {
				$(this).next('input').focus();
			});

			// Preview Course
			$(document).on('click', '#ts-preview-course', function() {
				var url = $('.ts-url-value').text().trim();
				if (url) {
					window.open(url, '_blank');
				}
			});

			// Tags Management
			$(document).on('click', '#ts-add-tag-btn', function() {
				$('#ts-add-tag-form').slideDown(200);
				$('#ts-new-tag-name').focus();
			});

			$(document).on('click', '#ts-tag-cancel-btn', function() {
				$('#ts-add-tag-form').slideUp(200);
				$('#ts-new-tag-name').val('');
			});

			$(document).on('click', '#ts-tag-ok-btn', function() {
				var name = $('#ts-new-tag-name').val().trim();
				if (!name) return;

				var $btn = $(this);
				$btn.prop('disabled', true).text('...');

				$.ajax({
					url: tsLmsCourseEditor.ajaxUrl,
					type: 'POST',
					data: {
						action: 'ts_lms_add_tag_editor',
						nonce: tsLmsCourseEditor.nonce,
						name: name
					},
					success: function(response) {
						$btn.prop('disabled', false).text('Ok');
						if (response.success) {
							var html = '<label class="ts-checkbox-item"><input type="checkbox" name="tax_input[ts_course_tag][]" value="' + response.data.term_id + '" checked> ' + response.data.name + '</label>';
							$('#ts-tags-list').find('.ts-no-categories').remove();
							$('#ts-tags-list').append(html);
							$('#ts-add-tag-form').slideUp(200);
							$('#ts-new-tag-name').val('');
							self.showToast('Tag added!', 'success');
						} else {
							self.showToast(response.data.message || 'Error adding tag', 'error');
						}
					},
					error: function() {
						$btn.prop('disabled', false).text('Ok');
						self.showToast('Server error', 'error');
					}
				});
			});

			// Categories Management
			$(document).on('click', '#ts-add-category-btn', function() {
				$('#ts-add-category-form').slideDown(200);
				$('#ts-new-category-name').focus();
			});

			$(document).on('click', '#ts-category-cancel-btn', function() {
				$('#ts-add-category-form').slideUp(200);
				$('#ts-new-category-name').val('');
			});

			$(document).on('click', '#ts-category-ok-btn', function() {
				var name = $('#ts-new-category-name').val().trim();
				var parent = $('#ts-category-parent').val();
				if (!name) return;

				var $btn = $(this);
				$btn.prop('disabled', true).text('...');

				$.ajax({
					url: tsLmsCourseEditor.ajaxUrl,
					type: 'POST',
					data: {
						action: 'ts_lms_add_category_editor',
						nonce: tsLmsCourseEditor.nonce,
						name: name,
						parent: parent
					},
					success: function(response) {
						$btn.prop('disabled', false).text('Ok');
						if (response.success) {
							var html = '<label class="ts-checkbox-item"><input type="checkbox" name="tax_input[ts_course_category][]" value="' + response.data.term_id + '" checked> ' + response.data.name + '</label>';
							$('#ts-categories-list').find('.ts-no-categories').remove();
							$('#ts-categories-list').append(html);
							$('#ts-add-category-form').slideUp(200);
							$('#ts-new-category-name').val('');
							self.showToast('Category added!', 'success');
						} else {
							self.showToast(response.data.message || 'Error adding category', 'error');
						}
					},
					error: function() {
						$btn.prop('disabled', false).text('Ok');
						self.showToast('Server error', 'error');
					}
				});
			});
		},

		/**
		 * Extract YouTube Video ID
		 */
		getYouTubeId: function(url) {
			var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
			var match = url.match(regExp);
			return (match && match[2].length == 11) ? match[2] : false;
		},

		/**
		 * Extract Vimeo Video ID
		 */
		getVimeoId: function(url) {
			var match = url.match(/vimeo\.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|)(\d+)(?:$|\/|\?)/);
			return (match && match[3]) ? match[3] : false;
		},

		/**
		 * Handle Video Preview and Logic
		 */
		handleVideoPreview: function(isSilent) {
			var self = this;
			var $urlInput = $('#ts-course-video-url');
			var $previewContainer = $('#ts-video-preview-container');
			var $previewContent = $('#ts-video-preview-content');
			var videoUrl = $urlInput.val().trim();

			if (!videoUrl) {
				if (!isSilent) this.showToast('Please enter a valid URL', 'error');
				return;
			}

			// Try YouTube
			var ytId = this.getYouTubeId(videoUrl);
			if (ytId) {
				$previewContent.html(
					'<div class="ts-video-preview-thumbnail-wrapper">' +
						'<img src="https://img.youtube.com/vi/' + ytId + '/maxresdefault.jpg" class="ts-video-preview-thumbnail">' +
						'<div class="ts-video-play-overlay"><span class="dashicons dashicons-controls-play"></span></div>' +
					'</div>'
				);
				$previewContainer.show();
				$('#ts-video-url-input-area').slideUp(200);
				if (!isSilent) this.showToast('YouTube video added!', 'success');
				
				// Click on thumbnail to replace with iframe
				$previewContent.off('click').on('click', function() {
					$(this).html('<iframe src="https://www.youtube.com/embed/' + ytId + '?autoplay=1" allowfullscreen allow="autoplay"></iframe>');
				});
				return;
			}

			// Try Vimeo
			var vimeoId = this.getVimeoId(videoUrl);
			if (vimeoId) {
				// We can't easily get Vimeo thumbnail without API call, so just embed
				$previewContent.html('<iframe src="https://player.vimeo.com/video/' + vimeoId + '" allowfullscreen></iframe>');
				$previewContainer.show();
				$('#ts-video-url-input-area').slideUp(200);
				if (!isSilent) this.showToast('Vimeo video added!', 'success');
				return;
			}

			// Try Direct MP4/Video
			if (videoUrl.match(/\.(mp4|webm|ogg)$/)) {
				$previewContent.html('<video controls src="' + videoUrl + '"></video>');
				$previewContainer.show();
				$('#ts-video-url-input-area').slideUp(200);
				if (!isSilent) this.showToast('External video added!', 'success');
				return;
			}

			if (!isSilent) this.showToast('Unsupported video format or invalid URL', 'error');
		},

		/**
		 * Load Curriculum from DB
		 */
		loadCurriculum: function() {
			var self = this;
			var courseId = $('#course-id').val();

			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_get_curriculum',
					nonce: tsLmsCourseEditor.nonce,
					course_id: courseId
				},
				success: function(response) {
					if (response.success) {
						self.renderCurriculum(response.data.curriculum);
					}
				}
			});
		},

		/**
		 * Render Curriculum UI
		 */
		renderCurriculum: function(curriculum) {
			var self = this;
			var $list = $('#ts-topics-list');
			$list.empty();

			if (curriculum && curriculum.length > 0) {
				curriculum.forEach(function(topic) {
					var $topicCard = self.createTopicCard(topic);
					$list.append($topicCard);
				});
			}

			this.updateSummary();
			this.initSortable();
		},

		/**
		 * Create Topic Card element
		 */
		createTopicCard: function(topic) {
			var self = this;
			var isNew = !topic.id;
			var topicHtml = `
				<div class="ts-topic-card ${isNew ? 'ts-topic-edit-mode' : ''} ts-collapsed" data-topic-id="${topic.id}">
					<div class="ts-topic-card-body">
						<div class="ts-topic-drag-handle">⋮⋮</div>
						<div class="ts-topic-main-content">
							<!-- View Mode -->
							<div class="ts-topic-view-mode" style="${isNew ? 'display:none' : ''}">
								<div class="ts-topic-title-row">
									<h3 class="ts-topic-display-title">${topic.title || 'Topic Title'}</h3>
									<div class="ts-topic-header-actions">
										<button type="button" class="ts-topic-action-icon ts-topic-edit" title="Edit"><span class="dashicons dashicons-edit"></span></button>
										<button type="button" class="ts-topic-action-icon ts-topic-duplicate" title="Duplicate"><span class="dashicons dashicons-admin-page"></span></button>
										<button type="button" class="ts-topic-action-icon ts-topic-delete" title="Delete"><span class="dashicons dashicons-trash"></span></button>
										<button type="button" class="ts-topic-action-icon ts-topic-toggle" title="Toggle"><span class="dashicons dashicons-arrow-up-alt2"></span></button>
									</div>
								</div>
								<p class="ts-topic-display-summary">${topic.summary || 'Enter topic summary...'}</p>
							</div>

							<!-- Edit Mode -->
							<div class="ts-topic-edit-mode-form" style="${isNew ? '' : 'display:none'}">
								<div class="ts-topic-edit-row">
									<input type="text" class="ts-topic-input-title" placeholder="Topic Title" value="${topic.title || ''}">
								</div>
								<textarea class="ts-topic-description-area" placeholder="Topic Summary" rows="2">${topic.summary || ''}</textarea>
								<div class="ts-topic-confirm-row">
									<button type="button" class="ts-topic-cancel-btn">Cancel</button>
									<button type="button" class="ts-topic-save-btn">Ok</button>
								</div>
							</div>
						</div>
					</div>
					<div class="ts-topic-items-list"></div>
					<div class="ts-topic-footer">
						<div class="ts-topic-footer-left">
							<button type="button" class="ts-topic-item-add" data-type="lesson" ${isNew ? 'disabled' : ''}>
								<span class="dashicons dashicons-plus"></span> Lesson
							</button>
							<button type="button" class="ts-topic-item-add" data-type="quiz" ${isNew ? 'disabled' : ''}>
								<span class="dashicons dashicons-plus"></span> Quiz
							</button>
							<button type="button" class="ts-topic-item-add" data-type="assignment" ${isNew ? 'disabled' : ''}>
								<span class="dashicons dashicons-plus"></span> Assignment
							</button>
						</div>
						<div class="ts-topic-footer-right">
							<button type="button" class="ts-topic-footer-more" title="More Options">
								<span class="dashicons dashicons-ellipsis"></span>
							</button>
						</div>
					</div>
				</div>
			`;

			var $card = $(topicHtml);
			if (topic.items) {
				topic.items.forEach(function(item) {
					$card.find('.ts-topic-items-list').append(self.createItemRow(item));
				});
			}
			return $card;
		},


		/**
		 * Create Item Row element
		 */
		createItemRow: function(item) {
			var icon = 'dashicons-media-document';
			if (item.type === 'quiz') icon = 'dashicons-forms';
			if (item.type === 'assignment') icon = 'dashicons-edit';
			if (item.type === 'meet') icon = 'dashicons-video-alt3';
			if (item.type === 'zoom') icon = 'dashicons-video-alt2';
            // If the item title is 'video' (just for demo match) or based on type, we might want specific icons, 
            // but for now we follow the general layout. The screenshot shows the title 'video' itself.

			var itemHtml = `
				<div class="ts-item-row" data-item-id="${item.id}" data-type="${item.type}">
					<div class="ts-topic-drag-handle"><span class="dashicons dashicons-menu"></span></div>
					<div class="ts-item-content">
                        <span class="ts-item-type-icon float-left mr-2"><span class="dashicons ${icon}"></span></span>
                        <input type="text" class="ts-item-title-input" value="${item.title}" readonly>
                    </div>
					<div class="ts-item-actions">
						<button type="button" class="ts-topic-action-icon ts-item-edit" title="Edit"><span class="dashicons dashicons-edit"></span></button>
						<button type="button" class="ts-topic-action-icon ts-item-duplicate" title="Duplicate"><span class="dashicons dashicons-admin-page"></span></button>
						<button type="button" class="ts-topic-action-icon ts-item-delete" title="Delete"><span class="dashicons dashicons-trash"></span></button>
					</div>
				</div>
			`;
			return $(itemHtml);
		},

		/**
		 * Add Topic Action
		 */
		addTopicAction: function() {
			var $list = $('#ts-topics-list');
			var tempId = 'new-' + Date.now();
			var $newTopic = this.createTopicCard({ id: 0, title: '', summary: '', items: [] });
			$newTopic.attr('data-temp-id', tempId);
			$list.append($newTopic);
			$newTopic.find('.ts-topic-input-title').focus();
		},

		/**
		 * Save Topic Action
		 */
		saveTopicAction: function(e) {
			var self = this;
			var $btn = $(e.currentTarget);
			var $card = $btn.closest('.ts-topic-card');
			var title = $card.find('.ts-topic-input-title').val().trim();
			var summary = $card.find('.ts-topic-description-area').val().trim();
			var topicId = $card.data('topic-id');
			var courseId = $('#course-id').val();

			if (!title) {
				self.showToast('Please enter a topic title', 'error');
				$card.find('.ts-topic-input-title').focus();
				return;
			}

			$btn.prop('disabled', true).text('Saving...');

			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_save_topic',
					nonce: tsLmsCourseEditor.nonce,
					course_id: courseId,
					topic_id: topicId,
					title: title,
					summary: summary,
					course_title: $('#course-title').val()
				},
				success: function(response) {
					$btn.prop('disabled', false).text('Ok');
					
					if (response.success) {
						if (response.data.course_id) {
							$('#course-id').val(response.data.course_id);
							if (tsLmsCourseEditor.editUrl) {
								var newUrl = tsLmsCourseEditor.editUrl + '&course_id=' + response.data.course_id;
								window.history.replaceState(null, '', newUrl);
							}
						}

						$card.data('topic-id', response.data.topic_id);
						$card.attr('data-topic-id', response.data.topic_id);
						
						// Update display labels
						$card.find('.ts-topic-display-title').text(title);
						$card.find('.ts-topic-display-summary').text(summary || 'Add a summary');
						
						// Switch to View Mode
						$card.removeClass('ts-topic-edit-mode');
						$card.find('.ts-topic-edit-mode-form').hide();
						$card.find('.ts-topic-view-mode').show();
						
						// Enable Add Item buttons
						$card.find('.ts-topic-item-add').prop('disabled', false);
						self.showToast(response.data.message || 'Topic saved!', 'success');
					} else {
						self.showToast(response.data.message || 'Error saving topic', 'error');
					}
				},
				error: function() {
					$btn.prop('disabled', false).text('Ok');
					self.showToast('Server error while saving topic', 'error');
				}
			});
		},

		/**
		 * Edit Topic Action
		 */
		editTopicAction: function(e) {
			var $card = $(e.currentTarget).closest('.ts-topic-card');
			$card.addClass('ts-topic-edit-mode');
			$card.find('.ts-topic-view-mode').hide();
			$card.find('.ts-topic-edit-mode-form').show();
			$card.find('.ts-topic-input-title').focus();
		},

		/**
		 * Cancel Topic Action
		 */
		cancelTopicAction: function(e) {
			var $card = $(e.currentTarget).closest('.ts-topic-card');
			var topicId = $card.data('topic-id');
			
			if (topicId == 0) {
				// If new topic, just remove it
				$card.remove();
			} else {
				// If existing topic, switch back to view mode
				$card.removeClass('ts-topic-edit-mode');
				$card.find('.ts-topic-edit-mode-form').hide();
				$card.find('.ts-topic-view-mode').show();
			}
		},

		/**
		 * Delete Topic Action
		 */
		deleteTopicAction: function(e) {
			if (!confirm('Are you sure you want to delete this topic and all its contents?')) return;
			var self = this;
			var $card = $(e.currentTarget).closest('.ts-topic-card');
			var topicId = $card.data('topic-id');

			if (!topicId || topicId == 0) {
				$card.remove();
				return;
			}

			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_delete_topic',
					nonce: tsLmsCourseEditor.nonce,
					topic_id: topicId
				},
				success: function(response) {
					if (response.success) {
						$card.remove();
						self.showToast(response.data.message, 'success');
						self.updateSummary();
					} else {
						self.showToast(response.data.message || 'Error deleting topic', 'error');
					}
				},
				error: function() {
					self.showToast('Server error while deleting topic', 'error');
				}
			});
		},

		/**
		 * Duplicate Topic Action
		 */
		duplicateTopicAction: function(e) {
			var self = this;
			var $card = $(e.currentTarget).closest('.ts-topic-card');
			var topicId = $card.data('topic-id');

			if (!topicId || topicId == 0) return;

			$(e.currentTarget).find('.dashicons').addClass('ts-spin');

			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_duplicate_topic',
					nonce: tsLmsCourseEditor.nonce,
					topic_id: topicId
				},
				success: function(response) {
					$(e.currentTarget).find('.dashicons').removeClass('ts-spin');
					if (response.success) {
						self.showToast(response.data.message, 'success');
						self.loadCurriculum(); // Reload full curriculum to show the new topic
					} else {
						self.showToast(response.data.message || 'Error duplicating topic', 'error');
					}
				},
				error: function() {
					$(e.currentTarget).find('.dashicons').removeClass('ts-spin');
					self.showToast('Server error while duplicating topic', 'error');
				}
			});
		},

		/**
		 * Duplicate Item Action
		 */
		duplicateItemAction: function(e) {
			var self = this;
			var $row = $(e.currentTarget).closest('.ts-item-row');
			var itemId = $row.data('item-id');

			if (!itemId || itemId == 0) return;

			$(e.currentTarget).find('.dashicons').addClass('ts-spin');

			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_duplicate_item',
					nonce: tsLmsCourseEditor.nonce,
					item_id: itemId
				},
				success: function(response) {
					$(e.currentTarget).find('.dashicons').removeClass('ts-spin');
					if (response.success) {
						self.showToast(response.data.message, 'success');
						self.loadCurriculum(); // Reload full curriculum
					} else {
						self.showToast(response.data.message || 'Error duplicating item', 'error');
					}
				},
				error: function() {
					$(e.currentTarget).find('.dashicons').removeClass('ts-spin');
					self.showToast('Server error while duplicating item', 'error');
				}
			});
		},

		/**
		 * Initialize Date and Time Pickers
		 */
		initDateTimePickers: function() {
			if (typeof $.fn.datepicker !== 'undefined') {
				$('.ts-datepicker').datepicker({
					dateFormat: 'yy-mm-dd',
					minDate: 0,
					beforeShow: function(input, inst) {
						setTimeout(function() {
							$('#ui-datepicker-div').css('z-index', 999999);
						}, 0);
					}
				});
			}

			// If no timepicker library, we'll use a simple HTML5 time input or similar
			// but let's try to find if there's a standard one.
		},

		/**
		 * Toggle Topic Context Menu (3-dot menu)
		 */
		toggleTopicContextMenu: function(e) {
			var $btn = $(e.currentTarget);
			$('.ts-context-menu').remove();
			
			var menuHtml = `
				<div class="ts-context-menu" style="display:none;">
					<button type="button" class="ts-context-menu-item" data-action="meet">
						<span class="dashicons dashicons-video-alt3"></span> Meet live lesson
					</button>
					<button type="button" class="ts-context-menu-item" data-action="zoom">
						<span class="dashicons dashicons-video-alt2"></span> Zoom live lesson
					</button>
					<button type="button" class="ts-context-menu-item" data-action="import-quiz">
						<span class="dashicons dashicons-download"></span> Import Quiz
					</button>
				</div>
			`;
			
			var $menu = $(menuHtml);
			$('body').append($menu);
			
			var offset = $btn.offset();
			$menu.css({
				position: 'absolute',
				top: offset.top + $btn.outerHeight() + 8,
				left: offset.left - $menu.outerWidth() + $btn.outerWidth(),
				zIndex: 99999
			});
			
			$menu.fadeIn(150);

			// Handle Menu Item Clicks
			var self = this;
			$menu.find('.ts-context-menu-item').on('click', function() {
				var action = $(this).data('action');
				$menu.remove();
				
				if (action === 'meet') {
					var $modal = $('#ts-meet-modal');
					var offset = $btn.offset();
					var topicId = $btn.closest('.ts-topic-card').data('topic-id');
					
					self.populateTopicSelector('ts-meet-topic-id');
					$('#ts-meet-topic-id').val(topicId);
					$modal.find('.ts-topic-select-group').hide();

					if (!$modal.parent().is('body')) {
						$('body').append($modal);
					}

					$modal.css({
						position: 'absolute',
						top: offset.top - $modal.find('.ts-live-modal-container').outerHeight() + $btn.outerHeight(),
						left: offset.left - $modal.find('.ts-live-modal-container').outerWidth() + $btn.outerWidth(),
						zIndex: 100000
					}).fadeIn(200);
				} else if (action === 'zoom') {
					var $modal = $('#ts-zoom-modal');
					var offset = $btn.offset();
					var topicId = $btn.closest('.ts-topic-card').data('topic-id');
					
					self.populateTopicSelector('ts-zoom-topic-id');
					$('#ts-zoom-topic-id').val(topicId);
					$modal.find('.ts-topic-select-group').hide();
					
					if (!$modal.parent().is('body')) {
						$('body').append($modal);
					}

					$modal.css({
						position: 'absolute',
						top: offset.top - $modal.find('.ts-live-modal-container').outerHeight() + $btn.outerHeight(),
						left: offset.left - $modal.find('.ts-live-modal-container').outerWidth() + $btn.outerWidth(),
						zIndex: 100000
					}).fadeIn(200);
				} else if (action === 'import-quiz') {
					var $modal = $('#ts-import-quiz-modal');
					var offset = $btn.offset();
					
					if (!$modal.parent().is('body')) {
						$('body').append($modal);
					}

					$modal.css({
						top: offset.top - $modal.find('.ts-live-modal-container').outerHeight() + $btn.outerHeight(),
						left: offset.left - $modal.find('.ts-live-modal-container').outerWidth() + $btn.outerWidth()
					}).fadeIn(200);
				}
				// Add other actions here...
			});
		},

		/**
		 * Populate Topic Selector in Live Modals
		 */
		populateTopicSelector: function(selectId) {
			var $select = $('#' + selectId);
			$select.empty();
			
			var hasTopics = false;
			$('.ts-topic-card').each(function() {
				var topicId = $(this).data('topic-id');
				var topicTitle = $(this).find('.ts-topic-display-title').text();
				if (topicId) {
					$select.append(`<option value="${topicId}">${topicTitle}</option>`);
					hasTopics = true;
				}
			});

			if (!hasTopics) {
				$select.append('<option value="">No topics available</option>');
			}
		},

		/**
		 * Save Meet Modal
		 */
		saveMeetModal: function() {
			var self = this;
			var name = $('#ts-meet-name').val().trim();
			var summary = $('#ts-meet-summary').val().trim();
			var startDate = $('#ts-meet-start-date').val();
			var startTime = $('#ts-meet-start-time').val();
			var endDate = $('#ts-meet-end-date').val();
			var endTime = $('#ts-meet-end-time').val();
			var timezone = $('#ts-meet-timezone').val();
			var topicId = $('#ts-meet-topic-id').val();
			
			if (!name) {
				self.showToast('Please enter meeting name', 'error');
				return;
			}

			if (!topicId) {
				self.showToast('Please select a topic', 'error');
				return;
			}

			var $btn = $('.ts-meet-btn-save');
			$btn.prop('disabled', true).text('Creating...');

			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_save_item',
					nonce: tsLmsCourseEditor.nonce,
					type: 'meet',
					title: name,
					content: summary,
					topic_id: topicId,
					meta: {
						_start_date: startDate,
						_start_time: startTime,
						_end_date: endDate,
						_end_time: endTime,
						_timezone: timezone
					}
				},
				success: function(response) {
					$btn.prop('disabled', false).text('Create Meeting');
					if (response.success) {
						self.showToast('Google Meet created successfully!', 'success');
						$('#ts-meet-modal').fadeOut(200);
						// Reset form
						$('#ts-meet-name, #ts-meet-summary, #ts-meet-start-date, #ts-meet-start-time, #ts-meet-end-date, #ts-meet-end-time').val('');
						// Refresh curriculum
						var $card = $(`.ts-topic-card[data-topic-id="${topicId}"]`);
						$card.find('.ts-topic-items-list').append(self.createItemRow(response.data.item));
					} else {
						self.showToast(response.data.message || 'Error creating meeting', 'error');
					}
				},
				error: function() {
					$btn.prop('disabled', false).text('Create Meeting');
					self.showToast('Server error while creating meeting', 'error');
				}
			});
		},

		/**
		 * Save Zoom Modal
		 */
		saveZoomModal: function() {
			var self = this;
			var name = $('#ts-zoom-name').val().trim();
			var summary = $('#ts-zoom-summary').val().trim();
			var startDate = $('#ts-zoom-start-date').val();
			var startTime = $('#ts-zoom-start-time').val();
			var endDate = $('#ts-zoom-end-date').val();
			var endTime = $('#ts-zoom-end-time').val();
			var timezone = $('#ts-zoom-timezone').val();
			var topicId = $('#ts-zoom-topic-id').val();
			
			if (!name) {
				self.showToast('Please enter meeting name', 'error');
				return;
			}

			if (!topicId) {
				self.showToast('Please select a topic', 'error');
				return;
			}

			var $btn = $('.ts-zoom-btn-save');
			$btn.prop('disabled', true).text('Creating...');

			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_save_item',
					nonce: tsLmsCourseEditor.nonce,
					type: 'zoom',
					title: name,
					content: summary,
					topic_id: topicId,
					meta: {
						_start_date: startDate,
						_start_time: startTime,
						_end_date: endDate,
						_end_time: endTime,
						_timezone: timezone
					}
				},
				success: function(response) {
					$btn.prop('disabled', false).text('Create Meeting');
					if (response.success) {
						self.showToast('Zoom Meeting created successfully!', 'success');
						$('#ts-zoom-modal').fadeOut(200);
						// Reset form
						$('#ts-zoom-name, #ts-zoom-summary, #ts-zoom-start-date, #ts-zoom-start-time, #ts-zoom-end-date, #ts-zoom-end-time').val('');
						// Refresh curriculum
						var $card = $(`.ts-topic-card[data-topic-id="${topicId}"]`);
						$card.find('.ts-topic-items-list').append(self.createItemRow(response.data.item));
					} else {
						self.showToast(response.data.message || 'Error creating meeting', 'error');
					}
				},
				error: function() {
					$btn.prop('disabled', false).text('Create Meeting');
					self.showToast('Server error while creating meeting', 'error');
				}
			});
		},

		/**
		 * Add Item Action (Lesson/Quiz/Assignment)
		 */
		addItemAction: function(e) {
			var self = this;
			var type = $(e.currentTarget).data('type');
			var $card = $(e.currentTarget).closest('.ts-topic-card');
			var topicId = $card.data('topic-id');
			var topicTitle = $card.find('.ts-topic-display-title').text();
			
			if (type === 'lesson') {
				this.openLessonModal({ id: 0, title: '', content: '' }, topicTitle, topicId);
			} else if (type === 'quiz' && $('#ts-quiz-modal').length > 0) {
				var $modal = $('#ts-quiz-modal');
				$modal.attr('data-topic-id', topicId);
				$modal.data('item-id', 0);
				$modal.find('input, textarea').val('');
				$('#ts-quiz-modal-topic-title').text(topicTitle);
				$modal.fadeIn(200);
			} else if (type === 'assignment' && $('#ts-assignment-modal').length > 0) {
				var $modal = $('#ts-assignment-modal');
				$modal.attr('data-topic-id', topicId);
				$modal.data('item-id', 0);
				$modal.find('input, textarea').val('');
				$('#ts-assignment-modal-topic-title').text(topicTitle);
				$modal.fadeIn(200);
			} else {
				var title = prompt('Enter ' + type + ' title:');
				if (!title) return;
				this.saveItemAction(title, type, topicId, $card);
			}
		},

		/**
		 * Open Lesson Modal
		 */
		openLessonModal: function(lesson, topicTitle, topicId) {
			var $modal = $('#ts-lesson-modal');
			$('#ts-lesson-modal-topic-title').text(topicTitle);
			$modal.attr('data-topic-id', topicId);
			$modal.attr('data-item-id', lesson.id);
			
			$('#ts-lesson-title').val(lesson.title);
			$('#ts-lesson-content').val(lesson.content || '');

			// Meta Fields
			var meta = lesson.meta || {};
			
			// Duration
			var duration = parseInt(meta.duration) || 0;
			var h = Math.floor(duration / 3600);
			var m = Math.floor((duration % 3600) / 60);
			var s = duration % 60;
			$('#ts-lesson-time-hour').val(h);
			$('#ts-lesson-time-min').val(m);
			$('#ts-lesson-time-sec').val(s);
			
			// Preview
			$('#ts-lesson-preview').prop('checked', meta.preview == 1); // loose check for '1' or 1
			
			// Featured Image
			$('#ts-lesson-image-id').val(meta.featured_image || ''); 
			// Note: UI for image preview needs to be handled if reusing WP media uploader logic which is usually complex. 
			// For now, at least the ID is preserved.

			// Video
			$('#ts-lesson-video-url').val(meta.video_url || '');
			$('#ts-lesson-video-id').val(meta.video_id || ''); // Assuming we store video ID too
			$('#ts-lesson-video-type').val(meta.video_type || 'none');
			
			// Reset UI for Video
			this.updateLessonVideoUI(meta.video_type, meta.video_url);

			$modal.fadeIn(200);
		},

		openQuizModal: function(quiz, topicTitle, topicId) {
			var $modal = $('#ts-quiz-modal');
			$('#ts-quiz-modal-topic-title').text(topicTitle);
			$modal.attr('data-topic-id', topicId);
			$modal.attr('data-item-id', quiz.id);

			$('#ts-quiz-title').val(quiz.title);
			$('#ts-quiz-summary').val(quiz.content || '');

			var meta = quiz.meta || {};
			
			// Settings
			$('#ts-quiz-time-limit').val(meta.time_limit || 0);
			$('#ts-quiz-time-unit').val(meta.time_unit || 'minutes');
			$('#ts-quiz-hide-time').prop('checked', meta.hide_time == 1);
			$('#ts-quiz-feedback-mode').val(meta.feedback_mode || 'default');
			$('#ts-quiz-attempts').val(meta.attempts || 10);
			$('#ts-quiz-passing-grade').val(meta.passing_grade || 80);
			$('#ts-quiz-max-questions').val(meta.max_questions || 10);
			
			// Advanced
			$('#ts-quiz-auto-start').prop('checked', meta.auto_start == 1);
			$('#ts-quiz-question-layout').val(meta.question_layout || 'single');
			$('#ts-quiz-question-order').val(meta.question_order || 'random');
			$('#ts-quiz-hide-question-number').prop('checked', meta.hide_question_number == 1);
			$('#ts-quiz-short-answer-limit').val(meta.short_answer_limit || 200);
			$('#ts-quiz-essay-limit').val(meta.essay_limit || 500);

			$modal.fadeIn(200);
			this.loadQuizQuestions(quiz.id); // Load questions
		},

		openAssignmentModal: function(assignment, topicTitle, topicId) {
			var $modal = $('#ts-assignment-modal');
			$('#ts-assignment-modal-topic-title').text(topicTitle);
			$modal.attr('data-topic-id', topicId);
			$modal.attr('data-item-id', assignment.id);

			$('#ts-assignment-title').val(assignment.title);
			$('#ts-assignment-content').val(assignment.content || ''); // Note: Editor integration pending

			var meta = assignment.meta || {};

			// Settings
			$('#ts-assignment-time-limit').val(meta.time_limit || 0);
			$('#ts-assignment-time-unit').val(meta.time_unit || 'weeks');
			$('#ts-assignment-deadline-toggle').prop('checked', meta.deadline_toggle == 1);
			if (meta.deadline_toggle == 1) $('#ts-assignment-deadline-fields').show(); else $('#ts-assignment-deadline-fields').hide();
			$('#ts-assignment-deadline').val(meta.deadline || '');
			
			$('#ts-assignment-total-points').val(meta.total_points || 10);
			$('#ts-assignment-min-points').val(meta.min_points || 5);
			$('#ts-assignment-file-limit').val(meta.file_limit || 1);
			$('#ts-assignment-file-size').val(meta.file_size || 2);
			$('#ts-assignment-file-size-unit').val(meta.file_size_unit || 'mb');
			
			$('#ts-assignment-resubmission-toggle').prop('checked', meta.resubmission == 1);
			if (meta.resubmission == 1) $('#ts-assignment-resubmission-attempts-section').show(); else $('#ts-assignment-resubmission-attempts-section').hide();
			$('#ts-assignment-max-attempts').val(meta.max_attempts || 5);

			$modal.fadeIn(200);
		},

		/**
		 * Save Item Action (Legacy/Internal)
		 */
		saveItemAction: function(title, type, topicId, $card) {
			var self = this;
			var courseId = $('#course-id').val();
			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_save_item',
					nonce: tsLmsCourseEditor.nonce,
					course_id: courseId,
					topic_id: topicId,
					type: type,
					title: title
				},
				success: function(response) {
					if (response.success) {
						var $itemRow = self.createItemRow(response.data.item);
						$card.find('.ts-topic-items-list').append($itemRow);
						self.showToast(response.data.message, 'success');
						self.updateSummary();
						self.initSortable();
					} else {
						self.showToast(response.data.message || 'Error saving item', 'error');
					}
				}
			});
		},

		/**
		 * Save Lesson Modal
		 */
		saveLessonModal: function() {
			var self = this;
			var $modal = $('#ts-lesson-modal');
			var topicId = $modal.attr('data-topic-id');
			var itemId = $modal.attr('data-item-id');
			var courseId = $('#course-id').val();
			
			var title = $('#ts-lesson-title').val();
			var content = $('#ts-lesson-content').val();
			var imageId = $('#ts-lesson-image-id').val();
			var preview = $('#ts-lesson-preview').is(':checked') ? 1 : 0;
			
			// Duration Calculation
			var h = parseInt($('#ts-lesson-time-hour').val()) || 0;
			var m = parseInt($('#ts-lesson-time-min').val()) || 0;
			var s = parseInt($('#ts-lesson-time-sec').val()) || 0;
			var duration = (h * 3600) + (m * 60) + s;

			if (!title) {
				alert('Please enter a lesson title');
				return;
			}

			// Gather attachments if implemented
			var attachments = [];
			
			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_save_item',
					nonce: tsLmsCourseEditor.nonce,
					course_id: courseId,
					topic_id: topicId,
					item_id: itemId,
					type: 'lesson',
					title: title,
					content: content,
					featured_image: imageId,
					preview: preview,
					duration: duration,
					duration: duration,
					attachments: attachments,
					video_url: $('#ts-lesson-video-url').val(),
					video_type: $('#ts-lesson-video-type').val(),
					course_title: $('#course-title').val()
				},
				success: function(response) {
					if (response.success) {
						if (response.data.course_id) {
							$('#course-id').val(response.data.course_id);
							if (tsLmsCourseEditor.editUrl) {
								var newUrl = tsLmsCourseEditor.editUrl + '&course_id=' + response.data.course_id;
								window.history.replaceState(null, '', newUrl);
							}
						}
						if (!itemId || itemId == 0) {
							// New item
							var $card = $(`.ts-topic-card[data-topic-id="${topicId}"]`);
							var $itemRow = self.createItemRow(response.data.item);
							$card.find('.ts-topic-items-list').append($itemRow);
						} else {
							// Update existing row title
							$(`.ts-item-row[data-item-id="${itemId}"]`).find('.ts-item-title-input').val(title);
						}
						
						$modal.fadeOut(200);
						self.showToast(response.data.message, 'success');
						self.updateSummary();
					} else {
						self.showToast(response.data.message || 'Error saving lesson', 'error');
					}
				},
				error: function() {
					self.showToast('Server error while saving lesson', 'error');
				}
			});
		},

		saveQuizModal: function() {
			var self = this;
			var $modal = $('#ts-quiz-modal');
			var topicId = $modal.attr('data-topic-id');
			var itemId = $modal.attr('data-item-id');
			var courseId = $('#course-id').val();
			
			var title = $('#ts-quiz-title').val();
			var content = $('#ts-quiz-summary').val(); // Using summary textarea as content
			
			if (!title) { self.showToast('Please enter a quiz title', 'error'); return; }

			var data = {
				action: 'ts_lms_save_item',
				nonce: tsLmsCourseEditor.nonce,
				course_id: courseId,
				topic_id: topicId,
				item_id: itemId,
				type: 'quiz',
				title: title,
				content: content,
				time_limit: $('#ts-quiz-time-limit').val(),
				time_unit: $('#ts-quiz-time-unit').val(),
				hide_time: $('#ts-quiz-hide-time').is(':checked') ? 1 : 0,
				feedback_mode: $('#ts-quiz-feedback-mode').val(),
				attempts: $('#ts-quiz-attempts').val(),
				passing_grade: $('#ts-quiz-passing-grade').val(),
				max_questions: $('#ts-quiz-max-questions').val(),
				auto_start: $('#ts-quiz-auto-start').is(':checked') ? 1 : 0,
				question_layout: $('#ts-quiz-question-layout').val(),
				question_order: $('#ts-quiz-question-order').val(),
				hide_question_number: $('#ts-quiz-hide-question-number').is(':checked') ? 1 : 0,
				short_answer_limit: $('#ts-quiz-short-answer-limit').val(),
				essay_limit: $('#ts-quiz-essay-limit').val(),
				course_title: $('#course-title').val()
			};

			this.performSaveItem(data, $modal);
		},

		saveAssignmentModal: function() {
			var self = this;
			var $modal = $('#ts-assignment-modal');
			var topicId = $modal.attr('data-topic-id');
			var itemId = $modal.attr('data-item-id');
			var courseId = $('#course-id').val();
			
			var title = $('#ts-assignment-title').val();
			var content = $('#ts-assignment-content').val();
			
			if (!title) { self.showToast('Please enter an assignment title', 'error'); return; }

			var data = {
				action: 'ts_lms_save_item',
				nonce: tsLmsCourseEditor.nonce,
				course_id: courseId,
				topic_id: topicId,
				item_id: itemId,
				type: 'assignment',
				title: title,
				content: content,
				time_limit: $('#ts-assignment-time-limit').val(),
				time_unit: $('#ts-assignment-time-unit').val(),
				deadline_toggle: $('#ts-assignment-deadline-toggle').is(':checked') ? 1 : 0,
				deadline: $('#ts-assignment-deadline').val(),
				total_points: $('#ts-assignment-total-points').val(),
				min_points: $('#ts-assignment-min-points').val(),
				file_limit: $('#ts-assignment-file-limit').val(),
				file_size: $('#ts-assignment-file-size').val(),
				file_size_unit: $('#ts-assignment-file-size-unit').val(),
				resubmission: $('#ts-assignment-resubmission-toggle').is(':checked') ? 1 : 0,
				max_attempts: $('#ts-assignment-max-attempts').val(),
				course_title: $('#course-title').val()
			};

			this.performSaveItem(data, $modal);
		},

		performSaveItem: function(data, $modal) {
			var self = this;
			var $btn = $modal.find('button[class*="-btn-save"], button[class*="-btn-ok"]');
			$btn.prop('disabled', true).text('Saving...');

			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: data,
				success: function(response) {
					$btn.prop('disabled', false).text(data.type === 'quiz' ? 'Ok' : 'Save Assignment');
					
					if (response.success) {
						if (response.data.course_id) {
							$('#course-id').val(response.data.course_id);
							if (tsLmsCourseEditor.editUrl) {
								var newUrl = tsLmsCourseEditor.editUrl + '&course_id=' + response.data.course_id;
								window.history.replaceState(null, '', newUrl);
							}
						}
						var itemId = data.item_id;
						if (!itemId || itemId == 0) {
							// New item
							var $card = $(`.ts-topic-card[data-topic-id="${data.topic_id}"]`);
							var $itemRow = self.createItemRow(response.data.item);
							$card.find('.ts-topic-items-list').append($itemRow);
						} else {
							// Update existing row title
							$(`.ts-item-row[data-item-id="${itemId}"]`).find('.ts-item-title-input').val(data.title);
						}
						
						$modal.fadeOut(200);
						self.showToast(response.data.message, 'success');
						self.updateSummary();

						// Save Quiz Questions if it's a quiz
						if (data.type === 'quiz') {
							self.saveQuizQuestions(response.data.item_id);
						}
					} else {
						self.showToast(response.data.message || 'Error saving item', 'error');
					}
				},
				error: function() {
					$btn.prop('disabled', false).text(data.type === 'quiz' ? 'Ok' : 'Save Assignment');
					self.showToast('Server error while saving item', 'error');
				}
			});
		},


		/**
		 * Delete Item
		 */
		deleteItemAction: function(e) {
			if (!confirm('Are you sure you want to delete this item?')) return;
			var self = this;
			var $row = $(e.currentTarget).closest('.ts-item-row');
			var itemId = $row.data('item-id');

			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_delete_item',
					nonce: tsLmsCourseEditor.nonce,
					item_id: itemId
				},
				success: function(response) {
					if (response.success) {
						$row.remove();
						self.updateSummary();
					}
				}
			});
		},

		/**
		 * Edit Item Action
		 */
		editItemAction: function(e) {
			var self = this;
			var $row = $(e.currentTarget).closest('.ts-item-row');
			var type = $row.data('type');
			var itemId = $row.data('item-id');
			var title = $row.find('.ts-item-title-input').val();

			// Open corresponding modal
			if (type === 'lesson') {
				var topicTitle = $row.closest('.ts-topic-card').find('.ts-topic-display-title').text();
				var topicId = $row.closest('.ts-topic-card').data('topic-id');
				
				// Fetch full content
				$.ajax({
					url: tsLmsCourseEditor.ajaxUrl,
					type: 'GET',
					data: {
						action: 'ts_lms_get_item',
						nonce: tsLmsCourseEditor.nonce,
						item_id: itemId,
						type: 'lesson'
					},
					success: function(response) {
						if (response.success) {
							if (type === 'lesson') {
								self.openLessonModal(response.data.item, topicTitle, topicId);
							} else if (type === 'quiz') {
								self.openQuizModal(response.data.item, topicTitle, topicId);
							} else if (type === 'assignment') {
								self.openAssignmentModal(response.data.item, topicTitle, topicId);
							}
						} else {
							self.showToast('Error fetching item details', 'error');
						}
					},
					error: function() {
						self.showToast('Error fetching item details', 'error');
					}
				});
				
			} else {
				// Should not happen theoretically
			}
		},

		/**
		 * Init Sortable
		 */
		initSortable: function() {
			var self = this;
			
			$("#ts-topics-list").sortable({
				handle: ".ts-topic-drag-handle",
				placeholder: "ts-sortable-placeholder ts-topic-card",
				update: function() { self.saveOrder(); }
			});

			$(".ts-topic-items-list").sortable({
				connectWith: ".ts-topic-items-list",
				handle: ".ts-topic-drag-handle",
				placeholder: "ts-sortable-placeholder ts-item-row",
				update: function() { self.saveOrder(); }
			});
		},

		/**
		 * Save Order
		 */
		saveOrder: function() {
			var data = [];
			$(".ts-topic-card").each(function() {
				var topicId = $(this).data('topic-id');
				if (!topicId) return;

				var items = [];
				$(this).find(".ts-item-row").each(function() {
					items.push({ id: $(this).data('item-id') });
				});
				data.push({ id: topicId, items: items });
			});

			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_sort_curriculum',
					nonce: tsLmsCourseEditor.nonce,
					data: data
				}
			});
			this.updateSummary();
		},

		/**
		 * Update Summary Stats
		 */
		updateSummary: function() {
			$("#ts-total-lessons").text($(".ts-item-row[data-type='lesson']").length);
			$("#ts-total-quizzes").text($(".ts-item-row[data-type='quiz']").length);
			$("#ts-total-assignments").text($(".ts-item-row[data-type='assignment']").length);
		},

		/* --- Basics & Sidebar Logic --- */

		handleStepClick: function (e) {
			var $step = $(e.currentTarget);
			var stepNumber = $step.data('step');
			$('.ts-step').removeClass('ts-step-active');
			$step.addClass('ts-step-active');
			$('.ts-step-content').removeClass('ts-step-content-active');
			$('.ts-step-content[data-step="' + stepNumber + '"]').addClass('ts-step-content-active');
			this.currentStep = stepNumber;
			window.scrollTo(0,0);
		},

		initSidebar: function () {
			var self = this;
			$('input[name="pricing_model"]').on('change', function () {
				var val = $(this).val();
				$('#ts-product-selection').toggle(val === 'paid');
				$('#ts-subscription-settings').toggle(val === 'subscription');
			});
			
			// Trigger initial state
			$('input[name="pricing_model"]:checked').trigger('change');

			$('#ts-intro-video-source').on('change', function () {
				var source = $(this).val();
				$('.ts-intro-video-url').toggle(source !== 'upload');
				$('.ts-btn-upload-video-sm').toggle(source === 'upload');
			});
			
			$('.ts-author-dropdown').on('change', function () {
				var $option = $(this).find('option:selected');
				var name = $option.text();
				var email = $option.data('email');
				var avatar = $option.data('avatar');
				
				var $display = $(this).closest('.ts-author-select-box').find('.ts-author-display');
				$display.find('.ts-author-name').text(name);
				$display.find('.ts-author-email').text(email);
				$display.find('.ts-author-avatar img').attr('src', avatar);
			});
		},

		initSlugGeneration: function () {
			var self = this;
			$('#course-title').on('input', function () {
				var slug = $(this).val().toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').trim();
				$('#course-slug').val(slug);
			});
		},

		saveDraft: function(e) { e.preventDefault(); this.saveCourse('draft', $(e.currentTarget)); },
		publishCourse: function(e) { e.preventDefault(); this.saveCourse('publish', $(e.currentTarget)); },

		saveCourse: function(status, $btn) {
			var self = this;
			
			if ($btn) $btn.addClass('ts-btn-loading');
			
			// Collect Data
			var data = {
				action: 'ts_lms_save_course',
				nonce: tsLmsCourseEditor.nonce,
				course_id: $('#course-id').val(),
				title: $('#course-title').val(),
				slug: $('#course-slug').val(),
				description: typeof tinyMCE !== 'undefined' && tinyMCE.get('course_description') ? tinyMCE.get('course_description').getContent() : $('#course_description').val(),
				status: status, // 'publish' or 'draft'
				
				// Sidebar / Basics
				difficulty_level: $('select[name="difficulty_level"]').val(),
				public_course: $('input[name="public_course"]').is(':checked') ? 1 : 0,
				qa_enabled: $('input[name="qa_enabled"]').is(':checked') ? 1 : 0,
				content_drip_type: $('input[name="content_drip_type"]:checked').val(),
				
				// Enrollment
				max_students: $('input[name="max_students"]').val(),
				enrollment_period_enabled: $('input[name="enrollment_period_enabled"]').is(':checked') ? 1 : 0,
				pause_enrollment: $('input[name="pause_enrollment"]').is(':checked') ? 1 : 0,
				
				// Sidebar settings
				post_status: $('select[name="post_status"]').val(), // Visibility
				is_scheduled: $('input[name="is_scheduled"]').is(':checked') ? 1 : 0,
				thumbnail_id: $('#_thumbnail_id').val(),
				
				// Intro Video
				video_source: $('#ts-course-video-source').val() || 'external',
				video_url: $('#ts-course-video-url').val(), 
				
				// Pricing
				pricing_model: $('input[name="pricing_model"]:checked').val(),
				course_product: $('#course-product-select').val(),
				
				// Subscription
				subscription_plan_type: $('#subscription-plan-type').val(),
				subscription_price: $('#subscription-price').val(),
				subscription_scope: $('input[name="subscription_scope"]:checked').val(),
				
				// Taxonomies
				categories: [],
				tags: [],
				post_author: $('select[name="post_author"]').val(),
				
				// Additional Step
				what_will_learn: $('#course-what-will-learn').val(),
				target_audience: $('#course-target-audience').val(),
				total_duration_hours: $('#course-total-duration-hours').val(),
				total_duration_minutes: $('#course-total-duration-minutes').val(),
				materials_included: $('#course-materials-included').val(),
				requirements_instructions: $('#course-requirements-instructions').val(),
				selected_certificate: $('#course-selected-certificate').val(),
				custom_certificate_id: $('#custom-certificate-id').val(),
				attachments: $('#course-attachments-ids').val() ? $('#course-attachments-ids').val().split(',') : [],
				prerequisites: $('#course-prerequisites-ids').val() ? $('#course-prerequisites-ids').val().split(',') : []
			};
			
			// Collect Checkbox Categories
			$('input[name="tax_input[ts_course_category][]"]:checked').each(function() {
				data.categories.push($(this).val());
			});
			
			// Collect Checkbox Tags
			$('input[name="tax_input[ts_course_tag][]"]:checked').each(function() {
				data.tags.push($(this).val());
			});

			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: data,
				success: function(r) { 
					if ($btn) $btn.removeClass('ts-btn-loading');
					if(r.success) {
						self.showToast('Course saved successfully!', 'success');
						// Update URL if new course created
						if (r.data.edit_url && window.location.href !== r.data.edit_url) {
							window.history.pushState(null, '', r.data.edit_url);
							$('#course-id').val(r.data.course_id);
						}
					} else {
						self.showToast(r.data.message || 'Error saving course', 'error');
					}
				},
				error: function() {
					if ($btn) $btn.removeClass('ts-btn-loading');
					self.showToast('Server error', 'error');
				}
			});
		},

		trackChanges: function() {
			var self = this;
			$(document).on('change input', 'input, textarea, select', function() { self.hasUnsavedChanges = true; });
		},

		warnBeforeLeave: function(e) {
			if (this.hasUnsavedChanges) return "You have unsaved changes.";
		},

		showToast: function(msg, type) {
			var $toast = $('#ts-toast');
			if (!$toast.length) {
				$toast = $('<div id="ts-toast"></div>').appendTo('body');
			}
			$toast.text(msg).attr('class', 'ts-toast ' + type).fadeIn(300).delay(2000).fadeOut(300);
		},

		/**
		 * Show API Warning Modal
		 */
		showApiWarning: function(apiType, settingsUrl) {
			var apiName = apiType === 'zoom' ? 'Zoom' : 'Google Meet';
			
			// Remove existing warning modal if any
			$('#ts-api-warning-modal').remove();
			
			// Create warning modal HTML
			var modalHtml = `
				<div id="ts-api-warning-modal" class="ts-api-warning-modal" style="
					position: fixed;
					top: 0;
					left: 0;
					right: 0;
					bottom: 0;
					background: rgba(0, 0, 0, 0.5);
					display: flex;
					align-items: center;
					justify-content: center;
					z-index: 999999;
				">
					<div class="ts-api-warning-content" style="
						background: white;
						border-radius: 12px;
						padding: 32px;
						max-width: 480px;
						box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
						text-align: center;
					">
						<div style="
							width: 64px;
							height: 64px;
							background: #FEE2E2;
							border-radius: 50%;
							display: flex;
							align-items: center;
							justify-content: center;
							margin: 0 auto 20px;
						">
							<span class="dashicons dashicons-warning" style="
								font-size: 32px;
								width: 32px;
								height: 32px;
								color: #DC2626;
							"></span>
						</div>
						<h3 style="
							margin: 0 0 12px;
							font-size: 20px;
							font-weight: 700;
							color: #1F2937;
						">API Not Configured</h3>
						<p style="
							margin: 0 0 24px;
							font-size: 14px;
							line-height: 1.6;
							color: #DC2626;
							font-weight: 600;
						">${apiName} API credentials are not configured. Please set up your ${apiName} API credentials in the settings first.</p>
						<div style="display: flex; gap: 12px; justify-content: center;">
							<button class="ts-api-warning-cancel" style="
								padding: 10px 20px;
								border: 1px solid #D1D5DB;
								background: white;
								color: #374151;
								border-radius: 8px;
								font-size: 14px;
								font-weight: 600;
								cursor: pointer;
								transition: all 0.2s;
							">Cancel</button>
							<button class="ts-api-warning-settings" style="
								padding: 10px 20px;
								border: none;
								background: linear-gradient(135deg, #DC2626 0%, #B91C1C 100%);
								color: white;
								border-radius: 8px;
								font-size: 14px;
								font-weight: 600;
								cursor: pointer;
								transition: all 0.2s;
								box-shadow: 0 4px 12px rgba(220, 38, 38, 0.25);
							">Go to Settings</button>
						</div>
					</div>
				</div>
			`;
			
			$('body').append(modalHtml);
			
			// Bind events
			$('#ts-api-warning-modal .ts-api-warning-cancel, #ts-api-warning-modal').on('click', function(e) {
				if (e.target === this) {
					$('#ts-api-warning-modal').fadeOut(200, function() {
						$(this).remove();
					});
				}
			});
			
			$('#ts-api-warning-modal .ts-api-warning-content').on('click', function(e) {
				e.stopPropagation();
			});
			
			$('#ts-api-warning-modal .ts-api-warning-settings').on('click', function() {
				window.open(settingsUrl, '_blank');
				$('#ts-api-warning-modal').fadeOut(200, function() {
					$(this).remove();
				});
			});
			
			// Add hover effects
			$('#ts-api-warning-modal .ts-api-warning-cancel').hover(
				function() { $(this).css({'background': '#F3F4F6', 'border-color': '#9CA3AF'}); },
				function() { $(this).css({'background': 'white', 'border-color': '#D1D5DB'}); }
			);
			
			$('#ts-api-warning-modal .ts-api-warning-settings').hover(
				function() { $(this).css({'transform': 'translateY(-2px)', 'box-shadow': '0 8px 20px rgba(220, 38, 38, 0.35)'}); },
				function() { $(this).css({'transform': 'translateY(0)', 'box-shadow': '0 4px 12px rgba(220, 38, 38, 0.25)'}); }
			);
		},

		/**
		 * Open Media Uploader
		 */
		openMediaUploader: function(e) {
			e.preventDefault();
			var self = this;

			if (this.imageFrame) {
				this.imageFrame.open();
				return;
			}

			this.imageFrame = wp.media({
				title: 'Select Featured Image',
				button: { text: 'Use this image' },
				multiple: false
			});

			this.imageFrame.on('select', function() {
				var attachment = self.imageFrame.state().get('selection').first().toJSON();
				self.setLessonImage(attachment);
			});

			this.imageFrame.open();
		},

		/**
		 * Set Lesson Image
		 */
		setLessonImage: function(attachment) {
			$('#ts-lesson-image-id').val(attachment.id);
			
			var html = `
				<div class="ts-preview-image-container">
					<img src="${attachment.url}" alt="" style="max-width:100%; height:auto; border-radius:4px;">
					<button type="button" id="ts-lesson-remove-image" class="ts-remove-image-btn" style="position:absolute; top:5px; right:5px; background:#fff; border:none; border-radius:50%; cursor:pointer; width:20px; height:20px; display:flex; align-items:center; justify-content:center;">&times;</button>
				</div>
			`;
			
			$('#ts-lesson-image-upload .ts-lesson-upload-placeholder').hide();
			// Remove existing preview if any
			$('#ts-lesson-image-upload .ts-preview-image-container').remove();
			$('#ts-lesson-image-upload').append(html);
		},

		/**
		 * Remove Lesson Image
		 */
		 removeLessonImage: function(e) {
			e.preventDefault();
			$('#ts-lesson-image-id').val('');
			$('#ts-lesson-image-upload .ts-preview-image-container').remove();
			$('#ts-lesson-image-upload .ts-lesson-upload-placeholder').show();
		},

		/**
		 * Open Lesson Video Uploader
		 */
		openLessonVideoUploader: function(e) {
			e.preventDefault();
			var self = this;

			if (this.videoFrame) {
				this.videoFrame.open();
				return;
			}

			this.videoFrame = wp.media({
				title: 'Select Lesson Video',
				button: { text: 'Use this video' },
				library: { type: 'video' },
				multiple: false
			});

			this.videoFrame.on('select', function() {
				var attachment = self.videoFrame.state().get('selection').first().toJSON();
				self.setLessonVideo(attachment.url, 'html5', attachment.id);
			});

			this.videoFrame.open();
		},

		/**
		 * Add Lesson Video via URL (Toggle Input)
		 */
		addLessonVideoUrl: function(e) {
			e.preventDefault();
			var $container = $('#ts-video-url-input-container');
			$container.slideToggle(200);
			if ($container.is(':visible')) {
				$('#ts-video-url-input').focus();
			}
		},

		/**
		 * Confirm Video URL Input
		 */
		confirmLessonVideoUrl: function(e) {
			e.preventDefault();
			var url = $('#ts-video-url-input').val().trim();
			
			if (url) {
                // Check for YouTube
                var youtubeMatch = url.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
                
                if (youtubeMatch && youtubeMatch[1]) {
                    this.setLessonVideo(url, 'youtube', youtubeMatch[1]);
                } else {
                    this.setLessonVideo(url, 'url');
                }
				$('#ts-video-url-input').val(''); // Clear input
				$('#ts-video-url-input-container').hide(); // Hide container
			} else {
				this.showToast('Please enter a valid URL', 'error');
			}
		},

		/**
		 * Set Lesson Video Data
		 */
		setLessonVideo: function(url, type, id) {
			$('#ts-lesson-video-url').val(url);
			$('#ts-lesson-video-type').val(type);
			$('#ts-lesson-video-id').val(id || '');
			
			this.updateLessonVideoUI(type, url, id);
		},

		/**
		 * Update Lesson Video UI
		 */
		updateLessonVideoUI: function(type, url, id) {
			var $wrapper = $('#ts-lesson-video-wrapper');
			$wrapper.find('.ts-video-preview, .ts-video-remove-btn').remove();
			
			if (type && type !== 'none' && url) {
				$wrapper.find('.ts-video-upload-placeholder').hide();
				
				var previewHtml = '<div class="ts-video-preview" style="position:relative; margin-top:10px;">';
				if (type === 'html5') {
					previewHtml += '<video src="' + url + '" controls style="width:100%; max-height:200px; background:#000; border-radius:4px;"></video>';
				} else if (type === 'youtube' && id) {
                     // YouTube Thumbnail
                     var thumbUrl = 'https://img.youtube.com/vi/' + id + '/hqdefault.jpg';
                     previewHtml += '<div style="background:#f1f5f9; padding:0; border-radius:4px; overflow:hidden; position:relative;">';
                     previewHtml += '<img src="' + thumbUrl + '" style="width:100%; height:auto; display:block;">';
                     previewHtml += '<div style="position:absolute; bottom:0; left:0; right:0; background:rgba(0,0,0,0.7); color:white; padding:5px 10px; font-size:12px; display:flex; align-items:center; gap:5px;"><span class="dashicons dashicons-video-alt3"></span> YouTube Video</div>';
                     previewHtml += '</div>';
                } else {
					// External URL
					previewHtml += '<div style="background:#f1f5f9; padding:10px; border-radius:4px; text-align:center;"><span class="dashicons dashicons-video-alt3" style="font-size:24px; width:24px; height:24px; color:#64748b;"></span> <p style="margin:5px 0 0; word-break:break-all; font-size:12px; color:#334155;">' + url + '</p></div>';
				}
				
				previewHtml += '<button type="button" class="ts-video-remove-btn" style="position:absolute; top:-10px; right:-10px; background:#ef4444; color:white; border:none; border-radius:50%; width:24px; height:24px; cursor:pointer; display:flex; align-items:center; justify-content:center; box-shadow:0 2px 4px rgba(0,0,0,0.1);">&times;</button>';
				previewHtml += '</div>';
				
				$wrapper.append(previewHtml);
				
				// Bind remove button
				$wrapper.find('.ts-video-remove-btn').on('click', function() {
					$('#ts-lesson-video-url').val('');
					$('#ts-lesson-video-type').val('none');
					$('#ts-lesson-video-id').val('');
					$(this).parent().remove();
					$wrapper.find('.ts-video-upload-placeholder').show();
				});
			} else {
				$wrapper.find('.ts-video-upload-placeholder').show();
			}
		},



	/**
	 * Load Quiz Questions
	 */
	loadQuizQuestions: function(quizId) {
		var self = this;
		$('#ts-quiz-questions-list').html('<p class="ts-loading-text">Loading questions...</p>');
		
		$.ajax({
			url: tsLmsCourseEditor.ajaxUrl,
			type: 'GET',
			data: {
				action: 'ts_lms_get_questions',
				nonce: tsLmsCourseEditor.nonce,
				quiz_id: quizId
			},
			success: function(response) {
				$('#ts-quiz-questions-list').empty();
				
				if (response.success && response.data.questions.length > 0) {
					$('.ts-empty-questions-state').hide();
					response.data.questions.forEach(function(q) {
						self.renderQuestionItem(q);
					});
				} else {
					$('.ts-empty-questions-state').show();
				}
			}
		});
	},

	/**
	 * Render Question Item
	 */
	renderQuestionItem: function(q) {
		var html = `
			<div class="ts-question-item" data-id="${q.id}">
				<div class="ts-question-content" style="flex:1;">
					<input type="text" class="ts-question-title-input" value="${q.title}" placeholder="Enter question title..." style="width:100%; border:1px solid #ddd; padding:8px; border-radius:4px; margin-bottom:8px;">
					<div style="display:flex; gap:10px;">
						<select class="ts-question-type-select" style="padding:6px; border:1px solid #ddd; border-radius:4px;">
							<option value="single_choice" ${q.type == 'single_choice' ? 'selected' : ''}>Single Choice</option>
							<option value="multiple_choice" ${q.type == 'multiple_choice' ? 'selected' : ''}>Multiple Choice</option>
							<option value="true_false" ${q.type == 'true_false' ? 'selected' : ''}>True/False</option>
							<option value="short_answer" ${q.type == 'short_answer' ? 'selected' : ''}>Short Answer</option>
						</select>
						<input type="number" class="ts-question-score" value="${q.points}" min="0" placeholder="Points" style="width:60px; padding:6px; border:1px solid #ddd; border-radius:4px;">
					</div>
				</div>
				<div class="ts-question-actions" style="margin-left:16px;">
					<button type="button" class="ts-question-delete" style="background:none; border:none; cursor:pointer; color:#d63638;"><span class="dashicons dashicons-trash"></span></button>
				</div>
			</div>
		`;
		
		$('#ts-quiz-questions-list').append(html);
		
		// Bind delete
		$('#ts-quiz-questions-list').find('.ts-question-item[data-id="' + q.id + '"] .ts-question-delete').on('click', function() {
			var $item = $(this).closest('.ts-question-item');
			var qId = $item.data('id');
			
			if (confirm('Delete this question?')) {
				$.ajax({
					url: tsLmsCourseEditor.ajaxUrl,
					type: 'POST',
					data: {
						action: 'ts_lms_delete_question',
						nonce: tsLmsCourseEditor.nonce,
						question_id: qId
					},
					success: function() {
						$item.remove();
						if ($('#ts-quiz-questions-list .ts-question-item').length === 0) {
							$('.ts-empty-questions-state').show();
						}
					}
				});
			}
		});
	},

	/**
	 * Save Questions Loop
	 */
	saveQuizQuestions: function(quizId) {
		var self = this;
		
		$('.ts-question-item').each(function() {
			var $item = $(this);
			var qId = $item.data('id');
			var title = $item.find('.ts-question-title-input').val();
			var type = $item.find('.ts-question-type-select').val();
			var points = $item.find('.ts-question-score').val();
			
			// Check if it's a temp ID (new question)
			var isNew = qId.toString().startsWith('q-');
			
			$.ajax({
				url: tsLmsCourseEditor.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_save_question',
					nonce: tsLmsCourseEditor.nonce,
					quiz_id: quizId,
					question_id: isNew ? 0 : qId,
					title: title,
					type: type,
					points: points
				}
			});
		});
	},

	/**
	 * Add Question UI (Updated)
	 */
	addQuestionUI: function(e) {
		if (e) e.preventDefault();
		$('.ts-empty-questions-state').hide();
		var tempQ = {
			id: 'q-' + Date.now(),
			title: '',
			type: 'single_choice',
			points: 1
		};
		this.renderQuestionItem(tempQ);
	},
	// ... (Previous code)

	/**
	 * Rich Text Editor Logic
	 */
	bindEditorEvents: function() {
		var self = this;
		
		// Toolbar Buttons (Lesson & Assignment)
		$(document).on('click', '.ts-assignment-editor-tool-btn, .ts-editor-tool-btn', function(e) {
			e.preventDefault();
			var action = $(this).data('action');
			
			// Determine which textarea to target
			var textarea;
			if ($(this).closest('#ts-lesson-modal').length > 0) {
				textarea = document.getElementById('ts-lesson-content');
			} else {
				textarea = document.getElementById('ts-assignment-content');
			}
			
			if (!textarea) return;
			
			self.formatText(textarea, action);
		});
		
		// Format Select
		$(document).on('change', '.ts-assignment-editor-format-select, .ts-editor-format-select', function(e) {
			var format = $(this).val();
			var textarea;
			if ($(this).closest('#ts-lesson-modal').length > 0) {
				textarea = document.getElementById('ts-lesson-content');
			} else {
				textarea = document.getElementById('ts-assignment-content');
			}

			self.formatText(textarea, 'formatBlock', format);
			$(this).val('paragraph'); // Reset
		});
		
		// Add Media
		$(document).on('click', '.ts-assignment-editor-btn[data-action="add-media"], .ts-editor-btn[data-action="add-media"]', function(e) {
			e.preventDefault();
			var isLesson = $(this).closest('#ts-lesson-modal').length > 0;
			self.openMediaUploaderForEditor(isLesson);
		});
	},

	openMediaUploaderForEditor: function(isLesson) {
		var self = this;
		
		// Create a separate frame for editor if needed or reuse
		// Since we need to know target, let's just create one or update handler context
		// Simplest: just store current target on self
		self.currentEditorTarget = isLesson ? 'lesson' : 'assignment';

		if (this.editorMediaFrame) {
			this.editorMediaFrame.open();
			return;
		}
		
		this.editorMediaFrame = wp.media({
			title: 'Add Media',
			button: { text: 'Insert into post' },
			multiple: false
		});
		
		this.editorMediaFrame.on('select', function() {
			var attachment = self.editorMediaFrame.state().get('selection').first().toJSON();
			var html = '';
			if (attachment.type === 'image') {
				html = '<img src="' + attachment.url + '" alt="' + attachment.alt + '" />';
			} else {
				html = '<a href="' + attachment.url + '">' + attachment.title + '</a>';
			}
			
			var textareaId = self.currentEditorTarget === 'lesson' ? 'ts-lesson-content' : 'ts-assignment-content';
			var textarea = document.getElementById(textareaId);
			self.insertAtCursor(textarea, html);
		});
		
		this.editorMediaFrame.open();
	},

	formatText: function(textarea, action, value) {
		var start = textarea.selectionStart;
		var end = textarea.selectionEnd;
		var text = textarea.value;
		var selectedText = text.substring(start, end);
		var replacement = '';
		
		switch(action) {
			case 'bold': replacement = '<strong>' + selectedText + '</strong>'; break;
			case 'italic': replacement = '<em>' + selectedText + '</em>'; break;
			case 'underline': replacement = '<u>' + selectedText + '</u>'; break;
			case 'alignleft': replacement = '<div style="text-align:left">' + selectedText + '</div>'; break;
			case 'aligncenter': replacement = '<div style="text-align:center">' + selectedText + '</div>'; break;
			case 'alignright': replacement = '<div style="text-align:right">' + selectedText + '</div>'; break;
			case 'ul': replacement = '<ul>\n<li>' + selectedText + '</li>\n</ul>'; break;
			case 'ol': replacement = '<ol>\n<li>' + selectedText + '</li>\n</ol>'; break;
			case 'quote': replacement = '<blockquote>' + selectedText + '</blockquote>'; break;
			case 'code': replacement = '<code>' + selectedText + '</code>'; break;
			case 'link': 
				var url = prompt('Enter URL:', 'http://');
				if (url) replacement = '<a href="' + url + '">' + selectedText + '</a>';
				else replacement = selectedText;
				break;
			case 'unlink': 
				// Simple strip tags would be complex here, just replacing text back
				replacement = selectedText; 
				break;
			case 'table':
				replacement = '<table border="1"><tr><td>Cell 1</td><td>Cell 2</td></tr></table>';
				break;
			case 'removeformat':
				// Strip tags? Too complex for regex on selection only safely
				replacement = selectedText; 
				break;
			case 'formatBlock':
				if (value === 'heading1') replacement = '<h1>' + selectedText + '</h1>';
				if (value === 'heading2') replacement = '<h2>' + selectedText + '</h2>';
				if (value === 'paragraph') replacement = '<p>' + selectedText + '</p>';
				break;
		}
		
		if (replacement) {
			textarea.value = text.substring(0, start) + replacement + text.substring(end);
			// Restore selection (optional)
		}
	},
	
	insertAtCursor: function(textarea, myValue) {
		if (document.selection) {
			textarea.focus();
			sel = document.selection.createRange();
			sel.text = myValue;
		} else if (textarea.selectionStart || textarea.selectionStart == '0') {
			var startPos = textarea.selectionStart;
			var endPos = textarea.selectionEnd;
			textarea.value = textarea.value.substring(0, startPos) + myValue + textarea.value.substring(endPos, textarea.value.length);
		} else {
			textarea.value += myValue;
		}
	},

	/**
	 * Open Attachment Uploader
	 */
	openAttachmentUploader: function(e) {
		e.preventDefault();
		var self = this;
		var $btn = $(e.currentTarget);
		var targetIdField = $btn.next('input[type="hidden"]');
		
		// Determine context (Lesson or Assignment)
		var isLesson = $btn.attr('id') === 'ts-lesson-upload-attachment';
		var contextText = isLesson ? 'Lesson Attachment' : 'Assignment Attachment';

		var attachmentFrame = wp.media({
			title: 'Upload ' + contextText,
			button: {
				text: 'Use this file'
			},
			library: {
				// Don't restrict type too much, or allow generic files
			},
			multiple: false // or true if we want multiple? For now single.
		});

		attachmentFrame.on('select', function() {
			var attachment = attachmentFrame.state().get('selection').first().toJSON();
			
			// Update hidden field
			targetIdField.val(attachment.id);
			
			// Improve UI to show selected file
			$btn.html('<span class="dashicons dashicons-yes"></span> ' + attachment.filename);
			$btn.addClass('ts-file-selected');
			
			// Optional: Store full attachment object or URL if needed in another field?
			// For now, ID is enough for backend to handle.
		});

		attachmentFrame.open();
	},

	showToast: function(message, type) {
		var $toast = $('#ts-toast');
		if (!$toast.length) return;
		
		$toast.text(message)
			.removeClass('success error')
			.addClass(type)
			.fadeIn(300)
			.delay(3000)
			.fadeOut(300);
	}

	};

	$(document).ready(function () {
		CourseEditor.init();
		CourseEditor.bindEditorEvents();
		
		// Bind Attachment Uploader
		$(document).on('click', '#ts-lesson-upload-attachment, #ts-assignment-upload-attachment', function(e) {
			CourseEditor.openAttachmentUploader(e);
		});
	});

	window.CourseEditor = CourseEditor;
})(jQuery);
