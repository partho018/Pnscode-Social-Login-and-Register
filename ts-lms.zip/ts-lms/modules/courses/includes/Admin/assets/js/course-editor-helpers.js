/**
 * Course Editor Helper Functions
 * 
 * @package TS_LMS
 * @version 1.0.0
 */

(function ($) {
	'use strict';

	// Extend CourseEditor with missing functions
	if (typeof window.CourseEditor !== 'undefined') {
		$.extend(window.CourseEditor, {
			/**
			 * Track Changes for Unsaved Warning
			 */
			trackChanges: function() {
				var self = this;
				$(document).on('input change', 'input, textarea, select', function() {
					self.hasUnsavedChanges = true;
				});
			},

			/**
			 * Initialize Sidebar Interactions
			 */
			initSidebar: function() {
				var self = this;
				
				// Pricing Model Toggle
				$(document).on('change', 'input[name="pricing_model"]', function() {
					var selectedModel = $(this).val();
					$('.ts-pricing-settings-panel').hide();
					
					if (selectedModel === 'paid') {
						$('#ts-product-selection').slideDown(200);
					} else if (selectedModel === 'subscription') {
						$('#ts-product-selection').show();
						$('#ts-subscription-settings').slideDown(200);
					}
				});

				// Featured Image Upload
				$(document).on('click', '#ts-featured-image-upload .ts-upload-btn', function(e) {
					e.preventDefault();
					self.openFeaturedImageUploader();
				});

				// Remove Featured Image
				$(document).on('click', '#ts-featured-image-upload .ts-remove-image', function(e) {
					e.preventDefault();
					$('#ts-featured-image-upload').html(
						'<div class="ts-upload-placeholder">' +
							'<span class="dashicons dashicons-format-image ts-upload-icon"></span>' +
							'<button type="button" class="ts-upload-btn">Upload Thumbnail</button>' +
							'<p class="ts-upload-hint">JPEG, PNG, GIF, and WebP formats, up to 40 MB</p>' +
						'</div>'
					);
					$('#_thumbnail_id').val('');
				});

				// Author Dropdown Change
				$(document).on('change', '.ts-author-dropdown', function() {
					var $option = $(this).find('option:selected');
					var name = $option.text();
					var email = $option.data('email');
					var avatar = $option.data('avatar');
					
					$('.ts-author-name').text(name);
					$('.ts-author-email').text(email);
					$('.ts-author-avatar img').attr('src', avatar);
				});

				// Initialize pricing model on load
				var selectedPricing = $('input[name="pricing_model"]:checked').val();
				if (selectedPricing === 'paid') {
					$('#ts-product-selection').show();
				} else if (selectedPricing === 'subscription') {
					$('#ts-product-selection').show();
					$('#ts-subscription-settings').show();
				}
			},

			/**
			 * Initialize Slug Generation from Title
			 */
			initSlugGeneration: function() {
				var self = this;
				var $titleInput = $('#course-title');
				var $urlValue = $('.ts-url-value');
				var isManuallyEdited = false;

				// Generate slug from title
				$titleInput.on('input', function() {
					if (!isManuallyEdited) {
						var title = $(this).val();
						var slug = self.generateSlug(title);
						var baseUrl = $urlValue.text().split('/courses/')[0];
						$urlValue.text(baseUrl + '/courses/' + (slug || 'placeholder'));
					}
				});

				// URL Edit Button
				$(document).on('click', '.ts-url-edit-btn', function() {
					var currentUrl = $urlValue.text();
					var slug = currentUrl.split('/courses/')[1] || '';
					
					var newSlug = prompt('Edit course URL slug:', slug);
					if (newSlug !== null && newSlug.trim() !== '') {
						isManuallyEdited = true;
						newSlug = self.generateSlug(newSlug);
						var baseUrl = currentUrl.split('/courses/')[0];
						$urlValue.text(baseUrl + '/courses/' + newSlug);
					}
				});
			},

			/**
			 * Generate URL Slug from Text
			 */
			generateSlug: function(text) {
				return text
					.toLowerCase()
					.trim()
					.replace(/[^\w\s-]/g, '')
					.replace(/[\s_-]+/g, '-')
					.replace(/^-+|-+$/g, '');
			},

			/**
			 * Open Featured Image Uploader
			 */
			openFeaturedImageUploader: function() {
				var self = this;
				
				if (this.imageFrame) {
					this.imageFrame.open();
					return;
				}

				this.imageFrame = wp.media({
					title: 'Select Featured Image',
					button: { text: 'Use this image' },
					multiple: false,
					library: { type: 'image' }
				});

				this.imageFrame.on('select', function() {
					var attachment = self.imageFrame.state().get('selection').first().toJSON();
					
					$('#ts-featured-image-upload').html(
						'<img src="' + attachment.url + '" class="ts-uploaded-image">' +
						'<button type="button" class="ts-remove-image"><span class="dashicons dashicons-no-alt"></span></button>'
					);
					$('#_thumbnail_id').val(attachment.id);
				});

				this.imageFrame.open();
			},

			/**
			 * Initialize Sortable for Topics and Items
			 */
			initSortable: function() {
				// Topics sortable
				$('#ts-topics-list').sortable({
					handle: '.ts-topic-drag-handle',
					placeholder: 'ts-topic-placeholder',
					axis: 'y',
					opacity: 0.8,
					update: function(event, ui) {
						// Update order in database if needed
					}
				});

				// Items sortable within topics
				$(document).on('mouseenter', '.ts-topic-items-list', function() {
					if (!$(this).hasClass('ui-sortable')) {
						$(this).sortable({
							handle: '.ts-topic-drag-handle',
							placeholder: 'ts-item-placeholder',
							axis: 'y',
							opacity: 0.8
						});
					}
				});
			},

			/**
			 * Update Curriculum Summary
			 */
			updateSummary: function() {
				var totalLessons = 0;
				var totalQuizzes = 0;
				var totalAssignments = 0;
				var totalDuration = 0;

				$('.ts-item-row').each(function() {
					var type = $(this).data('type');
					if (type === 'lesson') totalLessons++;
					else if (type === 'quiz') totalQuizzes++;
					else if (type === 'assignment') totalAssignments++;
				});

				$('#ts-total-lessons').text(totalLessons);
				$('#ts-total-quizzes').text(totalQuizzes);
				$('#ts-total-assignments').text(totalAssignments);
				$('#ts-total-duration').text(totalDuration + 'm');
			},

			/**
			 * Handle Step Click Navigation
			 */
			handleStepClick: function(e) {
				var $step = $(e.currentTarget);
				var stepNum = $step.data('step');
				
				if (!stepNum) return;

				// Update step indicators
				$('.ts-step').removeClass('ts-step-active');
				$step.addClass('ts-step-active');

				// Update content
				$('.ts-step-content').removeClass('ts-step-content-active');
				$('.ts-step-content[data-step="' + stepNum + '"]').addClass('ts-step-content-active');

				this.currentStep = stepNum;
			},

			/**
			 * Warn Before Leave
			 */
			warnBeforeLeave: function(e) {
				if (this.hasUnsavedChanges) {
					e.preventDefault();
					e.returnValue = tsLmsCourseEditor.strings.confirmLeave;
					return tsLmsCourseEditor.strings.confirmLeave;
				}
			},

			/**
			 * Save Draft
			 */
			saveDraft: function() {
				this.saveCourse('draft');
			},

			/**
			 * Publish Course
			 */
			publishCourse: function() {
				this.saveCourse('publish');
			},

			/**
			 * Save Course (Main Function)
			 */
			saveCourse: function(status) {
				var self = this;
				var courseId = $('#course-id').val() || 0;
				
				// Get form data
				var formData = {
					action: 'ts_lms_save_course',
					nonce: tsLmsCourseEditor.nonce,
					course_id: courseId,
					title: $('#course-title').val(),
					slug: $('.ts-url-value').text().split('/courses/')[1] || '',
					description: tinyMCE.get('course_description') ? tinyMCE.get('course_description').getContent() : $('#course_description').val(),
					status: status,
					thumbnail_id: $('#_thumbnail_id').val(),
					difficulty_level: $('select[name="difficulty_level"]').val(),
					public_course: $('input[name="public_course"]').is(':checked') ? 1 : 0,
					qa_enabled: $('input[name="qa_enabled"]').is(':checked') ? 1 : 0,
					content_drip_type: $('input[name="content_drip_type"]:checked').val(),
					max_students: $('input[name="max_students"]').val(),
					enrollment_period_enabled: $('input[name="enrollment_period_enabled"]').is(':checked') ? 1 : 0,
					pause_enrollment: $('input[name="pause_enrollment"]').is(':checked') ? 1 : 0,
					is_scheduled: $('input[name="is_scheduled"]').is(':checked') ? 1 : 0,
					video_source: $('#ts-course-video-source').val(),
					video_url: $('#ts-course-video-url').val(),
					pricing_model: $('input[name="pricing_model"]:checked').val(),
					course_product: $('select[name="course_product"]').val(),
					subscription_plan_type: $('select[name="subscription_plan_type"]').val(),
					subscription_price: $('input[name="subscription_price"]').val(),
					subscription_scope: $('input[name="subscription_scope"]:checked').val(),
					post_author: $('select[name="post_author"]').val()
				};

				// Get categories
				var categories = [];
				$('input[name="tax_input[ts_course_category][]"]:checked').each(function() {
					categories.push($(this).val());
				});
				formData.categories = categories;

				// Get tags
				var tags = [];
				$('input[name="tax_input[ts_course_tag][]"]:checked').each(function() {
					tags.push($(this).val());
				});
				formData.tags = tags;

				// Show loading
				var $btn = status === 'publish' ? $('#ts-publish-course') : $('#ts-save-draft');
				var originalText = $btn.text();
				$btn.prop('disabled', true).text(tsLmsCourseEditor.strings.saving);

				$.ajax({
					url: tsLmsCourseEditor.ajaxUrl,
					type: 'POST',
					data: formData,
					success: function(response) {
						$btn.prop('disabled', false).text(originalText);
						
						if (response.success) {
							self.hasUnsavedChanges = false;
							self.showToast(response.data.message, 'success');
							
							// Update course ID if new
							if (response.data.course_id && !courseId) {
								$('#course-id').val(response.data.course_id);
								if (response.data.edit_url) {
									window.history.replaceState(null, '', response.data.edit_url);
								}
								$('#ts-preview-course').show();
							}
						} else {
							self.showToast(response.data.message || tsLmsCourseEditor.strings.error, 'error');
						}
					},
					error: function() {
						$btn.prop('disabled', false).text(originalText);
						self.showToast(tsLmsCourseEditor.strings.error, 'error');
					}
				});
			}
		});
	}

	// Initialize on document ready
	$(document).ready(function() {
		if (typeof window.CourseEditor !== 'undefined' && window.CourseEditor.initSidebar) {
			// Functions are now available
			console.log('Course Editor Helper Functions loaded');
		}
	});

})(jQuery);
