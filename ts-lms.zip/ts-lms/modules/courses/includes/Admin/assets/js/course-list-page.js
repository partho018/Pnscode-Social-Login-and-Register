/**
 * Modern Course List Page JavaScript
 * Handles interactions, AJAX, and animations
 */

(function($) {
	'use strict';

	const CourseListPage = {
		/**
		 * Initialize
		 */
		init: function() {
			this.bindEvents();
			this.initViewToggle();
			this.initSearch();
			this.loadViewPreference();
		},

		/**
		 * Bind event handlers
		 */
		bindEvents: function() {
			// Bulk selection
			$('.ts-course-select').on('change', this.handleBulkSelection);
			
			// Bulk actions
			$('#ts-apply-bulk-action').on('click', this.handleBulkAction);
			
			// Delete course
			$(document).on('click', '.ts-delete-course', this.handleDeleteCourse);
			
			// View toggle
			$('.ts-view-btn').on('click', this.handleViewToggle);
			
			// Search
			$('#ts-course-search').on('input', this.debounce(this.handleSearch, 500));
			
			// Filter changes
			$('#ts-category-filter, #ts-status-filter, #ts-post-type-filter').on('change', this.handleFilterChange);
		},

		/**
		 * Handle bulk selection
		 */
		handleBulkSelection: function() {
			const selectedCount = $('.ts-course-select:checked').length;
			$('#ts-apply-bulk-action').prop('disabled', selectedCount === 0);
			
			// Update button text
			if (selectedCount > 0) {
				$('#ts-apply-bulk-action').text(`Apply (${selectedCount})`);
			} else {
				$('#ts-apply-bulk-action').text('Apply');
			}
		},

		/**
		 * Handle bulk action
		 */
		handleBulkAction: function(e) {
			e.preventDefault();
			
			const action = $('#ts-bulk-action-select').val();
			const courseIds = $('.ts-course-select:checked').map(function() {
				return $(this).val();
			}).get();

			if (!action || courseIds.length === 0) {
				CourseListPage.showNotification('Please select an action and courses', 'warning');
				return;
			}

			// Confirm for delete action
			if (action === 'delete') {
				if (!confirm(tsLmsCourseListPage.confirmBulkDelete)) {
					return;
				}
			}

			// Show loading
			CourseListPage.showLoading('#ts-apply-bulk-action');

			// AJAX request
			$.ajax({
				url: tsLmsCourseListPage.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_course_bulk_action',
					nonce: tsLmsCourseListPage.nonce,
					bulk_action: action,
					course_ids: courseIds
				},
				success: function(response) {
					if (response.success) {
						CourseListPage.showNotification(response.data.message, 'success');
						
						// Reload page after short delay
						setTimeout(function() {
							window.location.reload();
						}, 1000);
					} else {
						CourseListPage.showNotification(response.data.message || 'Action failed', 'error');
					}
				},
				error: function() {
					CourseListPage.showNotification('Network error occurred', 'error');
				},
				complete: function() {
					CourseListPage.hideLoading('#ts-apply-bulk-action');
				}
			});
		},

		/**
		 * Handle delete course
		 */
		handleDeleteCourse: function(e) {
			e.preventDefault();
			
			const $btn = $(this);
			const courseId = $btn.data('course-id');
			const $card = $btn.closest('.ts-course-card');

			if (!confirm(tsLmsCourseListPage.confirmDelete)) {
				return;
			}

			// Show loading
			CourseListPage.showLoading($btn);

			// AJAX request
			$.ajax({
				url: tsLmsCourseListPage.ajaxUrl,
				type: 'POST',
				data: {
					action: 'ts_lms_course_delete',
					nonce: tsLmsCourseListPage.nonce,
					course_id: courseId
				},
				success: function(response) {
					if (response.success) {
						// Animate card removal
						$card.css({
							transform: 'scale(0.8)',
							opacity: '0',
							transition: 'all 0.3s ease'
						});
						
						setTimeout(function() {
							$card.remove();
							CourseListPage.showNotification(response.data.message, 'success');
							
							// Check if grid is empty
							if ($('.ts-course-card').length === 0) {
								window.location.reload();
							}
						}, 300);
					} else {
						CourseListPage.showNotification(response.data.message || 'Delete failed', 'error');
						CourseListPage.hideLoading($btn);
					}
				},
				error: function() {
					CourseListPage.showNotification('Network error occurred', 'error');
					CourseListPage.hideLoading($btn);
				}
			});
		},

		/**
		 * Handle view toggle
		 */
		handleViewToggle: function(e) {
			e.preventDefault();
			
			const $btn = $(this);
			const view = $btn.data('view');
			
			// Update active state
			$('.ts-view-btn').removeClass('active');
			$btn.addClass('active');
			
			// Update container view
			$('.ts-courses-container').attr('data-view', view);
			
			// Save preference
			localStorage.setItem('ts_course_list_view', view);
			
			// Animate transition
			$('.ts-courses-grid').css({
				opacity: '0',
				transform: 'translateY(20px)'
			});
			
			setTimeout(function() {
				$('.ts-courses-grid').css({
					opacity: '1',
					transform: 'translateY(0)',
					transition: 'all 0.3s ease'
				});
			}, 100);
		},

		/**
		 * Initialize view toggle
		 */
		initViewToggle: function() {
			const savedView = localStorage.getItem('ts_course_list_view');
			if (savedView) {
				$('.ts-view-btn').removeClass('active');
				$(`.ts-view-btn[data-view="${savedView}"]`).addClass('active');
				$('.ts-courses-container').attr('data-view', savedView);
			}
		},

		/**
		 * Load view preference
		 */
		loadViewPreference: function() {
			const savedView = localStorage.getItem('ts_course_list_view') || 'list';
			$('.ts-courses-container').attr('data-view', savedView);
			$(`.ts-view-btn[data-view="${savedView}"]`).addClass('active');
		},

		/**
		 * Initialize search
		 */
		initSearch: function() {
			// Add clear button to search
			const $searchBox = $('.ts-search-box');
			if ($('#ts-course-search').val()) {
				$searchBox.append('<button type="button" class="ts-search-clear">×</button>');
			}
			
			// Handle clear button
			$(document).on('click', '.ts-search-clear', function() {
				$('#ts-course-search').val('').trigger('input');
				$(this).remove();
			});
		},

		/**
		 * Handle search
		 */
		handleSearch: function() {
			const searchTerm = $(this).val();
			const $searchBox = $('.ts-search-box');
			
			// Add/remove clear button
			if (searchTerm && !$('.ts-search-clear').length) {
				$searchBox.append('<button type="button" class="ts-search-clear">×</button>');
			} else if (!searchTerm) {
				$('.ts-search-clear').remove();
			}
			
			// Update URL and reload
			const url = new URL(window.location.href);
			if (searchTerm) {
				url.searchParams.set('s', searchTerm);
			} else {
				url.searchParams.delete('s');
			}
			url.searchParams.delete('paged'); // Reset to first page
			
			window.location.href = url.toString();
		},

		/**
		 * Handle filter change
		 */
		handleFilterChange: function() {
			const category = $('#ts-category-filter').val();
			const status = $('#ts-status-filter').val();
			const postType = $('#ts-post-type-filter').val();
			
			// Update URL
			const url = new URL(window.location.href);
			
			if (category) {
				url.searchParams.set('category', category);
			} else {
				url.searchParams.delete('category');
			}
			
			if (status) {
				url.searchParams.set('status', status);
			} else {
				url.searchParams.delete('status');
			}

			if (postType) {
				url.searchParams.set('post_type', postType);
			} else {
				url.searchParams.delete('post_type');
			}
			
			url.searchParams.delete('paged'); // Reset to first page
			
			window.location.href = url.toString();
		},

		/**
		 * Show loading state
		 */
		showLoading: function(element) {
			const $el = $(element);
			$el.prop('disabled', true);
			$el.data('original-html', $el.html());
			$el.html('<span class="ts-loading"></span>');
		},

		/**
		 * Hide loading state
		 */
		hideLoading: function(element) {
			const $el = $(element);
			$el.prop('disabled', false);
			$el.html($el.data('original-html'));
		},

		/**
		 * Show notification
		 */
		showNotification: function(message, type = 'info') {
			// Remove existing notifications
			$('.ts-notification').remove();
			
			// Create notification
			const $notification = $(`
				<div class="ts-notification ts-notification-${type}">
					<div class="ts-notification-content">
						<span class="ts-notification-icon">
							${this.getNotificationIcon(type)}
						</span>
						<span class="ts-notification-message">${message}</span>
					</div>
					<button type="button" class="ts-notification-close">×</button>
				</div>
			`);
			
			// Append to body
			$('body').append($notification);
			
			// Animate in
			setTimeout(function() {
				$notification.addClass('ts-notification-show');
			}, 10);
			
			// Auto hide after 5 seconds
			setTimeout(function() {
				CourseListPage.hideNotification($notification);
			}, 5000);
			
			// Handle close button
			$notification.find('.ts-notification-close').on('click', function() {
				CourseListPage.hideNotification($notification);
			});
		},

		/**
		 * Hide notification
		 */
		hideNotification: function($notification) {
			$notification.removeClass('ts-notification-show');
			setTimeout(function() {
				$notification.remove();
			}, 300);
		},

		/**
		 * Get notification icon
		 */
		getNotificationIcon: function(type) {
			const icons = {
				success: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M22 11.08V12a10 10 0 11-5.93-9.14" stroke-width="2" stroke-linecap="round"/><path d="M22 4L12 14.01l-3-3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
				error: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10" stroke-width="2"/><line x1="15" y1="9" x2="9" y2="15" stroke-width="2" stroke-linecap="round"/><line x1="9" y1="9" x2="15" y2="15" stroke-width="2" stroke-linecap="round"/></svg>',
				warning: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><line x1="12" y1="9" x2="12" y2="13" stroke-width="2" stroke-linecap="round"/><line x1="12" y1="17" x2="12.01" y2="17" stroke-width="2" stroke-linecap="round"/></svg>',
				info: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10" stroke-width="2"/><line x1="12" y1="16" x2="12" y2="12" stroke-width="2" stroke-linecap="round"/><line x1="12" y1="8" x2="12.01" y2="8" stroke-width="2" stroke-linecap="round"/></svg>'
			};
			return icons[type] || icons.info;
		},

		/**
		 * Debounce function
		 */
		debounce: function(func, wait) {
			let timeout;
			return function executedFunction(...args) {
				const later = () => {
					clearTimeout(timeout);
					func.apply(this, args);
				};
				clearTimeout(timeout);
				timeout = setTimeout(later, wait);
			};
		}
	};

	// Initialize on document ready
	$(document).ready(function() {
		CourseListPage.init();
	});

	// Add notification styles dynamically
	const notificationStyles = `
		<style>
			.ts-notification {
				position: fixed;
				top: 32px;
				right: -400px;
				max-width: 400px;
				background: white;
				border-radius: 12px;
				box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
				padding: 1rem 1.5rem;
				z-index: 999999;
				transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
				border-left: 4px solid;
			}
			
			.ts-notification-show {
				right: 32px;
			}
			
			.ts-notification-content {
				display: flex;
				align-items: center;
				gap: 0.75rem;
			}
			
			.ts-notification-icon {
				flex-shrink: 0;
				display: flex;
				align-items: center;
			}
			
			.ts-notification-message {
				flex: 1;
				font-size: 0.875rem;
				font-weight: 500;
				color: #0f172a;
			}
			
			.ts-notification-close {
				position: absolute;
				top: 0.5rem;
				right: 0.5rem;
				background: transparent;
				border: none;
				font-size: 1.5rem;
				color: #94a3b8;
				cursor: pointer;
				width: 24px;
				height: 24px;
				display: flex;
				align-items: center;
				justify-content: center;
				border-radius: 4px;
				transition: all 0.15s;
			}
			
			.ts-notification-close:hover {
				background: #f1f5f9;
				color: #0f172a;
			}
			
			.ts-notification-success {
				border-left-color: #10b981;
			}
			
			.ts-notification-success .ts-notification-icon {
				color: #10b981;
			}
			
			.ts-notification-error {
				border-left-color: #ef4444;
			}
			
			.ts-notification-error .ts-notification-icon {
				color: #ef4444;
			}
			
			.ts-notification-warning {
				border-left-color: #f59e0b;
			}
			
			.ts-notification-warning .ts-notification-icon {
				color: #f59e0b;
			}
			
			.ts-notification-info {
				border-left-color: #3b82f6;
			}
			
			.ts-notification-info .ts-notification-icon {
				color: #3b82f6;
			}
			
			.ts-search-clear {
				position: absolute;
				right: 1rem;
				top: 50%;
				transform: translateY(-50%);
				background: #e2e8f0;
				border: none;
				width: 24px;
				height: 24px;
				border-radius: 50%;
				font-size: 1.25rem;
				line-height: 1;
				cursor: pointer;
				color: #64748b;
				transition: all 0.15s;
				display: flex;
				align-items: center;
				justify-content: center;
			}
			
			.ts-search-clear:hover {
				background: #cbd5e1;
				color: #0f172a;
			}
		</style>
	`;
	
	$('head').append(notificationStyles);

})(jQuery);
