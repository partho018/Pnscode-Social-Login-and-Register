/**
 * Course Categories Page JavaScript
 *
 * @package TS_LMS\Modules\Courses\Admin
 * @since 1.0.0
 */

(function($) {
    'use strict';

    var CategoryPage = {
        mediaUploader: null,

        /**
         * Initialize
         */
        init: function() {
            this.bindEvents();
            this.updateCategoryCount();
        },

        /**
         * Bind events
         */
        bindEvents: function() {
            // Form submission
            $('#ts-lms-add-category-form').on('submit', this.handleFormSubmit.bind(this));

            // Image upload
            $('#upload-category-thumbnail').on('click', this.uploadImage.bind(this));
            $('#remove-category-thumbnail').on('click', this.removeImage.bind(this));

            // Delete category
            $(document).on('click', '.delete-category', this.handleDelete.bind(this));

            // Select all checkboxes
            $('#cb-select-all-1, #cb-select-all-2').on('change', this.toggleAllCheckboxes.bind(this));

            // Bulk actions
            $('#doaction').on('click', this.handleBulkAction.bind(this));

            // Sortable columns
            $('.ts-lms-categories-table th.sortable a').on('click', this.handleSort.bind(this));

            // Auto-generate slug from name
            $('#category-name').on('blur', this.autoGenerateSlug.bind(this));
        },

        /**
         * Handle form submission
         */
        handleFormSubmit: function(e) {
            e.preventDefault();

            var $form = $(e.target);
            var $submitBtn = $form.find('input[type="submit"], button[type="submit"]');
            var $message = $('#category-form-message');

            // Disable submit button and show spinner
            $submitBtn.prop('disabled', true);
            $form.find('.spinner').addClass('is-active');

            // Hide previous messages
            $message.hide().removeClass('notice-success notice-error');

            var formData = {
                action: 'ts_lms_add_category',
                nonce: tsLmsCategoryPage.nonce,
                name: $('#category-name').val(),
                slug: $('#category-slug').val(),
                parent: $('#category-parent').val(),
                description: $('#category-description').val(),
                thumbnail: $('#category-thumbnail-id').val()
            };

            $.ajax({
                url: tsLmsCategoryPage.ajaxUrl,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        $message
                            .addClass('notice-success')
                            .html('<p>' + response.data.message + '</p>')
                            .slideDown();

                        // Reset form
                        $form[0].reset();
                        CategoryPage.removeImage();

                        // Reload categories
                        CategoryPage.reloadCategories();
                    } else {
                        // Show error message
                        $message
                            .addClass('notice-error')
                            .html('<p>' + response.data.message + '</p>')
                            .slideDown();
                    }
                },
                error: function(xhr, status, error) {
                    $message
                        .addClass('notice-error')
                        .html('<p>An error occurred. Please try again.</p>')
                        .slideDown();
                },
                complete: function() {
                    // Re-enable submit button and hide spinner
                    $submitBtn.prop('disabled', false);
                    $form.find('.spinner').removeClass('is-active');
                }
            });
        },

        /**
         * Upload image
         */
        uploadImage: function(e) {
            e.preventDefault();

            // If the media uploader already exists, reopen it
            if (this.mediaUploader) {
                this.mediaUploader.open();
                return;
            }

            // Create the media uploader
            this.mediaUploader = wp.media({
                title: tsLmsCategoryPage.uploadTitle,
                button: {
                    text: tsLmsCategoryPage.uploadButton
                },
                multiple: false
            });

            // When an image is selected
            this.mediaUploader.on('select', function() {
                var attachment = CategoryPage.mediaUploader.state().get('selection').first().toJSON();
                
                $('#category-thumbnail-id').val(attachment.id);
                $('#category-thumbnail-preview').html('<img src="' + attachment.url + '" alt="" width="100">');
                $('#remove-category-thumbnail').show();
            });

            // Open the uploader
            this.mediaUploader.open();
        },

        /**
         * Remove image
         */
        removeImage: function(e) {
            if (e) {
                e.preventDefault();
            }

            $('#category-thumbnail-id').val('');
            $('#category-thumbnail-preview').html('');
            $('#remove-category-thumbnail').hide();
        },

        /**
         * Handle category deletion
         */
        handleDelete: function(e) {
            e.preventDefault();

            if (!confirm(tsLmsCategoryPage.confirmDelete)) {
                return;
            }

            var $link = $(e.currentTarget);
            var termId = $link.data('term-id');
            var $row = $link.closest('tr');

            // Add loading state
            $row.css('opacity', '0.5');

            $.ajax({
                url: tsLmsCategoryPage.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ts_lms_delete_category',
                    nonce: tsLmsCategoryPage.nonce,
                    term_id: termId
                },
                success: function(response) {
                    if (response.success) {
                        // Remove row with animation
                        $row.fadeOut(400, function() {
                            $(this).remove();
                            CategoryPage.updateCategoryCount();
                            CategoryPage.checkEmptyTable();
                        });
                    } else {
                        alert(response.data.message);
                        $row.css('opacity', '1');
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                    $row.css('opacity', '1');
                }
            });
        },

        /**
         * Toggle all checkboxes
         */
        toggleAllCheckboxes: function(e) {
            var checked = $(e.target).prop('checked');
            $('.ts-lms-categories-table tbody input[type="checkbox"]').prop('checked', checked);
        },

        /**
         * Handle bulk actions
         */
        handleBulkAction: function(e) {
            e.preventDefault();

            var action = $('#bulk-action-selector-top').val();
            
            if (action === '-1') {
                alert('Please select an action.');
                return;
            }

            var $checkedBoxes = $('.ts-lms-categories-table tbody input[type="checkbox"]:checked');
            
            if ($checkedBoxes.length === 0) {
                alert('Please select at least one category.');
                return;
            }

            if (action === 'delete') {
                if (!confirm('Are you sure you want to delete the selected categories?')) {
                    return;
                }

                var termIds = [];
                $checkedBoxes.each(function() {
                    termIds.push($(this).val());
                });

                // Delete each category
                var deletedCount = 0;
                termIds.forEach(function(termId) {
                    $.ajax({
                        url: tsLmsCategoryPage.ajaxUrl,
                        type: 'POST',
                        data: {
                            action: 'ts_lms_delete_category',
                            nonce: tsLmsCategoryPage.nonce,
                            term_id: termId
                        },
                        success: function(response) {
                            if (response.success) {
                                $('tr[data-term-id="' + termId + '"]').fadeOut(400, function() {
                                    $(this).remove();
                                    deletedCount++;
                                    
                                    if (deletedCount === termIds.length) {
                                        CategoryPage.updateCategoryCount();
                                        CategoryPage.checkEmptyTable();
                                    }
                                });
                            }
                        }
                    });
                });
            }
        },

        /**
         * Handle table sorting
         */
        handleSort: function(e) {
            e.preventDefault();

            var $link = $(e.currentTarget);
            var $th = $link.closest('th');
            var sortBy = $link.data('sort');
            var isAsc = $th.hasClass('asc');

            // Remove sorting classes from all headers
            $('.ts-lms-categories-table th.sortable').removeClass('asc desc');

            // Add sorting class to current header
            if (isAsc) {
                $th.removeClass('asc').addClass('desc');
            } else {
                $th.removeClass('desc').addClass('asc');
            }

            // Sort table rows
            var $tbody = $('.ts-lms-categories-table tbody');
            var $rows = $tbody.find('tr').not('.no-items').get();

            $rows.sort(function(a, b) {
                var aValue = $(a).find('.column-' + sortBy).text().trim().toLowerCase();
                var bValue = $(b).find('.column-' + sortBy).text().trim().toLowerCase();

                // Handle numeric values
                if (sortBy === 'count') {
                    aValue = parseInt(aValue) || 0;
                    bValue = parseInt(bValue) || 0;
                }

                if (isAsc) {
                    return aValue > bValue ? -1 : (aValue < bValue ? 1 : 0);
                } else {
                    return aValue < bValue ? -1 : (aValue > bValue ? 1 : 0);
                }
            });

            // Reorder rows
            $.each($rows, function(index, row) {
                $tbody.append(row);
            });
        },

        /**
         * Auto-generate slug from name
         */
        autoGenerateSlug: function() {
            var $slug = $('#category-slug');
            
            // Only auto-generate if slug is empty
            if ($slug.val() === '') {
                var name = $('#category-name').val();
                var slug = name
                    .toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-+|-+$/g, '');
                
                $slug.val(slug);
            }
        },

        /**
         * Reload categories table
         */
        reloadCategories: function() {
            $.ajax({
                url: tsLmsCategoryPage.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ts_lms_get_categories',
                    nonce: tsLmsCategoryPage.nonce
                },
                success: function(response) {
                    if (response.success && response.data.categories) {
                        var $tbody = $('#categories-table-body');
                        $tbody.empty();

                        if (response.data.categories.length === 0) {
                            $tbody.append(
                                '<tr class="no-items">' +
                                '<td colspan="6" class="colspanchange">No categories found.</td>' +
                                '</tr>'
                            );
                        } else {
                            response.data.categories.forEach(function(category) {
                                var thumbnailHtml = category.thumbnail 
                                    ? '<img src="' + category.thumbnail + '" alt="' + category.name + '" width="40">'
                                    : '—';

                                var row = '<tr id="tag-' + category.id + '">' +
                                    '<th scope="row" class="check-column"><input type="checkbox" name="delete_tags[]" value="' + category.id + '"></th>' +
                                    '<td class="column-image">' + thumbnailHtml + '</td>' +
                                    '<td class="column-name column-primary" data-colname="Name">' +
                                    '<strong><a class="row-title" href="#">' + category.name + '</a></strong>' +
                                    '<div class="row-actions">' +
                                    '<span class="edit"><a href="#">Edit</a> | </span>' +
                                    '<span class="delete"><a class="delete-category" href="#" data-term-id="' + category.id + '">Delete</a> | </span>' +
                                    '<span class="view"><a href="#" target="_blank">View</a></span>' +
                                    '</div>' +
                                    '</td>' +
                                    '<td class="column-description" data-colname="Description">' + category.description + '</td>' +
                                    '<td class="column-slug" data-colname="Slug">' + category.slug + '</td>' +
                                    '<td class="column-posts num" data-colname="Count">' + category.count + '</td>' +
                                    '</tr>';

                                $tbody.append(row);
                            });
                        }

                        CategoryPage.updateCategoryCount();
                    }
                }
            });
        },

        /**
         * Update category count
         */
        updateCategoryCount: function() {
            var count = $('.ts-lms-categories-table tbody tr').not('.no-items').length;
            $('#category-count').text(count + ' item' + (count !== 1 ? 's' : ''));
        },

        /**
         * Check if table is empty and show message
         */
        checkEmptyTable: function() {
            var $tbody = $('#categories-table-body');
            if ($tbody.find('tr').not('.no-items').length === 0) {
                $tbody.html(
                    '<tr class="no-items">' +
                    '<td colspan="6" class="colspanchange">No categories found.</td>' +
                    '</tr>'
                );
            }
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        CategoryPage.init();
    });

})(jQuery);
