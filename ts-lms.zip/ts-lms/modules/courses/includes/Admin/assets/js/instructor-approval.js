jQuery(document).ready(function($) {
    'use strict';
    
    // Approve instructor
    $('.approve-instructor').on('click', function(e) {
        e.preventDefault();
        
        var userId = $(this).data('user-id');
        var button = $(this);
        
        if (!confirm('Are you sure you want to approve this instructor application?')) {
            return;
        }
        
        button.prop('disabled', true).text('Processing...');
        
        $.ajax({
            url: ts_lms_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ts_lms_approve_instructor',
                nonce: ts_lms_admin.nonce,
                user_id: userId
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message);
                    button.prop('disabled', false).text('Approve');
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
                button.prop('disabled', false).text('Approve');
            }
        });
    });
    
    // Reject instructor
    $('.reject-instructor').on('click', function(e) {
        e.preventDefault();
        
        var userId = $(this).data('user-id');
        var button = $(this);
        
        var reason = prompt('Please enter the reason for rejection:');
        
        if (!reason) {
            return;
        }
        
        button.prop('disabled', true).text('Processing...');
        
        $.ajax({
            url: ts_lms_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ts_lms_reject_instructor',
                nonce: ts_lms_admin.nonce,
                user_id: userId,
                reason: reason
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message);
                    button.prop('disabled', false).text('Reject');
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
                button.prop('disabled', false).text('Reject');
            }
        });
    });
    
    // Suspend instructor
    $('.suspend-instructor').on('click', function(e) {
        e.preventDefault();
        
        var userId = $(this).data('user-id');
        var button = $(this);
        
        if (!confirm('Are you sure you want to suspend this instructor?')) {
            return;
        }
        
        button.prop('disabled', true).text('Processing...');
        
        $.ajax({
            url: ts_lms_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'ts_lms_suspend_instructor',
                nonce: ts_lms_admin.nonce,
                user_id: userId
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message);
                    button.prop('disabled', false).text('Suspend');
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
                button.prop('disabled', false).text('Suspend');
            }
        });
    });
});
