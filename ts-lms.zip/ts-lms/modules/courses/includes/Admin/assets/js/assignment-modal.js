/**
 * Assignment Modal JavaScript
 * 
 * Handles all interactions for the Assignment modal
 * 
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

(function($) {
	'use strict';

	/**
	 * Assignment Modal Handler
	 */
	const AssignmentModal = {
		/**
		 * Initialize the modal
		 */
		init: function() {
			this.bindEvents();
		},

		/**
		 * Bind event listeners
		 */
		bindEvents: function() {
			// Open modal when clicking "Add Assignment" button
			$(document).on('click', '.ts-add-content-btn[data-type="assignment"]', this.openModal.bind(this));
			
			// Close modal
			$(document).on('click', '.ts-assignment-modal-close, .ts-assignment-btn-cancel', this.closeModal.bind(this));
			$(document).on('click', '.ts-assignment-modal-overlay', this.closeModal.bind(this));
			
			// Save assignment
			$(document).on('click', '.ts-assignment-btn-save', this.saveAssignment.bind(this));
			
			// Toggle deadline fields
			$(document).on('change', '#ts-assignment-deadline-toggle', this.toggleDeadlineFields.bind(this));
			
			// Toggle resubmission attempts field
			$(document).on('change', '#ts-assignment-resubmission-toggle', this.toggleResubmissionAttempts.bind(this));
			
			// File upload
			$(document).on('click', '#ts-assignment-upload-attachment', this.openMediaUploader.bind(this));
			
			// Editor tabs
			$(document).on('click', '.ts-assignment-editor-tab', this.switchEditorTab.bind(this));
			
			// Prevent modal close on container click
			$(document).on('click', '.ts-assignment-modal-container', function(e) {
				e.stopPropagation();
			});

			// ESC key to close
			$(document).on('keydown', this.handleKeyPress.bind(this));
		},

		/**
		 * Open the modal
		 */
		openModal: function(e) {
			e.preventDefault();
			
			const $modal = $('#ts-assignment-modal');
			$modal.addClass('ts-modal-open');
			$('body').addClass('ts-assignment-modal-active');
			
			// Reset form
			this.resetForm();
		},

		/**
		 * Close the modal
		 */
		closeModal: function(e) {
			if (e) {
				e.preventDefault();
			}
			
			const $modal = $('#ts-assignment-modal');
			$modal.removeClass('ts-modal-open');
			$('body').removeClass('ts-assignment-modal-active');
		},

		/**
		 * Handle keyboard events
		 */
		handleKeyPress: function(e) {
			// ESC key
			if (e.keyCode === 27 && $('#ts-assignment-modal').hasClass('ts-modal-open')) {
				this.closeModal();
			}
		},

		/**
		 * Reset form fields
		 */
		resetForm: function() {
			$('#ts-assignment-title').val('');
			$('#ts-assignment-content').val('');
			$('#ts-assignment-time-limit').val('0');
			$('#ts-assignment-time-unit').val('weeks');
			$('#ts-assignment-deadline-toggle').prop('checked', false);
			$('#ts-assignment-deadline-fields').hide();
			$('#ts-assignment-deadline').val('');
			$('#ts-assignment-total-points').val('10');
			$('#ts-assignment-min-points').val('5');
			$('#ts-assignment-file-limit').val('1');
			$('#ts-assignment-file-size').val('2');
			$('#ts-assignment-file-size-unit').val('mb');
			$('#ts-assignment-resubmission-toggle').prop('checked', false);
			$('#ts-assignment-resubmission-attempts-section').hide();
			$('#ts-assignment-max-attempts').val('5');
			$('#ts-assignment-attachment-id').val('');
		},

		/**
		 * Toggle deadline fields
		 */
		toggleDeadlineFields: function(e) {
			const $toggle = $(e.currentTarget);
			const $fields = $('#ts-assignment-deadline-fields');
			
			if ($toggle.is(':checked')) {
				$fields.slideDown(200);
			} else {
				$fields.slideUp(200);
			}
		},

		/**
		 * Toggle resubmission attempts field
		 */
		toggleResubmissionAttempts: function(e) {
			const $toggle = $(e.currentTarget);
			const $section = $('#ts-assignment-resubmission-attempts-section');
			
			if ($toggle.is(':checked')) {
				$section.slideDown(200);
			} else {
				$section.slideUp(200);
			}
		},

		/**
		 * Open WordPress media uploader
		 */
		openMediaUploader: function(e) {
			e.preventDefault();
			
			const self = this;
			
			// Create media frame
			const frame = wp.media({
				title: 'Select or Upload Attachment',
				button: {
					text: 'Use this file'
				},
				multiple: false
			});
			
			// When an attachment is selected
			frame.on('select', function() {
				const attachment = frame.state().get('selection').first().toJSON();
				$('#ts-assignment-attachment-id').val(attachment.id);
				
				// Show success message
				self.showToast('Attachment uploaded successfully', 'success');
			});
			
			// Open the media frame
			frame.open();
		},

		/**
		 * Switch editor tabs
		 */
		switchEditorTab: function(e) {
			e.preventDefault();
			
			const $tab = $(e.currentTarget);
			const tabName = $tab.data('tab');
			
			// Update active tab
			$('.ts-assignment-editor-tab').removeClass('ts-assignment-editor-tab-active');
			$tab.addClass('ts-assignment-editor-tab-active');
			
			// Switch editor mode (visual/code)
			// This is a placeholder - actual implementation would toggle editor modes
			console.log('Switched to ' + tabName + ' mode');
		},

		/**
		 * Save assignment
		 */
		saveAssignment: function(e) {
			e.preventDefault();
			
			// Get form data
			const data = {
				title: $('#ts-assignment-title').val(),
				content: $('#ts-assignment-content').val(),
				attachmentId: $('#ts-assignment-attachment-id').val(),
				timeLimit: $('#ts-assignment-time-limit').val(),
				timeUnit: $('#ts-assignment-time-unit').val(),
				hasDeadline: $('#ts-assignment-deadline-toggle').is(':checked'),
				deadline: $('#ts-assignment-deadline').val(),
				totalPoints: $('#ts-assignment-total-points').val(),
				minPoints: $('#ts-assignment-min-points').val(),
				fileLimit: $('#ts-assignment-file-limit').val(),
				fileSize: $('#ts-assignment-file-size').val(),
				fileSizeUnit: $('#ts-assignment-file-size-unit').val(),
				allowResubmission: $('#ts-assignment-resubmission-toggle').is(':checked'),
				maxAttempts: $('#ts-assignment-max-attempts').val()
			};
			
			// Validate
			if (!data.title.trim()) {
				this.showToast('Please enter an assignment title', 'error');
				return;
			}
			
			// TODO: Send AJAX request to save assignment
			console.log('Saving assignment:', data);
			
			// Show success message
			this.showToast('Assignment saved successfully', 'success');
			
			// Close modal
			setTimeout(() => {
				this.closeModal();
			}, 1000);
		},

		/**
		 * Show toast notification
		 */
		showToast: function(message, type) {
			const $toast = $('#ts-toast');
			$toast.text(message);
			$toast.removeClass('ts-toast-success ts-toast-error');
			
			if (type === 'success') {
				$toast.addClass('ts-toast-success');
			} else if (type === 'error') {
				$toast.addClass('ts-toast-error');
			}
			
			$toast.fadeIn(200);
			
			setTimeout(function() {
				$toast.fadeOut(200);
			}, 3000);
		}
	};

	// Initialize on document ready
	$(document).ready(function() {
		AssignmentModal.init();
	});

})(jQuery);
