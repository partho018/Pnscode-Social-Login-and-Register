(function($) {
    'use strict';

    $(document).ready(function() {
        const $form = $('#ts-bundle-form');
        const $saveBtn = $('#ts-save-bundle');
        const $courseFilter = $('#ts-course-filter');
        const $courseItems = $('.ts-course-selection-item');

        /**
         * Course Filtering Logic
         */
        $courseFilter.on('input', function() {
            const searchTerm = $(this).val().toLowerCase();
            
            $courseItems.each(function() {
                const title = $(this).data('title');
                if (title.includes(searchTerm)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });

        /**
         * Course Selection Toggle Class
         */
        $('.ts-checkbox-wrapper input').on('change', function() {
            const $item = $(this).closest('.ts-course-selection-item');
            if ($(this).is(':checked')) {
                $item.addClass('selected');
            } else {
                $item.removeClass('selected');
            }
        });

        /**
         * Media Library for Bundle Image
         */
        let mediaUploader;

        $('#ts-set-bundle-image, #ts-bundle-image-preview').on('click', function(e) {
            e.preventDefault();

            if (mediaUploader) {
                mediaUploader.open();
                return;
            }

            mediaUploader = wp.media({
                title: 'Select Bundle Image',
                button: {
                    text: 'Use this image'
                },
                multiple: false
            });

            mediaUploader.on('select', function() {
                const attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#ts-bundle-thumbnail-id').val(attachment.id);
                $('#ts-bundle-image-preview').addClass('has-image').html(`<img src="${attachment.url}" alt="">`);
                $('#ts-remove-bundle-image').removeClass('hidden');
            });

            mediaUploader.open();
        });

        /**
         * Pricing Model Toggles
         */
        $('input[name="price_type"]').on('change', function() {
            const val = $(this).val();
            const $productSection = $('#ts-bundle-product-selection');
            const $subSection = $('#ts-bundle-subscription-settings');

            if (val === 'paid') {
                $productSection.slideDown(200);
                $subSection.slideUp(200);
            } else if (val === 'subscription') {
                $subSection.slideDown(200);
                $productSection.slideUp(200);
            } else {
                $productSection.slideUp(200);
                $subSection.slideUp(200);
            }
        });

        $('#ts-remove-bundle-image').on('click', function(e) {
            e.preventDefault();
            $('#ts-bundle-thumbnail-id').val('');
            $('#ts-bundle-image-preview').removeClass('has-image').html(`
                <div class="ts-image-placeholder">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <rect x="3" y="3" width="18" height="18" rx="2" stroke-width="2"/>
                        <circle cx="8.5" cy="8.5" r="1.5" stroke-width="2"/>
                        <path d="M21 15l-5-5L5 21" stroke-width="2"/>
                    </svg>
                    <p>Click to select image</p>
                </div>
            `);
            $(this).addClass('hidden');
        });

        /**
         * Save Bundle via AJAX
         */
        $saveBtn.on('click', function() {
            const $btn = $(this);
            const $btnText = $btn.find('span');
            const originalText = $btnText.text();

            // validation
            const title = $('#bundle_title').val();
            if (!title) {
                alert('Please enter a bundle title.');
                $('#bundle_title').focus();
                return;
            }

            const courses = $('input[name="courses[]"]:checked').length;
            if (courses === 0) {
                alert('Please select at least one course.');
                return;
            }

            // Prepare data
            const formData = new FormData($form[0]);
            formData.append('action', 'ts_lms_save_bundle');
            formData.append('nonce', tsLmsBundleEditor.nonce);
            
            // Get editor content
            if (typeof tinyMCE !== 'undefined' && tinyMCE.get('bundle_description')) {
                formData.set('description', tinyMCE.get('bundle_description').getContent());
            }

            // Disable button
            $btn.prop('disabled', true);
            $btnText.text(tsLmsBundleEditor.strings.saving);

            $.ajax({
                url: tsLmsBundleEditor.ajaxUrl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        alert(tsLmsBundleEditor.strings.saved);
                        if (!formData.get('bundle_id') || formData.get('bundle_id') === '0') {
                            window.location.href = response.data.edit_url;
                        }
                    } else {
                        alert(response.data.message || tsLmsBundleEditor.strings.error);
                    }
                },
                error: function() {
                    alert(tsLmsBundleEditor.strings.error);
                },
                complete: function() {
                    $btn.prop('disabled', false);
                    $btnText.text(originalText);
                }
            });
        });

    });

})(jQuery);
