/**
 * Additional Section JavaScript
 * Handles certificate selection, prerequisites, attachments, and live class scheduling
 *
 * @package TS_LMS
 * @version 1.0.0
 */

(function($) {
	'use strict';

	const AdditionalSection = {
		
		/**
		 * Initialize
		 */
		init: function() {
			this.certificateSelection();
			this.certificateTabs();
			this.certificateNavigation();
			this.certificatePreview();
			this.prerequisites();
			this.attachments();

			this.customCertificateUpload();
		},

		/**
		 * Custom Certificate Upload
		 */
		customCertificateUpload: function() {
			const self = this;
			let customCertUploader;

			$(document).on('click', '.ts-custom-cert-upload-btn', function(e) {
				e.preventDefault();

				if (customCertUploader) {
					customCertUploader.open();
					return;
				}

				customCertUploader = wp.media({
					title: 'Upload Custom Certificate',
					button: {
						text: 'Select Certificate'
					},
					library: {
						type: ['application/pdf', 'image/jpeg', 'image/png']
					},
					multiple: false
				});

				customCertUploader.on('select', function() {
					const attachment = customCertUploader.state().get('selection').first().toJSON();
					const $container = $('#ts-custom-cert-upload');
					const $hiddenInput = $('#custom-certificate-id');

					$hiddenInput.val(attachment.id);

					const html = `
						<div class="ts-uploaded-cert-container">
							<div class="ts-cert-file-preview">
								<span class="dashicons dashicons-media-document ts-cert-file-icon"></span>
								<div class="ts-cert-info">
									<span class="ts-cert-filename">${attachment.filename}</span>
									<a href="${attachment.url}" target="_blank" class="ts-cert-download-link">View/Download Certificate</a>
								</div>
							</div>
							<button type="button" class="ts-remove-custom-cert" title="Remove Certificate">
								<span class="dashicons dashicons-no-alt"></span>
							</button>
						</div>
					`;

					$container.html(html);
				});

				customCertUploader.open();
			});

			$(document).on('click', '.ts-remove-custom-cert', function(e) {
				e.preventDefault();
				if (confirm('Are you sure you want to remove this custom certificate?')) {
					const $container = $('#ts-custom-cert-upload');
					const $hiddenInput = $('#custom-certificate-id');

					$hiddenInput.val('');

					const html = `
						<div class="ts-upload-placeholder">
							<span class="dashicons dashicons-upload ts-upload-icon"></span>
							<button type="button" class="ts-custom-cert-upload-btn">Upload Custom Certificate</button>
							<p class="ts-upload-hint">Supported formats: PDF, JPEG, PNG</p>
						</div>
					`;

					$container.html(html);
				}
			});
		},

		/**
		 * Certificate Preview Interaction
		 */
		certificatePreview: function() {
			// Open Preview Modal
			$(document).on('click', '.ts-cert-preview-btn', function(e) {
				e.preventDefault();
				e.stopPropagation();

				const certId = $(this).data('cert-id');
				const $modal = $('#ts-cert-modal');
				const $content = $('#ts-cert-preview-content');

				// Ensure modal is visible and clean (overriding any fadeOut inline styles)
				$modal.stop(true, true).css('display', 'flex').addClass('active');

				// Show loading state
				$content.html(`
					<div class="ts-cert-loading">
						<div class="ts-spinner"></div>
						<p>${(tsLmsCourseEditor.strings && tsLmsCourseEditor.strings.generatingPreview) || 'Generating interactive preview...'}</p>
					</div>
				`);

				// Fetch certificate preview via AJAX
				$.ajax({
					url: tsLmsCourseEditor.ajaxUrl,
					type: 'POST',
					data: {
						action: 'ts_lms_get_cert_preview',
						nonce: tsLmsCourseEditor.nonce,
						cert_id: certId
					},
					success: function(response) {
						if (response.success && response.data.html) {
							// Load HTML into an iframe to isolate styles
							const iframe = document.createElement('iframe');
							iframe.className = 'ts-cert-preview-iframe';
							$content.html(iframe);
							
							const doc = iframe.contentWindow.document;
							doc.open();
							doc.write(response.data.html);
							doc.close();
						} else {
							$content.html('<p class="ts-error" style="padding: 20px; color: #ef4444; font-weight: 600;">' + (response.data.message || 'Error generating preview.') + '</p>');
						}
					},
					error: function() {
						$content.html('<p class="ts-error" style="padding: 20px; color: #ef4444; font-weight: 600;">Failed to connect to server. Please try again.</p>');
					}
				});
			});

			// Close Modal
			$(document).on('click', '#ts-cert-modal .ts-modal-close, #ts-cert-modal .ts-modal-overlay', function() {
				$('#ts-cert-modal').removeClass('active');
				$('#ts-cert-preview-content').empty();
			});

			// Close on ESC key
			$(document).on('keyup', function(e) {
				if (e.key === "Escape") {
					$('#ts-cert-modal').removeClass('active');
					$('#ts-cert-preview-content').empty();
				}
			});
		},

		/**
		 * Certificate Selection
		 */
		certificateSelection: function() {
			$(document).on('click', '.ts-cert-item', function() {
				const certId = $(this).data('cert-id');
				
				// Remove selected class from all items
				$('.ts-cert-item').removeClass('ts-cert-selected');
				$('.ts-cert-check').remove();
				
				// Add selected class to clicked item
				$(this).addClass('ts-cert-selected');
				
				// Add check mark
				$(this).append('<div class="ts-cert-check"><span class="dashicons dashicons-yes"></span></div>');
				
				// Update hidden input
				$('#course-selected-certificate').val(certId);
			});
		},

		/**
		 * Certificate Tabs
		 */
		certificateTabs: function() {
			$(document).on('click', '.ts-cert-tab', function() {
				const tab = $(this).data('tab');
				
				// Update tab buttons
				$('.ts-cert-tab').removeClass('ts-cert-tab-active');
				$(this).addClass('ts-cert-tab-active');
				
				// Update tab content
				$('.ts-cert-tab-content').removeClass('ts-cert-tab-content-active').hide();
				$(`.ts-cert-tab-content[data-tab="${tab}"]`).addClass('ts-cert-tab-content-active').show();
			});
		},

		/**
		 * Certificate Navigation
		 */
		certificateNavigation: function() {
			let currentScroll = 0;
			const scrollAmount = 300;

			$('#ts-cert-prev').on('click', function() {
				const grid = $('#ts-cert-grid');
				currentScroll = Math.max(0, currentScroll - scrollAmount);
				grid.animate({ scrollLeft: currentScroll }, 300);
			});

			$('#ts-cert-next').on('click', function() {
				const grid = $('#ts-cert-grid');
				const maxScroll = grid[0].scrollWidth - grid.width();
				currentScroll = Math.min(maxScroll, currentScroll + scrollAmount);
				grid.animate({ scrollLeft: currentScroll }, 300);
			});

			// Add/Delete certificate actions
			$('#ts-cert-add').on('click', function() {
				// TODO: Implement add certificate functionality
				console.log('Add certificate clicked');
			});

			$('#ts-cert-delete').on('click', function() {
				const selected = $('.ts-cert-selected');
				if (selected.length && selected.data('cert-id') !== 'none') {
					if (confirm('Are you sure you want to delete this certificate?')) {
						// TODO: Implement delete certificate functionality
						console.log('Delete certificate:', selected.data('cert-id'));
					}
				}
			});
		},

		/**
		 * Prerequisites
		 */
		prerequisites: function() {
			const self = this;
			const searchInput = $('#course-prerequisites-search');
			const emptyState = $('#ts-prerequisites-empty');
			const list = $('#ts-prerequisites-list');
			let searchTimeout;

			// Create search results container
			let $resultsContainer = $('.ts-prerequisites-search-results');
			if (!$resultsContainer.length) {
				$resultsContainer = $('<div class="ts-prerequisites-search-results"></div>');
				searchInput.parent().append($resultsContainer);
			}

			searchInput.on('input', function() {
				clearTimeout(searchTimeout);
				const query = $(this).val().trim();

				if (query.length < 1) {
					$resultsContainer.hide().empty();
					return;
				}

				searchTimeout = setTimeout(function() {
					$.ajax({
						url: tsLmsCourseEditor.ajaxUrl,
						type: 'POST',
						data: {
							action: 'ts_lms_search_courses',
							nonce: tsLmsCourseEditor.nonce,
							q: query,
							exclude: $('#course-id').val()
						},
						success: function(response) {
							if (response.success && response.data.results.length > 0) {
								let html = '';
								response.data.results.forEach(function(course) {
									// Don't show if already in the list
									if ($(`.ts-prerequisite-item[data-id="${course.id}"]`).length === 0) {
										html += `<div class="ts-search-result-item" data-id="${course.id}">${course.title}</div>`;
									}
								});
								
								if (html) {
									$resultsContainer.html(html).show();
								} else {
									$resultsContainer.hide().empty();
								}
							} else {
								$resultsContainer.hide().empty();
							}
						}
					});
				}, 300);
			});

			// Handle result selection
			$(document).on('click', '.ts-search-result-item', function() {
				const id = $(this).data('id');
				const title = $(this).text();

				$resultsContainer.hide().empty();
				searchInput.val('');

				const itemHtml = `
					<div class="ts-prerequisite-item" data-id="${id}">
						<span class="ts-prerequisite-title">${title}</span>
						<button type="button" class="ts-prerequisite-remove">
							<span class="dashicons dashicons-no-alt"></span>
						</button>
					</div>
				`;

				emptyState.hide();
				list.append(itemHtml).show();
				self.updatePrerequisiteIds();
			});

			// Close results on click outside
			$(document).on('click', function(e) {
				if (!$(e.target).closest('.ts-prerequisites-search').length) {
					$resultsContainer.hide().empty();
				}
			});

			// Remove prerequisite
			$(document).on('click', '.ts-prerequisite-remove', function() {
				$(this).closest('.ts-prerequisite-item').fadeOut(300, function() {
					$(this).remove();
					self.updatePrerequisiteIds();
					
					// Show empty state if no prerequisites
					if ($('.ts-prerequisite-item').length === 0) {
						list.hide();
						emptyState.show();
					}
				});
			});
		},

		/**
		 * Update Prerequisite IDs
		 */
		updatePrerequisiteIds: function() {
			const ids = [];
			$('.ts-prerequisite-item').each(function() {
				const id = $(this).attr('data-id');
				if (id) ids.push(id);
			});
			$('#course-prerequisites-ids').val(ids.join(','));
		},

		/**
		 * Attachments
		 */
		attachments: function() {
			let mediaUploader;

			$('#ts-upload-attachment').on('click', function(e) {
				e.preventDefault();

				// If the uploader object has already been created, reopen the dialog
				if (mediaUploader) {
					mediaUploader.open();
					return;
				}

				// Extend the wp.media object
				mediaUploader = wp.media({
					title: 'Upload Attachment',
					button: {
						text: 'Select Attachment'
					},
					library: {
						type: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip']
					},
					multiple: true
				});

				// When files are selected
				mediaUploader.on('select', function() {
					const attachments = mediaUploader.state().get('selection').toJSON();
					const list = $('#ts-attachments-list');

					attachments.forEach(function(attachment) {
						// Add attachment to list
						const item = $(`
							<div class="ts-attachment-item" data-id="${attachment.id}">
								<div class="ts-attachment-icon">
									<span class="dashicons dashicons-media-document"></span>
								</div>
								<div class="ts-attachment-info">
									<div class="ts-attachment-name">${attachment.filename}</div>
									<div class="ts-attachment-size">${formatFileSize(attachment.filesizeInBytes)}</div>
								</div>
								<button type="button" class="ts-attachment-remove">
									<span class="dashicons dashicons-no-alt"></span>
								</button>
							</div>
						`);

						list.append(item);
					});
					this.updateAttachmentIds();
				});

				// Open the uploader dialog
				mediaUploader.open();
			});

			// Remove attachment
			$(document).on('click', '.ts-attachment-remove', function() {
				const $item = $(this).closest('.ts-attachment-item');
				$item.fadeOut(300, function() {
					$item.remove();
					AdditionalSection.updateAttachmentIds();
				});
			});
		},

		/**
		 * Update Attachment IDs hidden field
		 */
		updateAttachmentIds: function() {
			const ids = [];
			$('.ts-attachment-item').each(function() {
				const id = $(this).attr('data-id');
				if (id) ids.push(id);
			});
			$('#course-attachments-ids').val(ids.join(','));
		},

		/**
		 * Helper function to format file size
		 */
		formatFileSize: function(bytes) {
			if (bytes === 0) return '0 Bytes';
			const k = 1024;
			const sizes = ['Bytes', 'KB', 'MB', 'GB'];
			const i = Math.floor(Math.log(bytes) / Math.log(k));
			return (Math.round(bytes / Math.pow(k, i) * 100) / 100) + ' ' + sizes[i];
		}
	};

	// Initialize when document is ready
	$(document).ready(function() {
		AdditionalSection.init();
	});

})(jQuery);
