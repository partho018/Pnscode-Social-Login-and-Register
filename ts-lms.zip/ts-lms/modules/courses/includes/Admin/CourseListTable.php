<?php
/**
 * Course List Table Customization
 *
 * Customizes the WordPress admin list table for courses.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Admin;

use TS_LMS\Modules\Courses\PostTypes\Course;
use TS_LMS\Modules\Courses\Managers\CourseManager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CourseListTable class.
 */
class CourseListTable {

	/**
	 * Initialize the course list table customizations.
	 *
	 * @return void
	 */
	public static function init() {
		// Add custom columns
		add_filter( 'manage_ts_course_posts_columns', array( __CLASS__, 'add_columns' ) );
		add_action( 'manage_ts_course_posts_custom_column', array( __CLASS__, 'render_column' ), 10, 2 );
		
		// Make columns sortable
		add_filter( 'manage_edit-ts_course_sortable_columns', array( __CLASS__, 'sortable_columns' ) );
		
		// Customize row actions
		add_filter( 'post_row_actions', array( __CLASS__, 'customize_row_actions' ), 10, 2 );
		
		// Add inline CSS for title column customization
		add_action( 'admin_head-edit.php', array( __CLASS__, 'add_inline_title_customization' ) );
		
		// Add custom buttons to page header
		add_action( 'admin_head-edit.php', array( __CLASS__, 'add_header_buttons' ) );
		
		// Enqueue admin assets
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		
		// Handle AJAX status change
		add_action( 'wp_ajax_ts_lms_change_course_status', array( __CLASS__, 'ajax_change_status' ) );
	}

	/**
	 * Define custom columns.
	 *
	 * @param array $columns Existing columns.
	 * @return array Modified columns.
	 */
	public static function add_columns( $columns ) {
		// Remove default columns
		unset( $columns['date'] );
		unset( $columns['author'] );
		
		// Build new column structure (thumbnail integrated with title)
		$new_columns = array(
			'cb'         => $columns['cb'],
			'title'      => $columns['title'],
			'categories' => __( 'Categories', 'ts-lms' ),
			'price'      => __( 'Price', 'ts-lms' ),
			'author'     => __( 'Author', 'ts-lms' ),
			'date'       => __( 'Date', 'ts-lms' ),
		);
		
		return $new_columns;
	}

	/**
	 * Render custom column content.
	 *
	 * @param string $column  Column name.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public static function render_column( $column, $post_id ) {
		switch ( $column ) {
			case 'categories':
				self::render_categories( $post_id );
				break;
				
			case 'price':
				self::render_price( $post_id );
				break;
				
			case 'author':
				self::render_author( $post_id );
				break;
				
			case 'date':
				self::render_date( $post_id );
				break;
		}
	}

	/**
	 * Render thumbnail column.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function render_thumbnail( $post_id ) {
		$thumbnail = get_the_post_thumbnail( $post_id, array( 80, 80 ), array( 'class' => 'ts-course-thumbnail' ) );
		
		if ( $thumbnail ) {
			echo $thumbnail;
		} else {
			echo '<div class="ts-course-thumbnail-placeholder">';
			echo '<span class="dashicons dashicons-welcome-learn-more"></span>';
			echo '</div>';
		}
		
		// Add course metadata badges
		self::render_metadata_badges( $post_id );
	}

	/**
	 * Render metadata badges (topics, lessons, quizzes, assignments).
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function render_metadata_badges( $post_id ) {
		// Get lesson count
		$lessons = get_posts( array(
			'post_type'      => 'ts_lesson',
			'posts_per_page' => -1,
			'meta_query'     => array(
				array(
					'key'   => '_lesson_course_id',
					'value' => $post_id,
				),
			),
			'fields'         => 'ids',
		) );
		
		$lesson_count = count( $lessons );
		
		// Get quiz count (from meta or related quizzes)
		$quiz_count = absint( get_post_meta( $post_id, '_course_quiz_count', true ) );
		
		// Get assignment count
		$assignment_count = absint( get_post_meta( $post_id, '_course_assignment_count', true ) );
		
		// Get topic count (could be categories or custom taxonomy)
		$topics = wp_get_post_terms( $post_id, 'ts_course_category' );
		$topic_count = is_array( $topics ) ? count( $topics ) : 0;
		
		echo '<div class="ts-course-meta-badges">';
		
		if ( $topic_count > 0 ) {
			echo '<span class="ts-meta-badge ts-badge-topic">';
			echo '<span class="dashicons dashicons-category"></span> ';
			echo sprintf( __( 'Topic: %d', 'ts-lms' ), $topic_count );
			echo '</span>';
		}
		
		if ( $lesson_count > 0 ) {
			echo '<span class="ts-meta-badge ts-badge-lesson">';
			echo '<span class="dashicons dashicons-media-document"></span> ';
			echo sprintf( __( 'Lesson: %d', 'ts-lms' ), $lesson_count );
			echo '</span>';
		}
		
		if ( $quiz_count > 0 ) {
			echo '<span class="ts-meta-badge ts-badge-quiz">';
			echo '<span class="dashicons dashicons-forms"></span> ';
			echo sprintf( __( 'Quiz: %d', 'ts-lms' ), $quiz_count );
			echo '</span>';
		}
		
		if ( $assignment_count > 0 ) {
			echo '<span class="ts-meta-badge ts-badge-assignment">';
			echo '<span class="dashicons dashicons-edit"></span> ';
			echo sprintf( __( 'Assignment: %d', 'ts-lms' ), $assignment_count );
			echo '</span>';
		}
		
		echo '</div>';
	}

	/**
	 * Add inline JavaScript to customize title column.
	 *
	 * @return void
	 */
	public static function add_inline_title_customization() {
		global $typenow;
		
		if ( $typenow !== 'ts_course' ) {
			return;
		}
		
		// Get all courses on current page
		global $wp_query;
		$courses = array();
		
		if ( isset( $_GET['post_type'] ) && $_GET['post_type'] === 'ts_course' ) {
			$args = array(
				'post_type' => 'ts_course',
				'posts_per_page' => 20,
				'paged' => isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1,
			);
			
			$query = new \WP_Query( $args );
			
			if ( $query->have_posts() ) {
				while ( $query->have_posts() ) {
					$query->the_post();
					$post_id = get_the_ID();
					
					// Get thumbnail
					$thumbnail_url = get_the_post_thumbnail_url( $post_id, array( 60, 60 ) );
					
					// Get metadata
					$lessons = get_posts( array(
						'post_type' => 'ts_lesson',
						'posts_per_page' => -1,
						'meta_query' => array(
							array(
								'key' => '_lesson_course_id',
								'value' => $post_id,
							),
						),
						'fields' => 'ids',
					) );
					
					$lesson_count = count( $lessons );
					$quiz_count = absint( get_post_meta( $post_id, '_course_quiz_count', true ) );
					$assignment_count = absint( get_post_meta( $post_id, '_course_assignment_count', true ) );
					$topics = wp_get_post_terms( $post_id, 'ts_course_category' );
					$topic_count = is_array( $topics ) ? count( $topics ) : 0;
					
					$courses[ $post_id ] = array(
						'thumbnail' => $thumbnail_url,
						'topic_count' => $topic_count,
						'lesson_count' => $lesson_count,
						'quiz_count' => $quiz_count,
						'assignment_count' => $assignment_count,
					);
				}
				wp_reset_postdata();
			}
		}
		?>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			var courseData = <?php echo wp_json_encode( $courses ); ?>;
			
			// Customize each course title
			$.each(courseData, function(postId, data) {
				var $titleCell = $('#post-' + postId + ' .column-title');
				var $titleStrong = $titleCell.find('.row-title');
				
				if ($titleStrong.length) {
					var titleHtml = $titleStrong.parent().html();
					
					// Build thumbnail HTML
					var thumbnailHtml = '';
					if (data.thumbnail) {
						thumbnailHtml = '<div class="ts-thumb-wrapper"><img src="' + data.thumbnail + '" class="ts-course-thumb-small" /></div>';
					} else {
						thumbnailHtml = '<div class="ts-thumb-wrapper"><div class="ts-course-thumb-placeholder"><span class="dashicons dashicons-welcome-learn-more"></span></div></div>';
					}
					
					// Build badges HTML
					var badgesHtml = '<div class="ts-course-badges-inline">';
					if (data.topic_count > 0) {
						badgesHtml += '<span class="ts-badge-inline ts-badge-topic"><span class="dashicons dashicons-category"></span> Topic: ' + data.topic_count + '</span>';
					}
					if (data.lesson_count > 0) {
						badgesHtml += '<span class="ts-badge-inline ts-badge-lesson"><span class="dashicons dashicons-media-document"></span> Lesson: ' + data.lesson_count + '</span>';
					}
					if (data.quiz_count > 0) {
						badgesHtml += '<span class="ts-badge-inline ts-badge-quiz"><span class="dashicons dashicons-forms"></span> Quiz: ' + data.quiz_count + '</span>';
					}
					if (data.assignment_count > 0) {
						badgesHtml += '<span class="ts-badge-inline ts-badge-assignment"><span class="dashicons dashicons-edit"></span> Assignment: ' + data.assignment_count + '</span>';
					}
					badgesHtml += '</div>';
					
					// Wrap title with thumbnail
					var newHtml = '<div class="ts-title-with-thumb">' + thumbnailHtml + '<div class="ts-title-wrapper-content">' + titleHtml + badgesHtml + '</div></div>';
					
					$titleCell.html(newHtml);
				}
			});
		});
		</script>
		<?php
	}

	/**
	 * Customize row actions.
	 *
	 * @param array   $actions Row actions.
	 * @param WP_Post $post    Post object.
	 * @return array Modified actions.
	 */
	public static function customize_row_actions( $actions, $post ) {
		if ( $post->post_type !== 'ts_course' ) {
			return $actions;
		}
		
		// Keep only Edit and Trash actions
		$new_actions = array();
		
		if ( isset( $actions['edit'] ) ) {
			$new_actions['edit'] = $actions['edit'];
		}
		
		if ( isset( $actions['trash'] ) ) {
			$new_actions['trash'] = $actions['trash'];
		}
		
		return $new_actions;
	}

	/**
	 * Render categories column.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function render_categories( $post_id ) {
		$terms = get_the_terms( $post_id, 'ts_course_category' );
		
		if ( $terms && ! is_wp_error( $terms ) ) {
			$term_links = array();
			foreach ( $terms as $term ) {
				$term_links[] = sprintf(
					'<a href="%s">%s</a>',
					esc_url( add_query_arg( array( 'ts_course_category' => $term->slug ), 'edit.php?post_type=ts_course' ) ),
					esc_html( $term->name )
				);
			}
			echo implode( ', ', $term_links );
		} else {
			echo '—';
		}
	}

	/**
	 * Render price column.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function render_price( $post_id ) {
		// Check if WooCommerce product is linked
		$product_id = get_post_meta( $post_id, '_course_product_id', true );
		
		// Also check legacy meta key for backward compatibility
		if ( ! $product_id ) {
			$product_id = get_post_meta( $post_id, '_linked_product_id', true );
		}
		
		// Validate that product ID is not empty and is a valid number
		if ( $product_id && is_numeric( $product_id ) && $product_id > 0 ) {
			// Verify the product actually exists
			if ( class_exists( 'WooCommerce' ) && function_exists( 'wc_get_product' ) ) {
				$product = wc_get_product( $product_id );
				if ( $product && $product->exists() ) {
					// Display "Paid" if a valid WooCommerce product is linked
					echo '<span class="ts-price-paid">' . __( 'Paid', 'ts-lms' ) . '</span>';
					return;
				}
			}
		}
		
		// Default to "Free"
		echo '<span class="ts-price-free">' . __( 'Free', 'ts-lms' ) . '</span>';
	}

	/**
	 * Render author column with avatar.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function render_author( $post_id ) {
		$post = get_post( $post_id );
		$author_id = $post->post_author;
		$author = get_userdata( $author_id );
		
		if ( $author ) {
			echo '<div class="ts-author-cell">';
			echo get_avatar( $author_id, 32, '', '', array( 'class' => 'ts-author-avatar' ) );
			echo '<span class="ts-author-name">' . esc_html( $author->display_name ) . '</span>';
			echo '</div>';
		}
	}

	/**
	 * Render date column with status dropdown.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function render_date( $post_id ) {
		$post = get_post( $post_id );
		
		// Display date
		echo '<div class="ts-date-cell">';
		echo '<div class="ts-post-date">';
		echo esc_html( get_the_date( 'F j, Y', $post_id ) );
		echo '<br>';
		echo '<span class="ts-post-time">' . esc_html( get_the_time( 'g:i a', $post_id ) ) . '</span>';
		echo '</div>';
		
		// Display status dropdown
		$current_status = $post->post_status;
		$status_label = $current_status === 'publish' ? __( 'Publish', 'ts-lms' ) : __( 'Draft', 'ts-lms' );
		$status_class = $current_status === 'publish' ? 'ts-status-publish' : 'ts-status-draft';
		
		echo '<div class="ts-status-dropdown">';
		echo '<select class="ts-status-select ' . esc_attr( $status_class ) . '" data-post-id="' . esc_attr( $post_id ) . '">';
		echo '<option value="draft"' . selected( $current_status, 'draft', false ) . '>' . __( 'Draft', 'ts-lms' ) . '</option>';
		echo '<option value="publish"' . selected( $current_status, 'publish', false ) . '>' . __( 'Publish', 'ts-lms' ) . '</option>';
		echo '</select>';
		echo '</div>';
		
		// Add View and More actions
		echo '<div class="ts-row-actions">';
		
		// View button
		if ( $current_status === 'publish' ) {
			echo '<a href="' . esc_url( get_permalink( $post_id ) ) . '" class="ts-btn-view" target="_blank">';
			echo __( 'View', 'ts-lms' );
			echo '</a>';
		}
		
		// More actions (three dots)
		echo '<span class="ts-more-actions">';
		echo '<span class="dashicons dashicons-ellipsis"></span>';
		echo '</span>';
		
		echo '</div>';
		echo '</div>';
	}

	/**
	 * Make columns sortable.
	 *
	 * @param array $columns Sortable columns.
	 * @return array Modified sortable columns.
	 */
	public static function sortable_columns( $columns ) {
		$columns['date'] = 'date';
		$columns['author'] = 'author';
		return $columns;
	}

	/**
	 * Add custom buttons to page header.
	 *
	 * @return void
	 */
	public static function add_header_buttons() {
		return;
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		// Only load on course list page
		if ( $hook !== 'edit.php' ) {
			return;
		}
		
		global $typenow;
		if ( $typenow !== 'ts_course' ) {
			return;
		}
		
		// Enqueue custom CSS for course list table
		wp_enqueue_style(
			'ts-lms-admin-course-list',
			plugin_dir_url( dirname( dirname( dirname( __FILE__ ) ) ) ) . 'assets/css/admin-course-list.css',
			array(),
			'1.0.0'
		);
		
		// Assets are already enqueued globally, but we can add specific scripts here if needed
		wp_localize_script( 'ts-lms-admin-script', 'tsLmsCourseList', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'ts_lms_course_list' ),
		) );
	}

	/**
	 * Handle AJAX status change.
	 *
	 * @return void
	 */
	public static function ajax_change_status() {
		check_ajax_referer( 'ts_lms_course_list', 'nonce' );
		
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'ts-lms' ) ) );
		}
		
		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		$new_status = isset( $_POST['status'] ) ? sanitize_text_field( $_POST['status'] ) : '';
		
		if ( ! $post_id || ! in_array( $new_status, array( 'draft', 'publish' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid parameters', 'ts-lms' ) ) );
		}
		
		// Update post status
		$result = wp_update_post( array(
			'ID'          => $post_id,
			'post_status' => $new_status,
		) );
		
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		
		wp_send_json_success( array(
			'message' => __( 'Status updated successfully', 'ts-lms' ),
			'status'  => $new_status,
		) );
	}
}
