<?php
/**
 * Editor Redirect Handler
 *
 * Redirects users from WordPress default editors to custom editors.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * EditorRedirect class.
 */
class EditorRedirect {

	/**
	 * Initialize the editor redirect.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'redirect_to_custom_editor' ) );
		add_filter( 'get_edit_post_link', array( __CLASS__, 'modify_edit_link' ), 10, 3 );
	}

	/**
	 * Redirect from WordPress default editor to custom editor.
	 *
	 * @return void
	 */
	public static function redirect_to_custom_editor() {
		global $pagenow;

		// Check if we're on post.php or post-new.php
		if ( ! in_array( $pagenow, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}

		// Get post type
		$post_type = '';
		
		if ( 'post-new.php' === $pagenow && isset( $_GET['post_type'] ) ) {
			$post_type = sanitize_text_field( $_GET['post_type'] );
		} elseif ( 'post.php' === $pagenow && isset( $_GET['post'] ) ) {
			$post_id = absint( $_GET['post'] );
			$post_type = get_post_type( $post_id );
		}

		// Redirect based on post type
		if ( 'ts_course' === $post_type ) {
			$redirect_url = admin_url( 'admin.php?page=ts-lms-course-editor' );
			
			// Add post ID if editing
			if ( 'post.php' === $pagenow && isset( $_GET['post'] ) ) {
				$redirect_url = add_query_arg( 'course_id', absint( $_GET['post'] ), $redirect_url );
			}
			
			wp_safe_redirect( $redirect_url );
			exit;
		} elseif ( 'ts_bundle' === $post_type ) {
			$redirect_url = admin_url( 'admin.php?page=ts-lms-bundle-editor' );
			
			// Add post ID if editing
			if ( 'post.php' === $pagenow && isset( $_GET['post'] ) ) {
				$redirect_url = add_query_arg( 'bundle_id', absint( $_GET['post'] ), $redirect_url );
			}
			
			wp_safe_redirect( $redirect_url );
			exit;
		}
	}

	/**
	 * Modify edit links to point to custom editors.
	 *
	 * @param string $link    The edit link.
	 * @param int    $post_id Post ID.
	 * @param string $context The link context.
	 * @return string Modified link.
	 */
	public static function modify_edit_link( $link, $post_id, $context ) {
		$post_type = get_post_type( $post_id );

		if ( 'ts_course' === $post_type ) {
			$link = admin_url( 'admin.php?page=ts-lms-course-editor&course_id=' . $post_id );
		} elseif ( 'ts_bundle' === $post_type ) {
			$link = admin_url( 'admin.php?page=ts-lms-bundle-editor&bundle_id=' . $post_id );
		}

		return $link;
	}
}
