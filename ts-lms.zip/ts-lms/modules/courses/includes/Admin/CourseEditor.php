<?php
/**
 * Custom Course Editor
 *
 * Handles the custom course creation and editing interface.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CourseEditor class.
 */
class CourseEditor {

	/**
	 * Page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'ts-lms-course-editor';

	/**
	 * Initialize the course editor.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 99 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_ajax_ts_lms_save_course', array( __CLASS__, 'ajax_save_course' ) );
		add_action( 'wp_ajax_ts_lms_upload_course_image', array( __CLASS__, 'ajax_upload_image' ) );
		add_action( 'wp_ajax_ts_lms_add_category_editor', array( __CLASS__, 'ajax_add_category_editor' ) );
		add_action( 'wp_ajax_ts_lms_add_tag_editor', array( __CLASS__, 'ajax_add_tag_editor' ) );
		add_action( 'wp_ajax_ts_lms_filter_products_by_title', array( __CLASS__, 'ajax_filter_products_by_title' ) );
		add_action( 'wp_ajax_ts_lms_search_courses', array( __CLASS__, 'ajax_search_courses' ) );
		add_filter( 'admin_body_class', array( __CLASS__, 'add_body_class' ) );
		// Initialize Curriculum AJAX
		CurriculumAjax::init();
	}

	/**
	 * Register admin menu.
	 *
	 * @return void
	 */
	public static function register_menu() {
		add_submenu_page(
			null, // Hidden from menu
			__( 'Course Editor', 'ts-lms' ),
			__( 'Course Editor', 'ts-lms' ),
			'edit_ts_courses',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Add custom body class for fullscreen mode.
	 *
	 * @param string $classes Current body classes.
	 * @return string Modified body classes.
	 */
	public static function add_body_class( $classes ) {
		$screen = get_current_screen();
		
		if ( $screen && strpos( $screen->id, self::PAGE_SLUG ) !== false ) {
			$classes .= ' ts-lms-fullscreen';
		}
		
		return $classes;
	}

	/**
	 * Enqueue page assets.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( strpos( $hook, self::PAGE_SLUG ) === false ) {
			return;
		}

		// Enqueue WordPress media uploader
		wp_enqueue_media();

		// Enqueue CSS
		wp_enqueue_style(
			'ts-lms-course-editor',
			plugin_dir_url( __FILE__ ) . 'assets/css/course-editor.css',
			array(),
			time() // Cache buster
		);

		// Enqueue Assignment Modal CSS
		wp_enqueue_style(
			'ts-lms-assignment-modal',
			plugin_dir_url( __FILE__ ) . 'assets/css/assignment-modal.css',
			array(),
			'1.0.0'
		);

		// Enqueue Additional Section CSS
		wp_enqueue_style(
			'ts-lms-additional-section',
			plugin_dir_url( __FILE__ ) . 'assets/css/additional-section.css',
			array( 'ts-lms-course-editor' ),
			time() // Cache buster
		);

		// Enqueue Toast CSS
		wp_enqueue_style(
			'ts-lms-toast',
			plugin_dir_url( __FILE__ ) . 'assets/css/toast.css',
			array(),
			time() // Cache buster
		);


		// Enqueue JavaScript
		wp_enqueue_script(
			'ts-lms-course-editor',
			plugin_dir_url( __FILE__ ) . 'assets/js/course-editor.js',
			array( 'jquery', 'jquery-ui-sortable' ),
			time(), // Cache buster - always load fresh version
			true
		);

		// Enqueue Course Editor Helpers
		wp_enqueue_script(
			'ts-lms-course-editor-helpers',
			plugin_dir_url( __FILE__ ) . 'assets/js/course-editor-helpers.js',
			array( 'jquery', 'ts-lms-course-editor' ),
			time(), // Cache buster
			true
		);

		// Enqueue Assignment Modal JavaScript
		wp_enqueue_script(
			'ts-lms-assignment-modal',
			plugin_dir_url( __FILE__ ) . 'assets/js/assignment-modal.js',
			array( 'jquery' ),
			'1.0.0',
			true
		);

		// Enqueue Additional Section JavaScript
		wp_enqueue_script(
			'ts-lms-additional-section',
			plugin_dir_url( __FILE__ ) . 'assets/js/additional-section.js',
			array( 'jquery', 'ts-lms-course-editor' ),
			time(), // Cache buster
			true
		);


		// Localize script
		wp_localize_script(
			'ts-lms-course-editor',
			'tsLmsCourseEditor',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'ts_lms_course_editor' ),
				'listUrl'    => admin_url( 'admin.php?page=ts-lms-courses' ),
				'editUrl'    => admin_url( 'admin.php?page=' . self::PAGE_SLUG ),
				'hasZoomApi' => (bool) ( get_option( 'ts_lms_zoom_account_id' ) && get_option( 'ts_lms_zoom_client_id' ) && get_option( 'ts_lms_zoom_client_secret' ) ),
				'hasMeetApi' => (bool) ( get_option( 'ts_lms_google_meet_client_id' ) && get_option( 'ts_lms_google_meet_client_secret' ) ),
				'zoomSettingsUrl' => admin_url( 'admin.php?page=ts-lms-zoom' ),
				'meetSettingsUrl' => admin_url( 'admin.php?page=ts-lms-google-meet' ),
				'strings'    => array(
					'saving'       => __( 'Saving...', 'ts-lms' ),
					'saved'        => __( 'Course saved successfully!', 'ts-lms' ),
					'error'        => __( 'An error occurred. Please try again.', 'ts-lms' ),
					'confirmLeave' => __( 'You have unsaved changes. Are you sure you want to leave?', 'ts-lms' ),
				),
			)
		);
	}

	/**
	 * Render the course editor page.
	 *
	 * @return void
	 */
	public static function render_page() {
		// Get course ID if editing
		$course_id = isset( $_GET['course_id'] ) ? absint( $_GET['course_id'] ) : 0;
		$course = null;
		$course_data = array();

		if ( $course_id ) {
			$course = get_post( $course_id );
			
			if ( ! $course || 'ts_course' !== $course->post_type ) {
				wp_die( __( 'Invalid course ID.', 'ts-lms' ) );
			}

			// Get course metadata
			$course_data = array(
				'title'        => $course->post_title,
				'description'  => $course->post_content,
				'excerpt'      => $course->post_excerpt,
				'thumbnail_id' => get_post_thumbnail_id( $course_id ),
				'status'       => $course->post_status,
				'price'        => get_post_meta( $course_id, '_course_price', true ),
				'duration'     => get_post_meta( $course_id, '_course_duration', true ),
				'level'        => get_post_meta( $course_id, '_course_level', true ),
				'max_students' => get_post_meta( $course_id, '_course_max_students', true ),
			);
		}

		// Load template
		include __DIR__ . '/templates/course-editor.php';
	}

	/**
	 * Handle AJAX save course.
	 *
	 * @return void
	 */
	public static function ajax_save_course() {
		check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

		if ( ! current_user_can( 'edit_ts_courses' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'ts-lms' ) ) );
		}

		$course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;
		$title = isset( $_POST['title'] ) ? sanitize_text_field( $_POST['title'] ) : '';
		$slug = isset( $_POST['slug'] ) ? sanitize_title( $_POST['slug'] ) : '';
		$description = isset( $_POST['description'] ) ? wp_kses_post( $_POST['description'] ) : '';
		$excerpt = isset( $_POST['excerpt'] ) ? sanitize_textarea_field( $_POST['excerpt'] ) : '';
		
		// Get settings for instructor permissions
		$settings = \TS_LMS\Admin\Settings::get_settings();
		$current_user = wp_get_current_user();
		$is_instructor = in_array( 'instructor', (array) $current_user->roles ) && ! current_user_can( 'manage_options' );
		
		// Determine status: use POST if set, otherwise keep existing if update, else draft
		if ( isset( $_POST['status'] ) ) {
			$status = sanitize_text_field( $_POST['status'] );
			
			// Check if instructor is allowed to publish courses
			if ( $is_instructor && $status === 'publish' ) {
				$allow_publish = isset( $settings['allow_publish_courses'] ) && $settings['allow_publish_courses'];
				if ( ! $allow_publish ) {
					// Force to pending status if instructor is not allowed to publish
					$status = 'pending';
				}
			}
		} elseif ( $course_id ) {
			$status = get_post_status( $course_id );
		} else {
			$status = 'draft';
		}

		$thumbnail_id = isset( $_POST['thumbnail_id'] ) ? absint( $_POST['thumbnail_id'] ) : 0;

		// Validate
		if ( empty( $title ) ) {
			wp_send_json_error( array( 'message' => __( 'Course title is required', 'ts-lms' ) ) );
		}

		// Prepare post data
		// Prepare post data
		$post_data = array(
			'post_title'   => $title,
			'post_name'    => $slug,
			'post_content' => $description,
			'post_excerpt' => $excerpt,
			'post_status'  => $status,
			'post_type'    => 'ts_course',
		);

		if ( isset( $_POST['post_author'] ) ) {
			$new_author = absint( $_POST['post_author'] );
			
			// Check if instructor is allowed to change author
			if ( $is_instructor ) {
				$allow_change_author = isset( $settings['allow_change_author'] ) && $settings['allow_change_author'];
				$current_author = $course_id ? get_post_field( 'post_author', $course_id ) : get_current_user_id();
				
				if ( ! $allow_change_author && $new_author != $current_author ) {
					// Don't allow author change - keep current author
					$post_data['post_author'] = $current_author;
				} else {
					$post_data['post_author'] = $new_author;
				}
			} else {
				// Admin can change author freely
				$post_data['post_author'] = $new_author;
			}
		} elseif ( ! $course_id ) {
			$post_data['post_author'] = get_current_user_id();
		}

		// Update or create
		if ( $course_id ) {
			$post_data['ID'] = $course_id;
			$result = wp_update_post( $post_data, true );
		} else {
			$result = wp_insert_post( $post_data, true );
		}

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		$course_id = $result;

		// Set thumbnail
		if ( $thumbnail_id ) {
			set_post_thumbnail( $course_id, $thumbnail_id );
		} else {
			delete_post_thumbnail( $course_id );
		}

		// --- Save Meta Fields ---

		// Options
		if ( isset( $_POST['difficulty_level'] ) ) update_post_meta( $course_id, '_course_level', sanitize_text_field( $_POST['difficulty_level'] ) );
		if ( isset( $_POST['public_course'] ) ) update_post_meta( $course_id, '_public_course', absint( $_POST['public_course'] ) );
		if ( isset( $_POST['qa_enabled'] ) ) update_post_meta( $course_id, '_qa_enabled', absint( $_POST['qa_enabled'] ) );
		if ( isset( $_POST['content_drip_type'] ) ) update_post_meta( $course_id, '_content_drip_type', sanitize_text_field( $_POST['content_drip_type'] ) );

		// Enrollment
		if ( isset( $_POST['max_students'] ) ) update_post_meta( $course_id, '_course_max_students', absint( $_POST['max_students'] ) );
		if ( isset( $_POST['enrollment_period_enabled'] ) ) update_post_meta( $course_id, '_enrollment_period_enabled', absint( $_POST['enrollment_period_enabled'] ) );
		if ( isset( $_POST['pause_enrollment'] ) ) update_post_meta( $course_id, '_pause_enrollment', absint( $_POST['pause_enrollment'] ) );

		// Sidebar
		if ( isset( $_POST['is_scheduled'] ) ) update_post_meta( $course_id, '_is_scheduled', absint( $_POST['is_scheduled'] ) );
		
		// Video
		if ( isset( $_POST['video_source'] ) ) update_post_meta( $course_id, '_course_intro_video_source', sanitize_text_field( $_POST['video_source'] ) );
		if ( isset( $_POST['video_url'] ) ) update_post_meta( $course_id, '_course_intro_video_url', esc_url_raw( $_POST['video_url'] ) );

		// Pricing
		if ( isset( $_POST['pricing_model'] ) ) update_post_meta( $course_id, '_course_price_type', sanitize_text_field( $_POST['pricing_model'] ) );
		if ( isset( $_POST['course_product'] ) ) update_post_meta( $course_id, '_course_product_id', absint( $_POST['course_product'] ) );
		
		// Subscription
		if ( isset( $_POST['subscription_plan_type'] ) ) update_post_meta( $course_id, '_subscription_plan_type', sanitize_text_field( $_POST['subscription_plan_type'] ) );
		
		// Auto-sync subscription price from product if linked
		if ( isset( $_POST['pricing_model'] ) && $_POST['pricing_model'] === 'subscription' ) {
			$product_id = isset( $_POST['course_product'] ) ? absint( $_POST['course_product'] ) : 0;
			if ( $product_id && function_exists( 'wc_get_product' ) ) {
				$product = wc_get_product( $product_id );
				if ( $product ) {
					update_post_meta( $course_id, '_subscription_price', $product->get_price() );
				}
			}
		} elseif ( isset( $_POST['subscription_price'] ) ) {
			update_post_meta( $course_id, '_subscription_price', sanitize_text_field( $_POST['subscription_price'] ) );
		}
		
		if ( isset( $_POST['subscription_scope'] ) ) update_post_meta( $course_id, '_subscription_scope', sanitize_text_field( $_POST['subscription_scope'] ) );

		// Additional Info
		if ( isset( $_POST['what_will_learn'] ) ) update_post_meta( $course_id, '_what_will_learn', wp_kses_post( $_POST['what_will_learn'] ) );
		if ( isset( $_POST['target_audience'] ) ) update_post_meta( $course_id, '_target_audience', wp_kses_post( $_POST['target_audience'] ) );
		if ( isset( $_POST['materials_included'] ) ) update_post_meta( $course_id, '_materials_included', wp_kses_post( $_POST['materials_included'] ) );
		if ( isset( $_POST['requirements_instructions'] ) ) update_post_meta( $course_id, '_requirements_instructions', wp_kses_post( $_POST['requirements_instructions'] ) );
		
		// Duration
		$h = isset( $_POST['total_duration_hours'] ) ? absint( $_POST['total_duration_hours'] ) : 0;
		$m = isset( $_POST['total_duration_minutes'] ) ? absint( $_POST['total_duration_minutes'] ) : 0;
		update_post_meta( $course_id, '_total_duration_hours', $h );
		update_post_meta( $course_id, '_total_duration_minutes', $m );
		
		// Certificate
		if ( isset( $_POST['selected_certificate'] ) ) update_post_meta( $course_id, '_selected_certificate', sanitize_text_field( $_POST['selected_certificate'] ) );
		if ( isset( $_POST['custom_certificate_id'] ) ) update_post_meta( $course_id, '_custom_certificate_id', absint( $_POST['custom_certificate_id'] ) );
		
		// Prerequisite Courses
		if ( isset( $_POST['prerequisites'] ) ) {
			$prerequisite_ids = is_array( $_POST['prerequisites'] ) ? $_POST['prerequisites'] : explode( ',', $_POST['prerequisites'] );
			$prerequisite_ids = array_filter( array_map( 'absint', $prerequisite_ids ) );
			update_post_meta( $course_id, '_course_prerequisites', $prerequisite_ids );
		} else {
			delete_post_meta( $course_id, '_course_prerequisites' );
		}

		// Attachments


		// --- Save Taxonomies ---

		// Categories
		if ( isset( $_POST['categories'] ) && is_array( $_POST['categories'] ) ) {
			$cat_ids = array_map( 'absint', $_POST['categories'] );
			wp_set_object_terms( $course_id, $cat_ids, 'ts_course_category' );
		} else {
			wp_set_object_terms( $course_id, array(), 'ts_course_category' ); // Clear if empty
		}

		// Tags
		if ( isset( $_POST['tags'] ) && is_array( $_POST['tags'] ) ) {
			$tag_ids = array_map( 'absint', $_POST['tags'] );
			wp_set_object_terms( $course_id, $tag_ids, 'ts_course_tag' );
		} else {
			wp_set_object_terms( $course_id, array(), 'ts_course_tag' );
		}

		// Fire saved action
		do_action( 'ts_lms_course_saved', $course_id, get_post( $course_id ) );

		wp_send_json_success( array(
			'message'   => __( 'Course saved successfully', 'ts-lms' ),
			'course_id' => $course_id,
			'edit_url'  => admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&course_id=' . $course_id ),
		) );
	}

	/**
	 * Handle AJAX image upload.
	 *
	 * @return void
	 */
	public static function ajax_upload_image() {
		check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'ts-lms' ) ) );
		}

		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$uploaded_file = $_FILES['file'];
		$upload_overrides = array( 'test_form' => false );

		$movefile = wp_handle_upload( $uploaded_file, $upload_overrides );

		if ( $movefile && ! isset( $movefile['error'] ) ) {
			$attachment = array(
				'post_mime_type' => $movefile['type'],
				'post_title'     => sanitize_file_name( $uploaded_file['name'] ),
				'post_content'   => '',
				'post_status'    => 'inherit',
			);

			$attach_id = wp_insert_attachment( $attachment, $movefile['file'] );

			require_once ABSPATH . 'wp-admin/includes/image.php';
			$attach_data = wp_generate_attachment_metadata( $attach_id, $movefile['file'] );
			wp_update_attachment_metadata( $attach_id, $attach_data );

			wp_send_json_success( array(
				'attachment_id' => $attach_id,
				'url'           => wp_get_attachment_url( $attach_id ),
			) );
		} else {
			wp_send_json_error( array( 'message' => $movefile['error'] ) );
		}
	}

	/**
	 * AJAX handler for adding a category from the editor.
	 *
	 * @return void
	 */
	public static function ajax_add_category_editor() {
		check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

		if ( ! current_user_can( 'edit_ts_courses' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
		}

		$name   = isset( $_POST['name'] ) ? sanitize_text_field( $_POST['name'] ) : '';
		$parent = isset( $_POST['parent'] ) ? absint( $_POST['parent'] ) : 0;

		if ( empty( $name ) ) {
			wp_send_json_error( array( 'message' => __( 'Category name is required.', 'ts-lms' ) ) );
		}

		$args = array(
			'parent' => $parent,
		);

		$result = wp_insert_term( $name, 'ts_course_category', $args );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array(
			'message' => __( 'Category added successfully.', 'ts-lms' ),
			'term_id' => $result['term_id'],
			'name'    => $name,
		) );
	}

	/**
	 * AJAX handler for adding a tag from the editor.
	 *
	 * @return void
	 */
	public static function ajax_add_tag_editor() {
		check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

		if ( ! current_user_can( 'edit_ts_courses' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
		}

		$name = isset( $_POST['name'] ) ? sanitize_text_field( $_POST['name'] ) : '';

		if ( empty( $name ) ) {
			wp_send_json_error( array( 'message' => __( 'Tag name is required.', 'ts-lms' ) ) );
		}

		$result = wp_insert_term( $name, 'ts_course_tag' );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array(
			'message' => __( 'Tag added successfully.', 'ts-lms' ),
			'term_id' => $result['term_id'],
			'name'    => $name,
		) );
	}

	/**
	 * AJAX handler for filtering products by course title.
	 *
	 * @return void
	 */
	public static function ajax_filter_products_by_title() {
		check_ajax_referer( 'ts_lms_filter_products', 'nonce' );

		if ( ! current_user_can( 'edit_ts_courses' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
		}

		$course_title = isset( $_POST['course_title'] ) ? sanitize_text_field( $_POST['course_title'] ) : '';
		$course_id = isset( $_POST['course_id'] ) ? absint( $_POST['course_id'] ) : 0;

		if ( empty( $course_title ) ) {
			wp_send_json_error( array( 'message' => __( 'Course title is required.', 'ts-lms' ) ) );
		}

		// Check if WooCommerce is active
		if ( ! class_exists( 'WooCommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'WooCommerce is not active.', 'ts-lms' ) ) );
		}

		// Get all published products
		$args = array(
			'post_type' => 'product',
			'posts_per_page' => -1,
			'post_status' => 'publish',
		);
		$all_products = get_posts( $args );

		// Filter products to only show those with the same name as the course
		$matching_products = array();
		foreach ( $all_products as $product ) {
			if ( trim( $product->post_title ) === trim( $course_title ) ) {
				$matching_products[] = array(
					'id' => $product->ID,
					'title' => $product->post_title,
					'price' => get_post_meta( $product->ID, '_price', true ),
				);
			}
		}

		// Get the currently selected product
		$selected_product = get_post_meta( $course_id, '_course_product_id', true );

		// Auto-select if there's exactly one matching product and no product is currently selected
		if ( count( $matching_products ) === 1 && empty( $selected_product ) ) {
			$selected_product = $matching_products[0]['id'];
			// Save the auto-selected product
			if ( $course_id ) {
				update_post_meta( $course_id, '_course_product_id', $selected_product );
			}
		}

		wp_send_json_success( array(
			'products' => $matching_products,
			'selected_product' => $selected_product,
		) );
	}

	/**
	 * AJAX handler for searching courses.
	 *
	 * @return void
	 */
	public static function ajax_search_courses() {
		check_ajax_referer( 'ts_lms_course_editor', 'nonce' );

		if ( ! current_user_can( 'edit_ts_courses' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
		}

		$q = isset( $_POST['q'] ) ? sanitize_text_field( $_POST['q'] ) : '';
		$exclude = isset( $_POST['exclude'] ) ? absint( $_POST['exclude'] ) : 0;

		$args = array(
			'post_type'      => 'ts_course',
			'post_status'    => array( 'publish', 'draft', 'pending', 'future' ),
			'posts_per_page' => 10,
			's'              => $q,
			'post__not_in'   => $exclude ? array( $exclude ) : array(),
		);

		$courses = get_posts( $args );
		$results = array();

		foreach ( $courses as $course ) {
			$results[] = array(
				'id'    => $course->ID,
				'title' => $course->post_title,
			);
		}

		wp_send_json_success( array( 'results' => $results ) );
	}
}
