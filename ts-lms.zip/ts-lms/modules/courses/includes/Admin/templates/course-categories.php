<?php
/**
 * Course Categories Page Template
 *
 * @package TS_LMS\Modules\Courses\Admin
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Get all categories
$categories = get_terms( array(
    'taxonomy'   => 'ts_course_category',
    'hide_empty' => false,
) );

$parent_categories = get_terms( array(
    'taxonomy'   => 'ts_course_category',
    'hide_empty' => false,
    'parent'     => 0,
) );
?>

<div class="wrap ts-lms-category-page">
    <h1 class="wp-heading-inline"><?php echo esc_html__( 'Course Categories', 'ts-lms' ); ?></h1>
    <hr class="wp-header-end">

    <div id="ajax-response"></div>

    <div id="col-container" class="wp-clearfix">
        <!-- Left Column: Add New Category -->
        <div id="col-left">
            <div class="col-wrap">
                <div class="form-wrap">
                    <h2><?php echo esc_html__( 'Add New Course Category', 'ts-lms' ); ?></h2>
                    <div id="category-form-message" style="display:none;" class="notice"></div>
                    <form id="ts-lms-add-category-form" method="post" class="validate">
                        <?php wp_nonce_field( 'ts_lms_add_category', 'ts_lms_category_nonce' ); ?>
                        
                        <div class="form-field form-required term-name-wrap">
                            <label for="category-name"><?php echo esc_html__( 'Name', 'ts-lms' ); ?></label>
                            <input name="name" id="category-name" type="text" value="" size="40" aria-required="true" required>
                            <p><?php echo esc_html__( 'The name is how it appears on your site.', 'ts-lms' ); ?></p>
                        </div>

                        <div class="form-field term-slug-wrap">
                            <label for="category-slug"><?php echo esc_html__( 'Slug', 'ts-lms' ); ?></label>
                            <input name="slug" id="category-slug" type="text" value="" size="40">
                            <p><?php echo esc_html__( 'The "slug" is the URL-friendly version of the name. It is usually all lowercase and contains only letters, numbers, and hyphens.', 'ts-lms' ); ?></p>
                        </div>

                        <div class="form-field term-parent-wrap">
                            <label for="category-parent"><?php echo esc_html__( 'Parent Category', 'ts-lms' ); ?></label>
                            <select name="parent" id="category-parent" class="postform">
                                <option value="0"><?php echo esc_html__( 'None', 'ts-lms' ); ?></option>
                                <?php if ( ! empty( $parent_categories ) && ! is_wp_error( $parent_categories ) ) : ?>
                                    <?php foreach ( $parent_categories as $parent ) : ?>
                                        <option value="<?php echo esc_attr( $parent->term_id ); ?>"><?php echo esc_html( $parent->name ); ?></option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                            <p><?php echo esc_html__( 'Assign a parent term to create a hierarchy.', 'ts-lms' ); ?></p>
                        </div>

                        <div class="form-field term-description-wrap">
                            <label for="category-description"><?php echo esc_html__( 'Description', 'ts-lms' ); ?></label>
                            <textarea name="description" id="category-description" rows="5" cols="40"></textarea>
                            <p><?php echo esc_html__( 'The description is not prominent by default; however, some themes may show it.', 'ts-lms' ); ?></p>
                        </div>

                        <div class="form-field term-thumbnail-wrap">
                            <label><?php echo esc_html__( 'Thumbnail', 'ts-lms' ); ?></label>
                            <div id="category-thumbnail-preview" class="category-thumbnail-preview"></div>
                            <button type="button" class="button" id="upload-category-thumbnail"><?php echo esc_html__( 'Upload/Add image', 'ts-lms' ); ?></button>
                            <button type="button" class="button" id="remove-category-thumbnail" style="display:none;"><?php echo esc_html__( 'Remove image', 'ts-lms' ); ?></button>
                            <input type="hidden" id="category-thumbnail-id" name="thumbnail" value="">
                        </div>

                        <p class="submit">
                            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_attr__( 'Add New Category', 'ts-lms' ); ?>">
                            <span class="spinner"></span>
                        </p>
                    </form>
                </div>
            </div>
        </div>

        <!-- Right Column: Categories Table -->
        <div id="col-right">
            <div class="col-wrap">
                <form id="posts-filter" method="get">
                    <div class="tablenav top">
                        <div class="alignleft actions bulkactions">
                            <select name="action" id="bulk-action-selector-top">
                                <option value="-1"><?php echo esc_html__( 'Bulk actions', 'ts-lms' ); ?></option>
                                <option value="delete"><?php echo esc_html__( 'Delete', 'ts-lms' ); ?></option>
                            </select>
                            <input type="button" id="doaction" class="button action" value="<?php echo esc_attr__( 'Apply', 'ts-lms' ); ?>">
                        </div>
                        <div class="tablenav-pages">
                            <span class="displaying-num" id="category-count">
                                <?php echo count($categories); ?> <?php echo esc_html__( 'items', 'ts-lms' ); ?>
                            </span>
                        </div>
                    </div>

                    <table class="wp-list-table widefat fixed striped tags ts-lms-categories-table">
                        <thead>
                            <tr>
                                <td id="cb" class="manage-column column-cb check-column"><input id="cb-select-all-1" type="checkbox"></td>
                                <th scope="col" class="manage-column column-image"><?php echo esc_html__( 'Image', 'ts-lms' ); ?></th>
                                <th scope="col" id="name" class="manage-column column-name column-primary sortable"><a href="#" data-sort="name"><span><?php echo esc_html__( 'Name', 'ts-lms' ); ?></span><span class="sorting-indicator"></span></a></th>
                                <th scope="col" id="description" class="manage-column column-description"><?php echo esc_html__( 'Description', 'ts-lms' ); ?></th>
                                <th scope="col" id="slug" class="manage-column column-slug sortable"><a href="#" data-sort="slug"><span><?php echo esc_html__( 'Slug', 'ts-lms' ); ?></span><span class="sorting-indicator"></span></a></th>
                                <th scope="col" id="posts" class="manage-column column-posts num sortable"><a href="#" data-sort="count"><span><?php echo esc_html__( 'Count', 'ts-lms' ); ?></span><span class="sorting-indicator"></span></a></th>
                            </tr>
                        </thead>
                        <tbody id="categories-table-body">
                            <?php if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) : ?>
                                <?php foreach ( $categories as $category ) : 
                                    $thumbnail_id = get_term_meta( $category->term_id, 'thumbnail_id', true );
                                    $thumbnail_url = $thumbnail_id ? wp_get_attachment_image_url( $thumbnail_id, 'thumbnail' ) : '';
                                ?>
                                    <tr id="tag-<?php echo esc_attr( $category->term_id ); ?>">
                                        <th scope="row" class="check-column"><input type="checkbox" name="delete_tags[]" value="<?php echo esc_attr( $category->term_id ); ?>"></th>
                                        <td class="column-image">
                                            <?php if ( $thumbnail_url ) : ?>
                                                <img src="<?php echo esc_url( $thumbnail_url ); ?>" alt="" width="40">
                                            <?php else : ?>
                                                —
                                            <?php endif; ?>
                                        </td>
                                        <td class="column-name column-primary" data-colname="Name">
                                            <strong><a class="row-title" href="#"><?php echo esc_html( $category->name ); ?></a></strong>
                                            <div class="row-actions">
                                                <span class="edit"><a href="#"><?php echo esc_html__( 'Edit', 'ts-lms' ); ?></a> | </span>
                                                <span class="delete"><a class="delete-category" href="#" data-term-id="<?php echo esc_attr( $category->term_id ); ?>"><?php echo esc_html__( 'Delete', 'ts-lms' ); ?></a> | </span>
                                                <span class="view"><a href="<?php echo esc_url( get_term_link( $category ) ); ?>" target="_blank"><?php echo esc_html__( 'View', 'ts-lms' ); ?></a></span>
                                            </div>
                                        </td>
                                        <td class="column-description" data-colname="Description"><?php echo esc_html( $category->description ); ?></td>
                                        <td class="column-slug" data-colname="Slug"><?php echo esc_html( $category->slug ); ?></td>
                                        <td class="column-posts num" data-colname="Count"><?php echo esc_html( $category->count ); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr class="no-items"><td colspan="6" class="colspanchange"><?php echo esc_html__( 'No categories found.', 'ts-lms' ); ?></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
