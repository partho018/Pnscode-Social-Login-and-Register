<?php
/**
 * Modern Course List Page Template
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use TS_LMS\Modules\Courses\Admin\CustomCourseListPage;
?>

<div class="wrap ts-lms-courses-page">
	<!-- Page Header -->
	<div class="ts-page-header">
		<div class="ts-header-left">
			<h1 class="ts-page-title">
				<span class="ts-title-icon">
					<svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M12 14l9-5-9-5-9 5 9 5z" fill="currentColor" opacity="0.3"/>
						<path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" fill="currentColor"/>
						<path d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
				</span>
				<?php esc_html_e( 'Courses', 'ts-lms' ); ?>
			</h1>
			<p class="ts-page-subtitle">
				<?php
				printf(
					/* translators: %d: number of items */
					esc_html__( 'Manage and organize your %d courses & bundles', 'ts-lms' ),
					$query->found_posts
				);
				?>
			</p>
		</div>
		<div class="ts-header-right">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-bundle-editor&action=new' ) ); ?>" class="ts-btn ts-btn-secondary">
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor">
					<path d="M20 7H4a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					<path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
				<span><?php esc_html_e( 'Add New Bundle', 'ts-lms' ); ?></span>
			</a>

			<a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-course-editor' ) ); ?>" class="ts-btn ts-btn-primary">
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor">
					<path d="M12 5v14M5 12h14" stroke-width="2.5" stroke-linecap="round"/>
				</svg>
				<span><?php esc_html_e( 'New Course', 'ts-lms' ); ?></span>
			</a>
		</div>
	</div>

	<!-- Filters and Search -->
	<div class="ts-filters-section">
		<div class="ts-filters-left">
			<!-- Bulk Actions -->
			<div class="ts-bulk-actions">
				<select id="ts-bulk-action-select" class="ts-select">
					<option value=""><?php esc_html_e( 'Bulk Actions', 'ts-lms' ); ?></option>
					<option value="delete"><?php esc_html_e( 'Delete', 'ts-lms' ); ?></option>
					<option value="publish"><?php esc_html_e( 'Publish', 'ts-lms' ); ?></option>
					<option value="draft"><?php esc_html_e( 'Move to Draft', 'ts-lms' ); ?></option>
				</select>
				<button type="button" id="ts-apply-bulk-action" class="ts-btn ts-btn-secondary" disabled>
					<?php esc_html_e( 'Apply', 'ts-lms' ); ?>
				</button>
			</div>

			<!-- Filters -->
			<div class="ts-filter-group">
				<!-- Category Filter -->
				<select id="ts-category-filter" class="ts-select ts-filter-select" onchange="this.form.submit()">
					<option value=""><?php esc_html_e( 'All Categories', 'ts-lms' ); ?></option>
					<?php if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) : ?>
						<?php foreach ( $categories as $cat ) : ?>
							<option value="<?php echo esc_attr( $cat->slug ); ?>" <?php selected( $category, $cat->slug ); ?>>
								<?php echo esc_html( $cat->name ); ?> (<?php echo esc_html( $cat->count ); ?>)
							</option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>

				<!-- Type Filter -->
				<select id="ts-post-type-filter" class="ts-select ts-filter-select">
					<option value=""><?php esc_html_e( 'All Types', 'ts-lms' ); ?></option>
					<option value="ts_course" <?php selected( $post_type_filter, 'ts_course' ); ?>><?php esc_html_e( 'Courses Only', 'ts-lms' ); ?></option>
					<option value="ts_bundle" <?php selected( $post_type_filter, 'ts_bundle' ); ?>><?php esc_html_e( 'Bundles Only', 'ts-lms' ); ?></option>
				</select>

				<!-- Status Filter -->
				<select id="ts-status-filter" class="ts-select ts-filter-select">
					<option value=""><?php esc_html_e( 'All Status', 'ts-lms' ); ?></option>
					<option value="publish" <?php selected( $status, 'publish' ); ?>><?php esc_html_e( 'Published', 'ts-lms' ); ?></option>
					<option value="draft" <?php selected( $status, 'draft' ); ?>><?php esc_html_e( 'Draft', 'ts-lms' ); ?></option>
					<option value="pending" <?php selected( $status, 'pending' ); ?>><?php esc_html_e( 'Pending', 'ts-lms' ); ?></option>
				</select>
			</div>
		</div>

		<div class="ts-filters-right">
			<!-- Search Box -->
			<div class="ts-search-box">
				<input 
					type="search" 
					id="ts-course-search" 
					class="ts-search-input" 
					placeholder="<?php esc_attr_e( 'Search courses...', 'ts-lms' ); ?>"
					value="<?php echo esc_attr( $search ); ?>"
				/>
			</div>

			<!-- View Toggle -->
			<div class="ts-view-toggle">
				<button type="button" class="ts-view-btn" data-view="grid" title="<?php esc_attr_e( 'Grid View', 'ts-lms' ); ?>">
					<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
						<rect x="3" y="3" width="7" height="7" rx="1" stroke-width="2"/>
						<rect x="14" y="3" width="7" height="7" rx="1" stroke-width="2"/>
						<rect x="14" y="14" width="7" height="7" rx="1" stroke-width="2"/>
						<rect x="3" y="14" width="7" height="7" rx="1" stroke-width="2"/>
					</svg>
				</button>
				<button type="button" class="ts-view-btn active" data-view="list" title="<?php esc_attr_e( 'List View', 'ts-lms' ); ?>">
					<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
						<line x1="8" y1="6" x2="21" y2="6" stroke-width="2" stroke-linecap="round"/>
						<line x1="8" y1="12" x2="21" y2="12" stroke-width="2" stroke-linecap="round"/>
						<line x1="8" y1="18" x2="21" y2="18" stroke-width="2" stroke-linecap="round"/>
						<line x1="3" y1="6" x2="3.01" y2="6" stroke-width="2" stroke-linecap="round"/>
						<line x1="3" y1="12" x2="3.01" y2="12" stroke-width="2" stroke-linecap="round"/>
						<line x1="3" y1="18" x2="3.01" y2="18" stroke-width="2" stroke-linecap="round"/>
					</svg>
				</button>
			</div>
		</div>
	</div>

	<!-- Courses Grid/List -->
	<div class="ts-courses-container" data-view="list">
		<?php if ( $query->have_posts() ) : ?>
			<div class="ts-courses-grid">
				<?php while ( $query->have_posts() ) : $query->the_post(); ?>
					<?php
					$course_id = get_the_ID();
					$post_type = get_post_type( $course_id );
					$is_bundle = ( 'ts_bundle' === $post_type );
					
					$thumbnail = get_the_post_thumbnail_url( $course_id, 'medium' );
					$metadata = CustomCourseListPage::get_course_metadata( $course_id );
					$price_html = CustomCourseListPage::get_course_price( $course_id );
					$author = get_userdata( get_post_field( 'post_author', $course_id ) );
					$categories = get_the_terms( $course_id, 'ts_course_category' );
					$post_status = get_post_status( $course_id );
					
					$edit_url = $is_bundle 
						? admin_url( 'admin.php?page=ts-lms-bundle-editor&bundle_id=' . $course_id )
						: admin_url( 'admin.php?page=ts-lms-course-editor&course_id=' . $course_id );
					?>
					
					<div class="ts-course-card <?php echo $is_bundle ? 'ts-bundle-card' : ''; ?>" data-course-id="<?php echo esc_attr( $course_id ); ?>" data-status="<?php echo esc_attr( $post_status ); ?>" data-post-type="<?php echo esc_attr( $post_type ); ?>">
						<div class="ts-card-left-section">
							<!-- Selection Checkbox -->
							<div class="ts-card-checkbox">
								<input type="checkbox" class="ts-course-select" value="<?php echo esc_attr( $course_id ); ?>">
							</div>

							<!-- Course Thumbnail -->
							<div class="ts-card-thumbnail">
								<?php if ( $thumbnail ) : ?>
									<img src="<?php echo esc_url( $thumbnail ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>">
								<?php else : ?>
									<div class="ts-thumbnail-placeholder">
										<?php if ( $is_bundle ) : ?>
											<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<path d="M20 7H4a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z" stroke-width="2" opacity="0.3"/>
												<path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" stroke-width="2"/>
											</svg>
										<?php else : ?>
											<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<path d="M12 14l9-5-9-5-9 5 9 5z" stroke-width="2"/>
												<path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" stroke-width="2"/>
											</svg>
										<?php endif; ?>
									</div>
								<?php endif; ?>
							</div>
						</div>

						<div class="ts-card-content">
							<div class="ts-card-main-info">
								<!-- Title -->
								<h3 class="ts-card-title">
									<a href="<?php echo esc_url( $edit_url ); ?>">
										<?php the_title(); ?>
										<?php if ( $is_bundle ) : ?>
											<span class="ts-bundle-badge"><?php esc_html_e( 'Bundle', 'ts-lms' ); ?></span>
										<?php endif; ?>
									</a>
								</h3>

								<!-- Meta Info -->
								<div class="ts-card-meta">
									<?php if ( $is_bundle ) : ?>
										<div class="ts-meta-item">
											<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<path d="M12 14l9-5-9-5-9 5 9 5z" stroke-width="2"/>
												<path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" stroke-width="2"/>
											</svg>
											<span><?php echo esc_html( $metadata['courses'] ); ?> <?php esc_html_e( 'Courses', 'ts-lms' ); ?></span>
										</div>
									<?php else : ?>
										<div class="ts-meta-item">
											<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<rect x="3" y="3" width="7" height="7" rx="1" stroke-width="2"/>
												<rect x="14" y="3" width="7" height="7" rx="1" stroke-width="2"/>
												<rect x="14" y="14" width="7" height="7" rx="1" stroke-width="2"/>
												<rect x="3" y="14" width="7" height="7" rx="1" stroke-width="2"/>
											</svg>
											<span><?php echo esc_html( $metadata['topics'] ); ?> <?php esc_html_e( 'Topics', 'ts-lms' ); ?></span>
										</div>
										<div class="ts-meta-item">
											<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" stroke-width="2"/>
												<path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" stroke-width="2" stroke-linecap="round"/>
											</svg>
											<span><?php echo esc_html( $metadata['lessons'] ); ?> <?php esc_html_e( 'Lessons', 'ts-lms' ); ?></span>
										</div>
										<div class="ts-meta-item">
											<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<path d="M9 11l3 3L22 4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
												<path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11" stroke-width="2" stroke-linecap="round"/>
											</svg>
											<span><?php echo esc_html( $metadata['quizzes'] ); ?> <?php esc_html_e( 'Quizzes', 'ts-lms' ); ?></span>
										</div>
										<div class="ts-meta-item">
											<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" stroke-width="2" stroke-linecap="round"/>
												<path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
											</svg>
											<span><?php echo esc_html( $metadata['assignments'] ); ?> <?php esc_html_e( 'Assignments', 'ts-lms' ); ?></span>
										</div>
									<?php endif; ?>
								</div>
							</div>

							<!-- Middle Section for Badges to fill space -->
							<div class="ts-card-middle-info">
								<div class="ts-card-badges-middle">
									<!-- Categories -->
									<?php if ( $categories && ! is_wp_error( $categories ) ) : ?>
										<div class="ts-card-categories">
											<?php foreach ( array_slice( $categories, 0, 2 ) as $cat ) : ?>
												<span class="ts-category-tag"><?php echo esc_html( $cat->name ); ?></span>
											<?php endforeach; ?>
										</div>
									<?php endif; ?>

									<!-- Status Badge -->
									<div class="ts-status-label ts-status-<?php echo esc_attr( $post_status ); ?>">
										<?php echo esc_html( ucfirst( $post_status ) ); ?>
									</div>
								</div>
							</div>

							<div class="ts-card-right-section">
								<!-- Price Label (Aligned to Right Section) -->
								<div class="ts-price-label">
									<?php echo $price_html; ?>
								</div>
								
								<!-- Author & Date -->
								<div class="ts-card-footer">
									<div class="ts-author-info">
										<?php echo get_avatar( $author->ID, 28, '', '', array( 'class' => 'ts-author-avatar' ) ); ?>
										<div class="ts-author-details">
											<span class="ts-author-name"><?php echo esc_html( $author->display_name ); ?></span>
											<span class="ts-post-date"><?php echo esc_html( human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ) ); ?> <?php esc_html_e( 'ago', 'ts-lms' ); ?></span>
										</div>
									</div>

									<!-- Actions -->
									<div class="ts-card-actions">
										<a href="<?php echo esc_url( $edit_url ); ?>" class="ts-action-btn" title="<?php esc_attr_e( 'Edit', 'ts-lms' ); ?>">
											<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" stroke-width="2"/>
												<path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" stroke-width="2"/>
											</svg>
										</a>
										<?php if ( $post_status === 'publish' || $is_bundle ) : ?>
											<a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>" class="ts-action-btn" target="_blank" title="<?php esc_attr_e( 'View', 'ts-lms' ); ?>">
												<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
													<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke-width="2"/>
													<circle cx="12" cy="12" r="3" stroke-width="2"/>
												</svg>
											</a>
										<?php endif; ?>
										<button type="button" class="ts-action-btn ts-delete-course" data-course-id="<?php echo esc_attr( $course_id ); ?>" title="<?php esc_attr_e( 'Delete', 'ts-lms' ); ?>">
											<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" stroke-width="2" stroke-linecap="round"/>
												<line x1="10" y1="11" x2="10" y2="17" stroke-width="2" stroke-linecap="round"/>
												<line x1="14" y1="11" x2="14" y2="17" stroke-width="2" stroke-linecap="round"/>
											</svg>
										</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endwhile; ?>
			</div>

			<!-- Pagination -->
			<?php if ( $query->max_num_pages > 1 ) : ?>
				<div class="ts-pagination">
					<?php
					$big = 999999999;
					echo paginate_links( array(
						'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
						'format'    => '?paged=%#%',
						'current'   => max( 1, $paged ),
						'total'     => $query->max_num_pages,
						'prev_text' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 18l-6-6 6-6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
						'next_text' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 18l6-6-6-6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
					) );
					?>
				</div>
			<?php endif; ?>

		<?php else : ?>
			<!-- Empty State -->
			<div class="ts-empty-state">
				<div class="ts-empty-icon">
					<svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor">
						<path d="M12 14l9-5-9-5-9 5 9 5z" stroke-width="1.5" opacity="0.3"/>
						<path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" stroke-width="1.5"/>
					</svg>
				</div>
				<h2 class="ts-empty-title"><?php esc_html_e( 'No courses found', 'ts-lms' ); ?></h2>
				<p class="ts-empty-description">
					<?php esc_html_e( 'Get started by creating your first course or adjust your filters.', 'ts-lms' ); ?>
				</p>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-course-editor' ) ); ?>" class="ts-btn ts-btn-primary">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor">
						<path d="M12 5v14M5 12h14" stroke-width="2.5" stroke-linecap="round"/>
					</svg>
					<span><?php esc_html_e( 'Create Your First Course', 'ts-lms' ); ?></span>
				</a>
			</div>
		<?php endif; ?>
	</div>
</div>

<?php wp_reset_postdata(); ?>
