<?php
/**
 * Bundle Editor Template
 *
 * @package TS_LMS
 */

defined( 'ABSPATH' ) || exit;

// If we have a query object, we are in List View
if ( isset( $query ) ) :
?>
	<div class="wrap ts-lms-courses-page ts-bundle-list-wrap">
		<!-- Page Header -->
		<div class="ts-page-header">
			<div class="ts-header-left">
				<h1 class="ts-page-title">
					<span class="ts-title-icon">
						<svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M20 7H4a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z" fill="currentColor" opacity="0.3"/>
							<path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" fill="currentColor"/>
						</svg>
					</span>
					<?php esc_html_e( 'Course Bundles', 'ts-lms' ); ?>
				</h1>
				<p class="ts-page-subtitle">
					<?php
					printf(
						/* translators: %d: number of bundles */
						esc_html__( 'Manage and organize your %d course bundles', 'ts-lms' ),
						$query->found_posts
					);
					?>
				</p>
			</div>
			<div class="ts-header-right">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-course' ) ); ?>" class="ts-btn ts-btn-secondary">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor">
						<path d="M12 14l9-5-9-5-9 5 9 5z" stroke-width="2"/>
						<path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" stroke-width="2"/>
					</svg>
					<span><?php esc_html_e( 'All Courses', 'ts-lms' ); ?></span>
				</a>

				<a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-bundle-editor&action=new' ) ); ?>" class="ts-btn ts-btn-primary">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor">
						<path d="M12 5v14M5 12h14" stroke-width="2.5" stroke-linecap="round"/>
					</svg>
					<span><?php esc_html_e( 'New Bundle', 'ts-lms' ); ?></span>
				</a>
			</div>
		</div>

		<!-- Filters and Search -->
		<div class="ts-filters-section">
			<div class="ts-filters-left">
				<div class="ts-bulk-actions">
					<select id="ts-bulk-action-select" class="ts-select">
						<option value=""><?php esc_html_e( 'Bulk Actions', 'ts-lms' ); ?></option>
						<option value="delete"><?php esc_html_e( 'Delete', 'ts-lms' ); ?></option>
						<option value="publish"><?php esc_html_e( 'Publish', 'ts-lms' ); ?></option>
						<option value="draft"><?php esc_html_e( 'Move to Draft', 'ts-lms' ); ?></option>
					</select>
					<button type="button" id="ts-apply-bulk-action" class="ts-btn ts-btn-secondary" disabled>
						<?php esc_html_e( 'Apply', 'ts-lms' ); ?>
					</button>
				</div>
			</div>

			<div class="ts-filters-right">
				<div class="ts-search-box">
					<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
						<input type="hidden" name="page" value="ts-lms-bundle-editor">
						<div class="ts-search-icon">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
								<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
							</svg>
						</div>
						<input 
							type="search" 
							name="s" 
							id="ts-bundle-search" 
							class="ts-search-input" 
							placeholder="<?php esc_attr_e( 'Search bundles...', 'ts-lms' ); ?>"
							value="<?php echo esc_attr( $search ); ?>"
						/>
					</form>
				</div>
			</div>
		</div>

		<!-- Bundles Grid/List -->
		<div class="ts-courses-container" data-view="list">
			<?php if ( $query->have_posts() ) : ?>
				<div class="ts-courses-grid">
					<?php while ( $query->have_posts() ) : $query->the_post(); ?>
						<?php
						$bundle_id = get_the_ID();
						$thumbnail = get_the_post_thumbnail_url( $bundle_id, 'medium' );
						$price = get_post_meta( $bundle_id, '_bundle_price', true );
						$author = get_userdata( get_post_field( 'post_author', $bundle_id ) );
						$post_status = get_post_status( $bundle_id );
						
						// Get course count in bundle
						global $wpdb;
						$table = $wpdb->prefix . 'ts_bundle_courses';
						$course_count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE bundle_id = %d", $bundle_id ) );
						?>
						
						<div class="ts-course-card" data-bundle-id="<?php echo esc_attr( $bundle_id ); ?>" data-status="<?php echo esc_attr( $post_status ); ?>">
							<div class="ts-card-left-section">
								<div class="ts-card-checkbox">
									<input type="checkbox" class="ts-bundle-select" value="<?php echo esc_attr( $bundle_id ); ?>">
								</div>

								<div class="ts-card-thumbnail">
									<?php if ( $thumbnail ) : ?>
										<img src="<?php echo esc_url( $thumbnail ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>">
									<?php else : ?>
										<div class="ts-thumbnail-placeholder">
											<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<path d="M20 7H4a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z" stroke-width="2"/>
												<path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" stroke-width="2"/>
											</svg>
										</div>
									<?php endif; ?>
								</div>
							</div>

							<div class="ts-card-content">
								<div class="ts-card-main-info">
									<h3 class="ts-card-title">
										<a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-bundle-editor&bundle_id=' . $bundle_id ) ); ?>">
											<?php echo esc_html( get_the_title() ); ?>
										</a>
									</h3>

									<div class="ts-card-meta">
										<div class="ts-meta-item">
											<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<path d="M12 14l9-5-9-5-9 5 9 5z" stroke-width="2"/>
												<path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" stroke-width="2"/>
											</svg>
											<span><?php echo esc_html( $course_count ); ?> <?php esc_html_e( 'Courses', 'ts-lms' ); ?></span>
										</div>
									</div>
								</div>

								<div class="ts-card-middle-info">
									<div class="ts-status-label ts-status-<?php echo esc_attr( $post_status ); ?>">
										<?php echo esc_html( ucfirst( $post_status ) ); ?>
									</div>
								</div>

								<div class="ts-card-right-section">
									<div class="ts-price-label">
										<span class="ts-price-paid"><?php echo $price ? esc_html( $price ) . ' ' . (function_exists('get_woocommerce_currency_symbol') ? get_woocommerce_currency_symbol() : '$') : esc_html__('Free', 'ts-lms'); ?></span>
									</div>
									
									<div class="ts-card-footer">
										<div class="ts-author-info">
											<?php echo get_avatar( $author->ID, 28, '', '', array( 'class' => 'ts-author-avatar' ) ); ?>
											<div class="ts-author-details">
												<span class="ts-author-name"><?php echo esc_html( $author->display_name ); ?></span>
												<span class="ts-post-date"><?php echo esc_html( human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ) ); ?> <?php esc_html_e( 'ago', 'ts-lms' ); ?></span>
											</div>
										</div>

										<div class="ts-card-actions">
											<a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-bundle-editor&bundle_id=' . $bundle_id ) ); ?>" class="ts-action-btn" title="<?php esc_attr_e( 'Edit', 'ts-lms' ); ?>">
												<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
													<path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" stroke-width="2"/>
													<path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" stroke-width="2"/>
												</svg>
											</a>
											<button type="button" class="ts-action-btn ts-delete-bundle" data-bundle-id="<?php echo esc_attr( $bundle_id ); ?>" title="<?php esc_attr_e( 'Delete', 'ts-lms' ); ?>">
												<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
													<path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" stroke-width="2" stroke-linecap="round"/>
													<line x1="10" y1="11" x2="10" y2="17" stroke-width="2" stroke-linecap="round"/>
													<line x1="14" y1="11" x2="14" y2="17" stroke-width="2" stroke-linecap="round"/>
												</svg>
											</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					<?php endwhile; ?>
				</div>

				<!-- Pagination -->
				<?php if ( $query->max_num_pages > 1 ) : ?>
					<div class="ts-pagination">
						<?php
						$big = 999999999;
						echo paginate_links( array(
							'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
							'format'    => '?paged=%#%',
							'current'   => max( 1, $paged ),
							'total'     => $query->max_num_pages,
							'prev_text' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 18l-6-6 6-6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
							'next_text' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 18l6-6-6-6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
						) );
						?>
					</div>
				<?php endif; ?>

			<?php else : ?>
				<div class="ts-empty-state-centered">
					<div class="ts-empty-state-card">
						<div class="ts-empty-icon-animated">
							<svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
								<path d="M20 7H4a2 2 0 0 0 -2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2 -2V9a2 2 0 0 0 -2 -2z" opacity="0.3"/>
								<path d="M16 21V5a2 2 0 0 0 -2 -2h-4a2 2 0 0 0 -2 2v16" />
								<path d="M12 12v.01M12 16v.01" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>
						<h2 class="ts-empty-title"><?php esc_html_e( 'No Bundles Created Yet', 'ts-lms' ); ?></h2>
						<p class="ts-empty-description">
							<?php esc_html_e( 'Transform your course catalog by creating exclusive package deals for your students.', 'ts-lms' ); ?>
						</p>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-bundle-editor&action=new' ) ); ?>" class="ts-btn ts-btn-primary ts-btn-lg">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
								<path d="M12 5v14M5 12h14" stroke-width="2.5" stroke-linecap="round"/>
							</svg>
							<span><?php esc_html_e( 'Create Your First Bundle', 'ts-lms' ); ?></span>
						</a>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>

<?php 
// Reset Post Data
wp_reset_postdata();

// End List View
else : 
?>
	<div class="wrap ts-bundle-editor-page ts-lms-courses-page ts-bundle-editor-wrap">
		<!-- Page Header -->
		<div class="ts-page-header">
			<div class="ts-header-left">
				<h1 class="ts-page-title">
					<span class="ts-title-icon">
						<svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M20 7H4a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z" fill="currentColor" opacity="0.3"/>
							<path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" fill="currentColor"/>
						</svg>
					</span>
					<?php echo $bundle ? esc_html__( 'Edit Bundle', 'ts-lms' ) : esc_html__( 'New Bundle', 'ts-lms' ); ?>
				</h1>
				<p class="ts-page-subtitle">
					<?php esc_html_e( 'Create a package by combining multiple courses.', 'ts-lms' ); ?>
				</p>
			</div>
			<div class="ts-header-right">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-bundle-editor' ) ); ?>" class="ts-btn ts-btn-secondary">
					<?php esc_html_e( 'Back to List', 'ts-lms' ); ?>
				</a>
				<button type="button" id="ts-save-bundle" class="ts-btn ts-btn-primary">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor">
						<path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
						<path d="M17 21v-8H7v8M7 3v5h8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
					<span><?php esc_html_e( 'Save Bundle', 'ts-lms' ); ?></span>
				</button>
			</div>
		</div>

		<div class="ts-editor-container">
			<form id="ts-bundle-form">
				<input type="hidden" name="bundle_id" id="bundle_id" value="<?php echo esc_attr( $bundle_id ); ?>">
				
				<div class="ts-editor-main">
					<!-- Bundle Content -->
					<div class="ts-editor-card">
						<div class="ts-card-header">
							<h3><?php esc_html_e( 'Bundle Information', 'ts-lms' ); ?></h3>
						</div>
						<div class="ts-card-body">
							<div class="ts-form-group">
								<label for="bundle_title"><?php esc_html_e( 'Bundle Title', 'ts-lms' ); ?></label>
								<input type="text" id="bundle_title" name="title" class="ts-form-control" value="<?php echo esc_attr( $bundle_data['title'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Enter bundle title...', 'ts-lms' ); ?>">
							</div>

							<div class="ts-form-group">
								<label><?php esc_html_e( 'Description', 'ts-lms' ); ?></label>
								<?php
								wp_editor(
									$bundle_data['description'] ?? '',
									'bundle_description',
									array(
										'textarea_name' => 'description',
										'media_buttons' => true,
										'textarea_rows' => 10,
										'tinymce'       => array(
											'setup' => 'function(ed) { ed.on("change", function() { ed.save(); }); }',
										),
									)
								);
								?>
							</div>
						</div>
					</div>

					<!-- Course Selection -->
					<div class="ts-editor-card">
						<div class="ts-card-header">
							<h3><?php esc_html_e( 'Select Courses', 'ts-lms' ); ?></h3>
							<div class="ts-card-actions">
								<input type="text" id="ts-course-filter" placeholder="<?php esc_attr_e( 'Search courses...', 'ts-lms' ); ?>" class="ts-search-input-sm">
							</div>
						</div>
						<div class="ts-card-body">
							<div class="ts-courses-selection-list">
								<?php if ( ! empty( $courses ) ) : ?>
									<?php foreach ( $courses as $course ) : 
										$is_selected = in_array( $course->ID, $selected_courses );
									?>
										<div class="ts-course-selection-item <?php echo $is_selected ? 'selected' : ''; ?>" data-title="<?php echo esc_attr( strtolower( $course->post_title ) ); ?>">
											<label class="ts-checkbox-wrapper">
												<input type="checkbox" name="courses[]" value="<?php echo esc_attr( $course->ID ); ?>" <?php checked( $is_selected ); ?>>
												<span class="ts-checkbox-custom"></span>
												<div class="ts-course-item-info">
													<span class="ts-course-item-title"><?php echo esc_html( $course->post_title ); ?></span>
													<span class="ts-course-item-meta"><?php echo esc_html( get_post_status( $course->ID ) ); ?></span>
												</div>
											</label>
										</div>
									<?php endforeach; ?>
								<?php else : ?>
									<p class="ts-no-courses"><?php esc_html_e( 'No courses available to bundle.', 'ts-lms' ); ?></p>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>

				<div class="ts-editor-sidebar">
					<!-- Publish Settings -->
					<div class="ts-editor-card">
						<div class="ts-card-header">
							<h3><?php esc_html_e( 'Settings', 'ts-lms' ); ?></h3>
						</div>
						<div class="ts-card-body">
							<div class="ts-form-group">
								<label for="bundle_status"><?php esc_html_e( 'Status', 'ts-lms' ); ?></label>
								<select id="bundle_status" name="status" class="ts-select-full">
									<option value="publish" <?php selected( $bundle_data['status'] ?? '', 'publish' ); ?>><?php esc_html_e( 'Published', 'ts-lms' ); ?></option>
									<option value="draft" <?php selected( $bundle_data['status'] ?? '', 'draft' ); ?>><?php esc_html_e( 'Draft', 'ts-lms' ); ?></option>
								</select>
							</div>

							<div class="ts-form-group ts-pricing-section-container">
								<label class="ts-field-label"><?php esc_html_e( 'Pricing Model', 'ts-lms' ); ?></label>
								
								<div class="ts-pricing-options">
									<label class="ts-pricing-option">
										<input type="radio" name="price_type" value="free" <?php checked( $bundle_data['price_type'] ?? 'free', 'free' ); ?>>
										<div class="ts-pricing-card">
											<span class="ts-pricing-icon dashicons dashicons-smiley"></span>
											<span class="ts-pricing-title"><?php esc_html_e( 'Free', 'ts-lms' ); ?></span>
										</div>
									</label>
									
									<label class="ts-pricing-option">
										<input type="radio" name="price_type" value="paid" <?php checked( $bundle_data['price_type'] ?? '', 'paid' ); ?>>
										<div class="ts-pricing-card">
											<span class="ts-pricing-icon dashicons dashicons-cart"></span>
											<span class="ts-pricing-title"><?php esc_html_e( 'One-Time', 'ts-lms' ); ?></span>
										</div>
									</label>
									
									<label class="ts-pricing-option">
										<input type="radio" name="price_type" value="subscription" <?php checked( $bundle_data['price_type'] ?? '', 'subscription' ); ?>>
										<div class="ts-pricing-card">
											<span class="ts-pricing-icon dashicons dashicons-calendar-alt"></span>
											<span class="ts-pricing-title"><?php esc_html_e( 'Subscription', 'ts-lms' ); ?></span>
										</div>
									</label>
								</div>

								<!-- Product Selection Panel -->
								<div class="ts-pricing-settings-panel" id="ts-bundle-product-selection" style="<?php echo ( $bundle_data['price_type'] ?? '' ) === 'paid' ? '' : 'display:none;'; ?>">
									<div class="ts-pricing-field">
										<label class="ts-pricing-label"><?php esc_html_e( 'Select Product', 'ts-lms' ); ?></label>
										<select name="product_id" id="bundle-product-select" class="ts-pricing-select">
											<option value=""><?php esc_html_e( 'Select a product', 'ts-lms' ); ?></option>
											<?php
											if ( class_exists( 'WooCommerce' ) ) {
												$bundle_title = $bundle_data['title'] ?? '';
												$all_products = get_posts( array(
													'post_type' => 'product',
													'posts_per_page' => -1,
													'post_status' => 'publish',
												) );

												$matching_products = array();
												foreach ( $all_products as $product ) {
													if ( $bundle_title && trim( strtolower( $product->post_title ) ) === trim( strtolower( $bundle_title ) ) ) {
														$matching_products[] = $product;
													}
												}

												$selected_product = $bundle_data['product_id'] ?? 0;

												// Auto-select if exactly one match and none selected
												if ( count( $matching_products ) === 1 && ! $selected_product ) {
													$selected_product = $matching_products[0]->ID;
												}

												if ( ! empty( $matching_products ) ) {
													foreach ( $matching_products as $product ) {
														echo '<option value="' . esc_attr( $product->ID ) . '" ' . selected( $selected_product, $product->ID, false ) . '>' . esc_html( $product->post_title ) . '</option>';
													}
												} else {
													echo '<option value="" disabled>' . esc_html__( 'No products found with matching bundle title', 'ts-lms' ) . '</option>';
												}
											}
											?>
										</select>
									</div>
								</div>

								<!-- Subscription Panel -->
								<div class="ts-pricing-settings-panel" id="ts-bundle-subscription-settings" style="<?php echo ( $bundle_data['price_type'] ?? '' ) === 'subscription' ? '' : 'display:none;'; ?>">
									<div class="ts-pricing-grid">
										<div class="ts-pricing-field">
											<label class="ts-pricing-label"><?php esc_html_e( 'Plan Type', 'ts-lms' ); ?></label>
											<select name="subscription_plan" class="ts-pricing-select">
												<option value="weekly" <?php selected( $bundle_data['sub_plan'] ?? '', 'weekly' ); ?>><?php esc_html_e( 'Weekly', 'ts-lms' ); ?></option>
												<option value="monthly" <?php selected( $bundle_data['sub_plan'] ?? '', 'monthly' ); ?>><?php esc_html_e( 'Monthly', 'ts-lms' ); ?></option>
												<option value="yearly" <?php selected( $bundle_data['sub_plan'] ?? '', 'yearly' ); ?>><?php esc_html_e( 'Yearly', 'ts-lms' ); ?></option>
											</select>
										</div>
										<div class="ts-pricing-field">
											<label class="ts-pricing-label"><?php esc_html_e( 'Price', 'ts-lms' ); ?></label>
											<div class="ts-input-with-icon">
												<span class="ts-currency-symbol"><?php echo function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '$'; ?></span>
												<input type="number" name="subscription_price" class="ts-pricing-input" step="0.01" value="<?php echo esc_attr( $bundle_data['sub_price'] ?? '' ); ?>" placeholder="0.00">
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<!-- Featured Image -->
					<div class="ts-editor-card">
						<div class="ts-card-header">
							<h3><?php esc_html_e( 'Bundle Image', 'ts-lms' ); ?></h3>
						</div>
						<div class="ts-card-body">
							<div id="ts-bundle-image-container">
								<?php 
								$image_url = $bundle_data['thumbnail_id'] ? wp_get_attachment_image_url( $bundle_data['thumbnail_id'], 'medium' ) : '';
								?>
								<div class="ts-image-preview <?php echo $image_url ? 'has-image' : ''; ?>" id="ts-bundle-image-preview">
									<?php if ( $image_url ) : ?>
										<img src="<?php echo esc_url( $image_url ); ?>" alt="">
									<?php else : ?>
										<div class="ts-image-placeholder">
											<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor">
												<rect x="3" y="3" width="18" height="18" rx="2" stroke-width="2"/>
												<circle cx="8.5" cy="8.5" r="1.5" stroke-width="2"/>
												<path d="M21 15l-5-5L5 21" stroke-width="2"/>
											</svg>
											<p><?php esc_html_e( 'Click to select image', 'ts-lms' ); ?></p>
										</div>
									<?php endif; ?>
								</div>
								<input type="hidden" name="thumbnail_id" id="ts-bundle-thumbnail-id" value="<?php echo esc_attr( $bundle_data['thumbnail_id'] ?? '' ); ?>">
								<div class="ts-image-actions">
									<button type="button" id="ts-set-bundle-image" class="ts-btn-link"><?php esc_html_e( 'Set image', 'ts-lms' ); ?></button>
									<button type="button" id="ts-remove-bundle-image" class="ts-btn-link ts-btn-danger <?php echo ! $image_url ? 'hidden' : ''; ?>"><?php esc_html_e( 'Remove', 'ts-lms' ); ?></button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
<?php endif; ?>

