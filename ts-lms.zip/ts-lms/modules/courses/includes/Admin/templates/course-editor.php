<?php
/**
 * Custom Course Editor Template
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_new = empty( $course_id );
$page_title = $is_new ? __( 'Create New Course', 'ts-lms' ) : __( 'Edit Course', 'ts-lms' );

// Get instructor permissions
$settings = \TS_LMS\Admin\Settings::get_settings();
$current_user = wp_get_current_user();
$is_admin = current_user_can( 'manage_options' );
$is_instructor = in_array( 'instructor', (array) $current_user->roles ) && ! $is_admin;
$allow_publish = ! $is_instructor || ( isset( $settings['allow_publish_courses'] ) && $settings['allow_publish_courses'] );
$allow_change_author = ! $is_instructor || ( isset( $settings['allow_change_author'] ) && $settings['allow_change_author'] );
$allow_trash = ! $is_instructor || ( isset( $settings['allow_trash_courses'] ) && $settings['allow_trash_courses'] );

// Visibility helper
$visibility = isset( $settings['builder_visibility'] ) ? $settings['builder_visibility'] : array();
$can_view = function( $item_id ) use ( $is_admin, $is_instructor, $visibility ) {
    $role = $is_admin ? 'admin' : ( $is_instructor ? 'instructor' : '' );
    if ( ! $role ) return true;
    return ! isset( $visibility[$item_id] ) || ( isset( $visibility[$item_id][$role] ) && $visibility[$item_id][$role] );
};
?>

<div class="wrap ts-course-editor-v2">
	<!-- Hidden Course ID -->
	<input type="hidden" id="course-id" value="<?php echo esc_attr( $course_id ); ?>">
	
	<!-- Course Builder Header -->
	<div class="ts-builder-header">
		<!-- Left: Logo -->
		<div class="ts-header-left">
			<img src="<?php echo esc_url( plugins_url( 'assets/img/ts-lms-logo.png', dirname( dirname( dirname( dirname( dirname( __FILE__ ) ) ) ) ) ) ); ?>" alt="Logo" class="ts-editor-logo">
		</div>

		<!-- Center: Progress Steps -->
		<div class="ts-header-center">
			<div class="ts-builder-steps">
				<div class="ts-step ts-step-active" data-step="1">
					<span class="ts-step-number">1</span>
					<span class="ts-step-label"><?php esc_html_e( 'Basics', 'ts-lms' ); ?></span>
				</div>
				<div class="ts-step-divider"></div>
				<div class="ts-step" data-step="2">
					<span class="ts-step-number">2</span>
					<span class="ts-step-label"><?php esc_html_e( 'Curriculum', 'ts-lms' ); ?></span>
				</div>
				<div class="ts-step-divider"></div>
				<div class="ts-step" data-step="3">
					<span class="ts-step-number">3</span>
					<span class="ts-step-label"><?php esc_html_e( 'Additional', 'ts-lms' ); ?></span>
				</div>
			</div>
		</div>

		<!-- Right: Actions -->
		<div class="ts-header-right">
			<div class="ts-builder-actions">
				<button type="button" id="ts-preview-course" class="ts-btn-preview" <?php echo $is_new ? 'style="display:none;"' : ''; ?>>
					<span class="dashicons dashicons-visibility"></span>
					<?php esc_html_e( 'Preview', 'ts-lms' ); ?>
				</button>
				<div class="ts-publish-group">
					<button type="button" id="ts-publish-course" class="ts-btn-publish" <?php echo ! $allow_publish ? 'title="' . esc_attr__( 'Your course will be submitted for admin review', 'ts-lms' ) . '"' : ''; ?>>
						<?php echo ! $allow_publish ? esc_html__( 'Submit for Review', 'ts-lms' ) : esc_html__( 'Publish', 'ts-lms' ); ?>
					</button>
					<button type="button" class="ts-btn-publish-dropdown">
						<span class="dashicons dashicons-arrow-down-alt2"></span>
					</button>
					<div class="ts-publish-more-menu" style="display:none;">
						<button type="button" id="ts-save-draft" class="ts-publish-more-item">
							<span class="dashicons dashicons-edit"></span>
							<?php esc_html_e( 'Save as Draft', 'ts-lms' ); ?>
						</button>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Main Content Area -->
	<div class="ts-builder-content">
		<!-- Left Panel -->
		<div class="ts-builder-main">
			<!-- Step 1: Basics -->
		<div class="ts-step-content ts-step-content-active" data-step="1">
			<div class="ts-basics-layout">
				<!-- Main Content Area -->
				<div class="ts-basics-main-content">
					
				<!-- Title Field -->
				<div class="ts-field-group">
					<div class="ts-course-title-section">
						<input type="text" name="course_title" id="course-title" class="ts-title-input" placeholder="<?php esc_attr_e( 'Course Title', 'ts-lms' ); ?>" value="<?php echo esc_attr( $course_data['title'] ?? '' ); ?>">
						<input type="hidden" name="course_slug" id="course-slug" value="<?php echo esc_attr( $course->post_name ?? '' ); ?>">
					</div>

					<div class="ts-course-url-display">
						<span class="ts-url-label"><?php esc_html_e( 'Course URL:', 'ts-lms' ); ?></span>
						<span class="ts-url-value"><?php echo $is_new ? esc_url( home_url( '/course/placeholder' ) ) : esc_url( get_permalink( $course_id ) ); ?></span>
						<span class="ts-status-badge <?php echo esc_attr( $course_data['status'] ?? 'draft' ); ?>"><?php echo esc_html( ucfirst( $course_data['status'] ?? 'draft' ) ); ?></span>
						<button type="button" class="ts-url-edit-btn" title="<?php esc_attr_e( 'Edit URL', 'ts-lms' ); ?>">
							<span class="dashicons dashicons-admin-links"></span>
						</button>
					</div>
				</div>

					<!-- Description Field -->
					<div class="ts-field-group">
						<label class="ts-field-label">
							<?php esc_html_e( 'About this course', 'ts-lms' ); ?>
							<span class="ts-required-star">*</span>
						</label>
						<div class="ts-editor-container">
							<?php
							wp_editor(
								$course_data['description'] ?? '',
								'course_description',
								array(
									'textarea_name' => 'content',
									'textarea_rows' => 10,
									'media_buttons' => true,
									'teeny'         => false,
									'editor_class'  => 'ts-wp-editor',
									'quicktags'     => true,
								)
							);
							?>
						</div>
					</div>

					<!-- Options Section -->
					<div class="ts-field-group">
						<label class="ts-field-label"><?php esc_html_e( 'Options', 'ts-lms' ); ?></label>
						
						<div class="ts-options-container">
							<!-- Vertical Tabs -->
							<div class="ts-vertical-tabs">
								<?php if ( $can_view( 'general' ) ) : ?>
								<button type="button" class="ts-vtab active" data-tab="general">
									<span class="ts-vtab-icon dashicons dashicons-admin-generic"></span>
									<?php esc_html_e( 'General', 'ts-lms' ); ?>
								</button>
								<?php endif; ?>
								
								<?php if ( $can_view( 'content_drip' ) ) : ?>
								<button type="button" class="ts-vtab" data-tab="content-drip">
									<span class="ts-vtab-icon dashicons dashicons-calendar-alt"></span>
									<?php esc_html_e( 'Content Drip', 'ts-lms' ); ?>
								</button>
								<?php endif; ?>

								<?php if ( $can_view( 'enrollment' ) ) : ?>
								<button type="button" class="ts-vtab" data-tab="enrollment">
									<span class="ts-vtab-icon dashicons dashicons-groups"></span>
									<?php esc_html_e( 'Enrollment', 'ts-lms' ); ?>
								</button>
								<?php endif; ?>
							</div>

								<!-- Tab Content -->
					<div class="ts-vtab-content-area">
							<!-- General Tab -->
					<?php if ( $can_view( 'general' ) ) : ?>
					<div class="ts-vtab-panel active" data-panel="general">
						
						<!-- Difficulty Level -->
						<div class="ts-simple-row">
							<label class="ts-simple-label">
								<?php esc_html_e( 'Difficulty Level', 'ts-lms' ); ?>
								<span class="dashicons dashicons-info-outline ts-info-tooltip"></span>
							</label>
							<select name="difficulty_level" class="ts-simple-select">
								<option value="beginner"><?php esc_html_e( 'Beginner', 'ts-lms' ); ?></option>
								<option value="intermediate" selected><?php esc_html_e( 'Intermediate', 'ts-lms' ); ?></option>
								<option value="advanced"><?php esc_html_e( 'Advanced', 'ts-lms' ); ?></option>
								<option value="all-levels"><?php esc_html_e( 'All Levels', 'ts-lms' ); ?></option>
							</select>
						</div>

						<!-- Public Course Toggle -->
						<div class="ts-simple-row">
							<label class="ts-simple-label">
								<?php esc_html_e( 'Public Course', 'ts-lms' ); ?>
								<span class="dashicons dashicons-info-outline ts-info-tooltip"></span>
							</label>
							<label class="ts-toggle-switch">
								<input type="checkbox" name="public_course" <?php checked( $course_data['public_course'] ?? false ); ?>>
								<span class="ts-toggle-slider"></span>
							</label>
						</div>

						<!-- Q&A Toggle -->
						<div class="ts-simple-row">
							<label class="ts-simple-label">
								<?php esc_html_e( 'Q&A', 'ts-lms' ); ?>
								<span class="dashicons dashicons-info-outline ts-info-tooltip"></span>
							</label>
							<label class="ts-toggle-switch">
								<input type="checkbox" name="qa_enabled" <?php checked( $course_data['qa_enabled'] ?? false ); ?>>
								<span class="ts-toggle-slider"></span>
							</label>
						</div>

					</div>
					<?php endif; ?>

							<!-- Content Drip Tab -->
					<?php if ( $can_view( 'content_drip' ) ) : ?>
					<div class="ts-vtab-panel" data-panel="content-drip">
						
						<div class="ts-drip-header">
							<h3 class="ts-drip-title"><?php esc_html_e( 'Content Drip Type', 'ts-lms' ); ?></h3>
							<p class="ts-drip-subtitle"><?php esc_html_e( 'You can schedule your course content using one of the following Content Drip options', 'ts-lms' ); ?></p>
						</div>

						<div class="ts-radio-group">
							<!-- Schedule by Date -->
							<label class="ts-radio-option-block">
								<input type="radio" name="content_drip_type" value="by-date">
								<span class="ts-radio-circle"></span>
								<span class="ts-radio-text"><?php esc_html_e( 'Schedule course content by date', 'ts-lms' ); ?></span>
							</label>

							<!-- Days After Enrollment -->
							<label class="ts-radio-option-block">
								<input type="radio" name="content_drip_type" value="after-enrollment">
								<span class="ts-radio-circle"></span>
								<span class="ts-radio-text"><?php esc_html_e( 'Content available after X days from enrollment', 'ts-lms' ); ?></span>
							</label>

							<!-- Sequential -->
							<label class="ts-radio-option-block">
								<input type="radio" name="content_drip_type" value="sequential">
								<span class="ts-radio-circle"></span>
								<span class="ts-radio-text"><?php esc_html_e( 'Course content available sequentially', 'ts-lms' ); ?></span>
							</label>

							<!-- After Prerequisites -->
							<label class="ts-radio-option-block">
								<input type="radio" name="content_drip_type" value="after-prerequisites">
								<span class="ts-radio-circle"></span>
								<span class="ts-radio-text"><?php esc_html_e( 'Course content unlocked after finishing prerequisites', 'ts-lms' ); ?></span>
							</label>

							<!-- None -->
							<label class="ts-radio-option-block">
								<input type="radio" name="content_drip_type" value="none" checked>
								<span class="ts-radio-circle"></span>
								<span class="ts-radio-text"><?php esc_html_e( 'None', 'ts-lms' ); ?></span>
							</label>
						</div>

					</div>
					<?php endif; ?>

							<!-- Enrollment Tab -->
					<?php if ( $can_view( 'enrollment' ) ) : ?>
					<div class="ts-vtab-panel" data-panel="enrollment">
						
						<!-- Maximum Student -->
						<div class="ts-enrollment-field">
							<label class="ts-enrollment-label">
								<?php esc_html_e( 'Maximum Student', 'ts-lms' ); ?>
								<span class="dashicons dashicons-info-outline ts-info-tooltip"></span>
							</label>
							<input type="number" name="max_students" class="ts-enrollment-input" placeholder="0" min="0" value="0">
						</div>

						<!-- Course Enrollment Period -->
						<div class="ts-enrollment-field">
							<label class="ts-enrollment-label">
								<?php esc_html_e( 'Course Enrollment Period', 'ts-lms' ); ?>
							</label>
							<label class="ts-toggle-switch">
								<input type="checkbox" name="enrollment_period_enabled">
								<span class="ts-toggle-slider"></span>
							</label>
						</div>

						<!-- Pause Enrollment -->
						<div class="ts-enrollment-checkbox">
							<label class="ts-checkbox-label">
								<input type="checkbox" name="pause_enrollment" class="ts-checkbox-input">
								<span class="ts-checkbox-text">
									<?php esc_html_e( 'Pause Enrollment', 'ts-lms' ); ?>
								</span>
							</label>
							<p class="ts-checkbox-desc">
								<?php esc_html_e( 'If you pause enrollment, students will no longer be able to enroll in the course.', 'ts-lms' ); ?>
							</p>
						</div>

					</div>
					<?php endif; ?>
				</div>
					</div>
				</div>

					<!-- Next Button -->
					<div class="ts-form-actions">
						<button type="button" class="ts-btn-next" data-next-step="2">
							<?php esc_html_e( 'Next', 'ts-lms' ); ?>
							<span class="dashicons dashicons-arrow-right-alt2"></span>
						</button>
					</div>

				</div>

				<!-- Sidebar -->
				<div class="ts-basics-sidebar-content">
					
					<!-- Visibility -->
					<div class="ts-sidebar-section">
						<label class="ts-sidebar-label"><?php esc_html_e( 'Visibility', 'ts-lms' ); ?></label>
						<select name="post_status" class="ts-sidebar-select">
							<option value="publish" <?php selected( get_post_status( $course_id ), 'publish' ); ?>>
								<span class="dashicons dashicons-visibility"></span>
								<?php esc_html_e( 'Public', 'ts-lms' ); ?>
							</option>
							<option value="private" <?php selected( get_post_status( $course_id ), 'private' ); ?>><?php esc_html_e( 'Private', 'ts-lms' ); ?></option>
							<option value="draft" <?php selected( get_post_status( $course_id ), 'draft' ); ?>><?php esc_html_e( 'Draft', 'ts-lms' ); ?></option>
						</select>
						<p class="ts-sidebar-meta"><?php printf( esc_html__( 'Last updated on 7th January, 2026', 'ts-lms' ) ); ?></p>
					</div>

					<!-- Schedule -->
					<div class="ts-sidebar-section">
						<label class="ts-sidebar-label"><?php esc_html_e( 'Schedule', 'ts-lms' ); ?></label>
						<label class="ts-toggle-switch">
							<input type="checkbox" name="is_scheduled">
							<span class="ts-toggle-slider"></span>
						</label>
					</div>

					<div class="ts-sidebar-divider"></div>

					<!-- Featured Image -->
					<?php if ( $can_view( 'featured_image' ) ) : ?>
					<div class="ts-sidebar-section">
						<label class="ts-sidebar-label">
							<?php esc_html_e( 'Featured Image', 'ts-lms' ); ?>
							<span class="ts-required-star">*</span>
						</label>
						<?php 
							$thumb_id = get_post_thumbnail_id( $course_id );
							$thumb_url = $thumb_id ? wp_get_attachment_url( $thumb_id ) : '';
						?>
						<div class="ts-image-upload-area" id="ts-featured-image-upload">
							<?php if ( $thumb_url ) : ?>
								<img src="<?php echo esc_url( $thumb_url ); ?>" class="ts-uploaded-image">
								<button type="button" class="ts-remove-image"><span class="dashicons dashicons-no-alt"></span></button>
							<?php else : ?>
								<div class="ts-upload-placeholder">
									<span class="dashicons dashicons-format-image ts-upload-icon"></span>
									<button type="button" class="ts-upload-btn"><?php esc_html_e( 'Upload Thumbnail', 'ts-lms' ); ?></button>
									<p class="ts-upload-hint"><?php esc_html_e( 'JPEG, PNG, GIF, and WebP formats, up to 40 MB', 'ts-lms' ); ?></p>
								</div>
							<?php endif; ?>
						</div>
						<input type="hidden" name="_thumbnail_id" id="_thumbnail_id" value="<?php echo esc_attr( $thumb_id ); ?>">
					</div>
					<?php endif; ?>

					<div class="ts-sidebar-divider"></div>

				<!-- Intro Video -->
					<?php if ( $can_view( 'intro_video' ) ) : ?>
					<div class="ts-sidebar-section">
						<label class="ts-sidebar-label"><?php esc_html_e( 'Intro Video', 'ts-lms' ); ?></label>
						<div class="ts-video-upload-buttons">
							<button type="button" class="ts-video-btn ts-video-upload">
								<span class="dashicons dashicons-video-alt3"></span>
								<?php esc_html_e( 'Upload Video', 'ts-lms' ); ?>
							</button>
							<button type="button" class="ts-video-btn ts-video-url">
								<?php esc_html_e( 'Add from URL', 'ts-lms' ); ?>
							</button>
						</div>
						
						<!-- Video Preview Area -->
						<div class="ts-video-preview-container" id="ts-video-preview-container" style="display: none; margin-top: 15px;">
							<div class="ts-video-preview-wrapper">
								<div id="ts-video-preview-content"></div>
								<button type="button" class="ts-remove-video-preview" title="<?php esc_attr_e( 'Remove Video', 'ts-lms' ); ?>">
									<span class="dashicons dashicons-no-alt"></span>
								</button>
							</div>
						</div>

						<!-- Video URL Input (Hidden by default) -->
						<div class="ts-video-url-input-area" id="ts-video-url-input-area" style="display: none; margin-top: 10px;">
							<div class="ts-video-url-input-group">
								<input 
									type="text" 
									name="ts_course_video_url" 
									id="ts-course-video-url"
									class="ts-video-url-input" 
									placeholder="<?php esc_attr_e( 'Paste video URL here', 'ts-lms' ); ?>" 
									value="<?php echo esc_attr( get_post_meta( $course_id, '_course_intro_video_url', true ) ); ?>"
								>
								<button type="button" class="ts-video-url-add-btn" id="ts-intro-video-url-add-btn">
									<?php esc_html_e( 'Add', 'ts-lms' ); ?>
								</button>
							</div>
						</div>
						
						<input type="hidden" name="ts_course_video_source" id="ts-course-video-source" value="<?php echo esc_attr( get_post_meta( $course_id, '_course_intro_video_source', true ) ?: 'external' ); ?>">

						<p class="ts-upload-hint"><?php esc_html_e( 'Supports YouTube, Vimeo, and direct MP4 links.', 'ts-lms' ); ?></p>
					</div>
					<?php endif; ?>

					<div class="ts-sidebar-divider"></div>

					<!-- Pricing Model -->
					<!-- Pricing Model -->
				<?php if ( $can_view( 'pricing_options' ) ) : ?>
				<div class="ts-sidebar-section ts-pricing-section">
					<label class="ts-sidebar-label"><?php esc_html_e( 'Pricing Model', 'ts-lms' ); ?></label>
					
					<div class="ts-pricing-options">
						<label class="ts-pricing-option">
							<input type="radio" name="pricing_model" value="free" id="pricing-free" <?php checked( get_post_meta( $course_id, '_course_price_type', true ), 'free' ); ?>>
							<div class="ts-pricing-card">
								<span class="ts-pricing-icon dashicons dashicons-smiley"></span>
								<span class="ts-pricing-title"><?php esc_html_e( 'Free', 'ts-lms' ); ?></span>
							</div>
						</label>
						
						<label class="ts-pricing-option">
							<input type="radio" name="pricing_model" value="paid" id="pricing-paid" <?php checked( get_post_meta( $course_id, '_course_price_type', true ), 'paid' ); ?>>
							<div class="ts-pricing-card">
								<span class="ts-pricing-icon dashicons dashicons-cart"></span>
								<span class="ts-pricing-title"><?php esc_html_e( 'One-Time', 'ts-lms' ); ?></span>
							</div>
						</label>
						
						<label class="ts-pricing-option">
							<input type="radio" name="pricing_model" value="subscription" id="pricing-subscription" <?php checked( get_post_meta( $course_id, '_course_price_type', true ), 'subscription' ); ?>>
							<div class="ts-pricing-card">
								<span class="ts-pricing-icon dashicons dashicons-calendar-alt"></span>
								<span class="ts-pricing-title"><?php esc_html_e( 'Subscription', 'ts-lms' ); ?></span>
							</div>
						</label>
					</div>
					
					<!-- Product Selection (Shows when Paid is selected) -->
					<div class="ts-pricing-settings-panel" id="ts-product-selection" style="display: none;">
						<div class="ts-pricing-field full-width">
							<label class="ts-pricing-label">
								<?php esc_html_e( 'Select Product', 'ts-lms' ); ?>
								<span class="ts-tooltip dashicons dashicons-info-outline" title="<?php esc_attr_e( 'Link this course to a WooCommerce product for payment.', 'ts-lms' ); ?>"></span>
							</label>
							<select name="course_product" id="course-product-select" class="ts-pricing-select">
								<option value=""><?php esc_html_e( 'Select a product', 'ts-lms' ); ?></option>
								<?php
								// Get WooCommerce products
								if ( class_exists( 'WooCommerce' ) ) {
									// Get the course title
									$course_title = get_the_title( $course_id );
									
									// Get all published products
									$args = array(
										'post_type' => 'product',
										'posts_per_page' => -1,
										'post_status' => 'publish',
									);
									$all_products = get_posts( $args );
									
									// Filter products to only show those with the same name as the course
									$matching_products = array();
									foreach ( $all_products as $product ) {
										if ( trim( $product->post_title ) === trim( $course_title ) ) {
											$matching_products[] = $product;
										}
									}
									
									// Get the currently selected product
									$selected_product = get_post_meta( $course_id, '_course_product_id', true );
									
									// Auto-select if there's exactly one matching product and no product is currently selected
									if ( count( $matching_products ) === 1 && empty( $selected_product ) ) {
										$selected_product = $matching_products[0]->ID;
										// Save the auto-selected product
										update_post_meta( $course_id, '_course_product_id', $selected_product );
									}
									
									// Display only matching products
									foreach ( $matching_products as $product ) {
										$price = get_post_meta( $product->ID, '_price', true );
										echo '<option value="' . esc_attr( $product->ID ) . '" data-price="' . esc_attr( $price ) . '" ' . selected( $selected_product, $product->ID, false ) . '>' . esc_html( $product->post_title ) . '</option>';
									}
									
									// If no matching products found, show a message
									if ( empty( $matching_products ) ) {
										echo '<option value="" disabled>' . esc_html__( 'No products found with matching course title', 'ts-lms' ) . '</option>';
									}
								}
								?>
							</select>
						</div>
					</div>

					<!-- Subscription Settings (Shows when Subscription is selected) -->
					<div class="ts-pricing-settings-panel" id="ts-subscription-settings" style="display: none;">
						<div class="ts-pricing-grid">
							<!-- Plan Type -->
							<div class="ts-pricing-field">
								<label class="ts-pricing-label"><?php esc_html_e( 'Plan Type', 'ts-lms' ); ?></label>
								<select name="subscription_plan_type" id="subscription-plan-type" class="ts-pricing-select">
									<?php $plan_type = get_post_meta( $course_id, '_subscription_plan_type', true ) ?: 'monthly'; ?>
									<option value="weekly" <?php selected( $plan_type, 'weekly' ); ?>><?php esc_html_e( 'Weekly', 'ts-lms' ); ?></option>
									<option value="monthly" <?php selected( $plan_type, 'monthly' ); ?>><?php esc_html_e( 'Monthly', 'ts-lms' ); ?></option>
									<option value="yearly" <?php selected( $plan_type, 'yearly' ); ?>><?php esc_html_e( 'Yearly', 'ts-lms' ); ?></option>
								</select>
							</div>


						</div>

						<!-- Access Rule -->
						<div class="ts-pricing-field full-width">
							<label class="ts-pricing-label"><?php esc_html_e( 'Access Rule', 'ts-lms' ); ?></label>
							<div class="ts-access-rule-box">
								<div class="ts-rule-item active">
									<span class="dashicons dashicons-yes-alt"></span>
									<span><?php esc_html_e( 'Active: Unlock course', 'ts-lms' ); ?></span>
								</div>
								<div class="ts-rule-item expired">
									<span class="dashicons dashicons-dismiss"></span>
									<span><?php esc_html_e( 'Expired: Auto-lock', 'ts-lms' ); ?></span>
								</div>
							</div>
						</div>

						<!-- Scope -->
						<div class="ts-pricing-field full-width">
							<label class="ts-pricing-label"><?php esc_html_e( 'Subscription Scope', 'ts-lms' ); ?></label>
							<div class="ts-scope-options">
								<label class="ts-radio-box">
									<input type="radio" name="subscription_scope" value="course" <?php checked( get_post_meta( $course_id, '_subscription_scope', true ) ?: 'course', 'course' ); ?>>
									<span class="ts-radio-box-content">
										<span class="ts-radio-box-circle"></span>
										<?php esc_html_e( 'Only this course', 'ts-lms' ); ?>
									</span>
								</label>
								<label class="ts-radio-box">
									<input type="radio" name="subscription_scope" value="bundle" <?php checked( get_post_meta( $course_id, '_subscription_scope', true ), 'bundle' ); ?>>
									<span class="ts-radio-box-content">
										<span class="ts-radio-box-circle"></span>
										<?php esc_html_e( 'Part of Bundle', 'ts-lms' ); ?>
									</span>
								</label>
							</div>
						</div>

					</div>
				</div>
				<?php endif; ?>

					<div class="ts-sidebar-divider"></div>

					<!-- Categories -->
				<?php if ( $can_view( 'categories' ) ) : ?>
				<div class="ts-sidebar-section">
					<label class="ts-sidebar-label"><?php esc_html_e( 'Categories', 'ts-lms' ); ?></label>
					
					<!-- Categories List -->
					<div class="ts-categories-box">
						<div class="ts-categories-list" id="ts-categories-list">
							<?php
							$categories = get_terms( array( 'taxonomy' => 'ts_course_category', 'hide_empty' => false ) );
							if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
								foreach ( $categories as $category ) {
									$checked = has_term( $category->term_id, 'ts_course_category', $course_id ) ? 'checked' : '';
									echo '<label class="ts-checkbox-item"><input type="checkbox" name="tax_input[ts_course_category][]" value="' . esc_attr( $category->term_id ) . '" ' . $checked . '> ' . esc_html( $category->name ) . '</label>';
								}
							} else {
								echo '<p class="ts-no-categories">' . esc_html__( 'No categories found.', 'ts-lms' ) . '</p>';
							}
							?>
						</div>
						
						<!-- Add Button -->
						<button type="button" class="ts-add-category-btn" id="ts-add-category-btn">
							<span class="dashicons dashicons-plus-alt2"></span>
							<?php esc_html_e( 'Add', 'ts-lms' ); ?>
						</button>
					</div>

					<!-- Add Category Form (Hidden by default) -->
					<div class="ts-add-category-form" id="ts-add-category-form" style="display: none;">
						<input 
							type="text" 
							id="ts-new-category-name" 
							class="ts-category-input" 
							placeholder="<?php esc_attr_e( 'Category name', 'ts-lms' ); ?>"
						>
						<select id="ts-category-parent" class="ts-category-select">
							<option value="0"><?php esc_html_e( 'Select parent', 'ts-lms' ); ?></option>
							<?php
							if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
								foreach ( $categories as $category ) {
									echo '<option value="' . esc_attr( $category->term_id ) . '">' . esc_html( $category->name ) . '</option>';
								}
							}
							?>
						</select>
						<div class="ts-category-form-actions">
							<button type="button" class="ts-category-cancel-btn" id="ts-category-cancel-btn">
								<?php esc_html_e( 'Cancel', 'ts-lms' ); ?>
							</button>
							<button type="button" class="ts-category-ok-btn" id="ts-category-ok-btn">
								<?php esc_html_e( 'Ok', 'ts-lms' ); ?>
							</button>
						</div>
					</div>
				</div>
				<?php endif; ?>

					<div class="ts-sidebar-divider"></div>

					<!-- Tags -->
					<?php if ( $can_view( 'tags' ) ) : ?>
					<div class="ts-sidebar-section">
						<label class="ts-sidebar-label"><?php esc_html_e( 'Tags', 'ts-lms' ); ?></label>
						
						<!-- Tags List -->
						<div class="ts-categories-box">
							<div class="ts-categories-list" id="ts-tags-list">
								<?php
								$tags = get_terms( array( 'taxonomy' => 'ts_course_tag', 'hide_empty' => false ) );
								if ( ! empty( $tags ) && ! is_wp_error( $tags ) ) {
									foreach ( $tags as $tag ) {
										$checked = has_term( $tag->term_id, 'ts_course_tag', $course_id ) ? 'checked' : '';
										echo '<label class="ts-checkbox-item"><input type="checkbox" name="tax_input[ts_course_tag][]" value="' . esc_attr( $tag->term_id ) . '" ' . $checked . '> ' . esc_html( $tag->name ) . '</label>';
									}
								} else {
									echo '<p class="ts-no-categories">' . esc_html__( 'No tags found.', 'ts-lms' ) . '</p>';
								}
								?>
							</div>
							
							<!-- Add Button -->
							<button type="button" class="ts-add-category-btn" id="ts-add-tag-btn">
								<span class="dashicons dashicons-plus-alt2"></span>
								<?php esc_html_e( 'Add', 'ts-lms' ); ?>
							</button>
						</div>

						<!-- Add Tag Form (Hidden by default) -->
						<div class="ts-add-category-form" id="ts-add-tag-form" style="display: none;">
							<input 
								type="text" 
								id="ts-new-tag-name" 
								class="ts-category-input" 
								placeholder="<?php esc_attr_e( 'Tag name', 'ts-lms' ); ?>"
							>
							<div class="ts-category-form-actions">
								<button type="button" class="ts-category-cancel-btn" id="ts-tag-cancel-btn">
									<?php esc_html_e( 'Cancel', 'ts-lms' ); ?>
								</button>
								<button type="button" class="ts-category-ok-btn" id="ts-tag-ok-btn">
									<?php esc_html_e( 'Ok', 'ts-lms' ); ?>
								</button>
							</div>
						</div>
					</div>
					<?php endif; ?>

					<div class="ts-sidebar-divider"></div>

					<!-- Author -->
				<?php if ( $can_view( 'author' ) ) : ?>
				<div class="ts-sidebar-section">
					<label class="ts-sidebar-label"><?php esc_html_e( 'Author', 'ts-lms' ); ?></label>
					<?php
					$author_id = get_post_field( 'post_author', $course_id );
					$author = get_userdata( $author_id );
					?>
					<div class="ts-author-select-box">
						<div class="ts-author-display">
							<div class="ts-author-avatar">
								<?php echo get_avatar( $author_id, 40 ); ?>
							</div>
							<div class="ts-author-details">
								<div class="ts-author-name"><?php echo esc_html( $author->display_name ?? 'Admin' ); ?></div>
								<div class="ts-author-email"><?php echo esc_html( $author->user_email ?? '' ); ?></div>
							</div>
						</div>
						<select name="post_author" class="ts-author-dropdown" <?php echo ! $allow_change_author ? 'disabled title="' . esc_attr__( 'You do not have permission to change the course author', 'ts-lms' ) . '"' : ''; ?>>
							<?php
							$users = get_users();
							foreach ( $users as $user ) {
								$user_avatar = get_avatar_url( $user->ID, array( 'size' => 40 ) );
								echo '<option value="' . esc_attr( $user->ID ) . '" data-email="' . esc_attr( $user->user_email ) . '" data-avatar="' . esc_url( $user_avatar ) . '" ' . selected( $author_id, $user->ID, false ) . '>' . esc_html( $user->display_name ) . '</option>';
							}
							?>
						</select>
						<span class="dashicons dashicons-arrow-down-alt2 ts-author-arrow"></span>
					</div>
				</div>
				<?php endif; ?>
				</div>
			</div>
		</div>

			<!-- Step 2: Curriculum -->
		<div class="ts-step-content" data-step="2">
			<!-- Curriculum Summary Bar -->
			<div class="ts-curriculum-summary-bar">
				<div class="ts-summary-item">
					<span class="ts-summary-label"><?php esc_html_e( 'Total Lessons:', 'ts-lms' ); ?></span>
					<span class="ts-summary-value" id="ts-total-lessons">0</span>
				</div>
				<div class="ts-summary-item">
					<span class="ts-summary-label"><?php esc_html_e( 'Total Quizzes:', 'ts-lms' ); ?></span>
					<span class="ts-summary-value" id="ts-total-quizzes">0</span>
				</div>
				<div class="ts-summary-item">
					<span class="ts-summary-label"><?php esc_html_e( 'Total Assignments:', 'ts-lms' ); ?></span>
					<span class="ts-summary-value" id="ts-total-assignments">0</span>
				</div>
				<div class="ts-summary-item">
					<span class="ts-summary-label"><?php esc_html_e( 'Total Duration:', 'ts-lms' ); ?></span>
					<span class="ts-summary-value" id="ts-total-duration">0m</span>
				</div>
			</div>

			<!-- Curriculum Header -->
			<div class="ts-curriculum-header">
				<div class="ts-curriculum-header-left">
					<button type="button" class="ts-curriculum-back-btn" onclick="CourseEditor.handleStepClick({currentTarget: $('.ts-step[data-step=1]')[0]})">
						<span class="dashicons dashicons-arrow-left-alt2"></span>
					</button>
					<h2 class="ts-curriculum-title"><?php esc_html_e( 'Curriculum', 'ts-lms' ); ?></h2>
				</div>
				<div class="ts-curriculum-header-right">
					<a href="#" class="ts-expand-all" id="ts-expand-all-topics"><?php esc_html_e( 'Expand All', 'ts-lms' ); ?></a>
				</div>
			</div>

			<!-- Curriculum Content -->
			<div class="ts-curriculum-content">
				<!-- Topics Container -->
				<div class="ts-topics-list" id="ts-topics-list">
					<!-- Topics will be loaded here via AJAX -->
				</div>

				<!-- Add Topic Button -->
				<div class="ts-add-topic-container">
					<button type="button" class="ts-add-topic-btn-final" id="ts-add-topic-btn">
						<span class="dashicons dashicons-plus"></span>
						<?php esc_html_e( 'Add Topic', 'ts-lms' ); ?>
					</button>
				</div>

				<!-- Navigation Buttons -->
				<div class="ts-curriculum-navigation">
					<button type="button" class="ts-curriculum-nav-btn ts-nav-prev" onclick="CourseEditor.handleStepClick({currentTarget: $('.ts-step[data-step=1]')[0]})">
						<span class="dashicons dashicons-arrow-left-alt2"></span>
					</button>
					<button type="button" class="ts-curriculum-nav-btn ts-nav-next" onclick="CourseEditor.handleStepClick({currentTarget: $('.ts-step[data-step=3]')[0]})">
						<?php esc_html_e( 'Next', 'ts-lms' ); ?>
						<span class="dashicons dashicons-arrow-right-alt2"></span>
					</button>
				</div>
			</div>
		</div>

			<!-- Step 3: Additional -->
			<div class="ts-step-content" data-step="3">
				<div class="ts-additional-header">
					<div class="ts-additional-title-row">
						<button type="button" class="ts-back-btn" onclick="CourseEditor.handleStepClick({currentTarget: $('.ts-step[data-step=2]')[0]})">
							<span class="dashicons dashicons-arrow-left-alt2"></span>
						</button>
						<h2 class="ts-additional-title"><?php esc_html_e( 'Additional', 'ts-lms' ); ?></h2>
					</div>
				</div>

				<!-- 2-Column Layout -->
				<div class="ts-additional-grid">
					
					<!-- LEFT COLUMN: Main Content -->
					<div class="ts-additional-left">
						
						<!-- Overview Section -->
						<div class="ts-additional-overview">
							<h3 class="ts-overview-title"><?php esc_html_e( 'Overview', 'ts-lms' ); ?></h3>
							<p class="ts-overview-description"><?php esc_html_e( 'Provide essential course information to attract and inform potential students', 'ts-lms' ); ?></p>
						</div>

						<!-- What Will I Learn? -->
						<?php if ( $can_view( 'overview_learn' ) ) : ?>
						<div class="ts-lms-form-group">
							<label class="ts-lms-label"><?php esc_html_e( 'What Will I Learn?', 'ts-lms' ); ?></label>
							<textarea 
								id="course-what-will-learn" 
								class="ts-lms-form-control ts-lms-textarea" 
								rows="4"
								placeholder="<?php esc_attr_e( 'Define the key takeaways from this course (list one benefit per line)', 'ts-lms' ); ?>"
							><?php echo esc_textarea( get_post_meta( $course_id, '_what_will_learn', true ) ); ?></textarea>
						</div>
						<?php endif; ?>

						<!-- Target Audience -->
						<?php if ( $can_view( 'overview_audience' ) ) : ?>
						<div class="ts-lms-form-group">
							<label class="ts-lms-label"><?php esc_html_e( 'Target Audience', 'ts-lms' ); ?></label>
							<textarea 
								id="course-target-audience" 
								class="ts-lms-form-control ts-lms-textarea" 
								rows="4"
								placeholder="<?php esc_attr_e( 'Specify the target audience that will benefit the most from the course. (One Line Per target audience)', 'ts-lms' ); ?>"
							><?php echo esc_textarea( get_post_meta( $course_id, '_target_audience', true ) ); ?></textarea>
						</div>
						<?php endif; ?>

						<!-- Total Course Duration -->
						<?php if ( $can_view( 'overview_duration' ) ) : ?>
						<div class="ts-lms-form-group">
							<label class="ts-lms-label"><?php esc_html_e( 'Total Course Duration', 'ts-lms' ); ?></label>
							<div class="ts-duration-inputs">
								<div class="ts-duration-field">
									<input 
										type="number" 
										id="course-total-duration-hours" 
										class="ts-lms-form-control ts-duration-input" 
										value="<?php echo esc_attr( get_post_meta( $course_id, '_total_duration_hours', true ) ?: '0' ); ?>" 
										min="0" 
										placeholder="0"
									>
									<label class="ts-duration-label"><?php esc_html_e( 'hour(s)', 'ts-lms' ); ?></label>
								</div>
								<div class="ts-duration-field">
									<input 
										type="number" 
										id="course-total-duration-minutes" 
										class="ts-lms-form-control ts-duration-input" 
										value="<?php echo esc_attr( get_post_meta( $course_id, '_total_duration_minutes', true ) ?: '0' ); ?>" 
										min="0" 
										max="59" 
										placeholder="0"
									>
									<label class="ts-duration-label"><?php esc_html_e( 'min(s)', 'ts-lms' ); ?></label>
								</div>
							</div>
						</div>
						<?php endif; ?>

						<!-- Materials Included -->
						<?php if ( $can_view( 'overview_materials' ) ) : ?>
						<div class="ts-lms-form-group">
							<label class="ts-lms-label"><?php esc_html_e( 'Materials Included', 'ts-lms' ); ?></label>
							<textarea 
								id="course-materials-included" 
								class="ts-lms-form-control ts-lms-textarea" 
								rows="4"
								placeholder="<?php esc_attr_e( 'A list of assets you will be providing for the students in this course (One Per Line)', 'ts-lms' ); ?>"
							><?php echo esc_textarea( get_post_meta( $course_id, '_materials_included', true ) ); ?></textarea>
						</div>
						<?php endif; ?>

						<!-- Requirements/Instructions -->
						<?php if ( $can_view( 'overview_reqs' ) ) : ?>
						<div class="ts-lms-form-group">
							<label class="ts-lms-label"><?php esc_html_e( 'Requirements/Instructions', 'ts-lms' ); ?></label>
							<textarea 
								id="course-requirements-instructions" 
								class="ts-lms-form-control ts-lms-textarea" 
								rows="4"
								placeholder="<?php esc_attr_e( 'Additional requirements or special instructions for the students (One Per Line)', 'ts-lms' ); ?>"
							><?php echo esc_textarea( get_post_meta( $course_id, '_requirements_instructions', true ) ); ?></textarea>
						</div>
						<?php endif; ?>

						<!-- Certificate Section -->
						<?php if ( $can_view( 'certificate' ) ) : ?>
						<div class="ts-certificate-section">
							<h3 class="ts-certificate-title"><?php esc_html_e( 'Certificate', 'ts-lms' ); ?></h3>
							<p class="ts-certificate-description"><?php esc_html_e( 'Select a certificate to award your learners.', 'ts-lms' ); ?></p>

							<!-- Certificate Tabs -->
							<div class="ts-certificate-tabs">
								<button type="button" class="ts-cert-tab ts-cert-tab-active" data-tab="templates">
									<?php esc_html_e( 'Templates', 'ts-lms' ); ?>
								</button>
								<button type="button" class="ts-cert-tab" data-tab="custom">
									<?php esc_html_e( 'Custom Certificates', 'ts-lms' ); ?>
								</button>
							</div>

							<!-- Templates Tab Content -->
							<div class="ts-cert-tab-content ts-cert-tab-content-active" data-tab="templates">
								<div class="ts-cert-actions">
									<button type="button" class="ts-cert-action-btn" id="ts-cert-add">
										<span class="dashicons dashicons-plus-alt"></span>
									</button>
									<button type="button" class="ts-cert-action-btn" id="ts-cert-delete">
										<span class="dashicons dashicons-trash"></span>
									</button>
								</div>

								<div class="ts-cert-grid-wrapper">
									<button type="button" class="ts-cert-nav ts-cert-nav-prev" id="ts-cert-prev">
										<span class="dashicons dashicons-arrow-left-alt2"></span>
									</button>

									<div class="ts-cert-grid" id="ts-cert-grid">
										<?php
										// Define certificate templates
										$certificates = array(
											array( 'id' => 'none', 'name' => 'None', 'preview' => '' ),
											array( 'id' => 'cert-1', 'name' => 'Certificate 1', 'preview' => 'cert-preview-1.jpg' ),
											array( 'id' => 'cert-2', 'name' => 'Certificate 2', 'preview' => 'cert-preview-2.jpg' ),
											array( 'id' => 'cert-3', 'name' => 'Certificate 3', 'preview' => 'cert-preview-3.jpg' ),
											array( 'id' => 'cert-4', 'name' => 'Certificate 4', 'preview' => 'cert-preview-4.jpg' ),
											array( 'id' => 'cert-5', 'name' => 'Certificate 5', 'preview' => 'cert-preview-5.jpg' ),
											array( 'id' => 'cert-6', 'name' => 'Certificate 6', 'preview' => 'cert-preview-6.jpg' ),
											array( 'id' => 'cert-7', 'name' => 'Certificate 7', 'preview' => 'cert-preview-7.jpg' ),
											array( 'id' => 'cert-8', 'name' => 'Certificate 8', 'preview' => 'cert-preview-8.jpg' ),
										);

										$selected_cert = get_post_meta( $course_id, '_selected_certificate', true ) ?: 'cert-1';

										foreach ( $certificates as $cert ) :
											$is_selected = ( $selected_cert === $cert['id'] );
											$is_none = ( $cert['id'] === 'none' );
										?>
											<div class="ts-cert-item <?php echo $is_selected ? 'ts-cert-selected' : ''; ?>" data-cert-id="<?php echo esc_attr( $cert['id'] ); ?>">
												<?php if ( $is_none ) : ?>
										<div class="ts-cert-none">
											<span class="dashicons dashicons-dismiss"></span>
											<p><?php esc_html_e( 'None', 'ts-lms' ); ?></p>
										</div>
									<?php else : 
										// Define unique visual style for each certificate
										$cert_styles = array(
											'cert-1' => 'background: linear-gradient(135deg, #d4af37 0%, #f4e5b8 50%, #d4af37 100%); border: 3px solid #8b6914;',
											'cert-2' => 'background: linear-gradient(135deg, #1e3a5f 0%, #3d7ab7 100%); border: 3px solid #1e3a5f;',
											'cert-3' => 'background: linear-gradient(135deg, #e9d5ff 0%, #d8b4fe 50%, #c084fc 100%); border: 3px solid #a855f7;',
											'cert-4' => 'background: linear-gradient(135deg, #14b8a6 0%, #fbbf24 50%, #f97316 100%); border: 3px solid #14b8a6;',
											'cert-5' => 'background: linear-gradient(135deg, #1e5128 0%, #4e9f3d 100%); border: 3px solid #d4af37;',
											'cert-6' => 'background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%); border: 3px solid #00d9ff;',
											'cert-7' => 'background: linear-gradient(135deg, #ff6b6b 0%, #feca57 50%, #fff8e7 100%); border: 3px solid #ee5a6f;',
											'cert-8' => 'background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: 3px solid #ffffff;',
										);
										$style = isset( $cert_styles[$cert['id']] ) ? $cert_styles[$cert['id']] : $cert_styles['cert-1'];
									?>
										<div class="ts-cert-preview" style="<?php echo $style; ?>">
											<!-- Certificate preview with distinct styling -->
											<div class="ts-cert-placeholder">
												<span class="dashicons dashicons-awards"></span>
											</div>
											<div class="ts-cert-hover-overlay">
												<button type="button" class="ts-cert-preview-btn" data-cert-id="<?php echo esc_attr( $cert['id'] ); ?>">
													<span class="dashicons dashicons-visibility"></span>
													<?php _e('Preview', 'ts-lms'); ?>
												</button>
											</div>
										</div>
									<?php endif; ?>
												<?php if ( $is_selected ) : ?>
													<div class="ts-cert-check">
														<span class="dashicons dashicons-yes"></span>
													</div>
												<?php endif; ?>
												<div class="ts-cert-name"><?php echo esc_html( $cert['name'] ); ?></div>
											</div>
										<?php endforeach; ?>
									</div>

									<button type="button" class="ts-cert-nav ts-cert-nav-next" id="ts-cert-next">
										<span class="dashicons dashicons-arrow-right-alt2"></span>
									</button>
								</div>
							</div>

							<!-- Custom Certificates Tab Content -->
						<div class="ts-cert-tab-content" data-tab="custom" style="display: none;">
                            <?php 
                            $custom_cert_id = get_post_meta( $course_id, '_custom_certificate_id', true );
                            $custom_cert_url = $custom_cert_id ? wp_get_attachment_url( $custom_cert_id ) : '';
                            $custom_cert_name = $custom_cert_id ? get_the_title( $custom_cert_id ) : '';
                            ?>
                            <div class="ts-custom-cert-upload-area" id="ts-custom-cert-upload">
                                <?php if ( $custom_cert_url ) : ?>
                                    <div class="ts-uploaded-cert-container">
                                        <div class="ts-cert-file-preview">
                                            <span class="dashicons dashicons-media-document ts-cert-file-icon"></span>
                                            <div class="ts-cert-info">
                                                <span class="ts-cert-filename"><?php echo esc_html( $custom_cert_name ); ?></span>
                                                <a href="<?php echo esc_url( $custom_cert_url ); ?>" target="_blank" class="ts-cert-download-link"><?php esc_html_e( 'View/Download Certificate', 'ts-lms' ); ?></a>
                                            </div>
                                        </div>
                                        <button type="button" class="ts-remove-custom-cert" title="<?php esc_attr_e( 'Remove Certificate', 'ts-lms' ); ?>">
                                            <span class="dashicons dashicons-no-alt"></span>
                                        </button>
                                    </div>
                                <?php else : ?>
                                    <div class="ts-upload-placeholder">
                                        <span class="dashicons dashicons-upload ts-upload-icon"></span>
                                        <button type="button" class="ts-custom-cert-upload-btn"><?php esc_html_e( 'Upload Custom Certificate', 'ts-lms' ); ?></button>
                                        <p class="ts-upload-hint"><?php esc_html_e( 'Supported formats: PDF, JPEG, PNG', 'ts-lms' ); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <input type="hidden" name="custom_certificate_id" id="custom-certificate-id" value="<?php echo esc_attr( $custom_cert_id ); ?>">
						</div>

							<input type="hidden" id="course-selected-certificate" value="<?php echo esc_attr( $selected_cert ); ?>">
						</div>
						<?php endif; ?>

					</div>
					
					<!-- RIGHT COLUMN: Sidebar -->
					<div class="ts-additional-right">
						
						<!-- Course Prerequisites -->
						<div class="ts-additional-sidebar-section">
							<h4 class="ts-additional-sidebar-title"><?php esc_html_e( 'Course Prerequisites', 'ts-lms' ); ?></h4>
							<div class="ts-prerequisites-search">
								<input 
									type="text" 
									id="course-prerequisites-search" 
									class="ts-lms-form-control ts-search-input" 
									placeholder="<?php esc_attr_e( 'Search courses for prerequisites', 'ts-lms' ); ?>"
								>
							</div>
							<div class="ts-prerequisites-empty" id="ts-prerequisites-empty">
								<div class="ts-empty-icon">
									<svg width="80" height="80" viewBox="0 0 80 80" fill="none">
										<circle cx="40" cy="40" r="35" stroke="#E5E7EB" stroke-width="2" fill="#F9FAFB"/>
										<path d="M40 25V40L50 50" stroke="#9CA3AF" stroke-width="2" stroke-linecap="round"/>
									</svg>
								</div>
								<p class="ts-empty-text"><?php esc_html_e( 'No course selected', 'ts-lms' ); ?></p>
								<p class="ts-empty-subtext"><?php esc_html_e( 'Select a course to add as a prerequisite', 'ts-lms' ); ?></p>
							</div>
							<input type="hidden" name="course_prerequisites_ids" id="course-prerequisites-ids" value="<?php echo esc_attr( implode( ',', (array) get_post_meta( $course_id, '_course_prerequisites', true ) ) ); ?>">
							<div class="ts-prerequisites-list" id="ts-prerequisites-list" <?php echo ! empty( get_post_meta( $course_id, '_course_prerequisites', true ) ) ? '' : 'style="display: none;"'; ?>>
								<?php 
								$prerequisites = get_post_meta( $course_id, '_course_prerequisites', true );
								if ( ! empty( $prerequisites ) && is_array( $prerequisites ) ) :
									foreach ( $prerequisites as $pre_id ) :
										$pre_title = get_the_title( $pre_id );
								?>
									<div class="ts-prerequisite-item" data-id="<?php echo esc_attr( $pre_id ); ?>">
										<span class="ts-prerequisite-title"><?php echo esc_html( $pre_title ); ?></span>
										<button type="button" class="ts-prerequisite-remove">
											<span class="dashicons dashicons-no-alt"></span>
										</button>
									</div>
								<?php 
									endforeach;
								endif;
								?>
							</div>
						</div>

						<!-- Attachments -->
						<?php if ( $can_view( 'attachments' ) ) : ?>
						<div class="ts-additional-sidebar-section">
							<h4 class="ts-additional-sidebar-title"><?php esc_html_e( 'Attachments', 'ts-lms' ); ?></h4>
							<button type="button" id="ts-upload-attachment" class="ts-btn-upload-attachment">
								<span class="dashicons dashicons-upload"></span>
								<?php esc_html_e( 'Upload Attachment', 'ts-lms' ); ?>
							</button>
							<p class="ts-upload-info"><?php esc_html_e( 'PDF, DOC, DOCX, ZIP formats, up to 10 MB', 'ts-lms' ); ?></p>
							<input type="hidden" name="course_attachments_ids" id="course-attachments-ids" value="<?php echo esc_attr( implode( ',', (array) get_post_meta( $course_id, '_course_attachments', true ) ) ); ?>">
							<div class="ts-attachments-list" id="ts-attachments-list">
								<?php 
								$attachments = get_post_meta( $course_id, '_course_attachments', true );
								if ( ! empty( $attachments ) && is_array( $attachments ) ) :
									foreach ( $attachments as $attachment_id ) :
										$filename = basename( get_attached_file( $attachment_id ) );
										$filesize = size_format( filesize( get_attached_file( $attachment_id ) ) );
								?>
									<div class="ts-attachment-item" data-id="<?php echo esc_attr( $attachment_id ); ?>">
										<div class="ts-attachment-icon">
											<span class="dashicons dashicons-media-document"></span>
										</div>
										<div class="ts-attachment-info">
											<div class="ts-attachment-name"><?php echo esc_html( $filename ); ?></div>
											<div class="ts-attachment-size"><?php echo esc_html( $filesize ); ?></div>
										</div>
										<button type="button" class="ts-attachment-remove">
											<span class="dashicons dashicons-no-alt"></span>
										</button>
									</div>
								<?php 
									endforeach;
								endif; 
								?>
							</div>
						</div>
						<?php endif; ?>

						<!-- Schedule Live Class -->
						<?php if ( $can_view( 'live_class' ) ) : ?>
						<div class="ts-additional-sidebar-section">
							<h4 class="ts-additional-sidebar-title"><?php esc_html_e( 'Schedule Live Class', 'ts-lms' ); ?></h4>
							<button type="button" id="ts-create-zoom-meeting" class="ts-btn-live-class ts-btn-zoom">
								<span class="dashicons dashicons-video-alt3"></span>
								<?php esc_html_e( 'Create a Zoom Meeting', 'ts-lms' ); ?>
							</button>
							<button type="button" id="ts-create-google-meet" class="ts-btn-live-class ts-btn-google-meet">
								<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
									<path d="M15 12c0 1.654-1.346 3-3 3s-3-1.346-3-3 1.346-3 3-3 3 1.346 3 3zm9-.449s-4.252 8.449-11.985 8.449c-4.896 0-8.015-2.904-8.015-8s3.119-8 8.015-8c7.733 0 11.985 8.449 11.985 8.449zm-7 .449c0-2.757-2.243-5-5-5s-5 2.243-5 5 2.243 5 5 5 5-2.243 5-5z"/>
								</svg>
								<?php esc_html_e( 'Create a Google Meet Link', 'ts-lms' ); ?>
							</button>
						</div>
						<?php endif; ?>

					</div>
					
				</div>
			</div>
		</div>


	</div>
	<!-- Hidden Fields -->
	<input type="hidden" id="course-id" value="<?php echo esc_attr( $course_id ); ?>">
</div>

<!-- Lesson Modal -->
<div id="ts-lesson-modal" class="ts-lesson-modal" style="display: none;">
	<div class="ts-lesson-modal-overlay"></div>
	<div class="ts-lesson-modal-container">
		<div class="ts-lesson-modal-header">
			<div class="ts-lesson-modal-title-row">
				<span class="dashicons dashicons-book-alt"></span>
				<h3 class="ts-lesson-modal-title">
					<?php esc_html_e( 'Lesson', 'ts-lms' ); ?>
					<span class="ts-lesson-topic-label"><?php echo esc_html__( 'Topic:', 'ts-lms' ) . ' <span id="ts-lesson-modal-topic-title"></span>'; ?></span>
				</h3>
			</div>
			<button type="button" class="ts-lesson-modal-close">
				<span class="dashicons dashicons-no-alt"></span>
			</button>
		</div>

		<div class="ts-lesson-modal-body">
			<div class="ts-lesson-modal-main">
				<!-- Name Field -->
				<div class="ts-lesson-field-group">
					<label class="ts-lesson-field-label">
						<?php esc_html_e( 'Name', 'ts-lms' ); ?>
					</label>
					<input 
						type="text" 
						id="ts-lesson-title" 
						class="ts-lesson-field-input" 
						placeholder="<?php esc_attr_e( 'Enter Lesson Name', 'ts-lms' ); ?>"
					>
				</div>

				<!-- Content Field -->
				<div class="ts-lesson-field-group">
					<label class="ts-lesson-field-label">
						<?php esc_html_e( 'Content', 'ts-lms' ); ?>
					</label>
					<div class="ts-lesson-editor-toolbar">
						<button type="button" class="ts-editor-btn" data-action="add-media">
							<span class="dashicons dashicons-admin-media"></span>
							<?php esc_html_e( 'Add media', 'ts-lms' ); ?>
						</button>
						<div class="ts-editor-tabs">
							<button type="button" class="ts-editor-tab ts-editor-tab-active" data-tab="visual">
								<?php esc_html_e( 'Visual', 'ts-lms' ); ?>
							</button>
							<button type="button" class="ts-editor-tab" data-tab="code">
								<?php esc_html_e( 'Code', 'ts-lms' ); ?>
							</button>
						</div>
					</div>
					<div class="ts-lesson-editor-wrapper">
						<div class="ts-editor-toolbar-buttons">
							<select class="ts-editor-format-select">
								<option value="paragraph"><?php esc_html_e( 'Paragraph', 'ts-lms' ); ?></option>
								<option value="heading1"><?php esc_html_e( 'Heading 1', 'ts-lms' ); ?></option>
								<option value="heading2"><?php esc_html_e( 'Heading 2', 'ts-lms' ); ?></option>
							</select>
							<div class="ts-editor-divider"></div>
							<button type="button" class="ts-editor-tool-btn" data-action="bold" title="<?php esc_attr_e( 'Bold', 'ts-lms' ); ?>">
								<strong>B</strong>
							</button>
							<button type="button" class="ts-editor-tool-btn" data-action="italic" title="<?php esc_attr_e( 'Italic', 'ts-lms' ); ?>">
								<em>I</em>
							</button>
							<button type="button" class="ts-editor-tool-btn" data-action="underline" title="<?php esc_attr_e( 'Underline', 'ts-lms' ); ?>">
								<u>U</u>
							</button>
							<div class="ts-editor-divider"></div>
							<button type="button" class="ts-editor-tool-btn" data-action="ul" title="<?php esc_attr_e( 'Bullet List', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-ul"></span>
							</button>
							<button type="button" class="ts-editor-tool-btn" data-action="ol" title="<?php esc_attr_e( 'Numbered List', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-ol"></span>
							</button>
							<div class="ts-editor-divider"></div>
							<button type="button" class="ts-editor-tool-btn" data-action="quote" title="<?php esc_attr_e( 'Quote', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-quote"></span>
							</button>
							<div class="ts-editor-divider"></div>
							<button type="button" class="ts-editor-tool-btn" data-action="alignleft" title="<?php esc_attr_e( 'Align Left', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-alignleft"></span>
							</button>
							<button type="button" class="ts-editor-tool-btn" data-action="aligncenter" title="<?php esc_attr_e( 'Align Center', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-aligncenter"></span>
							</button>
							<button type="button" class="ts-editor-tool-btn" data-action="alignright" title="<?php esc_attr_e( 'Align Right', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-alignright"></span>
							</button>
							<div class="ts-editor-divider"></div>
							<button type="button" class="ts-editor-tool-btn" data-action="link" title="<?php esc_attr_e( 'Insert Link', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-admin-links"></span>
							</button>
							<button type="button" class="ts-editor-tool-btn" data-action="unlink" title="<?php esc_attr_e( 'Remove Link', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-unlink"></span>
							</button>
							<div class="ts-editor-divider"></div>
							<button type="button" class="ts-editor-tool-btn" data-action="code" title="<?php esc_attr_e( 'Code', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-code"></span>
							</button>
							<div class="ts-editor-divider"></div>
							<button type="button" class="ts-editor-tool-btn" data-action="table" title="<?php esc_attr_e( 'Insert Table', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-table"></span>
							</button>
							<button type="button" class="ts-editor-tool-btn" data-action="removeformat" title="<?php esc_attr_e( 'Clear Formatting', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-removeformatting"></span>
							</button>
						</div>
						<textarea 
							id="ts-lesson-content" 
							class="ts-lesson-content-editor"
							rows="8"
						></textarea>
					</div>
				</div>
			</div>

			<div class="ts-lesson-modal-sidebar">
				<!-- Featured Image -->
				<?php if ( $can_view( 'lesson_featured_image' ) ) : ?>
				<div class="ts-lesson-sidebar-section">
					<h4 class="ts-lesson-sidebar-title"><?php esc_html_e( 'Featured Image', 'ts-lms' ); ?></h4>
					<div class="ts-lesson-upload-box" id="ts-lesson-image-upload">
						<div class="ts-lesson-upload-placeholder">
							<span class="dashicons dashicons-format-image ts-upload-icon"></span>
							<button type="button" class="ts-upload-btn"><?php esc_html_e( 'Upload Image', 'ts-lms' ); ?></button>
							<p class="ts-upload-hint"><?php esc_html_e( 'JPEG, PNG, GIF, and WebP formats, up to 40 MB', 'ts-lms' ); ?></p>
						</div>
					</div>
					<input type="hidden" id="ts-lesson-image-id" value="">
				</div>
				<?php endif; ?>

				<!-- Video -->
				<?php if ( $can_view( 'lesson_video' ) ) : ?>
				<div class="ts-lesson-sidebar-section">
					<h4 class="ts-lesson-sidebar-title"><?php esc_html_e( 'Video', 'ts-lms' ); ?></h4>
					<div class="ts-lesson-video-box" id="ts-lesson-video-wrapper">
						<div class="ts-video-upload-placeholder">
							<button type="button" class="ts-upload-btn-blue" id="ts-lesson-video-upload-btn">
								<span class="dashicons dashicons-video-alt3"></span>
								<?php esc_html_e( 'Upload Video', 'ts-lms' ); ?>
							</button>
							<button type="button" class="ts-add-url-btn" id="ts-lesson-video-url-btn"><?php esc_html_e( 'Add from URL', 'ts-lms' ); ?></button>
							
							<!-- URL Input Field (Hidden by default) -->
							<div class="ts-video-url-input-container" id="ts-video-url-input-container" style="display: none; margin-top: 10px;">
								<div style="display: flex; gap: 5px;">
									<input type="text" id="ts-video-url-input" class="ts-field-input" placeholder="https://" style="flex: 1; font-size: 13px;">
									<button type="button" id="ts-video-url-add-btn" class="button button-primary" style="min-height: 32px;"><?php esc_html_e( 'Add', 'ts-lms' ); ?></button>
								</div>
							</div>

							<p class="ts-upload-hint"><?php esc_html_e( 'MP4, and WebM formats, unlimited size', 'ts-lms' ); ?></p>
						</div>
					</div>
					<input type="hidden" id="ts-lesson-video-type" value="none"> <!-- html5, url, embed, none -->
					<input type="hidden" id="ts-lesson-video-url" value="">
					<input type="hidden" id="ts-lesson-video-id" value="">
				</div>
				<?php endif; ?>

				<!-- Video Playback Time -->
				<?php if ( $can_view( 'lesson_v_playback' ) ) : ?>
				<div class="ts-lesson-sidebar-section">
					<h4 class="ts-lesson-sidebar-title"><?php esc_html_e( 'Video Playback Time', 'ts-lms' ); ?></h4>
					<div class="ts-lesson-time-inputs">
						<div class="ts-lesson-time-field">
							<input type="number" id="ts-lesson-time-hour" class="ts-lesson-time-input" value="0" min="0">
							<label><?php esc_html_e( 'hour', 'ts-lms' ); ?></label>
						</div>
						<div class="ts-lesson-time-field">
							<input type="number" id="ts-lesson-time-min" class="ts-lesson-time-input" value="0" min="0" max="59">
							<label><?php esc_html_e( 'min', 'ts-lms' ); ?></label>
						</div>
						<div class="ts-lesson-time-field">
							<input type="number" id="ts-lesson-time-sec" class="ts-lesson-time-input" value="0" min="0" max="59">
							<label><?php esc_html_e( 'sec', 'ts-lms' ); ?></label>
						</div>
					</div>
				</div>
				<?php endif; ?>

				<!-- Exercise Files -->
				<?php if ( $can_view( 'lesson_exercise' ) ) : ?>
				<div class="ts-lesson-sidebar-section">
					<h4 class="ts-lesson-sidebar-title"><?php esc_html_e( 'Exercise Files', 'ts-lms' ); ?></h4>
					<button type="button" class="ts-lesson-btn-upload-attachment" id="ts-lesson-upload-attachment">
						<span class="dashicons dashicons-paperclip"></span>
						<?php esc_html_e( 'Upload Attachment', 'ts-lms' ); ?>
					</button>
					<input type="hidden" id="ts-lesson-attachment-id" value="">
				</div>
				<?php endif; ?>

				<!-- Lesson Preview -->
				<?php if ( $can_view( 'lesson_preview' ) ) : ?>
				<div class="ts-lesson-sidebar-section">
					<div class="ts-lesson-preview-row">
						<h4 class="ts-lesson-sidebar-title">
							<?php esc_html_e( 'Lesson Preview', 'ts-lms' ); ?>
							<span class="dashicons dashicons-info-outline ts-tooltip" title="<?php esc_attr_e( 'Allow students to preview this lesson without enrollment', 'ts-lms' ); ?>"></span>
						</h4>
						<label class="ts-switch">
							<input type="checkbox" id="ts-lesson-preview">
							<span class="ts-slider"></span>
						</label>
					</div>
				</div>
				<?php endif; ?>
			</div>
		</div>
		<div class="ts-lesson-modal-footer">
			<button type="button" class="ts-lesson-btn-cancel"><?php esc_html_e( 'Cancel', 'ts-lms' ); ?></button>
			<button type="button" class="ts-lesson-btn-save"><?php esc_html_e( 'Save Lesson', 'ts-lms' ); ?></button>
		</div>
	</div>
</div>


<!-- Quiz Modal -->
<div id="ts-quiz-modal" class="ts-quiz-modal" style="display: none;">
	<div class="ts-quiz-modal-overlay"></div>
	<div class="ts-quiz-modal-container">
		<div class="ts-quiz-modal-header">
			<div class="ts-quiz-modal-title-row">
				<span class="dashicons dashicons-welcome-learn-more"></span>
				<h3 class="ts-quiz-modal-title">
					<?php esc_html_e( 'Quiz', 'ts-lms' ); ?>
					<span class="ts-quiz-topic-label">Topic: Title filt</span>
				</h3>
			</div>
			<button type="button" class="ts-quiz-modal-close">
				<span class="dashicons dashicons-no-alt"></span>
			</button>
		</div>

		<!-- Tab Navigation -->
		<div class="ts-quiz-modal-tabs">
			<button type="button" class="ts-quiz-tab ts-quiz-tab-active" data-tab="questions">
				<?php esc_html_e( 'Questions', 'ts-lms' ); ?>
			</button>
			<button type="button" class="ts-quiz-tab" data-tab="settings">
				<?php esc_html_e( 'Settings', 'ts-lms' ); ?>
			</button>
		</div>

		<div class="ts-quiz-modal-body">
			<!-- Questions Tab -->
			<div class="ts-quiz-tab-content ts-quiz-tab-content-active" data-tab="questions">
				
				<!-- Quiz Header Info (Title/Summary) -->
				<div class="ts-quiz-header-info">
					<div class="ts-quiz-field-group">
						<textarea id="ts-quiz-title" class="ts-quiz-title-input" placeholder="<?php esc_attr_e( 'Quiz Title', 'ts-lms' ); ?>" rows="1"></textarea>
					</div>
					<div class="ts-quiz-field-group">
						<textarea id="ts-quiz-summary" class="ts-quiz-summary-input" placeholder="<?php esc_attr_e( 'Quiz Description / Instructions', 'ts-lms' ); ?>" rows="2"></textarea>
					</div>
				</div>

				<!-- Questions List Area -->
				<div class="ts-quiz-questions-area">
					<div class="ts-questions-list-header">
						<h4><?php esc_html_e( 'Questions', 'ts-lms' ); ?></h4>
						<button type="button" class="ts-add-question-btn" id="ts-add-question-btn">
							<span class="dashicons dashicons-plus"></span>
							<?php esc_html_e( 'Add Question', 'ts-lms' ); ?>
						</button>
					</div>
					
					<div id="ts-quiz-questions-list" class="ts-questions-list">
						<!-- Questions will be loaded here -->
						<div class="ts-empty-questions-state">
							<p><?php esc_html_e( 'No questions yet. Click "Add Question" to start.', 'ts-lms' ); ?></p>
						</div>
					</div>
				</div>

				<div class="ts-quiz-footer-actions">
					<button type="button" class="ts-quiz-btn-cancel"><?php esc_html_e( 'Cancel', 'ts-lms' ); ?></button>
					<button type="button" class="ts-quiz-btn-ok"><?php esc_html_e( 'Save Quiz', 'ts-lms' ); ?></button>
				</div>
			</div>

			<!-- Settings Tab -->
			<div class="ts-quiz-tab-content" data-tab="settings">
				<div class="ts-quiz-settings-panel">
					<!-- Basic Settings -->
					<div class="ts-quiz-settings-section ts-quiz-settings-section-open">
						<div class="ts-quiz-settings-header">
							<h4 class="ts-quiz-settings-title"><?php esc_html_e( 'Basic Settings', 'ts-lms' ); ?></h4>
							<button type="button" class="ts-quiz-settings-toggle">
								<span class="dashicons dashicons-arrow-down-alt2"></span>
							</button>
						</div>
						<div class="ts-quiz-settings-body">
							<!-- Time Limit -->
							<div class="ts-quiz-setting-row">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Time Limit', 'ts-lms' ); ?>
									<span class="dashicons dashicons-info-outline ts-quiz-tooltip" title="<?php esc_attr_e( 'Set time limit for quiz completion', 'ts-lms' ); ?>"></span>
								</label>
								<div class="ts-quiz-time-limit-group">
									<input type="number" id="ts-quiz-time-limit" class="ts-quiz-input-number" value="0" min="0">
									<select id="ts-quiz-time-unit" class="ts-quiz-select">
										<option value="minutes"><?php esc_html_e( 'Minutes', 'ts-lms' ); ?></option>
										<option value="hours"><?php esc_html_e( 'Hours', 'ts-lms' ); ?></option>
										<option value="days"><?php esc_html_e( 'Days', 'ts-lms' ); ?></option>
									</select>
								</div>
							</div>

							<!-- Hide Quiz Time -->
							<div class="ts-quiz-setting-row ts-quiz-setting-toggle">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Hide Quiz Time', 'ts-lms' ); ?>
								</label>
								<label class="ts-switch">
									<input type="checkbox" id="ts-quiz-hide-time">
									<span class="ts-slider"></span>
								</label>
							</div>

							<!-- Feedback Mode -->
							<div class="ts-quiz-setting-row">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Feedback Mode', 'ts-lms' ); ?>
								</label>
								<select id="ts-quiz-feedback-mode" class="ts-quiz-select">
									<option value="retry"><?php esc_html_e( 'Retry', 'ts-lms' ); ?></option>
									<option value="default" selected><?php esc_html_e( 'Default', 'ts-lms' ); ?></option>
									<option value="reveal"><?php esc_html_e( 'Reveal', 'ts-lms' ); ?></option>
								</select>
								<p class="ts-quiz-setting-description">
									<?php esc_html_e( 'Allows students to retake the quiz after their first attempt.', 'ts-lms' ); ?>
								</p>
							</div>

							<!-- Attempts Allowed -->
							<div class="ts-quiz-setting-row">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Attempts Allowed', 'ts-lms' ); ?>
								</label>
								<input type="number" id="ts-quiz-attempts" class="ts-quiz-input-number" value="10" min="1">
							</div>

							<!-- Passing Grade -->
							<div class="ts-quiz-setting-row">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Passing Grade', 'ts-lms' ); ?>
								</label>
								<div class="ts-quiz-input-with-suffix">
									<input type="number" id="ts-quiz-passing-grade" class="ts-quiz-input-number" value="80" min="0" max="100">
									<span class="ts-quiz-input-suffix">%</span>
								</div>
							</div>

							<!-- Max Question Allowed to Answer -->
							<div class="ts-quiz-setting-row">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Max Question Allowed to Answer', 'ts-lms' ); ?>
								</label>
								<input type="number" id="ts-quiz-max-questions" class="ts-quiz-input-number" value="10" min="1">
							</div>
						</div>
					</div>

					<!-- Advanced Settings -->
					<div class="ts-quiz-settings-section">
						<div class="ts-quiz-settings-header">
							<h4 class="ts-quiz-settings-title"><?php esc_html_e( 'Advanced Settings', 'ts-lms' ); ?></h4>
							<button type="button" class="ts-quiz-settings-toggle">
								<span class="dashicons dashicons-arrow-down-alt2"></span>
							</button>
						</div>
						<div class="ts-quiz-settings-body">
							<!-- Quiz Auto Start -->
							<div class="ts-quiz-setting-row ts-quiz-setting-toggle">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Quiz Auto Start', 'ts-lms' ); ?>
									<span class="dashicons dashicons-info-outline ts-quiz-tooltip" title="<?php esc_attr_e( 'Automatically start quiz when student opens it', 'ts-lms' ); ?>"></span>
								</label>
								<label class="ts-switch">
									<input type="checkbox" id="ts-quiz-auto-start">
									<span class="ts-slider"></span>
								</label>
							</div>

							<!-- Question Layout -->
							<div class="ts-quiz-setting-row">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Question Layout', 'ts-lms' ); ?>
								</label>
								<select id="ts-quiz-question-layout" class="ts-quiz-select">
									<option value="single" selected><?php esc_html_e( 'Single question', 'ts-lms' ); ?></option>
									<option value="all"><?php esc_html_e( 'All questions', 'ts-lms' ); ?></option>
								</select>
							</div>

							<!-- Question Order -->
							<div class="ts-quiz-setting-row">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Question Order', 'ts-lms' ); ?>
								</label>
								<select id="ts-quiz-question-order" class="ts-quiz-select">
									<option value="random" selected><?php esc_html_e( 'Random', 'ts-lms' ); ?></option>
									<option value="sequential"><?php esc_html_e( 'Sequential', 'ts-lms' ); ?></option>
								</select>
							</div>

							<!-- Hide Question Number -->
							<div class="ts-quiz-setting-row ts-quiz-setting-toggle">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Hide Question Number', 'ts-lms' ); ?>
								</label>
								<label class="ts-switch">
									<input type="checkbox" id="ts-quiz-hide-question-number">
									<span class="ts-slider"></span>
								</label>
							</div>

							<!-- Character Limit for Short Answers -->
							<div class="ts-quiz-setting-row">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Set Character Limit for Short Answers', 'ts-lms' ); ?>
								</label>
								<input type="number" id="ts-quiz-short-answer-limit" class="ts-quiz-input-number" value="200" min="1">
							</div>

							<!-- Character Limit for Open-Ended/Essay Answers -->
							<div class="ts-quiz-setting-row">
								<label class="ts-quiz-setting-label">
									<?php esc_html_e( 'Set Character Limit for Open-Ended/Essay Answers', 'ts-lms' ); ?>
								</label>
								<input type="number" id="ts-quiz-essay-limit" class="ts-quiz-input-number" value="500" min="1">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Assignment Modal -->
<div id="ts-assignment-modal" class="ts-assignment-modal" style="display: none;">
	<div class="ts-assignment-modal-overlay"></div>
	<div class="ts-assignment-modal-container">
		<div class="ts-assignment-modal-header">
			<div class="ts-assignment-modal-title-row">
				<span class="dashicons dashicons-clipboard"></span>
				<h3 class="ts-assignment-modal-title">
					<?php esc_html_e( 'Assignment', 'ts-lms' ); ?>
					<span class="ts-assignment-topic-label">Topic: Title filt</span>
				</h3>
			</div>
			<button type="button" class="ts-assignment-modal-close">
				<span class="dashicons dashicons-no-alt"></span>
			</button>
		</div>

		<div class="ts-assignment-modal-body">
			<div class="ts-assignment-modal-main">
				<!-- Title Field -->
				<div class="ts-assignment-field-group">
					<label class="ts-assignment-field-label">
						<?php esc_html_e( 'Title', 'ts-lms' ); ?>
					</label>
					<input 
						type="text" 
						id="ts-assignment-title" 
						class="ts-assignment-field-input" 
						placeholder="<?php esc_attr_e( 'Enter Assignment Title', 'ts-lms' ); ?>"
					>
				</div>

				<!-- Content Field -->
				<div class="ts-assignment-field-group">
					<label class="ts-assignment-field-label">
						<?php esc_html_e( 'Content', 'ts-lms' ); ?>
					</label>
					<div class="ts-assignment-editor-toolbar">
						<button type="button" class="ts-assignment-editor-btn" data-action="add-media">
							<span class="dashicons dashicons-admin-media"></span>
							<?php esc_html_e( 'Add media', 'ts-lms' ); ?>
						</button>
						<div class="ts-assignment-editor-tabs">
							<button type="button" class="ts-assignment-editor-tab ts-assignment-editor-tab-active" data-tab="visual">
								<?php esc_html_e( 'Visual', 'ts-lms' ); ?>
							</button>
							<button type="button" class="ts-assignment-editor-tab" data-tab="code">
								<?php esc_html_e( 'Code', 'ts-lms' ); ?>
							</button>
						</div>
					</div>
					<div class="ts-assignment-editor-wrapper">
						<div class="ts-assignment-editor-toolbar-buttons">
							<select class="ts-assignment-editor-format-select">
								<option value="paragraph"><?php esc_html_e( 'Paragraph', 'ts-lms' ); ?></option>
								<option value="heading1"><?php esc_html_e( 'Heading 1', 'ts-lms' ); ?></option>
								<option value="heading2"><?php esc_html_e( 'Heading 2', 'ts-lms' ); ?></option>
							</select>
							<div class="ts-assignment-editor-divider"></div>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="bold" title="<?php esc_attr_e( 'Bold', 'ts-lms' ); ?>">
								<strong>B</strong>
							</button>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="italic" title="<?php esc_attr_e( 'Italic', 'ts-lms' ); ?>">
								<em>I</em>
							</button>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="underline" title="<?php esc_attr_e( 'Underline', 'ts-lms' ); ?>">
								<u>U</u>
							</button>
							<div class="ts-assignment-editor-divider"></div>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="alignleft" title="<?php esc_attr_e( 'Align Left', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-alignleft"></span>
							</button>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="aligncenter" title="<?php esc_attr_e( 'Align Center', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-aligncenter"></span>
							</button>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="alignright" title="<?php esc_attr_e( 'Align Right', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-alignright"></span>
							</button>
							<div class="ts-assignment-editor-divider"></div>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="ul" title="<?php esc_attr_e( 'Bullet List', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-ul"></span>
							</button>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="ol" title="<?php esc_attr_e( 'Numbered List', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-ol"></span>
							</button>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="quote" title="<?php esc_attr_e( 'Quote', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-quote"></span>
							</button>
							<div class="ts-assignment-editor-divider"></div>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="link" title="<?php esc_attr_e( 'Insert Link', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-admin-links"></span>
							</button>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="unlink" title="<?php esc_attr_e( 'Remove Link', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-unlink"></span>
							</button>
							<div class="ts-assignment-editor-divider"></div>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="code" title="<?php esc_attr_e( 'Code', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-code"></span>
							</button>
							<div class="ts-assignment-editor-divider"></div>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="table" title="<?php esc_attr_e( 'Insert Table', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-table"></span>
							</button>
							<button type="button" class="ts-assignment-editor-tool-btn" data-action="removeformat" title="<?php esc_attr_e( 'Clear Formatting', 'ts-lms' ); ?>">
								<span class="dashicons dashicons-editor-removeformatting"></span>
							</button>
						</div>
						<textarea 
							id="ts-assignment-content" 
							class="ts-assignment-content-editor"
							rows="8"
						></textarea>
					</div>
				</div>
			</div>

			<div class="ts-assignment-modal-sidebar">
				<!-- Attachments -->
				<div class="ts-assignment-sidebar-section">
					<h4 class="ts-assignment-sidebar-title"><?php esc_html_e( 'Attachments', 'ts-lms' ); ?></h4>
					<button type="button" class="ts-assignment-btn-upload-attachment" id="ts-assignment-upload-attachment">
						<span class="dashicons dashicons-upload"></span>
						<?php esc_html_e( 'Upload Attachment', 'ts-lms' ); ?>
					</button>
					<span class="ts-assignment-upload-info">JPEG, PNG, PDF, DOC, DOCX formats, up to 40 MB</span>
					<input type="hidden" id="ts-assignment-attachment-id" value="">
				</div>

				<!-- Time Limit -->
				<div class="ts-assignment-sidebar-section">
					<h4 class="ts-assignment-sidebar-title"><?php esc_html_e( 'Time Limit', 'ts-lms' ); ?></h4>
					<div class="ts-assignment-time-limit-group">
						<input type="number" id="ts-assignment-time-limit" class="ts-assignment-input-number" value="0" min="0" placeholder="0">
						<select id="ts-assignment-time-unit" class="ts-assignment-select">
							<option value="weeks"><?php esc_html_e( 'Weeks', 'ts-lms' ); ?></option>
							<option value="days"><?php esc_html_e( 'Days', 'ts-lms' ); ?></option>
							<option value="hours"><?php esc_html_e( 'Hours', 'ts-lms' ); ?></option>
							<option value="minutes"><?php esc_html_e( 'Minutes', 'ts-lms' ); ?></option>
						</select>
					</div>
				</div>

				<!-- Set Deadline From Assignment Start Time -->
				<div class="ts-assignment-sidebar-section">
					<div class="ts-assignment-toggle-row">
						<h4 class="ts-assignment-sidebar-title"><?php esc_html_e( 'Set Deadline From Assignment Start Time', 'ts-lms' ); ?></h4>
						<label class="ts-switch">
							<input type="checkbox" id="ts-assignment-deadline-toggle">
							<span class="ts-slider"></span>
						</label>
					</div>
					<div id="ts-assignment-deadline-fields" style="display: none; margin-top: 12px;">
						<input type="datetime-local" id="ts-assignment-deadline" class="ts-assignment-field-input">
					</div>
				</div>

				<!-- Total Points -->
				<div class="ts-assignment-sidebar-section">
					<h4 class="ts-assignment-sidebar-title"><?php esc_html_e( 'Total Points', 'ts-lms' ); ?></h4>
					<input type="number" id="ts-assignment-total-points" class="ts-assignment-field-input" value="10" min="0" placeholder="10">
				</div>

				<!-- Minimum Pass Points -->
				<div class="ts-assignment-sidebar-section">
					<h4 class="ts-assignment-sidebar-title"><?php esc_html_e( 'Minimum Pass Points', 'ts-lms' ); ?></h4>
					<input type="number" id="ts-assignment-min-points" class="ts-assignment-field-input" value="5" min="0" placeholder="5">
				</div>

				<!-- File Upload Limit -->
				<div class="ts-assignment-sidebar-section">
					<h4 class="ts-assignment-sidebar-title"><?php esc_html_e( 'File Upload Limit', 'ts-lms' ); ?></h4>
					<input type="number" id="ts-assignment-file-limit" class="ts-assignment-field-input" value="1" min="1" placeholder="1">
				</div>

				<!-- Maximum File Size Limit -->
				<div class="ts-assignment-sidebar-section">
					<h4 class="ts-assignment-sidebar-title"><?php esc_html_e( 'Maximum File Size Limit', 'ts-lms' ); ?></h4>
					<div class="ts-assignment-file-size-group">
						<input type="number" id="ts-assignment-file-size" class="ts-assignment-input-number" value="2" min="1" placeholder="2">
						<select id="ts-assignment-file-size-unit" class="ts-assignment-select">
							<option value="mb" selected><?php esc_html_e( 'MB', 'ts-lms' ); ?></option>
							<option value="gb"><?php esc_html_e( 'GB', 'ts-lms' ); ?></option>
						</select>
					</div>
				</div>

				<!-- Allow Assignment Resubmission -->
				<div class="ts-assignment-sidebar-section">
					<div class="ts-assignment-toggle-row">
						<h4 class="ts-assignment-sidebar-title"><?php esc_html_e( 'Allow Assignment Resubmission', 'ts-lms' ); ?></h4>
						<label class="ts-switch">
							<input type="checkbox" id="ts-assignment-resubmission-toggle">
							<span class="ts-slider"></span>
						</label>
					</div>
				</div>

				<!-- Maximum Resubmission Attempts -->
				<div class="ts-assignment-sidebar-section" id="ts-assignment-resubmission-attempts-section" style="display: none;">
					<h4 class="ts-assignment-sidebar-title"><?php esc_html_e( 'Maximum Resubmission Attempts', 'ts-lms' ); ?></h4>
					<input type="number" id="ts-assignment-max-attempts" class="ts-assignment-field-input" value="5" min="1" placeholder="5">
				</div>
			</div>
		</div>

		<div class="ts-assignment-modal-footer">
			<button type="button" class="ts-assignment-btn-cancel">
				<?php esc_html_e( 'Cancel', 'ts-lms' ); ?>
			</button>
			<button type="button" class="ts-assignment-btn-save">
				<?php esc_html_e( 'Save Assignment', 'ts-lms' ); ?>
			</button>
		</div>
	</div>
</div>
<!-- Meet Live Lesson Modal -->
<div id="ts-meet-modal" class="ts-live-modal" style="display: none;">
	<div class="ts-modal-overlay"></div>
	<div class="ts-modal-container ts-live-modal-container">
		<div class="ts-modal-header">
			<h3 class="ts-modal-title"><?php esc_html_e( 'Meet live lesson', 'ts-lms' ); ?></h3>
			<button type="button" class="ts-modal-close ts-meet-modal-close">
				<span class="dashicons dashicons-no-alt"></span>
			</button>
		</div>
		<div class="ts-modal-body">
			<div class="ts-live-form">
				<div class="ts-live-field-group">
					<label class="ts-live-label"><?php esc_html_e( 'Meeting Name', 'ts-lms' ); ?></label>
					<input type="text" id="ts-meet-name" class="ts-live-input" placeholder="<?php esc_attr_e( 'Enter meeting name', 'ts-lms' ); ?>">
				</div>
				
				<div class="ts-live-field-group">
					<label class="ts-live-label"><?php esc_html_e( 'Meeting Summary', 'ts-lms' ); ?></label>
					<textarea id="ts-meet-summary" class="ts-live-textarea" placeholder="<?php esc_attr_e( 'Enter meeting summary', 'ts-lms' ); ?>" rows="3"></textarea>
				</div>

				<div class="ts-live-field-group ts-topic-select-group">
					<label class="ts-live-label"><?php esc_html_e( 'Select Topic', 'ts-lms' ); ?></label>
					<select id="ts-meet-topic-id" class="ts-live-select">
						<!-- Populated via JS -->
					</select>
				</div>

				<div class="ts-live-row">
					<div class="ts-live-field-group" style="flex: 1;">
						<label class="ts-live-label"><?php esc_html_e( 'Meeting Start Date', 'ts-lms' ); ?></label>
						<div class="ts-live-datetime-group">
							<div class="ts-live-input-with-icon">
								<span class="dashicons dashicons-calendar-alt"></span>
								<input type="date" id="ts-meet-start-date" class="ts-live-input ts-datepicker" placeholder="<?php esc_attr_e( 'Start date', 'ts-lms' ); ?>">
							</div>
							<div class="ts-live-input-with-icon">
								<span class="dashicons dashicons-clock"></span>
								<input type="time" id="ts-meet-start-time" class="ts-live-input ts-timepicker" placeholder="<?php esc_attr_e( 'Start time', 'ts-lms' ); ?>">
							</div>
						</div>
					</div>
				</div>

				<div class="ts-live-row">
					<div class="ts-live-field-group" style="flex: 1;">
						<label class="ts-live-label"><?php esc_html_e( 'Meeting End Date', 'ts-lms' ); ?></label>
						<div class="ts-live-datetime-group">
							<div class="ts-live-input-with-icon">
								<span class="dashicons dashicons-calendar-alt"></span>
								<input type="date" id="ts-meet-end-date" class="ts-live-input ts-datepicker" placeholder="<?php esc_attr_e( 'End date', 'ts-lms' ); ?>">
							</div>
							<div class="ts-live-input-with-icon">
								<span class="dashicons dashicons-clock"></span>
								<input type="time" id="ts-meet-end-time" class="ts-live-input ts-timepicker" placeholder="<?php esc_attr_e( 'End time', 'ts-lms' ); ?>">
							</div>
						</div>
					</div>
				</div>

				<div class="ts-live-field-group">
					<label class="ts-live-label"><?php esc_html_e( 'Timezone', 'ts-lms' ); ?></label>
					<select id="ts-meet-timezone" class="ts-live-select">
						<option value="UTC"><?php esc_html_e( 'UTC', 'ts-lms' ); ?></option>
						<?php 
						$timezones = timezone_identifiers_list();
						foreach($timezones as $tz) {
							echo '<option value="' . esc_attr($tz) . '">' . esc_html($tz) . '</option>';
						}
						?>
					</select>
				</div>
			</div>
		</div>
		<div class="ts-modal-footer">
			<button type="button" class="ts-live-btn-cancel ts-meet-btn-cancel"><?php esc_html_e( 'Cancel', 'ts-lms' ); ?></button>
			<button type="button" class="ts-live-btn-save ts-meet-btn-save"><?php esc_html_e( 'Create Meeting', 'ts-lms' ); ?></button>
		</div>
	</div>
</div>

<!-- Zoom Live Lesson Modal -->
<div id="ts-zoom-modal" class="ts-live-modal" style="display: none;">
	<div class="ts-modal-overlay"></div>
	<div class="ts-modal-container ts-live-modal-container">
		<div class="ts-modal-header">
			<h3 class="ts-modal-title"><?php esc_html_e( 'Zoom live lesson', 'ts-lms' ); ?></h3>
			<button type="button" class="ts-modal-close ts-zoom-modal-close">
				<span class="dashicons dashicons-no-alt"></span>
			</button>
		</div>
		<div class="ts-modal-body">
			<div class="ts-live-form">
				<div class="ts-live-field-group">
					<label class="ts-live-label"><?php esc_html_e( 'Meeting Name', 'ts-lms' ); ?></label>
					<input type="text" id="ts-zoom-name" class="ts-live-input" placeholder="<?php esc_attr_e( 'Enter meeting name', 'ts-lms' ); ?>">
				</div>
				
				<div class="ts-live-field-group">
					<label class="ts-live-label"><?php esc_html_e( 'Meeting Summary', 'ts-lms' ); ?></label>
					<textarea id="ts-zoom-summary" class="ts-live-textarea" placeholder="<?php esc_attr_e( 'Enter meeting summary', 'ts-lms' ); ?>" rows="3"></textarea>
				</div>

				<div class="ts-live-field-group ts-topic-select-group">
					<label class="ts-live-label"><?php esc_html_e( 'Select Topic', 'ts-lms' ); ?></label>
					<select id="ts-zoom-topic-id" class="ts-live-select">
						<!-- Populated via JS -->
					</select>
				</div>

				<div class="ts-live-row">
					<div class="ts-live-field-group" style="flex: 1;">
						<label class="ts-live-label"><?php esc_html_e( 'Meeting Start Date', 'ts-lms' ); ?></label>
						<div class="ts-live-datetime-group">
							<div class="ts-live-input-with-icon">
								<span class="dashicons dashicons-calendar-alt"></span>
								<input type="date" id="ts-zoom-start-date" class="ts-live-input ts-datepicker" placeholder="<?php esc_attr_e( 'Start date', 'ts-lms' ); ?>">
							</div>
							<div class="ts-live-input-with-icon">
								<span class="dashicons dashicons-clock"></span>
								<input type="time" id="ts-zoom-start-time" class="ts-live-input ts-timepicker" placeholder="<?php esc_attr_e( 'Start time', 'ts-lms' ); ?>">
							</div>
						</div>
					</div>
				</div>

				<div class="ts-live-row">
					<div class="ts-live-field-group" style="flex: 1;">
						<label class="ts-live-label"><?php esc_html_e( 'Meeting End Date', 'ts-lms' ); ?></label>
						<div class="ts-live-datetime-group">
							<div class="ts-live-input-with-icon">
								<span class="dashicons dashicons-calendar-alt"></span>
								<input type="date" id="ts-zoom-end-date" class="ts-live-input ts-datepicker" placeholder="<?php esc_attr_e( 'End date', 'ts-lms' ); ?>">
							</div>
							<div class="ts-live-input-with-icon">
								<span class="dashicons dashicons-clock"></span>
								<input type="time" id="ts-zoom-end-time" class="ts-live-input ts-timepicker" placeholder="<?php esc_attr_e( 'End time', 'ts-lms' ); ?>">
							</div>
						</div>
					</div>
				</div>

				<div class="ts-live-field-group">
					<label class="ts-live-label"><?php esc_html_e( 'Timezone', 'ts-lms' ); ?></label>
					<select id="ts-zoom-timezone" class="ts-live-select">
						<option value="UTC"><?php esc_html_e( 'UTC', 'ts-lms' ); ?></option>
						<?php 
						foreach($timezones as $tz) {
							echo '<option value="' . esc_attr($tz) . '">' . esc_html($tz) . '</option>';
						}
						?>
					</select>
				</div>
			</div>
		</div>
		<div class="ts-modal-footer">
			<button type="button" class="ts-live-btn-cancel ts-zoom-btn-cancel"><?php esc_html_e( 'Cancel', 'ts-lms' ); ?></button>
			<button type="button" class="ts-live-btn-save ts-zoom-btn-save"><?php esc_html_e( 'Create Meeting', 'ts-lms' ); ?></button>
		</div>
	</div>
</div>

<!-- Import Quiz Modal -->
<div id="ts-import-quiz-modal" class="ts-live-modal" style="display: none;">
	<div class="ts-modal-overlay"></div>
	<div class="ts-modal-container ts-live-modal-container">
		<div class="ts-modal-header">
			<h3 class="ts-modal-title"><?php esc_html_e( 'Import Quiz', 'ts-lms' ); ?></h3>
			<button type="button" class="ts-modal-close ts-import-quiz-modal-close">
				<span class="dashicons dashicons-no-alt"></span>
			</button>
		</div>
		<div class="ts-modal-body">
			<div class="ts-import-search-box" style="margin-bottom: 15px;">
				<div class="ts-live-input-with-icon">
					<span class="dashicons dashicons-search"></span>
					<input type="text" id="ts-quiz-import-search" class="ts-live-input" placeholder="<?php esc_attr_e( 'Search quizzes...', 'ts-lms' ); ?>">
				</div>
			</div>
			<div id="ts-import-quiz-list" class="ts-import-list">
				<!-- Dummy items for demonstration -->
				<div class="ts-import-item">
					<div class="ts-import-item-info">
						<span class="ts-import-item-title">General Math Quiz</span>
						<span class="ts-import-item-meta">10 Questions</span>
					</div>
					<button type="button" class="ts-import-item-btn"><?php esc_html_e( 'Import', 'ts-lms' ); ?></button>
				</div>
				<div class="ts-import-item">
					<div class="ts-import-item-info">
						<span class="ts-import-item-title">English Literature Final</span>
						<span class="ts-import-item-meta">25 Questions</span>
					</div>
					<button type="button" class="ts-import-item-btn"><?php esc_html_e( 'Import', 'ts-lms' ); ?></button>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Toast Notification -->
<div id="ts-toast" class="ts-toast" style="display: none;"></div>

<script type="text/javascript">
jQuery(document).ready(function($) {
	// Vertical Tab Switching
	$(document).on('click', '.ts-vtab', function(e) {
		e.preventDefault();
		
		var tabId = $(this).data('tab');
		
		// Remove active class from all tabs
		$('.ts-vtab').removeClass('active');
		
		// Add active class to clicked tab
		$(this).addClass('active');
		
		// Hide all panels
		$('.ts-vtab-panel').removeClass('active');
		
		// Show corresponding panel
		$('.ts-vtab-panel[data-panel="' + tabId + '"]').addClass('active');
	});

// Category Add Form Toggle
$('#ts-add-category-btn').on('click', function(e) {
	e.preventDefault();
	$('#ts-add-category-form').slideToggle(200);
});

// Category Cancel Button
$('#ts-category-cancel-btn').on('click', function(e) {
	e.preventDefault();
	$('#ts-add-category-form').slideUp(200);
	$('#ts-new-category-name').val('');
	$('#ts-category-parent').val('0');
});

// Category Ok Button
$('#ts-category-ok-btn').on('click', function(e) {
	e.preventDefault();
	var $btn = $(this);
	var categoryName = $('#ts-new-category-name').val();
	var parentId = $('#ts-category-parent').val();
	
	if (categoryName.trim() === '') {
		alert('Please enter a category name');
		return;
	}
	
	$btn.prop('disabled', true).text('Adding...');

	$.ajax({
		url: tsLmsCourseEditor.ajaxUrl,
		type: 'POST',
		data: {
			action: 'ts_lms_add_category_editor',
			nonce: tsLmsCourseEditor.nonce,
			name: categoryName,
			parent: parentId
		},
		success: function(response) {
			if (response.success) {
				// Hide form
				$('#ts-add-category-form').slideUp(200);
				$('#ts-new-category-name').val('');
				$('#ts-category-parent').val('0');
				
				// Add to list
				var newCatId = response.data.term_id;
				var newCatName = response.data.name;
				var html = '<label class="ts-checkbox-item"><input type="checkbox" name="tax_input[ts_course_category][]" value="' + newCatId + '" checked> ' + newCatName + '</label>';
				
				// Remove "No categories found" if exists
				$('.ts-no-categories').remove();
				
				$('#ts-categories-list').append(html);
				
				// Also add to parent dropdown for future sibling categories
				$('#ts-category-parent').append('<option value="' + newCatId + '">' + newCatName + '</option>');
				
				// Show success message via toast
				var $toast = $('#ts-toast');
				if ($toast.length) {
					$toast.text('Category added successfully!').attr('class', 'ts-toast success').fadeIn(300).delay(2000).fadeOut(300);
				} else {
					alert('Category added successfully!');
				}
			} else {
				alert(response.data.message || 'Error adding category');
			}
		},
		error: function() {
			alert('AJAX error occurred');
		},
		complete: function() {
			$btn.prop('disabled', false).text('Ok');
		}
	});
});

// Title Input Clear Button Functionality
var $titleInput = $('#course-title');
var $clearBtn = $('.ts-clear-input-btn');

// Show/hide clear button based on input value
function toggleClearButton() {
	if ($titleInput.val().trim() !== '') {
		$clearBtn.show();
	} else {
		$clearBtn.hide();
	}
}

// Initial check
toggleClearButton();

// Show button when typing
$titleInput.on('input', toggleClearButton);

// Clear input when button is clicked
$clearBtn.on('click', function() {
	$titleInput.val('').focus();
	toggleClearButton();
});

// Pricing Model Toggle - Show product selection when Paid or Subscription is selected
function toggleProductSelection() {
	if ($('#pricing-paid').is(':checked') || $('#pricing-subscription').is(':checked')) {
		$('#ts-product-selection').slideDown(200);
	} else {
		$('#ts-product-selection').slideUp(200);
	}
}

// Initial check on page load
toggleProductSelection();

// Toggle when pricing model changes
$('input[name="pricing_model"]').on('change', toggleProductSelection);

// Dynamic Product Filtering based on Course Title
function updateProductList() {
	var courseTitle = $('#course-title').val().trim();
	var $productSelect = $('#course-product-select');
	
	if (!courseTitle || !$productSelect.length) {
		return;
	}
	
	// Make AJAX request to get filtered products
	$.ajax({
		url: ajaxurl,
		type: 'POST',
		data: {
			action: 'ts_lms_filter_products_by_title',
			nonce: '<?php echo wp_create_nonce( 'ts_lms_filter_products' ); ?>',
			course_title: courseTitle,
			course_id: $('#course-id').val()
		},
		success: function(response) {
			if (response.success) {
				// Clear existing options except the first one
				$productSelect.find('option:not(:first)').remove();
				
				// Add filtered products
				if (response.data.products && response.data.products.length > 0) {
					$.each(response.data.products, function(index, product) {
						var selected = response.data.selected_product == product.id ? ' selected' : '';
						$productSelect.append('<option value="' + product.id + '" data-price="' + (product.price || '') + '"' + selected + '>' + product.title + '</option>');
					});
					
					// Update the first option text if no products found
					$productSelect.find('option:first').prop('disabled', false).text('<?php esc_html_e( 'Select a product', 'ts-lms' ); ?>');
				} else {
					// No matching products found
					$productSelect.find('option:first').prop('disabled', true).text('<?php esc_html_e( 'No products found with matching course title', 'ts-lms' ); ?>');
				}
			}
		}
	});
}

// Update product list when title changes (with debounce)
var titleChangeTimeout;
$('#course-title').on('input', function() {
	clearTimeout(titleChangeTimeout);
	titleChangeTimeout = setTimeout(function() {
		updateProductList();
	}, 500); // Wait 500ms after user stops typing
});

// Update Price when Product is selected
$('#course-product-select').on('change', function() {
	if ($('#pricing-subscription').is(':checked')) {
		var selectedPrice = $(this).find('option:selected').data('price');
		if (selectedPrice) {
			$('#subscription-price').val(selectedPrice);
		}
	}
});


// Featured Image Upload
var featuredImageUploader;
$('#ts-featured-image-upload').on('click', '.ts-upload-btn', function(e) {
	e.preventDefault();
	
	// If the uploader object has already been created, reopen the dialog
	if (featuredImageUploader) {
		featuredImageUploader.open();
		return;
	}
	
	// Create the media uploader
	featuredImageUploader = wp.media({
		title: 'Select Featured Image',
		button: {
			text: 'Use this image'
		},
		library: {
			type: 'image'
		},
		multiple: false
	});
	
	// When an image is selected, run a callback
	featuredImageUploader.on('select', function() {
		var attachment = featuredImageUploader.state().get('selection').first().toJSON();
		
		// Update the thumbnail
		$('#ts-featured-image-upload').html(
			'<img src="' + attachment.url + '" class="ts-uploaded-image">' +
			'<button type="button" class="ts-remove-image"><span class="dashicons dashicons-no-alt"></span></button>'
		);
		
		// Update the hidden field
		$('#_thumbnail_id').val(attachment.id);
	});
	
	// Open the uploader dialog
	featuredImageUploader.open();
});

// Remove Featured Image
$(document).on('click', '#ts-featured-image-upload .ts-remove-image', function(e) {
	e.preventDefault();
	
	// Reset to placeholder
	$('#ts-featured-image-upload').html(
		'<div class="ts-upload-placeholder">' +
			'<span class="dashicons dashicons-format-image ts-upload-icon"></span>' +
			'<button type="button" class="ts-upload-btn">Upload Thumbnail</button>' +
			'<p class="ts-upload-hint">JPEG, PNG, GIF, and WebP formats, up to 40 MB</p>' +
		'</div>'
	);
	
	// Clear the hidden field
	$('#_thumbnail_id').val('');
});

// Intro Video Upload
var videoUploader;
$('.ts-video-upload').on('click', function(e) {
	e.preventDefault();
	
	// If the uploader object has already been created, reopen the dialog
	if (videoUploader) {
		videoUploader.open();
		return;
	}
	
	// Create the media uploader for video
	videoUploader = wp.media({
		title: 'Select Intro Video',
		button: {
			text: 'Use this video'
		},
		library: {
			type: 'video'
		},
		multiple: false
	});
	
	// When a video is selected, run a callback
	videoUploader.on('select', function() {
		var attachment = videoUploader.state().get('selection').first().toJSON();
		
		$('#ts-course-video-url').val(attachment.url);
		$('#ts-course-video-source').val('upload');
		
		// Trigger preview
		if (typeof CourseEditor !== 'undefined') {
			CourseEditor.handleVideoPreview(true);
			CourseEditor.showToast('Video uploaded and added!', 'success');
		}
	});
	
	// Open the uploader dialog
	videoUploader.open();
});


});
</script>

<!-- Certificate Preview Modal -->
<div id="ts-cert-modal" class="ts-lms-modal">
	<div class="ts-modal-overlay"></div>
	<div class="ts-modal-container">
		<div class="ts-modal-header">
			<h3><?php _e('Certificate Template Preview', 'ts-lms'); ?></h3>
			<button type="button" class="ts-modal-close">&times;</button>
		</div>
		<div class="ts-modal-body">
			<div id="ts-cert-preview-content">
				<!-- Dynamic certificate content will be loaded here -->
				<div class="ts-cert-loading">
					<div class="ts-spinner"></div>
					<p><?php _e('Generating interactive preview...', 'ts-lms'); ?></p>
				</div>
			</div>
		</div>
	</div>

	<!-- Toast Notification -->
	<div id="ts-toast" style="display:none;"></div>
</div>
