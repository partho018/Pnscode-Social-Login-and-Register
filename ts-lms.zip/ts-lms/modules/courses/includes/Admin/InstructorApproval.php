<?php
/**
 * Instructor Approval Admin Page
 *
 * Admin interface for managing instructor applications.
 *
 * @package TS_LMS\Modules\Courses\Admin
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * InstructorApproval class.
 */
class InstructorApproval {
    
    /**
     * Initialize hooks.
     */
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'add_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
    }
    
    /**
     * Add admin menu.
     */
    public static function add_admin_menu() {
        add_submenu_page(
            'ts-lms',
            __( 'Instructor Applications', 'ts-lms' ),
            __( 'Instructors', 'ts-lms' ),
            'manage_options',
            'ts-lms-instructors',
            array( __CLASS__, 'render_page' )
        );
    }
    
    /**
     * Enqueue scripts.
     */
    public static function enqueue_scripts( $hook ) {
        if ( $hook !== 'ts-lms_page_ts-lms-instructors' ) {
            return;
        }
        
        wp_enqueue_script(
            'ts-lms-instructor-approval',
            plugin_dir_url( dirname( dirname( dirname( __FILE__ ) ) ) ) . 'modules/courses/includes/Admin/assets/js/instructor-approval.js',
            array( 'jquery' ),
            '1.0.0',
            true
        );
        
        wp_localize_script( 'ts-lms-instructor-approval', 'ts_lms_admin', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'ts_lms_admin_nonce' ),
        ) );
    }
    
    /**
     * Render admin page.
     */
    public static function render_page() {
        // Get filter status
        $filter_status = isset( $_GET['status'] ) ? sanitize_text_field( $_GET['status'] ) : 'all';
        
        // Get all instructor applications
        $meta_query = array(
            array(
                'key'     => 'ts_instructor_status',
                'compare' => 'EXISTS',
            ),
        );
        
        if ( $filter_status !== 'all' ) {
            $meta_query[] = array(
                'key'   => 'ts_instructor_status',
                'value' => $filter_status,
            );
        }
        
        $users = get_users( array(
            'meta_query' => $meta_query,
            'orderby'    => 'registered',
            'order'      => 'DESC',
        ) );
        
        // Count by status
        $counts = array(
            'all'       => count( get_users( array( 'meta_key' => 'ts_instructor_status' ) ) ),
            'pending'   => count( get_users( array( 'meta_key' => 'ts_instructor_status', 'meta_value' => 'pending' ) ) ),
            'approved'  => count( get_users( array( 'meta_key' => 'ts_instructor_status', 'meta_value' => 'approved' ) ) ),
            'rejected'  => count( get_users( array( 'meta_key' => 'ts_instructor_status', 'meta_value' => 'rejected' ) ) ),
            'suspended' => count( get_users( array( 'meta_key' => 'ts_instructor_status', 'meta_value' => 'suspended' ) ) ),
        );
        
        ?>
        <div class="wrap ts-lms-instructor-approval">
            <h1><?php esc_html_e( 'Instructor Management', 'ts-lms' ); ?></h1>
            
            <ul class="subsubsub">
                <li><a href="?page=ts-lms-instructors&status=all" class="<?php echo $filter_status === 'all' ? 'current' : ''; ?>"><?php printf( __( 'All (%d)', 'ts-lms' ), $counts['all'] ); ?></a> |</li>
                <li><a href="?page=ts-lms-instructors&status=pending" class="<?php echo $filter_status === 'pending' ? 'current' : ''; ?>"><?php printf( __( 'Pending (%d)', 'ts-lms' ), $counts['pending'] ); ?></a> |</li>
                <li><a href="?page=ts-lms-instructors&status=approved" class="<?php echo $filter_status === 'approved' ? 'current' : ''; ?>"><?php printf( __( 'Approved (%d)', 'ts-lms' ), $counts['approved'] ); ?></a> |</li>
                <li><a href="?page=ts-lms-instructors&status=rejected" class="<?php echo $filter_status === 'rejected' ? 'current' : ''; ?>"><?php printf( __( 'Rejected (%d)', 'ts-lms' ), $counts['rejected'] ); ?></a> |</li>
                <li><a href="?page=ts-lms-instructors&status=suspended" class="<?php echo $filter_status === 'suspended' ? 'current' : ''; ?>"><?php printf( __( 'Suspended (%d)', 'ts-lms' ), $counts['suspended'] ); ?></a></li>
            </ul>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Name', 'ts-lms' ); ?></th>
                        <th><?php esc_html_e( 'Email', 'ts-lms' ); ?></th>
                        <th><?php esc_html_e( 'Applied Date', 'ts-lms' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'ts-lms' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'ts-lms' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $users ) ) : ?>
                        <tr>
                            <td colspan="5"><?php esc_html_e( 'No instructor applications found.', 'ts-lms' ); ?></td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ( $users as $user ) : 
                            $status = get_user_meta( $user->ID, 'ts_instructor_status', true );
                            $applied_date = get_user_meta( $user->ID, 'ts_instructor_applied_date', true );
                            $bio = get_user_meta( $user->ID, 'ts_instructor_bio', true );
                            $skills = get_user_meta( $user->ID, 'ts_instructor_skills', true );
                            $experience = get_user_meta( $user->ID, 'ts_instructor_experience', true );
                        ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html( $user->display_name ); ?></strong>
                                <?php if ( $bio ) : ?>
                                    <br><small><?php echo esc_html( wp_trim_words( $bio, 15 ) ); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html( $user->user_email ); ?></td>
                            <td><?php echo esc_html( $applied_date ? date_i18n( get_option( 'date_format' ), strtotime( $applied_date ) ) : '-' ); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo esc_attr( $status ); ?>">
                                    <?php echo esc_html( ucfirst( $status ) ); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ( $status === 'pending' ) : ?>
                                    <button class="button button-primary approve-instructor" data-user-id="<?php echo esc_attr( $user->ID ); ?>">
                                        <?php esc_html_e( 'Approve', 'ts-lms' ); ?>
                                    </button>
                                    <button class="button reject-instructor" data-user-id="<?php echo esc_attr( $user->ID ); ?>">
                                        <?php esc_html_e( 'Reject', 'ts-lms' ); ?>
                                    </button>
                                <?php elseif ( $status === 'approved' ) : ?>
                                    <button class="button suspend-instructor" data-user-id="<?php echo esc_attr( $user->ID ); ?>">
                                        <?php esc_html_e( 'Suspend', 'ts-lms' ); ?>
                                    </button>
                                <?php endif; ?>
                                <a href="<?php echo esc_url( admin_url( 'user-edit.php?user_id=' . $user->ID ) ); ?>" class="button">
                                    <?php esc_html_e( 'View Profile', 'ts-lms' ); ?>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <style>
                .status-badge {
                    padding: 4px 12px;
                    border-radius: 12px;
                    font-size: 12px;
                    font-weight: 600;
                    display: inline-block;
                }
                .status-pending {
                    background: #fff3cd;
                    color: #856404;
                }
                .status-approved {
                    background: #d4edda;
                    color: #155724;
                }
                .status-rejected {
                    background: #f8d7da;
                    color: #721c24;
                }
                .status-suspended {
                    background: #d1ecf1;
                    color: #0c5460;
                }
            </style>
        </div>
        <?php
    }
}
