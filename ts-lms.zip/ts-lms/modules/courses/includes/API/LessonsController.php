<?php
/**
 * Lessons REST API Controller
 *
 * Handles REST API endpoints for lessons (read-only).
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\API;

use TS_LMS\Modules\Courses\PostTypes\Lesson;
use TS_LMS\Modules\Courses\Access\AccessControl;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * LessonsController class.
 */
class LessonsController extends \WP_REST_Controller {

    /**
     * Namespace.
     *
     * @var string
     */
    protected $namespace = 'ts-lms/v1';

    /**
     * Rest base.
     *
     * @var string
     */
    protected $rest_base = 'lessons';

    /**
     * Register routes.
     *
     * @return void
     */
    public function register_routes() {
        // Get all lessons
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base,
            array(
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_items' ),
                    'permission_callback' => array( $this, 'get_items_permissions_check' ),
                    'args'                => $this->get_collection_params(),
                ),
                'schema' => array( $this, 'get_item_schema' ),
            )
        );

        // Get single lesson
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)',
            array(
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_item' ),
                    'permission_callback' => array( $this, 'get_item_permissions_check' ),
                    'args'                => array(
                        'id' => array(
                            'description' => __( 'Unique identifier for the lesson.', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                    ),
                ),
                'schema' => array( $this, 'get_item_schema' ),
            )
        );

        // Check lesson access
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)/access',
            array(
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'check_access' ),
                    'permission_callback' => '__return_true',
                    'args'                => array(
                        'id' => array(
                            'description' => __( 'Unique identifier for the lesson.', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                    ),
                ),
            )
        );
    }

    /**
     * Get a collection of lessons.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error Response object or error.
     */
    public function get_items( $request ) {
        $args = array(
            'post_type'      => Lesson::POST_TYPE,
            'post_status'    => 'publish',
            'posts_per_page' => $request->get_param( 'per_page' ) ?: 10,
            'paged'          => $request->get_param( 'page' ) ?: 1,
        );

        // Filter by type
        if ( $request->get_param( 'type' ) ) {
            $args['meta_query'] = array(
                array(
                    'key'   => '_lesson_type',
                    'value' => sanitize_text_field( $request->get_param( 'type' ) ),
                ),
            );
        }

        // Filter by course
        if ( $request->get_param( 'course_id' ) ) {
            $args['meta_query'] = array(
                array(
                    'key'   => '_lesson_course_id',
                    'value' => absint( $request->get_param( 'course_id' ) ),
                ),
            );
        }

        $query = new \WP_Query( $args );
        $lessons = array();

        foreach ( $query->posts as $post ) {
            $data = $this->prepare_item_for_response( $post, $request );
            $lessons[] = $this->prepare_response_for_collection( $data );
        }

        $response = rest_ensure_response( $lessons );

        // Add pagination headers
        $response->header( 'X-WP-Total', $query->found_posts );
        $response->header( 'X-WP-TotalPages', $query->max_num_pages );

        return $response;
    }

    /**
     * Get a single lesson.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error Response object or error.
     */
    public function get_item( $request ) {
        $lesson_id = $request->get_param( 'id' );
        $lesson = get_post( $lesson_id );

        if ( ! $lesson || $lesson->post_type !== Lesson::POST_TYPE ) {
            return new \WP_Error( 'invalid_lesson', __( 'Invalid lesson ID.', 'ts-lms' ), array( 'status' => 404 ) );
        }

        $data = $this->prepare_item_for_response( $lesson, $request );

        return rest_ensure_response( $data );
    }

    /**
     * Check lesson access for current user.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error Response object or error.
     */
    public function check_access( $request ) {
        $lesson_id = $request->get_param( 'id' );
        $lesson = get_post( $lesson_id );

        if ( ! $lesson || $lesson->post_type !== Lesson::POST_TYPE ) {
            return new \WP_Error( 'invalid_lesson', __( 'Invalid lesson ID.', 'ts-lms' ), array( 'status' => 404 ) );
        }

        $user_id = get_current_user_id();
        $access_status = AccessControl::get_access_status( $lesson_id, $user_id );

        return rest_ensure_response( $access_status );
    }

    /**
     * Prepare item for response.
     *
     * @param WP_Post         $post    Post object.
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response Response object.
     */
    public function prepare_item_for_response( $post, $request ) {
        $data = array(
            'id'        => $post->ID,
            'title'     => $post->post_title,
            'content'   => $post->post_content,
            'type'      => get_post_meta( $post->ID, '_lesson_type', true ),
            'course_id' => get_post_meta( $post->ID, '_lesson_course_id', true ),
            'duration'  => get_post_meta( $post->ID, '_lesson_duration', true ),
            'link'      => get_permalink( $post->ID ),
        );

        // Add video data if video lesson
        if ( $data['type'] === 'video' ) {
            $data['video'] = array(
                'url'  => get_post_meta( $post->ID, '_lesson_video_url', true ),
                'type' => get_post_meta( $post->ID, '_lesson_video_type', true ),
            );
        }

        // Add drip data
        $data['drip'] = array(
            'type'         => get_post_meta( $post->ID, '_lesson_drip_type', true ),
            'days'         => get_post_meta( $post->ID, '_lesson_drip_days', true ),
            'prerequisite' => get_post_meta( $post->ID, '_lesson_drip_prerequisite', true ),
        );

        return rest_ensure_response( $data );
    }

    /**
     * Check permissions for getting items.
     *
     * @param WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function get_items_permissions_check( $request ) {
        return true; // Public endpoint
    }

    /**
     * Check permissions for getting a single item.
     *
     * @param WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function get_item_permissions_check( $request ) {
        return true; // Public endpoint
    }

    /**
     * Get collection parameters.
     *
     * @return array Collection parameters.
     */
    public function get_collection_params() {
        return array(
            'page'      => array(
                'description'       => __( 'Current page of the collection.', 'ts-lms' ),
                'type'              => 'integer',
                'default'           => 1,
                'sanitize_callback' => 'absint',
            ),
            'per_page'  => array(
                'description'       => __( 'Maximum number of items to return.', 'ts-lms' ),
                'type'              => 'integer',
                'default'           => 10,
                'sanitize_callback' => 'absint',
            ),
            'type'      => array(
                'description'       => __( 'Filter by lesson type.', 'ts-lms' ),
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'course_id' => array(
                'description'       => __( 'Filter by course ID.', 'ts-lms' ),
                'type'              => 'integer',
                'sanitize_callback' => 'absint',
            ),
        );
    }

    /**
     * Get item schema.
     *
     * @return array Item schema.
     */
    public function get_item_schema() {
        return array(
            '$schema'    => 'http://json-schema.org/draft-04/schema#',
            'title'      => 'lesson',
            'type'       => 'object',
            'properties' => array(
                'id'        => array(
                    'description' => __( 'Unique identifier for the lesson.', 'ts-lms' ),
                    'type'        => 'integer',
                    'readonly'    => true,
                ),
                'title'     => array(
                    'description' => __( 'The title of the lesson.', 'ts-lms' ),
                    'type'        => 'string',
                ),
                'content'   => array(
                    'description' => __( 'The content of the lesson.', 'ts-lms' ),
                    'type'        => 'string',
                ),
                'type'      => array(
                    'description' => __( 'The type of the lesson.', 'ts-lms' ),
                    'type'        => 'string',
                    'enum'        => array( 'video', 'text', 'quiz', 'assignment', 'live_class' ),
                ),
                'course_id' => array(
                    'description' => __( 'The ID of the parent course.', 'ts-lms' ),
                    'type'        => 'integer',
                ),
                'duration'  => array(
                    'description' => __( 'The duration of the lesson in minutes.', 'ts-lms' ),
                    'type'        => 'integer',
                ),
                'link'      => array(
                    'description' => __( 'URL to the lesson.', 'ts-lms' ),
                    'type'        => 'string',
                    'format'      => 'uri',
                    'readonly'    => true,
                ),
            ),
        );
    }
}
