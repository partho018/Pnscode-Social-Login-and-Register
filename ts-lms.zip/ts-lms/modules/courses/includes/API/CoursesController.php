<?php
/**
 * Courses REST API Controller
 *
 * Handles REST API endpoints for courses (read-only).
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\API;

use TS_LMS\Modules\Courses\PostTypes\Course;
use TS_LMS\Modules\Courses\Managers\CourseManager;
use TS_LMS\Modules\Courses\Managers\LessonManager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * CoursesController class.
 */
class CoursesController extends \WP_REST_Controller {

    /**
     * Namespace.
     *
     * @var string
     */
    protected $namespace = 'ts-lms/v1';

    /**
     * Rest base.
     *
     * @var string
     */
    protected $rest_base = 'courses';

    /**
     * Register routes.
     *
     * @return void
     */
    public function register_routes() {
        // Get all courses
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base,
            array(
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_items' ),
                    'permission_callback' => array( $this, 'get_items_permissions_check' ),
                    'args'                => $this->get_collection_params(),
                ),
                'schema' => array( $this, 'get_item_schema' ),
            )
        );

        // Get single course
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)',
            array(
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_item' ),
                    'permission_callback' => array( $this, 'get_item_permissions_check' ),
                    'args'                => array(
                        'id' => array(
                            'description' => __( 'Unique identifier for the course.', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                    ),
                ),
                'schema' => array( $this, 'get_item_schema' ),
            )
        );

        // Get course lessons
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)/lessons',
            array(
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_course_lessons' ),
                    'permission_callback' => array( $this, 'get_item_permissions_check' ),
                    'args'                => array(
                        'id' => array(
                            'description' => __( 'Unique identifier for the course.', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                    ),
                ),
            )
        );

        // Get course instructors
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)/instructors',
            array(
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'get_course_instructors' ),
                    'permission_callback' => array( $this, 'get_item_permissions_check' ),
                    'args'                => array(
                        'id' => array(
                            'description' => __( 'Unique identifier for the course.', 'ts-lms' ),
                            'type'        => 'integer',
                        ),
                    ),
                ),
            )
        );
    }

    /**
     * Get a collection of courses.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error Response object or error.
     */
    public function get_items( $request ) {
        $args = array(
            'post_type'      => Course::POST_TYPE,
            'post_status'    => 'publish',
            'posts_per_page' => $request->get_param( 'per_page' ) ?: 10,
            'paged'          => $request->get_param( 'page' ) ?: 1,
        );

        // Filter by status
        if ( $request->get_param( 'status' ) ) {
            $args['meta_query'] = array(
                array(
                    'key'   => '_course_status',
                    'value' => sanitize_text_field( $request->get_param( 'status' ) ),
                ),
            );
        }

        $query = new \WP_Query( $args );
        $courses = array();

        foreach ( $query->posts as $post ) {
            $data = $this->prepare_item_for_response( $post, $request );
            $courses[] = $this->prepare_response_for_collection( $data );
        }

        $response = rest_ensure_response( $courses );

        // Add pagination headers
        $response->header( 'X-WP-Total', $query->found_posts );
        $response->header( 'X-WP-TotalPages', $query->max_num_pages );

        return $response;
    }

    /**
     * Get a single course.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error Response object or error.
     */
    public function get_item( $request ) {
        $course_id = $request->get_param( 'id' );
        $course = get_post( $course_id );

        if ( ! $course || $course->post_type !== Course::POST_TYPE ) {
            return new \WP_Error( 'invalid_course', __( 'Invalid course ID.', 'ts-lms' ), array( 'status' => 404 ) );
        }

        $data = $this->prepare_item_for_response( $course, $request );

        return rest_ensure_response( $data );
    }

    /**
     * Get course lessons.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error Response object or error.
     */
    public function get_course_lessons( $request ) {
        $course_id = $request->get_param( 'id' );
        $course = get_post( $course_id );

        if ( ! $course || $course->post_type !== Course::POST_TYPE ) {
            return new \WP_Error( 'invalid_course', __( 'Invalid course ID.', 'ts-lms' ), array( 'status' => 404 ) );
        }

        $lesson_ids = LessonManager::get_course_lessons( $course_id, true );
        $lessons = array();

        foreach ( $lesson_ids as $lesson_id ) {
            $lesson = get_post( $lesson_id );
            if ( $lesson ) {
                $lessons[] = array(
                    'id'       => $lesson->ID,
                    'title'    => $lesson->post_title,
                    'type'     => get_post_meta( $lesson->ID, '_lesson_type', true ),
                    'duration' => get_post_meta( $lesson->ID, '_lesson_duration', true ),
                );
            }
        }

        return rest_ensure_response( $lessons );
    }

    /**
     * Get course instructors.
     *
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response|WP_Error Response object or error.
     */
    public function get_course_instructors( $request ) {
        $course_id = $request->get_param( 'id' );
        $course = get_post( $course_id );

        if ( ! $course || $course->post_type !== Course::POST_TYPE ) {
            return new \WP_Error( 'invalid_course', __( 'Invalid course ID.', 'ts-lms' ), array( 'status' => 404 ) );
        }

        $instructors = CourseManager::get_instructors( $course_id );

        return rest_ensure_response( $instructors );
    }

    /**
     * Prepare item for response.
     *
     * @param WP_Post         $post    Post object.
     * @param WP_REST_Request $request Request object.
     * @return WP_REST_Response Response object.
     */
    public function prepare_item_for_response( $post, $request ) {
        $data = array(
            'id'           => $post->ID,
            'title'        => $post->post_title,
            'content'      => $post->post_content,
            'excerpt'      => $post->post_excerpt,
            'status'       => get_post_meta( $post->ID, '_course_status', true ),
            'duration'     => get_post_meta( $post->ID, '_course_duration', true ),
            'level'        => get_post_meta( $post->ID, '_course_level', true ),
            'max_students' => get_post_meta( $post->ID, '_course_max_students', true ),
            'start_date'   => get_post_meta( $post->ID, '_course_start_date', true ),
            'end_date'     => get_post_meta( $post->ID, '_course_end_date', true ),
            'link'         => get_permalink( $post->ID ),
        );

        return rest_ensure_response( $data );
    }

    /**
     * Check permissions for getting items.
     *
     * @param WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function get_items_permissions_check( $request ) {
        return true; // Public endpoint
    }

    /**
     * Check permissions for getting a single item.
     *
     * @param WP_REST_Request $request Request object.
     * @return bool|WP_Error True if allowed, error otherwise.
     */
    public function get_item_permissions_check( $request ) {
        return true; // Public endpoint
    }

    /**
     * Get collection parameters.
     *
     * @return array Collection parameters.
     */
    public function get_collection_params() {
        return array(
            'page'     => array(
                'description'       => __( 'Current page of the collection.', 'ts-lms' ),
                'type'              => 'integer',
                'default'           => 1,
                'sanitize_callback' => 'absint',
            ),
            'per_page' => array(
                'description'       => __( 'Maximum number of items to return.', 'ts-lms' ),
                'type'              => 'integer',
                'default'           => 10,
                'sanitize_callback' => 'absint',
            ),
            'status'   => array(
                'description'       => __( 'Filter by course status.', 'ts-lms' ),
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ),
        );
    }

    /**
     * Get item schema.
     *
     * @return array Item schema.
     */
    public function get_item_schema() {
        return array(
            '$schema'    => 'http://json-schema.org/draft-04/schema#',
            'title'      => 'course',
            'type'       => 'object',
            'properties' => array(
                'id'           => array(
                    'description' => __( 'Unique identifier for the course.', 'ts-lms' ),
                    'type'        => 'integer',
                    'readonly'    => true,
                ),
                'title'        => array(
                    'description' => __( 'The title of the course.', 'ts-lms' ),
                    'type'        => 'string',
                ),
                'content'      => array(
                    'description' => __( 'The content of the course.', 'ts-lms' ),
                    'type'        => 'string',
                ),
                'excerpt'      => array(
                    'description' => __( 'The excerpt of the course.', 'ts-lms' ),
                    'type'        => 'string',
                ),
                'status'       => array(
                    'description' => __( 'The status of the course.', 'ts-lms' ),
                    'type'        => 'string',
                    'enum'        => array( 'upcoming', 'active', 'completed' ),
                ),
                'duration'     => array(
                    'description' => __( 'The duration of the course in hours.', 'ts-lms' ),
                    'type'        => 'integer',
                ),
                'level'        => array(
                    'description' => __( 'The level of the course.', 'ts-lms' ),
                    'type'        => 'string',
                    'enum'        => array( 'beginner', 'intermediate', 'advanced' ),
                ),
                'max_students' => array(
                    'description' => __( 'Maximum number of students.', 'ts-lms' ),
                    'type'        => 'integer',
                ),
                'link'         => array(
                    'description' => __( 'URL to the course.', 'ts-lms' ),
                    'type'        => 'string',
                    'format'      => 'uri',
                    'readonly'    => true,
                ),
            ),
        );
    }
}
