<?php
/**
 * Capabilities Management
 *
 * Defines and manages custom capabilities for courses and lessons.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses\Capabilities;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Capabilities class.
 */
class Capabilities {

    /**
     * Initialize capabilities.
     *
     * @return void
     */
    public static function init() {
        add_action( 'init', array( __CLASS__, 'add_capabilities' ) );
    }

    /**
     * Add custom capabilities to roles.
     *
     * @return void
     */
    public static function add_capabilities() {
        // Check if bundle capabilities are added
        if ( get_option( 'ts_lms_bundle_capabilities_added' ) ) {
            return;
        }

        $administrator = get_role( 'administrator' );
        $editor        = get_role( 'editor' );

        // Course capabilities
        $course_caps = self::get_course_capabilities();
        
        // Lesson capabilities
        $lesson_caps = self::get_lesson_capabilities();

        // Quiz capabilities (stub)
        $quiz_caps = self::get_quiz_capabilities();

        // Assignment capabilities (stub)
        $assignment_caps = self::get_assignment_capabilities();

        // Bundle capabilities
        $bundle_caps = self::get_bundle_capabilities();

        // Add all capabilities to administrator
        if ( $administrator ) {
            foreach ( array_merge( $course_caps, $lesson_caps, $quiz_caps, $assignment_caps, $bundle_caps ) as $cap ) {
                $administrator->add_cap( $cap );
            }
        }

        // Add capabilities to editor (excluding delete_others)
        if ( $editor ) {
            $editor_caps = array_filter(
                array_merge( $course_caps, $lesson_caps, $quiz_caps, $assignment_caps, $bundle_caps ),
                function( $cap ) {
                    return strpos( $cap, 'delete_others' ) === false;
                }
            );

            foreach ( $editor_caps as $cap ) {
                $editor->add_cap( $cap );
            }
        }

        update_option( 'ts_lms_bundle_capabilities_added', true );
    }

    /**
     * Get course capabilities.
     *
     * @return array Course capabilities.
     */
    public static function get_course_capabilities() {
        return array(
            'edit_ts_course',
            'read_ts_course',
            'delete_ts_course',
            'edit_ts_courses',
            'edit_others_ts_courses',
            'publish_ts_courses',
            'read_private_ts_courses',
            'delete_ts_courses',
            'delete_private_ts_courses',
            'delete_published_ts_courses',
            'delete_others_ts_courses',
            'edit_private_ts_courses',
            'edit_published_ts_courses',
        );
    }

    /**
     * Get lesson capabilities.
     *
     * @return array Lesson capabilities.
     */
    public static function get_lesson_capabilities() {
        return array(
            'edit_ts_lesson',
            'read_ts_lesson',
            'delete_ts_lesson',
            'edit_ts_lessons',
            'edit_others_ts_lessons',
            'publish_ts_lessons',
            'read_private_ts_lessons',
            'delete_ts_lessons',
            'delete_private_ts_lessons',
            'delete_published_ts_lessons',
            'delete_others_ts_lessons',
            'edit_private_ts_lessons',
            'edit_published_ts_lessons',
        );
    }

    /**
     * Get quiz capabilities.
     *
     * @return array Quiz capabilities.
     */
    public static function get_quiz_capabilities() {
        return array(
            'edit_ts_quiz',
            'read_ts_quiz',
            'delete_ts_quiz',
            'edit_ts_quizzes',
            'edit_others_ts_quizzes',
            'publish_ts_quizzes',
            'read_private_ts_quizzes',
            'delete_ts_quizzes',
            'delete_private_ts_quizzes',
            'delete_published_ts_quizzes',
            'delete_others_ts_quizzes',
            'edit_private_ts_quizzes',
            'edit_published_ts_quizzes',
        );
    }

    /**
     * Get assignment capabilities.
     *
     * @return array Assignment capabilities.
     */
    public static function get_assignment_capabilities() {
        return array(
            'edit_ts_assignment',
            'read_ts_assignment',
            'delete_ts_assignment',
            'edit_ts_assignments',
            'edit_others_ts_assignments',
            'publish_ts_assignments',
            'read_private_ts_assignments',
            'delete_ts_assignments',
            'delete_private_ts_assignments',
            'delete_published_ts_assignments',
            'delete_others_ts_assignments',
            'edit_private_ts_assignments',
            'edit_published_ts_assignments',
        );
    }

    /**
     * Get bundle capabilities.
     *
     * @return array Bundle capabilities.
     */
    public static function get_bundle_capabilities() {
        return array(
            'edit_ts_bundle',
            'read_ts_bundle',
            'delete_ts_bundle',
            'edit_ts_bundles',
            'edit_others_ts_bundles',
            'publish_ts_bundles',
            'read_private_ts_bundles',
            'delete_ts_bundles',
            'delete_private_ts_bundles',
            'delete_published_ts_bundles',
            'delete_others_ts_bundles',
            'edit_private_ts_bundles',
            'edit_published_ts_bundles',
        );
    }

    /**
     * Remove capabilities from roles.
     *
     * @return void
     */
    public static function remove_capabilities() {
        $roles = array( 'administrator', 'editor' );

        $all_caps = array_merge(
            self::get_course_capabilities(),
            self::get_lesson_capabilities(),
            self::get_quiz_capabilities(),
            self::get_assignment_capabilities(),
            self::get_bundle_capabilities()
        );

        foreach ( $roles as $role_name ) {
            $role = get_role( $role_name );
            if ( $role ) {
                foreach ( $all_caps as $cap ) {
                    $role->remove_cap( $cap );
                }
            }
        }

        delete_option( 'ts_lms_courses_capabilities_added' );
    }
}
