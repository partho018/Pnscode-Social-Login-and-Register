<?php
/**
 * Certificate Shortcode
 * 
 * Provides shortcodes to display certificates
 */

namespace TS_LMS\Courses;

class CertificateShortcode {

	/**
	 * Initialize shortcodes
	 */
	public static function init() {
		add_shortcode( 'ts_certificate', array( __CLASS__, 'certificate_shortcode' ) );
		add_shortcode( 'ts_my_certificates', array( __CLASS__, 'my_certificates_shortcode' ) );
	}

	/**
	 * Certificate display shortcode
	 * 
	 * Usage: [ts_certificate course_id="123"]
	 * 
	 * @param array $atts Shortcode attributes
	 * @return string Shortcode output
	 */
	public static function certificate_shortcode( $atts ) {
		$atts = shortcode_atts( array(
			'course_id' => 0,
			'user_id'   => 0,
		), $atts );

		$course_id = intval( $atts['course_id'] );
		$user_id = intval( $atts['user_id'] ) ?: get_current_user_id();

		if ( ! $course_id || ! $user_id ) {
			return '<p class="ts-cert-error">Invalid certificate request.</p>';
		}

		// Check if user completed the course
		$completed = get_user_meta( $user_id, '_ts_course_completed_' . $course_id, true );
		if ( ! $completed ) {
			return '<p class="ts-cert-error">You have not completed this course yet.</p>';
		}

		// Get certificate URL
		$cert_url = CertificateGenerator::get_certificate_url( $user_id, $course_id );

		ob_start();
		?>
		<div class="ts-certificate-display">
			<div class="ts-cert-card">
				<div class="ts-cert-icon">
					<span class="dashicons dashicons-awards"></span>
				</div>
				<h3><?php _e( 'Certificate of Completion', 'ts-lms' ); ?></h3>
				<p><?php echo esc_html( get_the_title( $course_id ) ); ?></p>
				<div class="ts-cert-actions">
					<a href="<?php echo esc_url( $cert_url ); ?>" class="ts-btn-primary" target="_blank">
						<span class="dashicons dashicons-visibility"></span>
						<?php _e( 'View Certificate', 'ts-lms' ); ?>
					</a>
					<a href="<?php echo esc_url( $cert_url ); ?>" class="ts-btn-secondary" download>
						<span class="dashicons dashicons-download"></span>
						<?php _e( 'Download Certificate', 'ts-lms' ); ?>
					</a>
				</div>
			</div>
		</div>
		<style>
			.ts-certificate-display {
				max-width: 600px;
				margin: 40px auto;
				padding: 20px;
			}
			.ts-cert-card {
				background: white;
				border: 1px solid #e0e0e0;
				border-radius: 12px;
				padding: 40px;
				text-align: center;
				box-shadow: 0 2px 10px rgba(0,0,0,0.05);
			}
			.ts-cert-icon {
				font-size: 60px;
				color: #d4af37;
				margin-bottom: 20px;
			}
			.ts-cert-icon .dashicons {
				width: 60px;
				height: 60px;
				font-size: 60px;
			}
			.ts-cert-card h3 {
				font-size: 24px;
				margin: 10px 0;
				color: #333;
			}
			.ts-cert-card p {
				font-size: 16px;
				color: #666;
				margin: 10px 0 30px;
			}
			.ts-cert-actions {
				display: flex;
				gap: 15px;
				justify-content: center;
				flex-wrap: wrap;
			}
			.ts-btn-primary, .ts-btn-secondary {
				display: inline-flex;
				align-items: center;
				gap: 8px;
				padding: 12px 24px;
				border-radius: 6px;
				text-decoration: none;
				font-weight: 600;
				transition: all 0.3s ease;
			}
			.ts-btn-primary {
				background: #4f46e5;
				color: white;
			}
			.ts-btn-primary:hover {
				background: #4338ca;
				color: white;
			}
			.ts-btn-secondary {
				background: white;
				color: #4f46e5;
				border: 2px solid #4f46e5;
			}
			.ts-btn-secondary:hover {
				background: #f5f3ff;
				color: #4338ca;
			}
			.ts-cert-error {
				text-align: center;
				padding: 20px;
				background: #fee;
				border: 1px solid #fcc;
				border-radius: 6px;
				color: #c00;
			}
		</style>
		<?php
		return ob_get_clean();
	}

	/**
	 * My certificates list shortcode
	 * 
	 * Usage: [ts_my_certificates]
	 * 
	 * @param array $atts Shortcode attributes
	 * @return string Shortcode output
	 */
	public static function my_certificates_shortcode( $atts ) {
		$user_id = get_current_user_id();
		
		if ( ! $user_id ) {
			return '<p class="ts-cert-error">Please log in to view your certificates.</p>';
		}

		// Get all completed courses
		global $wpdb;
		$table = $wpdb->prefix . 'ts_lms_user_courses';
		$completed_courses = $wpdb->get_results( $wpdb->prepare(
			"SELECT course_id, completed_date FROM $table WHERE user_id = %d AND status = 'completed'",
			$user_id
		) );

		if ( empty( $completed_courses ) ) {
			return '<p class="ts-cert-notice">You haven\'t completed any courses yet.</p>';
		}

		ob_start();
		?>
		<div class="ts-certificates-grid">
			<h2><?php _e( 'My Certificates', 'ts-lms' ); ?></h2>
			<div class="ts-certs-list">
				<?php foreach ( $completed_courses as $course_enrollment ) : 
					$course_id = $course_enrollment->course_id;
					$course = get_post( $course_id );
					if ( ! $course ) continue;

					// Check if course has a certificate template
					$cert_template = get_post_meta( $course_id, '_selected_certificate', true );
					if ( empty( $cert_template ) || $cert_template === 'none' ) continue;

					$cert_url = CertificateGenerator::get_certificate_url( $user_id, $course_id );
					$completion_date = date_i18n( get_option( 'date_format' ), strtotime( $course_enrollment->completed_date ) );
				?>
					<div class="ts-cert-item">
						<div class="ts-cert-item-icon">
							<span class="dashicons dashicons-awards"></span>
						</div>
						<div class="ts-cert-item-content">
							<h4><?php echo esc_html( $course->post_title ); ?></h4>
							<p class="ts-cert-date">
								<span class="dashicons dashicons-calendar"></span>
								<?php printf( __( 'Completed: %s', 'ts-lms' ), $completion_date ); ?>
							</p>
							<div class="ts-cert-item-actions">
								<a href="<?php echo esc_url( $cert_url ); ?>" target="_blank" class="ts-cert-view">
									<span class="dashicons dashicons-visibility"></span>
									<?php _e( 'View', 'ts-lms' ); ?>
								</a>
								<a href="<?php echo esc_url( $cert_url ); ?>" download class="ts-cert-download">
									<span class="dashicons dashicons-download"></span>
									<?php _e( 'Download', 'ts-lms' ); ?>
								</a>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<style>
			.ts-certificates-grid {
				max-width: 800px;
				margin: 40px auto;
				padding: 20px;
			}
			.ts-certificates-grid h2 {
				font-size: 32px;
				margin-bottom: 30px;
				color: #333;
			}
			.ts-certs-list {
				display: grid;
				gap: 20px;
			}
			.ts-cert-item {
				display: flex;
				gap: 20px;
				background: white;
				border: 1px solid #e0e0e0;
				border-radius: 12px;
				padding: 24px;
				transition: all 0.3s ease;
			}
			.ts-cert-item:hover {
				box-shadow: 0 4px 12px rgba(0,0,0,0.1);
				transform: translateY(-2px);
			}
			.ts-cert-item-icon {
				font-size: 48px;
				color: #d4af37;
				flex-shrink: 0;
			}
			.ts-cert-item-icon .dashicons {
				width: 48px;
				height: 48px;
				font-size: 48px;
			}
			.ts-cert-item-content {
				flex: 1;
			}
			.ts-cert-item-content h4 {
				font-size: 20px;
				margin: 0 0 10px;
				color: #333;
			}
			.ts-cert-date {
				display: flex;
				align-items: center;
				gap: 6px;
				font-size: 14px;
				color: #666;
				margin: 0 0 15px;
			}
			.ts-cert-date .dashicons {
				font-size: 16px;
				width: 16px;
				height: 16px;
			}
			.ts-cert-item-actions {
				display: flex;
				gap: 10px;
			}
			.ts-cert-view, .ts-cert-download {
				display: inline-flex;
				align-items: center;
				gap: 6px;
				padding: 8px 16px;
				border-radius: 6px;
				text-decoration: none;
				font-size: 14px;
				font-weight: 600;
				transition: all 0.3s ease;
			}
			.ts-cert-view {
				background: #4f46e5;
				color: white;
			}
			.ts-cert-view:hover {
				background: #4338ca;
				color: white;
			}
			.ts-cert-download {
				background: white;
				color: #4f46e5;
				border: 2px solid #4f46e5;
			}
			.ts-cert-download:hover {
				background: #f5f3ff;
				color: #4338ca;
			}
			.ts-cert-notice {
				text-align: center;
				padding: 40px;
				background: #f5f5f5;
				border-radius: 8px;
				color: #666;
			}
		</style>
		<?php
		return ob_get_clean();
	}
}

// Initialize shortcodes
CertificateShortcode::init();
