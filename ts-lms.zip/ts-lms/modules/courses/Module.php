<?php
/**
 * Course Engine Module
 *
 * Main module class that bootstraps the Course Engine.
 *
 * @package TS_LMS\Modules\Courses
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Courses;

use TS_LMS\Modules\Courses\Database\Installer;
use TS_LMS\Modules\Courses\Capabilities\Capabilities;
use TS_LMS\Modules\Courses\PostTypes\Course;
use TS_LMS\Modules\Courses\PostTypes\Lesson;
use TS_LMS\Modules\Courses\PostTypes\Quiz;
use TS_LMS\Modules\Courses\PostTypes\Assignment;
use TS_LMS\Modules\Courses\PostTypes\Topic;
use TS_LMS\Modules\Courses\PostTypes\Bundle;
use TS_LMS\Modules\Courses\Taxonomies\Taxonomies;
use TS_LMS\Modules\Courses\Access\AccessControl;
use TS_LMS\Modules\Courses\API\CoursesController;
use TS_LMS\Modules\Courses\API\LessonsController;
use TS_LMS\Modules\Courses\Integration\WooIntegration;
use TS_LMS\Modules\Courses\Managers\TemplateManager;
use TS_LMS\Modules\Courses\Hooks\Hooks;
use TS_LMS\Modules\Courses\Ajax\ReviewAjax;
use TS_LMS\Modules\Courses\Ajax\WishlistAjax;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Module class.
 */
class Module {

    /**
     * Module version.
     *
     * @var string
     */
    const VERSION = '1.0.0';

    /**
     * Singleton instance.
     *
     * @var Module
     */
    private static $instance = null;

    /**
     * Get singleton instance.
     *
     * @return Module
     */
    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->init();
    }

    /**
     * Initialize the module.
     *
     * @return void
     */
    private function init() {
        // Initialize capabilities
        Capabilities::init();

        // Initialize post types
        Course::init();
        Lesson::init();
        Quiz::init();
        Assignment::init();
        Topic::init();
        Bundle::init();

        // Initialize taxonomies
        Taxonomies::init();

        // Initialize access control
        AccessControl::init();

        // Initialize WooCommerce integration
        WooIntegration::init();
        
        // Run database migrations
        $this->run_migrations();

        // Initialize Template Manager
        TemplateManager::init();

        // Initialize hooks
        Hooks::init();
        
        // Initialize Course Permalink Fix
        require_once plugin_dir_path( __FILE__ ) . 'includes/Hooks/CoursePermalinkFix.php';
        \TS_LMS\Modules\Courses\Hooks\CoursePermalinkFix::init();

        
        // Initialize Review AJAX Handler
        ReviewAjax::init();
        
        // Initialize Wishlist AJAX Handler
        WishlistAjax::init();
        
        // Initialize Certificate Generator
        if ( file_exists( plugin_dir_path( __FILE__ ) . 'includes/CertificateGenerator.php' ) ) {
            require_once plugin_dir_path( __FILE__ ) . 'includes/CertificateGenerator.php';
            // Certificate generator is auto-hooked in its own file
        }
        
        // Initialize Certificate Shortcodes
        if ( file_exists( plugin_dir_path( __FILE__ ) . 'includes/CertificateShortcode.php' ) ) {
            require_once plugin_dir_path( __FILE__ ) . 'includes/CertificateShortcode.php';
            // Shortcodes are auto-initialized in the file
        }
        
        // Initialize Frontend
        \TS_LMS\Modules\Courses\Frontend\CourseCatalog::init();
        
        // Initialize Instructor Access Control - RE-ENABLED with fixes
        if ( file_exists( plugin_dir_path( __FILE__ ) . 'includes/Access/InstructorAccess.php' ) ) {
            require_once plugin_dir_path( __FILE__ ) . 'includes/Access/InstructorAccess.php';
            \TS_LMS\Modules\Courses\Access\InstructorAccess::init();
        }
        
        // Initialize custom admin pages
        if ( is_admin() ) {
            // Course List Table customization
            \TS_LMS\Modules\Courses\Admin\CourseListTable::init();
            
            // Custom Course List Page
            \TS_LMS\Modules\Courses\Admin\CustomCourseListPage::init();
            \TS_LMS\Modules\Courses\Admin\CourseEditor::init();
            \TS_LMS\Modules\Courses\Admin\BundleEditor::init();
            \TS_LMS\Modules\Courses\Admin\EditorRedirect::init();
            \TS_LMS\Modules\Courses\Admin\CourseCategoryPage::init();
            
            // Initialize Instructor Approval Admin Page - RE-ENABLED with fixes
            if ( file_exists( plugin_dir_path( __FILE__ ) . 'includes/Admin/InstructorApproval.php' ) ) {
                require_once plugin_dir_path( __FILE__ ) . 'includes/Admin/InstructorApproval.php';
                // \TS_LMS\Modules\Courses\Admin\InstructorApproval::init();
            }
        }


        // Register REST API routes
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

        // Add admin notices
        add_action( 'admin_notices', array( $this, 'admin_notices' ) );

        // Flush rewrite rules if needed
        add_action( 'admin_init', array( $this, 'maybe_flush_rewrite_rules' ) );
        
        // Temporary Flush for Lesson 404 Fix
        if ( isset($_GET['ts_flush']) ) {
            flush_rewrite_rules(true);
        }

		// Schedule Cron
		add_action( 'init', array( $this, 'schedule_cron' ) );
		add_action( 'ts_lms_verify_subscriptions', array( 'TS_LMS\Modules\Courses\Managers\CourseManager', 'check_expired_subscriptions' ) );
    }

    /**
     * Run database migrations.
     *
     * @return void
     */
    private function run_migrations() {
        // Only run in admin or during AJAX
        if ( ! is_admin() && ! wp_doing_ajax() ) {
            return;
        }

        // Check if we've already checked migrations recently (throttle to once per hour)
        $migration_check_key = 'ts_lms_migration_check_throttle';
        if ( get_transient( $migration_check_key ) ) {
            return; // Skip if we've checked recently
        }

        // Load migration class
        require_once plugin_dir_path( __FILE__ ) . 'includes/Database/Migration_Add_Order_Id.php';

        // Run migration if not already run
        if ( ! \TS_LMS\Modules\Courses\Database\Migration_Add_Order_Id::has_run() ) {
            \TS_LMS\Modules\Courses\Database\Migration_Add_Order_Id::run();
        }

        // Set transient to prevent checking again for 1 hour
        set_transient( $migration_check_key, true, HOUR_IN_SECONDS );
    }


    /**
     * Register REST API routes.
     *
     * @return void
     */
    public function register_rest_routes() {
        $courses_controller = new CoursesController();
        $courses_controller->register_routes();

        $lessons_controller = new LessonsController();
        $lessons_controller->register_routes();
    }

    /**
     * Install the module.
     *
     * @return void
     */
    public static function install() {
        // Install database tables
        Installer::install();

        // Flush rewrite rules
        flush_rewrite_rules();

        error_log( 'TS LMS Course Engine: Module installed successfully.' );
    }

    /**
     * Uninstall the module.
     *
     * @return void
     */
    public static function uninstall() {
        // Remove capabilities
        Capabilities::remove_capabilities();

        // Optionally remove database tables
        // Installer::uninstall();

        // Flush rewrite rules
        flush_rewrite_rules();

        error_log( 'TS LMS Course Engine: Module uninstalled.' );
    }

    /**
     * Display admin notices.
     *
     * @return void
     */
    public function admin_notices() {
        // Throttle table existence check to once every 5 minutes
        $tables_check_key = 'ts_lms_tables_exist_check';
        $tables_exist = get_transient( $tables_check_key );
        
        // If transient doesn't exist, check tables
        if ( false === $tables_exist ) {
            $tables_exist = Installer::tables_exist() ? 'yes' : 'no';
            set_transient( $tables_check_key, $tables_exist, 5 * MINUTE_IN_SECONDS );
        }
        
        // Check if database tables exist
        if ( 'no' === $tables_exist ) {
            // Attempt to install automatically if missing
            Installer::install();
            
            // Clear the transient so we check again next time
            delete_transient( $tables_check_key );
            
            // Re-check after attempt
            if ( ! Installer::tables_exist() ) {
                ?>
                <div class="notice notice-warning">
                    <p>
                        <strong><?php esc_html_e( 'TS LMS Course Engine:', 'ts-lms' ); ?></strong>
                        <?php esc_html_e( 'Database tables are still missing. Please ensure your database user has CREATE TABLE permissions.', 'ts-lms' ); ?>
                    </p>
                </div>
                <?php
            } else {
                ?>
                <div class="notice notice-success is-dismissible">
                    <p>
                        <strong><?php esc_html_e( 'TS LMS Course Engine:', 'ts-lms' ); ?></strong>
                        <?php esc_html_e( 'Database tables were missing but have been automatically created.', 'ts-lms' ); ?>
                    </p>
                </div>
                <?php
            }
        }
    }

    /**
     * Get module version.
     *
     * @return string Module version.
     */
    public static function get_version() {
        return self::VERSION;
    }

    /**
     * Get module info.
     *
     * @return array Module information.
     */
    public static function get_info() {
        return array(
            'name'        => 'Course Engine',
            'version'     => self::VERSION,
            'description' => 'Core course and lesson management module',
            'author'      => 'Raju',
            'status'      => Installer::tables_exist() ? 'active' : 'incomplete',
        );
    }

	/**
	 * Maybe flush rewrite rules if course slug was changed.
	 */
	public function maybe_flush_rewrite_rules() {
		$flushed = get_option( 'ts_lms_course_slug_flushed_v2', false );
		
		if ( ! $flushed ) {
			flush_rewrite_rules();
			update_option( 'ts_lms_course_slug_flushed_v2', true );
		}
	}

	/**
	 * Schedule cron jobs.
	 */
	public function schedule_cron() {
		if ( ! wp_next_scheduled( 'ts_lms_verify_subscriptions' ) ) {
			wp_schedule_event( time(), 'daily', 'ts_lms_verify_subscriptions' );
		}
	}
}
