<?php
/**
 * Basic Functionality Test
 *
 * Simple test to verify Course Engine module is loaded and working.
 * Run this from WordPress admin or via WP-CLI.
 *
 * @package TS_LMS\Modules\Courses
 */

// This file should be run within WordPress context
if ( ! defined( 'ABSPATH' ) ) {
    die( 'This file must be run within WordPress context.' );
}

echo "=== TS LMS Course Engine - Basic Functionality Test ===\n\n";

// Test 1: Check if module is loaded
echo "Test 1: Module Loaded\n";
if ( class_exists( 'TS_LMS\Modules\Courses\Module' ) ) {
    echo "✓ Module class exists\n";
    $module_info = \TS_LMS\Modules\Courses\Module::get_info();
    echo "  Name: {$module_info['name']}\n";
    echo "  Version: {$module_info['version']}\n";
    echo "  Status: {$module_info['status']}\n";
} else {
    echo "✗ Module class not found\n";
}
echo "\n";

// Test 2: Check database tables
echo "Test 2: Database Tables\n";
if ( \TS_LMS\Modules\Courses\Database\Installer::tables_exist() ) {
    echo "✓ All database tables exist\n";
    global $wpdb;
    $tables = array(
        'ts_course_instructors',
        'ts_lesson_order',
        'ts_course_enrollments',
        'ts_lesson_progress',
    );
    foreach ( $tables as $table ) {
        $full_table = $wpdb->prefix . $table;
        $count = $wpdb->get_var( "SELECT COUNT(*) FROM {$full_table}" );
        echo "  - {$full_table}: {$count} rows\n";
    }
} else {
    echo "✗ Some database tables are missing\n";
}
echo "\n";

// Test 3: Check post types
echo "Test 3: Custom Post Types\n";
$post_types = array(
    'ts_course'     => 'Course',
    'ts_lesson'     => 'Lesson',
    'ts_quiz'       => 'Quiz',
    'ts_assignment' => 'Assignment',
);
foreach ( $post_types as $type => $label ) {
    if ( post_type_exists( $type ) ) {
        $count = wp_count_posts( $type );
        echo "✓ {$label} post type registered ({$count->publish} published)\n";
    } else {
        echo "✗ {$label} post type not registered\n";
    }
}
echo "\n";

// Test 4: Check taxonomies
echo "Test 4: Taxonomies\n";
$taxonomies = array(
    'ts_course_category' => 'Course Category',
    'ts_course_tag'      => 'Course Tag',
);
foreach ( $taxonomies as $tax => $label ) {
    if ( taxonomy_exists( $tax ) ) {
        $count = wp_count_terms( array( 'taxonomy' => $tax ) );
        echo "✓ {$label} taxonomy registered ({$count} terms)\n";
    } else {
        echo "✗ {$label} taxonomy not registered\n";
    }
}
echo "\n";

// Test 5: Check capabilities
echo "Test 5: Capabilities\n";
$admin = get_role( 'administrator' );
if ( $admin ) {
    $test_caps = array(
        'edit_ts_courses',
        'edit_ts_lessons',
        'publish_ts_courses',
        'publish_ts_lessons',
    );
    $all_exist = true;
    foreach ( $test_caps as $cap ) {
        if ( ! $admin->has_cap( $cap ) ) {
            $all_exist = false;
            echo "✗ Administrator missing capability: {$cap}\n";
        }
    }
    if ( $all_exist ) {
        echo "✓ All test capabilities exist for Administrator\n";
    }
} else {
    echo "✗ Administrator role not found\n";
}
echo "\n";

// Test 6: Check REST API
echo "Test 6: REST API Endpoints\n";
$rest_server = rest_get_server();
$routes = $rest_server->get_routes();
$endpoints = array(
    '/ts-lms/v1/courses',
    '/ts-lms/v1/lessons',
);
foreach ( $endpoints as $endpoint ) {
    $found = false;
    foreach ( $routes as $route => $handlers ) {
        if ( strpos( $route, $endpoint ) === 0 ) {
            $found = true;
            break;
        }
    }
    if ( $found ) {
        echo "✓ Endpoint registered: {$endpoint}\n";
    } else {
        echo "✗ Endpoint not found: {$endpoint}\n";
    }
}
echo "\n";

// Test 7: Create a test course
echo "Test 7: Create Test Course\n";
$test_course_id = \TS_LMS\Modules\Courses\Managers\CourseManager::create_course( array(
    'title'   => 'Test Course - ' . time(),
    'content' => 'This is a test course created by the verification script.',
    'status'  => 'active',
    'level'   => 'beginner',
) );

if ( ! is_wp_error( $test_course_id ) ) {
    echo "✓ Test course created with ID: {$test_course_id}\n";
    
    // Clean up
    wp_delete_post( $test_course_id, true );
    echo "  (Test course deleted)\n";
} else {
    echo "✗ Failed to create test course: " . $test_course_id->get_error_message() . "\n";
}
echo "\n";

// Test 8: Create a test lesson
echo "Test 8: Create Test Lesson\n";
$test_lesson_id = \TS_LMS\Modules\Courses\Managers\LessonManager::create_lesson( array(
    'title'   => 'Test Lesson - ' . time(),
    'content' => 'This is a test lesson created by the verification script.',
    'type'    => 'text',
) );

if ( ! is_wp_error( $test_lesson_id ) ) {
    echo "✓ Test lesson created with ID: {$test_lesson_id}\n";
    
    // Clean up
    wp_delete_post( $test_lesson_id, true );
    echo "  (Test lesson deleted)\n";
} else {
    echo "✗ Failed to create test lesson: " . $test_lesson_id->get_error_message() . "\n";
}
echo "\n";

echo "=== Test Complete ===\n";
echo "\nNext Steps:\n";
echo "1. Review the test results above\n";
echo "2. Check the VERIFICATION.md file for detailed testing\n";
echo "3. Test course and lesson creation in WordPress admin\n";
echo "4. Test REST API endpoints in browser or Postman\n";
echo "5. Test access control with different user roles\n";
