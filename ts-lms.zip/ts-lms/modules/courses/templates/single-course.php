<?php
/**
 * Single Course Template - Redesigned
 *
 * @package TS_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$course_id = get_the_ID();
$current_user_id = get_current_user_id();

// Check Course Visibility Setting
$course_visibility = \TS_LMS\Admin\Settings::get_setting('course_visibility');
if ( $course_visibility && !is_user_logged_in() ) {
    $login_page = \TS_LMS\Admin\Settings::get_setting('login_page');
    if ( $login_page ) {
        wp_redirect( get_permalink($login_page) );
    } else {
        wp_redirect( wp_login_url( get_permalink() ) );
    }
    exit;
}

// Handle Free Enrollment Post
if ( isset($_POST['ts_lms_enroll_course']) && is_user_logged_in() ) {
    if ( wp_verify_nonce($_POST['ts_lms_enroll_nonce'], 'ts_lms_enroll_' . $course_id) ) {
        TS_LMS\Modules\Courses\Managers\CourseManager::enroll_student($course_id, $current_user_id);
        wp_safe_redirect(get_permalink());
        exit;
    }
}

// Handle Review Submission
if ( isset($_POST['ts_submit_review']) && is_user_logged_in() ) {
    if ( wp_verify_nonce($_POST['ts_review_nonce'], 'ts_lms_submit_review_' . $course_id) ) {
        
        $rating = isset($_POST['review_rating']) ? absint($_POST['review_rating']) : 0;
        $title = isset($_POST['review_title']) ? sanitize_text_field($_POST['review_title']) : '';
        $content = isset($_POST['review_content']) ? sanitize_textarea_field($_POST['review_content']) : '';
        
        if ($rating > 0 && $rating <= 5 && !empty($title) && !empty($content)) {
            // Check if user already reviewed
            $existing_review = get_comments(array(
                'post_id' => $course_id,
                'user_id' => $current_user_id,
                'type' => 'ts_course_review',
                'count' => true
            ));
            
            if ($existing_review == 0) {
                // Get current user
                $current_user = wp_get_current_user();
                
                // Insert review as comment
                $comment_data = array(
                    'comment_post_ID' => $course_id,
                    'comment_author' => $current_user->display_name,
                    'comment_author_email' => $current_user->user_email,
                    'comment_content' => $content,
                    'comment_type' => 'ts_course_review',
                    'comment_approved' => 1,
                    'user_id' => $current_user_id,
                );
                
                $comment_id = wp_insert_comment($comment_data);
                
                if ($comment_id) {
                    // Save rating and title as comment meta
                    add_comment_meta($comment_id, 'review_rating', $rating);
                    add_comment_meta($comment_id, 'review_title', $title);
                    
                    wp_safe_redirect(add_query_arg('review_submitted', '1', get_permalink()));
                    exit;
                }
            }
        }
    }
}

get_header();

$meta = array(
    'duration'     => get_post_meta( $course_id, '_course_duration', true ), 
    'level'        => get_post_meta( $course_id, '_course_level', true ),
    'price'        => get_post_meta( $course_id, '_course_price', true ),
    'video_url'    => get_post_meta( $course_id, '_course_intro_video_url', true ),
    'video_source' => get_post_meta( $course_id, '_course_intro_video_source', true ),
    'updated'      => get_the_modified_date(),
);

// Get Settings for features and layouts
$settings = get_option( 'ts_lms_settings', array() );
$enabled_features = isset( $settings['course_features'] ) ? (array)$settings['course_features'] : array();
$instructor_layout = isset( $settings['instructor_list_layout'] ) ? $settings['instructor_list_layout'] : 'portrait';

$show_feature = function($feature_key) use ($enabled_features) {
    return in_array($feature_key, $enabled_features);
};

// User and Enrollment status
$is_enrolled = TS_LMS\Modules\Courses\Managers\CourseManager::is_enrolled( $course_id, $current_user_id );
if ( current_user_can( 'manage_options' ) || get_post_field( 'post_author', $course_id ) == $current_user_id ) {
    $is_enrolled = true;
}

// Topics / Curriculum Calculation
$topics = get_posts( array(
    'post_type'      => 'ts_topic',
    'posts_per_page' => -1,
    'post_parent'    => $course_id,
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
) );

$curriculum_stats = array('lessons' => 0, 'quizzes' => 0, 'assignments' => 0, 'first_link' => '');
foreach($topics as $t) {
    $items = get_posts(array(
        'post_parent'    => $t->ID, 
        'post_type'      => array('ts_lesson', 'ts_quiz', 'ts_assignment'), 
        'posts_per_page' => -1, 
        'post_status'    => 'publish',
        'orderby'        => 'menu_order',
        'order'          => 'ASC'
    ));
    foreach($items as $item) {
        if ($item->post_type === 'ts_lesson') $curriculum_stats['lessons']++;
        if ($item->post_type === 'ts_quiz') $curriculum_stats['quizzes']++;
        if ($item->post_type === 'ts_assignment') $curriculum_stats['assignments']++;
        if (empty($curriculum_stats['first_link'])) $curriculum_stats['first_link'] = get_permalink($item->ID);
    }
}

// Pricing & Button Logic (Simplified for Redesign)
$price_type = get_post_meta( $course_id, '_course_price_type', true );
$price_html = __('Free', 'ts-lms');
if ($price_type === 'paid') {
    $product_id = get_post_meta( $course_id, '_course_product_id', true );
    if ($product_id && function_exists('wc_get_product')) {
        $product = wc_get_product($product_id);
        if ($product) $price_html = $product->get_price_html();
    }
} elseif ($price_type === 'subscription') {
    $product_id = get_post_meta( $course_id, '_course_product_id', true );
    $sub_plan = get_post_meta( $course_id, '_subscription_plan_type', true );
    if ($product_id && function_exists('wc_get_product')) {
        $product = wc_get_product($product_id);
        if ($product) {
            $price_html = sprintf('%s/%s', $product->get_price_html(), ucfirst($sub_plan));
        }
    } else {
        $sub_price = get_post_meta( $course_id, '_subscription_price', true );
        $price_html = sprintf('%s/%s', $sub_price, ucfirst($sub_plan));
    }
}

$enroll_text = $is_enrolled ? __('Start Learning', 'ts-lms') : __('Enroll Now', 'ts-lms');
$enroll_url = $is_enrolled ? ($curriculum_stats['first_link'] ?: get_permalink()) : '#';

// Certificate status
$selected_cert = get_post_meta($course_id, '_selected_certificate', true);
$showcase_certificate = \TS_LMS\Admin\Settings::get_setting('showcase_certificate');
?>

<div class="ts-lms-single-course-v2">
    <!-- Hero Section -->
    <div class="ts-course-hero">
        <div class="container">
            <div class="ts-hero-grid">
                <div class="ts-hero-content">
                    <nav class="ts-breadcrumb">
                        <a href="<?php echo home_url(); ?>"><?php _e('Home', 'ts-lms'); ?></a>
                        <span class="sep">/</span>
                        <a href="<?php echo get_post_type_archive_link('ts_course'); ?>"><?php _e('Courses', 'ts-lms'); ?></a>
                        <span class="sep">/</span>
                        <span class="current"><?php the_title(); ?></span>
                    </nav>

                    <h1 class="ts-title"><?php the_title(); ?></h1>
                    
                    <div class="ts-meta-badges">
                        <?php $cats = get_the_terms($course_id, 'ts_course_category'); if($cats): ?>
                            <span class="badge category"><?php echo esc_html($cats[0]->name); ?></span>
                        <?php endif; ?>
                        <span class="badge level"><?php echo esc_html(ucfirst($meta['level'] ?: 'All Levels')); ?></span>
                    </div>

                    <div class="ts-instructor-brief">
                        <?php $author_id = get_post_field('post_author', $course_id); ?>
                        <div class="avatar"><?php echo get_avatar($author_id, 40); ?></div>
                        <div class="info">
                            <span class="label"><?php _e('Instructor:', 'ts-lms'); ?></span>
                            <span class="name"><?php echo get_the_author_meta('display_name', $author_id); ?></span>
                        </div>
                        <div class="last-updated">
                            <span class="dashicons dashicons-calendar-alt"></span>
                            <?php printf(__('Updated %s', 'ts-lms'), get_the_modified_date()); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="ts-course-layout-v2">
            <!-- Main Content Area -->
            <div class="ts-main-column">
                
                <!-- Video/Thumbnail Wrapper -->
                <div class="ts-video-wrapper">
                    <?php 
                    $video_url = $meta['video_url'];
                    $poster = get_the_post_thumbnail_url($course_id, 'full');
                    if ($video_url) : ?>
                        <div id="ts-course-player" data-plyr-provider="youtube" data-plyr-embed-id="<?php echo esc_attr($video_url); ?>"></div>
                        <link rel="stylesheet" href="https://cdn.plyr.io/3.7.8/plyr.css" />
                        <script src="https://cdn.plyr.io/3.7.8/plyr.js"></script>
                        <script>document.addEventListener('DOMContentLoaded', () => { new Plyr('#ts-course-player'); });</script>
                    <?php else: ?>
                        <img src="<?php echo esc_url($poster); ?>" alt="<?php the_title(); ?>" class="ts-main-poster">
                    <?php endif; ?>
                </div>

                <!-- Tabs Navigation -->
                <div class="ts-tabs-nav">
                    <button class="tab-link active" data-tab="overview"><?php _e('Overview', 'ts-lms'); ?></button>
                    <button class="tab-link" data-tab="reviews"><?php _e('Reviews', 'ts-lms'); ?></button>
                </div>

                <div class="ts-tabs-content">
                    <!-- Overview Tab -->
                    <div id="overview" class="tab-pane active">
                        <?php 
                        // Get course description from Basic section
                        $course_post = get_post($course_id);
                        $course_content = '';
                        
                        if ($course_post && !empty($course_post->post_content)) {
                            $course_content = $course_post->post_content;
                            // Apply WordPress content filters to process shortcodes, embeds, etc.
                            $course_content = apply_filters('the_content', $course_content);
                        }
                        ?>
                        
                        <!-- About this course section - ALWAYS shows first -->
                        <div class="ts-content-block">
                            <h3 class="ts-section-title">
                                <span class="dashicons dashicons-text-page"></span>
                                <?php _e('About this course', 'ts-lms'); ?>
                            </h3>
                            <?php if (!empty($course_content)): ?>
                            <div class="ts-description-wrapper" id="course-description">
                                <div class="ts-description">
                                    <?php echo $course_content; ?>
                                </div>
                                <div class="ts-description-overlay"></div>
                            </div>
                            <button id="ts-toggle-description" class="ts-read-more-btn">
                                <span><?php _e('Show More', 'ts-lms'); ?></span>
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                            </button>
                            <?php else: ?>
                            <p class="ts-no-content"><?php _e('No description available for this course.', 'ts-lms'); ?></p>
                            <?php endif; ?>
                        </div>

                        <?php 
                        $prerequisites = get_post_meta($course_id, '_course_prerequisites', true);
                        if (!empty($prerequisites) && is_array($prerequisites)) : 
                        ?>
                        <div class="ts-content-block ts-prerequisites-section">
                            <h3 class="ts-section-title">
                                <span class="dashicons dashicons-list-view"></span>
                                <?php _e('Course Prerequisites', 'ts-lms'); ?>
                            </h3>
                            <p style="font-size: 14px; color: #64748b; margin-bottom: 15px;">
                                <?php _e('The following courses are recommended to be completed before starting this course:', 'ts-lms'); ?>
                            </p>
                            <div class="ts-prerequisites-links" style="display: flex; flex-wrap: wrap; gap: 10px;">
                                <?php foreach ($prerequisites as $pre_id) : ?>
                                    <a href="<?php echo get_permalink($pre_id); ?>" class="ts-prerequisite-link" style="
                                        display: inline-flex;
                                        align-items: center;
                                        padding: 8px 16px;
                                        background: #f1f5f9;
                                        border-radius: 50px;
                                        color: #3b82f6;
                                        text-decoration: none;
                                        font-size: 14px;
                                        font-weight: 600;
                                        transition: all 0.2s;
                                        border: 1px solid #e2e8f0;
                                    ">
                                        <span class="dashicons dashicons-welcome-learn-more" style="margin-right: 8px; font-size: 16px;"></span>
                                        <?php echo get_the_title($pre_id); ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <style>
                            .ts-prerequisite-link:hover {
                                background: #eff6ff;
                                border-color: #3b82f6;
                                transform: translateY(-2px);
                                box-shadow: 0 4px 12px rgba(59, 130, 246, 0.1);
                            }
                        </style>
                        <?php endif; ?>

                        <?php $learn = get_post_meta($course_id, '_what_will_learn', true); if($learn): ?>
                        <div class="ts-content-block highlight-box">
                            <h3><?php _e('What you\'ll learn', 'ts-lms'); ?></h3>
                            <div class="ts-grid-list">
                                <?php foreach(explode("\n", str_replace("\r", "", $learn)) as $item): if(trim($item)): ?>
                                    <div class="list-item">
                                        <span class="dashicons dashicons-yes"></span>
                                        <span><?php echo esc_html($item); ?></span>
                                    </div>
                                <?php endif; endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php $target_audience = get_post_meta($course_id, '_target_audience', true); if($target_audience): ?>
                        <div class="ts-content-block">
                            <h3><?php _e('Target Audience', 'ts-lms'); ?></h3>
                            <ul class="ts-bullet-list">
                                <?php foreach(explode("\n", str_replace("\r", "", $target_audience)) as $item): if(trim($item)): ?>
                                    <li><?php echo esc_html($item); ?></li>
                                <?php endif; endforeach; ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <?php $materials = get_post_meta($course_id, '_materials_included', true); if($materials): ?>
                        <div class="ts-content-block">
                            <h3><?php _e('Materials Included', 'ts-lms'); ?></h3>
                            <ul class="ts-bullet-list">
                                <?php foreach(explode("\n", str_replace("\r", "", $materials)) as $item): if(trim($item)): ?>
                                    <li><?php echo esc_html($item); ?></li>
                                <?php endif; endforeach; ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <?php $reqs = get_post_meta($course_id, '_requirements_instructions', true); if($reqs): ?>
                        <div class="ts-content-block">
                            <h3><?php _e('Requirements', 'ts-lms'); ?></h3>
                            <ul class="ts-bullet-list">
                                <?php foreach(explode("\n", str_replace("\r", "", $reqs)) as $item): if(trim($item)): ?>
                                    <li><?php echo esc_html($item); ?></li>
                                <?php endif; endforeach; ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <!-- Course Curriculum (Moved to Overview) -->
                        <div class="ts-content-block">
                            <div class="ts-curriculum-header">
                                <h3><?php _e('Course Curriculum', 'ts-lms'); ?></h3>
                                <span class="stats"><?php printf(__('%d Lessons • %d Quizzes', 'ts-lms'), $curriculum_stats['lessons'], $curriculum_stats['quizzes']); ?></span>
                            </div>
                            <div class="ts-accordion-v2">
                                <?php foreach($topics as $topic): ?>
                                    <div class="accordion-item">
                                        <div class="accordion-trigger">
                                            <span class="title"><?php echo esc_html($topic->post_title); ?></span>
                                            <span class="dashicons dashicons-arrow-down-alt2"></span>
                                        </div>
                                        <div class="accordion-content">
                                            <?php 
                                            $items = get_posts(array('post_parent' => $topic->ID, 'post_type' => array('ts_lesson', 'ts_quiz', 'ts_assignment'), 'orderby' => 'menu_order', 'order' => 'ASC', 'posts_per_page' => -1));
                                            foreach($items as $item): 
                                                $type = str_replace('ts_', '', $item->post_type);
                                                $icon = 'dashicons-media-document';
                                                if ($type === 'lesson') {
                                                    $lesson_type = get_post_meta($item->ID, '_lesson_type', true);
                                                    if ($lesson_type === 'zoom') $icon = 'dashicons-video-alt2';
                                                    elseif ($lesson_type === 'meet') $icon = 'dashicons-video-alt3';
                                                    else $icon = 'dashicons-video-alt3';
                                                }
                                                if ($type === 'quiz') $icon = 'dashicons-forms';
                                                if ($type === 'assignment') $icon = 'dashicons-clipboard';
                                                
                                                $is_preview = ($type === 'lesson' && get_post_meta($item->ID, '_lesson_preview', true));
                                                $locked = !$is_enrolled && !$is_preview;
                                            ?>
                                                <div class="curriculum-item <?php echo $locked ? 'locked' : 'unlocked'; ?>">
                                                    <div class="left">
                                                        <span class="dashicons <?php echo $icon; ?>"></span>
                                                        <?php if($locked): ?>
                                                            <span class="item-title"><?php echo esc_html($item->post_title); ?></span>
                                                        <?php else: ?>
                                                            <a href="<?php echo get_permalink($item->ID); ?>" class="item-title"><?php echo esc_html($item->post_title); ?></a>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="right">
                                                        <?php if($is_preview && !$is_enrolled): ?>
                                                            <span class="preview-badge"><?php _e('Preview', 'ts-lms'); ?></span>
                                                        <?php endif; ?>
                                                        <span class="dashicons <?php echo $locked ? 'dashicons-lock' : 'dashicons-unlock'; ?>"></span>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>

                                <?php 
                                // Display course-wide attachments in a Resources section at the bottom
                                $course_attachments = get_post_meta( $course_id, '_course_attachments', true );
                                if ( ! empty( $course_attachments ) && is_array( $course_attachments ) ) : 
                                ?>
                                    <div class="accordion-item resources-item">
                                        <div class="accordion-trigger">
                                            <span class="title"><?php _e('Course Resources', 'ts-lms'); ?></span>
                                            <span class="dashicons dashicons-arrow-down-alt2"></span>
                                        </div>
                                        <div class="accordion-content">
                                            <?php foreach ( $course_attachments as $attachment_id ) : 
                                                $attachment_url = wp_get_attachment_url( $attachment_id );
                                                $attachment_name = basename( get_attached_file( $attachment_id ) );
                                                $locked = !$is_enrolled; 
                                            ?>
                                                <div class="curriculum-item <?php echo $locked ? 'locked' : 'unlocked'; ?>">
                                                    <div class="left">
                                                        <span class="dashicons dashicons-download"></span>
                                                        <?php if($locked): ?>
                                                            <span class="item-title"><?php echo esc_html($attachment_name); ?></span>
                                                        <?php else: ?>
                                                            <a href="<?php echo esc_url($attachment_url); ?>" class="item-title" download><?php echo esc_html($attachment_name); ?></a>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="right">
                                                        <span class="dashicons <?php echo $locked ? 'dashicons-lock' : 'dashicons-unlock'; ?>"></span>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <?php 
                        // Display Certificate if setting is enabled
                        if ($showcase_certificate && ( ($selected_cert && $selected_cert !== 'none') || get_post_meta($course_id, '_custom_certificate_id', true) )):
                            // Check if student completed the course
                            $is_completed = false;
                            if (is_user_logged_in()) {
                                $is_completed = get_user_meta($current_user_id, '_ts_course_completed_' . $course_id, true);
                            }
                            
                            $custom_cert_id = get_post_meta($course_id, '_custom_certificate_id', true);
                            $cert_url = '';
                            if ($is_completed) {
                                if ($custom_cert_id) {
                                    $cert_url = wp_get_attachment_url($custom_cert_id);
                                } else {
                                    $cert_url = \TS_LMS\Courses\CertificateGenerator::get_certificate_url($current_user_id, $course_id);
                                }
                            }
                        ?>
                            <div class="ts-content-block ts-certificate-showcase" style="margin-top: 40px;">
                                <div class="ts-section-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                                    <h3 style="font-size: 18px; font-weight: 700; margin: 0; color: #0f172a;">
                                        <span class="dashicons dashicons-awards" style="color: #f59e0b; font-size: 20px;"></span>
                                        <?php _e('Course Certificate', 'ts-lms'); ?>
                                    </h3>
                                    <?php if ($is_completed): ?>
                                        <a href="<?php echo esc_url($cert_url); ?>" class="ts-btn ts-btn-primary" target="_blank" style="padding: 8px 20px; font-size: 14px; border-radius: 50px;">
                                            <span class="dashicons dashicons-download" style="margin-right: 5px; font-size: 14px;"></span>
                                            <?php _e('Download Certificate', 'ts-lms'); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <div style="background: #f8fafc; padding: 40px; border-radius: 16px; border: 1px solid #e2e8f0; text-align: center; position: relative; overflow: hidden;">
                                    <!-- Beautiful background decoration -->
                                    <div style="position: absolute; top: -50px; right: -50px; width: 150px; height: 150px; background: rgba(245, 158, 11, 0.05); border-radius: 50%;"></div>
                                    <div style="position: absolute; bottom: -30px; left: -30px; width: 100px; height: 100px; background: rgba(79, 70, 229, 0.05); border-radius: 50%;"></div>
                                    
                                    <div class="certificate-preview-box" style="max-width: 500px; margin: 0 auto; transition: transform 0.3s ease;">
                                        <?php 
                                        // Use CertificateGenerator logic to show a preview
                                        $preview_styles = array(
                                            'cert-1' => 'background: linear-gradient(135deg, #f5f0e8 0%, #fef9f3 100%); border: 12px solid #d4af37;',
                                            'cert-2' => 'background: linear-gradient(135deg, #ffffff 0%, #e8f4f8 100%); border: 8px solid #1e3a5f;',
                                            'cert-3' => 'background: linear-gradient(135deg, #ffffff 0%, #f9f5ff 100%); border: 4px solid #d8b4fe;',
                                            'cert-4' => 'background: linear-gradient(135deg, #ffffff 0%, #fef3c7 100%); border: 6px solid #14b8a6;',
                                            'cert-5' => 'background: linear-gradient(135deg, #f5f3e8 0%, #fcf9f0 100%); border: 10px solid #1e5128;',
                                            'cert-6' => 'background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%); border: 4px solid #00d9ff;',
                                            'cert-7' => 'background: linear-gradient(135deg, #ff6b6b 0%, #feca57 50%, #fff8e7 100%); border: 5px solid #ee5a6f;',
                                            'cert-8' => 'background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: 6px solid #ffffff;',
                                        );
                                        $style = isset($preview_styles[$selected_cert]) ? $preview_styles[$selected_cert] : $preview_styles['cert-1'];
                                        ?>
                                        <div class="cert-mockup" style="<?php echo $style; ?> padding: 40px; border-radius: 8px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); position: relative;">
                                            <div style="font-family: serif; color: #334155; opacity: 0.1; font-size: 32px; font-weight: 700; text-transform: uppercase; margin-bottom: 20px;"><?php _e('Certificate', 'ts-lms'); ?></div>
                                            <div style="height: 2px; width: 60%; background: #e2e8f0; margin: 0 auto 15px; opacity: 0.5;"></div>
                                            <div style="height: 2px; width: 40%; background: #e2e8f0; margin: 0 auto; opacity: 0.5;"></div>
                                            
                                            <div style="position: absolute; bottom: 20px; right: 20px; font-size: 24px; color: #f59e0b; opacity: 0.8;">
                                                <span class="dashicons dashicons-awards"></span>
                                            </div>
                                        </div>
                                        
                                        <div style="margin-top: 30px;">
                                            <?php if ($is_completed): ?>
                                                <p style="color: #059669; font-weight: 600; margin-bottom: 5px;">
                                                    <span class="dashicons dashicons-yes-alt" style="font-size: 18px; margin-right: 5px;"></span>
                                                    <?php _e('Course Completed!', 'ts-lms'); ?>
                                                </p>
                                                <p style="color: #64748b; font-size: 14px;">
                                                    <?php _e('Congratulations! You can now download your professional certificate.', 'ts-lms'); ?>
                                                </p>
                                            <?php else: ?>
                                                <p style="color: #64748b; font-size: 14px;">
                                                    <span class="dashicons dashicons-info" style="font-size: 16px; margin-right: 5px; color: #3b82f6;"></span>
                                                    <?php _e('Complete all lessons and quizzes to earn this certificate.', 'ts-lms'); ?>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>



                    <!-- Reviews Tab -->
                    <div id="reviews" class="tab-pane">
                        <div class="ts-reviews-v2">
                            
                            <!-- Write Review Form (Only for Enrolled Students) -->
                            <?php if ($is_enrolled && is_user_logged_in()): ?>
                                
                                <?php if (isset($_GET['review_submitted']) && $_GET['review_submitted'] == '1'): ?>
                                    <div style="background: #d1fae5; padding: 20px; border-radius: 12px; margin-bottom: 30px; border: 1px solid #10b981; text-align: center;">
                                        <p style="margin: 0; color: #065f46; font-weight: 600;">
                                            <span class="dashicons dashicons-yes-alt" style="color: #10b981;"></span>
                                            <?php _e('Thank you! Your review has been submitted successfully.', 'ts-lms'); ?>
                                        </p>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="ts-write-review-section" style="background: #fff; padding: 30px; border-radius: 12px; margin-bottom: 30px; border: 1px solid #e2e8f0;">
                                    <h3 style="font-size: 20px; font-weight: 700; margin-bottom: 20px; color: #0f172a;">
                                        <?php _e('Write a Review', 'ts-lms'); ?>
                                    </h3>
                                    <form method="post" class="ts-review-form">
                                        <?php wp_nonce_field('ts_lms_submit_review_' . $course_id, 'ts_review_nonce'); ?>
                                        
                                        <div class="form-group" style="margin-bottom: 20px;">
                                            <label style="display: block; font-weight: 600; margin-bottom: 10px; color: #334155;">
                                                <?php _e('Rating', 'ts-lms'); ?> <span style="color: #ef4444;">*</span>
                                            </label>
                                            <div class="star-rating-input" style="display: flex; gap: 5px; font-size: 24px;">
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <span class="star-input dashicons dashicons-star-filled" data-rating="<?php echo $i; ?>" style="cursor: pointer; color: #cbd5e1;"></span>
                                                <?php endfor; ?>
                                            </div>
                                            <input type="hidden" name="review_rating" id="review_rating" value="" required>
                                        </div>

                                        <div class="form-group" style="margin-bottom: 20px;">
                                            <label style="display: block; font-weight: 600; margin-bottom: 10px; color: #334155;">
                                                <?php _e('Review Title', 'ts-lms'); ?> <span style="color: #ef4444;">*</span>
                                            </label>
                                            <input type="text" name="review_title" required 
                                                   style="width: 100%; padding: 12px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 16px;"
                                                   placeholder="<?php esc_attr_e('Summarize your review', 'ts-lms'); ?>">
                                        </div>

                                        <div class="form-group" style="margin-bottom: 20px;">
                                            <label style="display: block; font-weight: 600; margin-bottom: 10px; color: #334155;">
                                                <?php _e('Your Review', 'ts-lms'); ?> <span style="color: #ef4444;">*</span>
                                            </label>
                                            <textarea name="review_content" required rows="5"
                                                      style="width: 100%; padding: 12px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 16px; resize: vertical;"
                                                      placeholder="<?php esc_attr_e('Share your experience...', 'ts-lms'); ?>"></textarea>
                                        </div>

                                        <button type="submit" name="ts_submit_review" class="ts-btn ts-btn-primary" 
                                                style="padding: 12px 24px;">
                                            <?php _e('Submit Review', 'ts-lms'); ?>
                                        </button>
                                    </form>
                                </div>
                            <?php elseif (is_user_logged_in()): ?>
                                <div style="background: #fef3c7; padding: 20px; border-radius: 12px; margin-bottom: 30px; text-align: center;">
                                    <p style="margin: 0; color: #92400e; font-weight: 600;">
                                        <?php _e('You must enroll in this course to write a review.', 'ts-lms'); ?>
                                    </p>
                                </div>
                            <?php endif; ?>
                            
                            
                            <!-- Reviews List -->
                            <div class="ts-reviews-feed">
                                <?php
                                // Fetch all reviews for this course
                                $reviews = get_comments(array(
                                    'post_id' => $course_id,
                                    'type' => 'ts_course_review',
                                    'status' => 'approve',
                                    'orderby' => 'comment_date',
                                    'order' => 'DESC'
                                ));
                                
                                if ($reviews && count($reviews) > 0):
                                    foreach ($reviews as $review):
                                        $rating = get_comment_meta($review->comment_ID, 'review_rating', true);
                                        $review_title = get_comment_meta($review->comment_ID, 'review_title', true);
                                        $author_name = $review->comment_author;
                                        $date = mysql2date('F j, Y', $review->comment_date);
                                        ?>
                                        <div class="ts-review-item" style="padding: 24px; background: #fff; border-radius: 12px; margin-bottom: 20px; border: 1px solid #e2e8f0;">
                                            <div class="review-header" style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
                                                <div class="author-info">
                                                    <div class="author-avatar" style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
                                                        <?php echo get_avatar($review->user_id, 48, '', '', array('style' => 'border-radius: 50%;')); ?>
                                                        <div>
                                                            <h5 style="margin: 0; font-size: 16px; font-weight: 600; color: #0f172a;"><?php echo esc_html($author_name); ?></h5>
                                                            <span style="font-size: 13px; color: #64748b;"><?php echo esc_html($date); ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="review-rating" style="display: flex; gap: 2px;">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <span class="dashicons dashicons-star-filled" style="font-size: 18px; color: <?php echo $i <= $rating ? '#f59e0b' : '#e2e8f0'; ?>;"></span>
                                                    <?php endfor; ?>
                                                </div>
                                            </div>
                                            
                                            <?php if ($review_title): ?>
                                                <h4 style="margin: 0 0 12px 0; font-size: 18px; font-weight: 600; color: #0f172a;"><?php echo esc_html($review_title); ?></h4>
                                            <?php endif; ?>
                                            
                                            <div class="review-content" style="color: #475569; line-height: 1.6; font-size: 15px;">
                                                <?php echo wpautop(esc_html($review->comment_content)); ?>
                                            </div>
                                        </div>
                                        <?php
                                    endforeach;
                                else:
                                    ?>
                                    <p class="placeholder" style="text-align: center; color: #94a3b8; padding: 40px 20px;"><?php _e('No reviews found for this course.', 'ts-lms'); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar Column -->
            <div class="ts-sidebar-column">
                <div class="ts-sticky-card">
                    <?php if (!$is_enrolled): ?>
                    <div class="ts-card-price">
                        <span class="price"><?php echo $price_html; ?></span>
                    </div>
                    <?php endif; ?>

                    <div class="ts-card-actions">
                        <?php if($is_enrolled): ?>
                            <a href="<?php echo esc_url($enroll_url); ?>" class="ts-btn ts-btn-primary full"><?php echo $enroll_text; ?></a>
                            
                            <?php 
                                $custom_cert_id = get_post_meta($course_id, '_custom_certificate_id', true);
                                if (($selected_cert && $selected_cert !== 'none') || $custom_cert_id): 
                                    $cert_download_url = '';
                                    if ($custom_cert_id) {
                                        $cert_download_url = wp_get_attachment_url($custom_cert_id);
                                    } else {
                                        $cert_download_url = \TS_LMS\Courses\CertificateGenerator::get_certificate_url($current_user_id, $course_id);
                                    }
                                ?>
                                <a href="<?php echo esc_url($cert_download_url); ?>" class="ts-btn ts-btn-outline full" target="_blank" style="margin-top: 10px;">
                                    <span class="dashicons dashicons-awards" style="margin-right: 8px;"></span>
                                    <?php _e('Download Certificate', 'ts-lms'); ?>
                                </a>
                            <?php endif; ?>
                        <?php elseif(!is_user_logged_in()): ?>
                            <a href="<?php echo wp_login_url(get_permalink()); ?>" class="ts-btn ts-btn-primary full"><?php _e('Enroll Now', 'ts-lms'); ?></a>
                        <?php else: ?>
                            <?php 
                            // Check if course is paid or subscription
                            $button_html = '';
                            $product_id = get_post_meta( $course_id, '_course_product_id', true );

                            if ($price_type === 'paid') {
                                if ($product_id && function_exists('WC')) {
                                    $checkout_url = add_query_arg(array(
                                        'add-to-cart' => $product_id,
                                        'quantity' => 1
                                    ), wc_get_checkout_url());
                                    $button_html = '<a href="' . esc_url($checkout_url) . '" class="ts-btn ts-btn-primary full">' . __('Enroll Now', 'ts-lms') . '</a>';
                                } else {
                                    $button_html = '<button type="button" class="ts-btn ts-btn-primary full" disabled>' . __('Product Not Configured', 'ts-lms') . '</button>';
                                }
                            } elseif ($price_type === 'subscription') {
                                if ($product_id && function_exists('WC')) {
                                    $checkout_url = add_query_arg(array(
                                        'add-to-cart' => $product_id,
                                        'quantity' => 1
                                    ), wc_get_checkout_url());
                                    $button_html = '<a href="' . esc_url($checkout_url) . '" class="ts-btn ts-btn-primary full">' . __('Subscribe Now', 'ts-lms') . '</a>';
                                } else {
                                    $button_html = '<button type="button" class="ts-btn ts-btn-primary full" disabled>' . __('Subscription Product Not Configured', 'ts-lms') . '</button>';
                                }
                            } else {
                                // Free course - direct enrollment
                                ob_start();
                                ?>
                                <form method="post" class="ts-enroll-form">
                                    <?php wp_nonce_field('ts_lms_enroll_'.$course_id, 'ts_lms_enroll_nonce'); ?>
                                    <button type="submit" name="ts_lms_enroll_course" class="ts-btn ts-btn-primary full"><?php _e('Enroll Now', 'ts-lms'); ?></button>
                                </form>
                                <?php
                                $button_html = ob_get_clean();
                            }
                            echo $button_html;
                            ?>
                        <?php endif; ?>
                        
                        <?php 
                        if (!$is_enrolled && $show_feature('wishlist')): 
                            $in_wishlist = false;
                            if (is_user_logged_in() && class_exists('TS_LMS\Modules\Courses\Managers\WishlistManager')) {
                                $in_wishlist = \TS_LMS\Modules\Courses\Managers\WishlistManager::is_in_wishlist($course_id, $current_user_id);
                            }
                        ?>
                        <button class="ts-btn ts-btn-outline full ts-wishlist-btn<?php echo $in_wishlist ? ' active' : ''; ?>" 
                                data-course-id="<?php echo esc_attr($course_id); ?>"
                                title="<?php echo $in_wishlist ? esc_attr__('Remove from Wishlist', 'ts-lms') : esc_attr__('Add to Wishlist', 'ts-lms'); ?>">
                            <span class="dashicons <?php echo $in_wishlist ? 'dashicons-heart' : 'dashicons-bookmark'; ?>"></span>
                            <span class="btn-text"><?php echo $in_wishlist ? esc_html__('In Wishlist', 'ts-lms') : esc_html__('Add to Wishlist', 'ts-lms'); ?></span>
                        </button>
                        <?php endif; ?>
                    </div>

                    <div class="ts-card-features">
                        <h4><?php _e('This course includes:', 'ts-lms'); ?></h4>
                        <ul>
                            <li><span class="dashicons dashicons-clock"></span> <?php printf(__('%s hours video', 'ts-lms'), get_post_meta($course_id, '_total_duration_hours', true) ?: '10'); ?></li>
                            <li><span class="dashicons dashicons-welcome-learn-more"></span> <?php _e('Certificate of completion', 'ts-lms'); ?></li>
                            <li><span class="dashicons dashicons-admin-generic"></span> <?php _e('Full lifetime access', 'ts-lms'); ?></li>
                            <li><span class="dashicons dashicons-smartphone"></span> <?php _e('Access on mobile and TV', 'ts-lms'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Tabs
    $('.tab-link').on('click', function() {
        var tabId = $(this).data('tab');
        $('.tab-link').removeClass('active');
        $('.tab-pane').removeClass('active');
        $(this).addClass('active');
        $('#' + tabId).addClass('active');
    });

    // Accordion
    $('.accordion-trigger').on('click', function() {
        var item = $(this).parent();
        item.toggleClass('active');
        $(this).find('.dashicons').toggleClass('dashicons-arrow-down-alt2 dashicons-arrow-up-alt2');
    });

    // Description Toggle
    const $descWrapper = $('#course-description');
    const $toggleBtn = $('#ts-toggle-description');
    
    if ($descWrapper.find('.ts-description').height() > 250) {
        $descWrapper.addClass('is-collapsed');
        $toggleBtn.show();
    } else {
        $toggleBtn.hide();
    }

    $toggleBtn.on('click', function() {
        const isCollapsed = $descWrapper.hasClass('is-collapsed');
        if (isCollapsed) {
            $descWrapper.removeClass('is-collapsed').addClass('is-expanded');
            $(this).find('span:first').text('<?php _e('Show Less', 'ts-lms'); ?>');
            $(this).find('.dashicons').removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-up-alt2');
        } else {
            $descWrapper.removeClass('is-expanded').addClass('is-collapsed');
            $(this).find('span:first').text('<?php _e('Show More', 'ts-lms'); ?>');
            $(this).find('.dashicons').removeClass('dashicons-up-alt2').addClass('dashicons-arrow-down-alt2');
            
            // Smooth scroll back to top of description if needed
            $('html, body').animate({
                scrollTop: $descWrapper.offset().top - 100
            }, 300);
        }
    });

    // Star Rating Interaction
    $('.star-input').on('click', function() {
        var rating = $(this).data('rating');
        $('#review_rating').val(rating);
        
        // Update star colors
        $('.star-input').each(function() {
            if ($(this).data('rating') <= rating) {
                $(this).css('color', '#f59e0b'); // Gold color
            } else {
                $(this).css('color', '#cbd5e1'); // Gray color
            }
        });
    });

    // Star hover effect
    $('.star-input').on('mouseenter', function() {
        var rating = $(this).data('rating');
        $('.star-input').each(function() {
            if ($(this).data('rating') <= rating) {
                $(this).css('color', '#fbbf24');
            } else {
                $(this).css('color', '#cbd5e1');
            }
        });
    });

    $('.star-rating-input').on('mouseleave', function() {
        var selectedRating = $('#review_rating').val();
        $('.star-input').each(function() {
            if (selectedRating && $(this).data('rating') <= selectedRating) {
                $(this).css('color', '#f59e0b');
            } else {
                $(this).css('color', '#cbd5e1');
            }
        });
    });
});
</script>

<?php get_footer(); ?>
