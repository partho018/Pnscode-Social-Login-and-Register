<?php
/**
 * Single Bundle Template - Adapting Course Design
 *
 * @package TS_LMS
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$bundle_id = get_the_ID();
$current_user_id = get_current_user_id();

// Handle Free Enrollment Post (Adapting for bundles)
if ( isset($_POST['ts_lms_enroll_bundle']) && is_user_logged_in() ) {
    if ( wp_verify_nonce($_POST['ts_lms_enroll_nonce'], 'ts_lms_enroll_' . $bundle_id) ) {
        if ( class_exists( 'TS_LMS\Modules\Courses\Managers\BundleManager' ) ) {
            \TS_LMS\Modules\Courses\Managers\BundleManager::enroll_user_in_bundle( $bundle_id, $current_user_id );
        }
        
        wp_safe_redirect(get_permalink());
        exit;
    }
}

get_header();

// Bundle Metadata
$price_type = get_post_meta( $bundle_id, '_bundle_price_type', true );
$product_id = get_post_meta( $bundle_id, '_bundle_product_id', true );
$price      = get_post_meta( $bundle_id, '_bundle_price', true );

// Get included courses
global $wpdb;
$table = $wpdb->prefix . 'ts_bundle_courses';
$course_ids = $wpdb->get_col( $wpdb->prepare( "SELECT course_id FROM {$table} WHERE bundle_id = %d ORDER BY order_index ASC", $bundle_id ) );

// User and Enrollment status (Check if enrolled in all courses or use a bundle enrollment check)
$is_enrolled = true;
if ( empty($course_ids) ) {
    $is_enrolled = false;
} else {
    foreach ( $course_ids as $c_id ) {
        if ( ! TS_LMS\Modules\Courses\Managers\CourseManager::is_enrolled( $c_id, $current_user_id ) ) {
            $is_enrolled = false;
            break;
        }
    }
}

if ( current_user_can( 'manage_options' ) || get_post_field( 'post_author', $bundle_id ) == $current_user_id ) {
    $is_enrolled = true;
}

// Pricing Logic
$price_html = __('Free', 'ts-lms');
if ($price_type === 'paid') {
    if ($product_id && function_exists('wc_get_product')) {
        $product = wc_get_product($product_id);
        if ($product) $price_html = $product->get_price_html();
    }
} elseif ($price_type === 'subscription') {
    $sub_price = get_post_meta( $bundle_id, '_bundle_subscription_price', true );
    $sub_plan = get_post_meta( $bundle_id, '_bundle_subscription_plan', true );
    $price_html = sprintf('%s/%s', $sub_price ?: '0', ucfirst($sub_plan ?: 'monthly'));
}

$enroll_text = $is_enrolled ? __('Start Learning', 'ts-lms') : __('Enroll Now', 'ts-lms');
$enroll_url = '#'; // Bundle doesn't have a single "first link" like a course, maybe link to first course?
if ( $is_enrolled && !empty($course_ids) ) {
    $enroll_url = get_permalink($course_ids[0]);
}

?>

<div class="ts-lms-single-course-v2 ts-lms-single-bundle">
    <!-- Hero Section -->
    <div class="ts-course-hero">
        <div class="container">
            <div class="ts-hero-grid">
                <div class="ts-hero-content">
                    <nav class="ts-breadcrumb">
                        <a href="<?php echo home_url(); ?>"><?php _e('Home', 'ts-lms'); ?></a>
                        <span class="sep">/</span>
                        <a href="<?php echo home_url('/courses'); ?>"><?php _e('Courses', 'ts-lms'); ?></a>
                        <span class="sep">/</span>
                        <span class="current"><?php the_title(); ?></span>
                    </nav>

                    <h1 class="ts-title"><?php the_title(); ?></h1>
                    
                    <div class="ts-meta-badges">
                        <span class="badge bundle" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);"><?php _e('Bundle', 'ts-lms'); ?></span>
                        <span class="badge count"><?php printf(__('%d Courses Included', 'ts-lms'), count($course_ids)); ?></span>
                    </div>

                    <div class="ts-instructor-brief">
                        <?php $author_id = get_post_field('post_author', $bundle_id); ?>
                        <div class="avatar"><?php echo get_avatar($author_id, 40); ?></div>
                        <div class="info">
                            <span class="label"><?php _e('Created by:', 'ts-lms'); ?></span>
                            <span class="name"><?php echo get_the_author_meta('display_name', $author_id); ?></span>
                        </div>
                        <div class="last-updated">
                            <span class="dashicons dashicons-calendar-alt"></span>
                            <?php printf(__('Updated %s', 'ts-lms'), get_the_modified_date()); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="ts-course-layout-v2">
            <!-- Main Content Area -->
            <div class="ts-main-column">
                
                <!-- Video/Thumbnail Wrapper -->
                <div class="ts-video-wrapper">
                    <?php 
                    $poster = get_the_post_thumbnail_url($bundle_id, 'full');
                    if ($poster): ?>
                        <img src="<?php echo esc_url($poster); ?>" alt="<?php the_title(); ?>" class="ts-main-poster">
                    <?php else: ?>
                        <div class="ts-course-placeholder" style="height: 400px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display:flex; align-items:center; justify-content:center; color:white; font-size:48px; border-radius:12px;">
                            <span class="dashicons dashicons-portfolio" style="font-size: 80px; width: 80px; height: 80px;"></span>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Tabs Navigation -->
                <div class="ts-tabs-nav">
                    <button class="tab-link active" data-tab="overview"><?php _e('Overview', 'ts-lms'); ?></button>
                </div>

                <div class="ts-tabs-content">
                    <!-- Overview Tab -->
                    <div id="overview" class="tab-pane active">
                        <!-- About this bundle section -->
                        <div class="ts-content-block">
                            <h3 class="ts-section-title">
                                <span class="dashicons dashicons-text-page"></span>
                                <?php _e('About this bundle', 'ts-lms'); ?>
                            </h3>
                            <div class="ts-description">
                                <?php the_content(); ?>
                            </div>
                        </div>

                        <!-- Courses Included section -->
                        <div class="ts-content-block">
                            <div class="ts-curriculum-header">
                                <h3><?php _e('Courses Included in this Bundle', 'ts-lms'); ?></h3>
                                <span class="stats"><?php printf(__('%d Courses', 'ts-lms'), count($course_ids)); ?></span>
                            </div>
                            <div class="ts-bundle-courses-list">
                                <?php 
                                if (!empty($course_ids)) :
                                    foreach($course_ids as $c_id): 
                                        $course = get_post($c_id);
                                        if (!$course) continue;
                                        $c_is_enrolled = TS_LMS\Modules\Courses\Managers\CourseManager::is_enrolled($c_id, $current_user_id);
                                ?>
                                    <div class="ts-bundle-course-item" style="display: flex; align-items: center; justify-content: space-between; padding: 20px; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; margin-bottom: 15px; transition: all 0.3s ease;">
                                        <div class="course-info" style="display: flex; align-items: center; gap: 15px;">
                                            <div class="course-thumb" style="width: 80px; height: 50px; border-radius: 6px; overflow: hidden;">
                                                <?php if (has_post_thumbnail($c_id)): ?>
                                                    <?php echo get_the_post_thumbnail($c_id, 'thumbnail', array('style' => 'width:100%; height:100%; object-fit:cover;')); ?>
                                                <?php else: ?>
                                                    <div style="width:100%; height:100%; background:#f1f5f9; display:flex; align-items:center; justify-content:center;">
                                                        <span class="dashicons dashicons-book" style="color:#94a3b8;"></span>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <div>
                                                <h4 style="margin: 0; font-size: 16px; font-weight: 600;"><?php echo esc_html($course->post_title); ?></h4>
                                                <span style="font-size: 13px; color: #64748b;"><?php _e('Instructor:', 'ts-lms'); ?> <?php echo get_the_author_meta('display_name', $course->post_author); ?></span>
                                            </div>
                                        </div>
                                        <div class="course-action">
                                            <?php if ($is_enrolled || $c_is_enrolled): ?>
                                                <a href="<?php echo get_permalink($c_id); ?>" class="ts-btn ts-btn-primary" style="padding: 8px 16px; font-size: 13px;"><?php _e('View Course', 'ts-lms'); ?></a>
                                            <?php else: ?>
                                                <span class="dashicons dashicons-lock" style="color: #94a3b8;"></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php 
                                    endforeach;
                                else:
                                ?>
                                    <p class="ts-no-content"><?php _e('No courses added to this bundle yet.', 'ts-lms'); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar Column -->
            <div class="ts-sidebar-column">
                <div class="ts-sticky-card">
                    <?php if (!$is_enrolled): ?>
                    <div class="ts-card-price">
                        <span class="price"><?php echo $price_html; ?></span>
                    </div>
                    <?php endif; ?>

                    <div class="ts-card-actions">
                        <?php if($is_enrolled): ?>
                            <a href="<?php echo esc_url($enroll_url); ?>" class="ts-btn ts-btn-primary full"><?php echo $enroll_text; ?></a>
                        <?php elseif(!is_user_logged_in()): ?>
                            <a href="<?php echo wp_login_url(get_permalink()); ?>" class="ts-btn ts-btn-primary full"><?php _e('Enroll Now', 'ts-lms'); ?></a>
                        <?php else: ?>
                            <?php 
                            if ($price_type === 'paid' || $price_type === 'subscription') {
                                if ($price_type === 'paid' && $product_id && function_exists('WC')) {
                                    $checkout_url = add_query_arg(array(
                                        'add-to-cart' => $product_id,
                                        'quantity' => 1
                                    ), wc_get_checkout_url());
                                    ?>
                                    <a href="<?php echo esc_url($checkout_url); ?>" class="ts-btn ts-btn-primary full"><?php _e('Enroll Now', 'ts-lms'); ?></a>
                                <?php } elseif ($price_type === 'subscription') { ?>
                                    <a href="<?php echo esc_url(wc_get_checkout_url()); ?>" class="ts-btn ts-btn-primary full"><?php _e('Subscribe Now', 'ts-lms'); ?></a>
                                <?php } else { ?>
                                    <button type="button" class="ts-btn ts-btn-primary full" disabled><?php _e('Product Not Configured', 'ts-lms'); ?></button>
                                <?php } ?>
                            <?php } else { ?>
                                <form method="post" class="ts-enroll-form">
                                    <?php wp_nonce_field('ts_lms_enroll_'.$bundle_id, 'ts_lms_enroll_nonce'); ?>
                                    <button type="submit" name="ts_lms_enroll_bundle" class="ts-btn ts-btn-primary full"><?php _e('Enroll Now', 'ts-lms'); ?></button>
                                </form>
                            <?php } ?>
                        <?php endif; ?>
                    </div>

                    <div class="ts-card-features">
                        <h4><?php _e('This bundle includes:', 'ts-lms'); ?></h4>
                        <ul>
                            <li><span class="dashicons dashicons-welcome-learn-more"></span> <?php printf(__('%d complete courses', 'ts-lms'), count($course_ids)); ?></li>
                            <li><span class="dashicons dashicons-admin-generic"></span> <?php _e('Full lifetime access', 'ts-lms'); ?></li>
                            <li><span class="dashicons dashicons-smartphone"></span> <?php _e('Access on mobile and TV', 'ts-lms'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
