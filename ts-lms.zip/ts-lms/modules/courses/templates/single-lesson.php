<?php
/**
 * Single Lesson Template (Course Player)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$lesson_id = get_the_ID();
// Retrieve Course ID (Meta or Hierarchy Fallback)
$course_id = get_post_meta( $lesson_id, '_lesson_course_id', true );

if ( ! $course_id ) {
    // Fallback: Check hierarchy (Lesson -> Topic -> Course)
    $parent_id = wp_get_post_parent_id( $lesson_id ); // Topic
    if ( $parent_id ) {
        $grandparent_id = wp_get_post_parent_id( $parent_id ); // Course
        if ( $grandparent_id && get_post_type($grandparent_id) === 'ts_course' ) {
            $course_id = $grandparent_id;
            // Repair the meta for future performance
            update_post_meta( $lesson_id, '_lesson_course_id', $course_id );
        }
    }
}

// Redirect if no course associated
if ( ! $course_id ) {
    wp_redirect( home_url() );
    exit;
}

// User Access Check
$current_user_id = get_current_user_id();

// Check if lesson preview is enabled - allow access to everyone
$is_preview = get_post_meta( $lesson_id, '_lesson_preview', true );
$can_view = false;

if ( $is_preview ) {
    // Preview lessons are accessible to everyone
    $can_view = true;
} else {
    // Regular access checks for non-preview lessons
    $is_enrolled = TS_LMS\Modules\Courses\Managers\CourseManager::is_enrolled( $course_id, $current_user_id );
    
    // Check Course Content Access setting
    $course_content_access = \TS_LMS\Admin\Settings::get_setting('course_content_access');
    
    // Allow access if enrolled, admin, or course author
    $can_view = $is_enrolled || current_user_can( 'manage_options' ) || get_post_field( 'post_author', $course_id ) == $current_user_id;
    
    // If Course Content Access is enabled, allow instructors and admins without enrollment
    if ( $course_content_access && !$can_view ) {
        $is_instructor = get_post_field( 'post_author', $course_id ) == $current_user_id;
        $is_admin = current_user_can( 'manage_options' );
        if ( $is_instructor || $is_admin ) {
            $can_view = true;
        }
    }
}

// If explicitly using "Private" or "Draft" status logic for non-authors, it's handled by WP, but enrollment is custom.
// If not enrolled/allowed, redirect to course page
if ( ! $can_view ) {
    wp_redirect( get_permalink( $course_id ) );
    exit;
}

// Fetch Data
$course_title = get_the_title( $course_id );
$lesson_title = get_the_title( $lesson_id );
$lesson_content = get_post_field( 'post_content', $lesson_id );

// Video Data
$video_url = get_post_meta( $lesson_id, '_lesson_video_url', true );
$video_type = get_post_meta( $lesson_id, '_lesson_video_type', true );

// Curriculum for Sidebar
$topics = get_posts( array(
    'post_type'      => 'ts_topic',
    'posts_per_page' => -1,
    'post_parent'    => $course_id,
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'post_status'    => 'publish' // Topics are usually publish
) );

// Helper to format time
function ts_format_duration($seconds) {
    if (!$seconds) return '00:00';
    $h = floor($seconds / 3600);
    $m = floor(($seconds % 3600) / 60);
    $s = $seconds % 60;
    return $h > 0 ? sprintf('%02d:%02d:%02d', $h, $m, $s) : sprintf('%02d:%02d', $m, $s);
}

// Get Progress
global $wpdb;
$progress_table = $wpdb->prefix . 'ts_lesson_progress';
$completed_lessons = $wpdb->get_var( $wpdb->prepare(
    "SELECT COUNT(*) FROM {$progress_table} WHERE course_id = %d AND user_id = %d AND status = 'completed'",
    $course_id,
    $current_user_id
) ) ?: 0;

$total_lessons = 0;
foreach ($topics as $t) {
    $children = get_posts(array(
        'post_type' => array('ts_lesson', 'ts_quiz', 'ts_assignment'),
        'post_parent' => $t->ID,
        'posts_per_page' => -1,
        'post_status' => 'publish'
    ));
    $total_lessons += count($children);
}

$progress_percent = $total_lessons > 0 ? round(($completed_lessons / $total_lessons) * 100) : 0;

// Flatten curriculum for navigation
$all_items = array();
foreach ( $topics as $topic ) {
    $topic_items = get_posts( array(
        'post_type'      => array( 'ts_lesson', 'ts_quiz', 'ts_assignment' ),
        'posts_per_page' => -1,
        'post_parent'    => $topic->ID,
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        'post_status'    => array( 'publish', 'draft', 'private', 'pending' )
    ) );
    $all_items = array_merge( $all_items, $topic_items );
}

$current_index = -1;
foreach ( $all_items as $index => $item ) {
    if ( $item->ID == $lesson_id ) {
        $current_index = $index;
        break;
    }
}

$prev_link = ($current_index > 0) ? get_permalink($all_items[$current_index - 1]->ID) : '#';
$next_link = ($current_index < count($all_items) - 1) ? get_permalink($all_items[$current_index + 1]->ID) : '#';
$has_prev = ($current_index > 0);
$has_next = ($current_index < count($all_items) - 1);

?>
<?php 
// Check Spotlight Mode setting
$spotlight_mode = \TS_LMS\Admin\Settings::get_setting('spotlight_mode');
if ( !$spotlight_mode ) {
    get_header(); 
}
?>
    <style>
        /* Reset overrides for standalone player */
        .ts-course-player-wrapper { margin: 0; padding: 0; height: calc(100vh - 100px); /* Approx height if header present */ display: flex; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif; overflow: hidden; }
        .ts-video-wrapper .plyr { height: 100%; width: 100%; }
        .ts-video-wrapper { background: #000; display: flex; align-items: center; justify-content: center; position: relative; }
        
        /* Preview Mode Notice */
        .ts-preview-notice {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #4CAF50;
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
        }
        .ts-preview-notice .dashicons {
            font-size: 18px;
            width: 18px;
            height: 18px;
        }
    </style>
    <link rel="stylesheet" href="https://cdn.plyr.io/3.7.8/plyr.css" />
<div class="ts-course-player-wrapper">

    <!-- Header -->


    <!-- Main Layout -->
    <div class="ts-player-container">
        
        <!-- Sidebar -->
        <aside class="ts-player-sidebar">
            <div class="ts-sidebar-header">
                <h3>Course Content</h3>
            </div>
            <div class="ts-sidebar-content">
                <?php foreach ( $topics as $topic ) : 
                     $items = get_posts( array(
                        'post_type'      => array( 'ts_lesson', 'ts_quiz', 'ts_assignment' ),
                        'posts_per_page' => -1,
                        'post_parent'    => $topic->ID,
                        'orderby'        => 'menu_order',
                        'order'          => 'ASC',
                        'post_status'    => array( 'publish', 'draft', 'private', 'pending' )
                    ) );
                    
                    $topic_completed = 0;
                    foreach($items as $item) {
                        $p = TS_LMS\Modules\Courses\Managers\LessonManager::get_progress($item->ID, $current_user_id);
                        if ($p && $p['status'] === 'completed') $topic_completed++;
                    }
                    $topic_progress = $topic_completed . "/" . count($items);
                ?>
                <div class="ts-player-topic">
                    <div class="ts-player-topic-header">
                        <span class="ts-topic-title"><?php echo esc_html($topic->post_title); ?></span>
                        <span class="ts-topic-meta"><?php echo $topic_progress; ?> <span class="dashicons dashicons-arrow-down-alt2"></span></span>
                    </div>
                    <ul class="ts-player-lessons">
                        <?php foreach ( $items as $item ) : 
                            $type = str_replace('ts_', '', $item->post_type);
                            $duration = (int) get_post_meta( $item->ID, '_lesson_duration', true );
                            $active = ($item->ID == $lesson_id) ? 'active' : '';
                            
                            // Completion Status
                            $is_completed = false;
                            $progress_data = TS_LMS\Modules\Courses\Managers\LessonManager::get_progress( $item->ID, $current_user_id );
                            if ( $progress_data && $progress_data['status'] === 'completed' ) {
                                $is_completed = true;
                            }

                            $icon = 'dashicons-media-document';
                            if ($type == 'lesson') {
                                $lesson_type = get_post_meta( $item->ID, '_lesson_type', true );
                                if ($lesson_type === 'zoom') $icon = 'dashicons-video-alt2';
                                elseif ($lesson_type === 'meet') $icon = 'dashicons-video-alt3';
                                else $icon = 'dashicons-video-alt3';
                            }
                            if ($type == 'quiz') $icon = 'dashicons-forms';
                            if ($type == 'assignment') $icon = 'dashicons-clipboard';
                        ?>
                        <li class="ts-player-lesson-item <?php echo $active; ?> <?php echo $is_completed ? 'completed' : ''; ?>" data-id="<?php echo $item->ID; ?>">
                            <a href="<?php echo get_permalink($item->ID); ?>" class="ts-lesson-link">
                                <div class="ts-lesson-link-left">
                                    <span class="ts-lesson-status-icon dashicons <?php echo $icon; ?>"></span>
                                    <span class="ts-lesson-name"><?php echo esc_html($item->post_title); ?></span>
                                </div>
                                <div class="ts-lesson-link-right">
                                    <?php if ($type == 'lesson' && $duration > 0): ?>
                                        <span class="ts-lesson-time"><?php echo ts_format_duration($duration); ?></span>
                                    <?php endif; ?>
                                    <span class="ts-lesson-check">
                                        <span class="dashicons dashicons-yes"></span>
                                    </span>
                                </div>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endforeach; ?>
            </div>


        </aside>

        <!-- Content Area -->
        <main class="ts-player-content">
            
            <header class="ts-player-header">
                <div class="ts-header-left">
                    <a href="<?php echo get_permalink($course_id); ?>" class="ts-back-btn" title="<?php esc_attr_e('Back to Course', 'ts-lms'); ?>">
                        <span class="dashicons dashicons-arrow-left-alt2"></span>
                    </a>
                    <div class="ts-titles-wrapper">
                        <span class="ts-course-name-small"><?php echo esc_html($course_title); ?></span>
                        <h1 class="ts-lesson-main-title"><?php echo esc_html($lesson_title); ?></h1>
                    </div>
                </div>
                <div class="ts-header-right">
                    <?php if ( $current_user_id > 0 ) : // Only show progress for logged-in users ?>
                    <?php 
                    $is_lesson_completed = false;
                    $lesson_progress = TS_LMS\Modules\Courses\Managers\LessonManager::get_progress($lesson_id, $current_user_id);
                    if ($lesson_progress && $lesson_progress['status'] === 'completed') {
                        $is_lesson_completed = true;
                    }
                    ?>
                    <div class="ts-progress-info">
                        <?php _e('Your Progress:', 'ts-lms'); ?> <strong><?php echo $completed_lessons; ?> <?php _e('of', 'ts-lms'); ?> <?php echo $total_lessons; ?></strong> (<?php echo $progress_percent; ?>%)
                    </div>
                    <button class="ts-btn-complete <?php echo $is_lesson_completed ? 'completed' : ''; ?>">
                        <span class="dashicons dashicons-yes"></span> <?php echo $is_lesson_completed ? __('Completed', 'ts-lms') : __('Mark as Complete', 'ts-lms'); ?>
                    </button>
                    <?php else : // For preview viewers, show enrollment prompt ?>
                    <div class="ts-preview-notice">
                        <span class="dashicons dashicons-visibility"></span>
                        <?php _e('Preview Mode', 'ts-lms'); ?>
                    </div>
                    <?php endif; ?>
                    <a href="<?php echo get_permalink($course_id); ?>" class="ts-close-btn" title="<?php esc_attr_e('Close Player', 'ts-lms'); ?>">&times;</a>
                </div>
            </header>

            <div class="ts-video-wrapper">
                <?php 
                $lesson_type = get_post_meta( $lesson_id, '_lesson_type', true );
                if ( $lesson_type === 'meet' || $lesson_type === 'zoom' ) : 
                    $start_date = get_post_meta( $lesson_id, '_start_date', true );
                    $start_time = get_post_meta( $lesson_id, '_start_time', true );
                    $timezone = get_post_meta( $lesson_id, '_timezone', true );
                    $join_url = '';
                    
                    if ( $lesson_type === 'zoom' ) {
                        $join_url = get_post_meta( $lesson_id, '_zoom_join_url', true );
                    } else {
                        // For Google Meet, we'll need to fetch the hangoutLink from meta if saved
                        $join_url = get_post_meta( $lesson_id, '_google_meet_link', true );
                    }
                ?>
                    <div class="ts-live-meeting-box">
                        <div class="ts-live-meeting-icon <?php echo $lesson_type; ?>">
                            <span class="dashicons dashicons-video-alt2"></span>
                        </div>
                        <h2><?php echo ($lesson_type === 'zoom') ? 'Zoom Live Class' : 'Google Meet Live Class'; ?></h2>
                        <div class="ts-live-meeting-details">
                            <p><strong><span class="dashicons dashicons-calendar-alt"></span> Date:</strong> <?php echo esc_html($start_date); ?></p>
                            <p><strong><span class="dashicons dashicons-clock"></span> Time:</strong> <?php echo esc_html($start_time); ?> (<?php echo esc_html($timezone); ?>)</p>
                        </div>
                        <?php if ( $join_url ) : ?>
                            <a href="<?php echo esc_url($join_url); ?>" target="_blank" class="ts-btn-join-meeting">
                                <?php esc_html_e( 'Join Meeting Now', 'ts-lms' ); ?>
                            </a>
                        <?php else : ?>
                            <div class="ts-meeting-alert warning">
                                <?php esc_html_e( 'Meeting link is not available yet. Please check back later.', 'ts-lms' ); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php elseif ( $video_url ) : ?>
                    <?php 
                        // Get Featured Image for video poster/thumbnail
                        $featured_image_url = '';
                        if ( has_post_thumbnail( $lesson_id ) ) {
                            $featured_image_url = get_the_post_thumbnail_url( $lesson_id, 'full' );
                        }
                        
                        // Logic to determine video type & ID
                        $youtube_id = '';
                        $is_youtube = false;

                        if ( $video_type == 'youtube' ) {
                            $is_youtube = true;
                            // Check if it's already an ID (no spaces, length ~11)
                            if ( preg_match('/^[a-zA-Z0-9_-]{11}$/', $video_url ) ) {
                                $youtube_id = $video_url;
                            } else {
                                // Extract from URL
                                preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i', $video_url, $matches);
                                if (isset($matches[1])) {
                                    $youtube_id = $matches[1];
                                }
                            }
                        } elseif (strpos($video_url, 'youtube') !== false || strpos($video_url, 'youtu.be') !== false) {
                            // Automatically detect URL type if not explicitly set
                            $is_youtube = true;
                            preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i', $video_url, $matches);
                            if (isset($matches[1])) {
                                $youtube_id = $matches[1];
                            }
                        }

                        if ( $is_youtube && $youtube_id ) : 
                    ?>
                        <!-- Plyr YouTube Embed -->
                        <div id="player" data-plyr-provider="youtube" data-plyr-embed-id="<?php echo esc_attr($youtube_id); ?>" <?php if ( $featured_image_url ) : ?>data-poster="<?php echo esc_url($featured_image_url); ?>"<?php endif; ?>></div>
                    <?php else: ?>
                        <!-- Plyr HTML5 Video -->
                         <video id="player" playsinline controls <?php if ( $featured_image_url ) : ?>poster="<?php echo esc_url($featured_image_url); ?>"<?php endif; ?>>
                            <source src="<?php echo esc_url($video_url); ?>" type="video/mp4" />
                        </video>
                    <?php endif; ?>
                    
                    <?php 
                    // Video Watermark
                    $watermark_enabled = \TS_LMS\Admin\Settings::get_setting('video_watermark_enabled');
                    $watermark_image = \TS_LMS\Admin\Settings::get_setting('video_watermark_image');
                    
                    if ( $watermark_enabled && $watermark_image ) :
                        $watermark_size = \TS_LMS\Admin\Settings::get_setting('video_watermark_size', 'small');
                        $watermark_position = \TS_LMS\Admin\Settings::get_setting('video_watermark_position', 'bottom-right');
                        $watermark_movement = \TS_LMS\Admin\Settings::get_setting('video_watermark_movement', 'static');
                        $watermark_opacity = \TS_LMS\Admin\Settings::get_setting('video_watermark_opacity', 70);
                    ?>
                        <div class="ts-video-watermark" 
                             data-size="<?php echo esc_attr($watermark_size); ?>" 
                             data-position="<?php echo esc_attr($watermark_position); ?>" 
                             data-movement="<?php echo esc_attr($watermark_movement); ?>"
                             data-opacity="<?php echo esc_attr($watermark_opacity); ?>">
                            <img src="<?php echo esc_url($watermark_image); ?>" alt="Watermark">
                        </div>
                    <?php endif; ?>
                <?php else : ?>
                    <div class="ts-no-video">
                        <p>No video content for this lesson.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Navigation Buttons -->
            <div class="ts-lesson-nav">
                <?php if ($has_prev): ?>
                    <a href="<?php echo esc_url($prev_link); ?>" class="ts-nav-btn">
                        <span class="dashicons dashicons-arrow-left-alt2"></span> Previous
                    </a>
                <?php else: ?>
                    <span class="ts-nav-btn disabled">
                        <span class="dashicons dashicons-arrow-left-alt2"></span> Previous
                    </span>
                <?php endif; ?>

                <?php if ($has_next): ?>
                    <a href="<?php echo esc_url($next_link); ?>" class="ts-nav-btn">
                         Next <span class="dashicons dashicons-arrow-right-alt2"></span>
                    </a>
                <?php else: ?>
                    <span class="ts-nav-btn disabled">
                         Next <span class="dashicons dashicons-arrow-right-alt2"></span>
                    </span>
                <?php endif; ?>
            </div>

            <?php if ( ! empty( trim($lesson_content) ) ) : ?>
            <div class="ts-lesson-text-content">
                <?php echo do_shortcode(wp_kses_post($lesson_content)); ?>
            </div>
            <?php endif; ?>
            
            <?php 
            // Enable Lesson Comment setting
            $lesson_comment = \TS_LMS\Admin\Settings::get_setting('lesson_comment');
            if ( $lesson_comment && $current_user_id > 0 ) : 
            ?>
            <div class="ts-lesson-comments-section" style="margin-top: 2rem; padding: 1.5rem; background: #f9f9f9; border-radius: 8px;">
                <h3 style="margin-bottom: 1rem;"><?php _e('Lesson Comments', 'ts-lms'); ?></h3>
                <?php 
                // Enable comments for this lesson
                comments_template(); 
                ?>
            </div>
            <?php endif; ?>

        </main>
    </div>

    <?php // wp_footer call removed as get_footer() handles it ?>
    <script src="https://cdn.plyr.io/3.7.8/plyr.js"></script>
    <script>
        // Initialize Plyr
        const playerElement = document.querySelector('#player');
        const posterUrl = playerElement ? playerElement.getAttribute('data-poster') : null;
        
        const player = new Plyr('#player', {
            controls: ['play-large', 'play', 'progress', 'current-time', 'mute', 'volume', 'captions', 'settings', 'pip', 'airplay', 'fullscreen'],
            hideControls: true,
            youtube: {
                noCookie: false,
                rel: 0,
                showinfo: 0,
                iv_load_policy: 3,
                modestbranding: 1
            }
        });

        // Set poster for YouTube videos (Plyr doesn't natively support poster for YouTube)
        if (posterUrl && playerElement.getAttribute('data-plyr-provider') === 'youtube') {
            player.on('ready', () => {
                const wrapper = playerElement.closest('.ts-video-wrapper');
                if (wrapper && !player.playing) {
                    // Create custom poster overlay for YouTube
                    const posterOverlay = document.createElement('div');
                    posterOverlay.className = 'ts-custom-poster';
                    posterOverlay.style.cssText = `
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background-image: url('${posterUrl}');
                        background-size: cover;
                        background-position: center;
                        cursor: pointer;
                        z-index: 10;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    `;
                    
                    // Add play button overlay
                    const playBtn = document.createElement('div');
                    playBtn.innerHTML = '<svg style="width: 80px; height: 80px; opacity: 0.9;" viewBox="0 0 24 24"><path fill="#fff" d="M8,5.14V19.14L19,12.14L8,5.14Z" /></svg>';
                    playBtn.style.cssText = `
                        background: rgba(0,0,0,0.6);
                        border-radius: 50%;
                        width: 100px;
                        height: 100px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        transition: transform 0.2s;
                    `;
                    playBtn.onmouseenter = () => playBtn.style.transform = 'scale(1.1)';
                    playBtn.onmouseleave = () => playBtn.style.transform = 'scale(1)';
                    
                    posterOverlay.appendChild(playBtn);
                    wrapper.style.position = 'relative';
                    wrapper.appendChild(posterOverlay);
                    
                    // Remove poster when play starts
                    posterOverlay.addEventListener('click', () => {
                        player.play();
                        posterOverlay.remove();
                    });
                    
                    player.on('play', () => {
                        if (posterOverlay.parentNode) {
                            posterOverlay.remove();
                        }
                    });
                }
            });
        }


        // Simple Sidebar Toggle
        document.querySelectorAll('.ts-player-topic-header').forEach(header => {
            header.addEventListener('click', () => {
                header.parentElement.classList.toggle('open');
            });
        });
        // Open active topic by default
        document.querySelector('.ts-player-lesson-item.active')?.closest('.ts-player-topic').classList.add('open');

        // Mark as Complete
        jQuery(document).ready(function($) {
            
            function markLessonComplete() {
                var btn = $('.ts-btn-complete');
                if (btn.hasClass('completed')) return;

                btn.text('Marking...').prop('disabled', true);

                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'ts_lms_complete_lesson',
                        lesson_id: <?php echo $lesson_id; ?>
                    },
                    success: function(r) {
                        if (r.success) {
                            btn.html('<span class="dashicons dashicons-yes"></span> Completed').addClass('completed');
                            // Update sidebar circle
                            $('.ts-player-lesson-item.active').addClass('completed');
                            
                            // Auto Load Next Content
                            <?php 
                            $auto_load_next = \TS_LMS\Admin\Settings::get_setting('auto_load_next');
                            if ( $auto_load_next && $has_next ) : 
                            ?>
                            setTimeout(function() {
                                window.location.href = '<?php echo esc_js($next_link); ?>';
                            }, 2000);
                            <?php endif; ?>
                        } else {
                            alert(r.data.message || 'Error');
                            btn.text('Mark as Complete').prop('disabled', false);
                        }
                    }
                });
            }

            $('.ts-btn-complete').on('click', function() {
                markLessonComplete();
            });

            // Auto-complete on video end (HTML5)
            var video = document.querySelector('video');
            if (video) {
                video.addEventListener('ended', function() {
                    markLessonComplete();
                });
            }
        });
    </script>
    
    <?php 
    // Screen Recording Protection
    $prevent_recording = \TS_LMS\Admin\Settings::get_setting('prevent_video_recording');
    if ( $prevent_recording ) : 
    ?>
    <style>
        /* Disable Text Selection */
        body, .ts-course-player-wrapper {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
        
        /* Hide content on print */
        @media print {
            html, body {
                display: none !important;
            }
        }

        /* Screen Recording Protection Overlay */
        .ts-recording-protection-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #000;
            z-index: 999999;
            display: none;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            padding: 20px;
        }
        
        .ts-recording-protection-overlay.active {
            display: flex;
        }
        
        /* Video blackout when recording detected */
        .ts-video-wrapper.recording-detected video,
        .ts-video-wrapper.recording-detected iframe,
        .ts-video-wrapper.recording-detected .plyr {
            filter: brightness(0) !important;
            opacity: 0 !important;
        }
    </style>
    <script>
        (function() {
            // Disable Right Click
            document.addEventListener('contextmenu', function(e) {
                e.preventDefault();
            });

            // Disable Keyboard Shortcuts
            document.addEventListener('keydown', function(e) {
                // F12
                if (e.keyCode == 123) {
                    e.preventDefault();
                    return false;
                }
                
                // Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+Shift+C
                if (e.ctrlKey && e.shiftKey && (e.keyCode == 73 || e.keyCode == 74 || e.keyCode == 67)) {
                    e.preventDefault();
                    return false;
                }
                
                // Ctrl+U (View Source)
                if (e.ctrlKey && e.keyCode == 85) {
                    e.preventDefault();
                    return false;
                }

                // Ctrl+S (Save)
                if (e.ctrlKey && e.keyCode == 83) {
                    e.preventDefault();
                    return false;
                }

                 // Ctrl+P (Print)
                 if (e.ctrlKey && e.keyCode == 80) {
                    e.preventDefault();
                    return false;
                }
            });

            // Clear Clipboard on PrintScreen (Best Effort - browser support varies)
            document.addEventListener('keyup', function(e) {
                if (e.keyCode == 44) { // PrintScreen
                    navigator.clipboard.writeText('');
                }
            });
            
            // Advanced Screen Recording Detection
            const videoWrapper = document.querySelector('.ts-video-wrapper');
            let protectionOverlay = null;
            
            // Create protection overlay
            function createProtectionOverlay() {
                if (!protectionOverlay) {
                    protectionOverlay = document.createElement('div');
                    protectionOverlay.className = 'ts-recording-protection-overlay';
                    protectionOverlay.innerHTML = '<div><p>⚠️ Screen Recording Detected</p><p style="font-size: 16px; margin-top: 10px;">Video playback has been paused for security reasons.</p></div>';
                    document.body.appendChild(protectionOverlay);
                }
            }
            
            // Activate protection
            function activateProtection() {
                document.body.classList.add('ts-critical-blackout');
                if (videoWrapper) {
                    videoWrapper.classList.add('recording-detected');
                }
                
                const fullscreenElement = document.fullscreenElement || 
                                         document.webkitFullscreenElement || 
                                         document.mozFullScreenElement || 
                                         document.msFullscreenElement;
                
                if (protectionOverlay) {
                    if (fullscreenElement && !fullscreenElement.contains(protectionOverlay)) {
                        fullscreenElement.appendChild(protectionOverlay);
                    } else if (!fullscreenElement && !document.body.contains(protectionOverlay)) {
                        document.body.appendChild(protectionOverlay);
                    }
                    protectionOverlay.classList.add('active');
                    protectionOverlay.style.display = 'flex';
                    protectionOverlay.style.setProperty('display', 'flex', 'important');
                }
                
                const video = document.querySelector('video');
                if (video && !video.paused) {
                    video.pause();
                }
            }
            
            // Deactivate protection
            function deactivateProtection() {
                document.body.classList.remove('ts-critical-blackout');
                if (videoWrapper) {
                    videoWrapper.classList.remove('recording-detected');
                }
                if (protectionOverlay) {
                    protectionOverlay.classList.remove('active');
                    protectionOverlay.style.display = 'none';
                    if (!document.body.contains(protectionOverlay)) {
                        document.body.appendChild(protectionOverlay);
                    }
                }
            }

            // Method A: Viewport Monitoring (detects "Sharing Screen" Bar)
            let initialHeight = window.innerHeight;
            window.addEventListener('resize', function() {
                // If height drops significantly, it might be the sharing bar or developer tools
                if (window.innerHeight < initialHeight - 50) {
                    activateProtection();
                } else if (window.innerHeight >= initialHeight) {
                    deactivateProtection();
                }
            });
            
            // Periodic height check
            setInterval(function() {
                if (window.innerHeight < initialHeight - 50) {
                    activateProtection();
                }
            }, 1000);
            
            // Method B: Anti-Capture API Block
            const blockCapture = function() {
                activateProtection();
                return Promise.reject(new Error('Screen capture is strictly prohibited.'));
            };

            if (navigator.mediaDevices) {
                navigator.mediaDevices.getDisplayMedia = blockCapture;
            }
            if (navigator.getDisplayMedia) {
                navigator.getDisplayMedia = blockCapture;
            }

            // Method C: Focus/Blur - Instant Blackout
            window.addEventListener('blur', activateProtection);
            window.addEventListener('focus', function() {
                setTimeout(deactivateProtection, 500);
            });
            
            // Method D: Visibility Change
            document.addEventListener('visibilitychange', function() {
                if (document.hidden) activateProtection();
                else setTimeout(deactivateProtection, 500);
            });

            // Method E: DevTools Monitoring
            setInterval(function() {
                const threshold = 160;
                if (window.outerWidth - window.innerWidth > threshold || 
                    window.outerHeight - window.innerHeight > threshold) {
                    activateProtection();
                }
            }, 1000);

            createProtectionOverlay();
            
            // Prevent Print Screen & context menu
            document.addEventListener('keyup', function(e) {
                if (e.keyCode == 44) navigator.clipboard.writeText('');
            });
            document.addEventListener('contextmenu', e => e.preventDefault());

        })();
    </script>
    <style>
        /* Nuclear Blackout Styles */
        body.ts-critical-blackout {
            overflow: hidden !important;
            height: 100vh !important;
        }
        
        body.ts-critical-blackout .ts-course-player-wrapper,
        body.ts-critical-blackout .ts-video-wrapper {
            filter: brightness(0) invert(0) !important;
            opacity: 0 !important;
            visibility: hidden !important;
            pointer-events: none !important;
        }

        .ts-recording-protection-overlay {
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            width: 100vw !important;
            height: 100vh !important;
            background: #000 !important;
            z-index: 2147483647 !important; /* Maximum possible z-index */
            display: none;
            align-items: center;
            justify-content: center;
            color: #fff !important;
            font-family: sans-serif !important;
        }
    </style>
    <?php endif; ?>
    
    <?php 
    // Video Watermark Styles and Script
    $watermark_enabled = \TS_LMS\Admin\Settings::get_setting('video_watermark_enabled');
    if ( $watermark_enabled ) : 
    ?>
    <style>
        .ts-video-watermark {
            position: absolute;
            pointer-events: none;
            z-index: 100;
            transition: all 0.3s ease;
        }
        
        .ts-video-watermark img {
            display: block;
            max-width: 100%;
            height: auto;
        }
        
        /* Size Variations */
        .ts-video-watermark[data-size="small"] img {
            max-width: 80px;
        }
        
        .ts-video-watermark[data-size="medium"] img {
            max-width: 150px;
        }
        
        .ts-video-watermark[data-size="large"] img {
            max-width: 250px;
        }
        
        /* Position Variations (Static) */
        .ts-video-watermark[data-movement="static"][data-position="top-left"] {
            top: 20px;
            left: 20px;
        }
        
        .ts-video-watermark[data-movement="static"][data-position="top-right"] {
            top: 20px;
            right: 20px;
        }
        
        .ts-video-watermark[data-movement="static"][data-position="bottom-left"] {
            bottom: 60px;
            left: 20px;
        }
        
        .ts-video-watermark[data-movement="static"][data-position="bottom-right"] {
            bottom: 60px;
            right: 20px;
        }
        
        .ts-video-watermark[data-movement="static"][data-position="center"] {
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        
        /* Moving Animation */
        @keyframes watermarkMove {
            0% {
                top: 20px;
                left: 20px;
            }
            25% {
                top: 20px;
                left: calc(100% - 20px);
                transform: translateX(-100%);
            }
            50% {
                top: calc(100% - 80px);
                left: calc(100% - 20px);
                transform: translateX(-100%);
            }
            75% {
                top: calc(100% - 80px);
                left: 20px;
                transform: translateX(0);
            }
            100% {
                top: 20px;
                left: 20px;
                transform: translateX(0);
            }
        }
        
        .ts-video-watermark[data-movement="moving"] {
            animation: watermarkMove 30s linear infinite;
        }
        
        /* Fullscreen Mode Support */
        .plyr--fullscreen .ts-video-watermark,
        .plyr:-webkit-full-screen .ts-video-watermark,
        .plyr:-moz-full-screen .ts-video-watermark,
        .plyr:-ms-fullscreen .ts-video-watermark {
            position: fixed !important;
            z-index: 999999 !important;
        }
        
        /* Ensure video wrapper has position relative in fullscreen */
        .plyr--fullscreen,
        .plyr:-webkit-full-screen,
        .plyr:-moz-full-screen,
        .plyr:-ms-fullscreen {
            position: relative;
        }
    </style>
    <script>
        (function() {
            // Initialize watermark opacity
            const watermark = document.querySelector('.ts-video-watermark');
            if (watermark) {
                const opacity = watermark.getAttribute('data-opacity') || 70;
                watermark.style.opacity = opacity / 100;
                
                // Handle fullscreen changes
                const player = document.querySelector('#player');
                const videoWrapper = document.querySelector('.ts-video-wrapper');
                
                if (player && videoWrapper) {
                    // Listen for fullscreen changes
                    document.addEventListener('fullscreenchange', handleFullscreenChange);
                    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
                    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
                    document.addEventListener('MSFullscreenChange', handleFullscreenChange);
                    
                    function handleFullscreenChange() {
                        const isFullscreen = !!(document.fullscreenElement || 
                                               document.webkitFullscreenElement || 
                                               document.mozFullScreenElement || 
                                               document.msFullscreenElement);
                        
                        if (isFullscreen) {
                            // Move watermark to fullscreen element
                            const fullscreenElement = document.fullscreenElement || 
                                                     document.webkitFullscreenElement || 
                                                     document.mozFullScreenElement || 
                                                     document.msFullscreenElement;
                            
                            if (fullscreenElement && !fullscreenElement.contains(watermark)) {
                                fullscreenElement.appendChild(watermark);
                            }
                        } else {
                            // Move watermark back to video wrapper
                            if (!videoWrapper.contains(watermark)) {
                                videoWrapper.appendChild(watermark);
                            }
                        }
                    }
                }
            }
        })();
    </script>
    <?php endif; ?>
</div>
<?php 
if ( !$spotlight_mode ) {
    get_footer(); 
}
?>
