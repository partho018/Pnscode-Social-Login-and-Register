<?php
/**
 * Public Profile Template
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$author = get_queried_object();
$user_id = $author->ID;

// Get Settings
$settings = get_option('ts_lms_settings', array());
$is_instructor = in_array('instructor', (array)$author->roles) || in_array('administrator', (array)$author->roles);

if ( $is_instructor ) {
    $layout = isset($settings['instructor_profile_layout']) ? $settings['instructor_profile_layout'] : 'classic';
} else {
    $layout = isset($settings['student_profile_layout']) ? $settings['student_profile_layout'] : 'classic';
}

get_header(); ?>

<div class="ts-profile-page layout-<?php echo esc_attr($layout); ?>">
    <?php if ( $layout === 'private' ) : ?>
        <div class="ts-profile-private">
            <div class="ts-private-icon">
                <span class="dashicons dashicons-lock"></span>
            </div>
            <h1><?php _e('This Profile is Private', 'ts-lms'); ?></h1>
            <p><?php _e('You do not have permission to view this profile.', 'ts-lms'); ?></p>
            <a href="<?php echo home_url(); ?>" class="ts-btn-back"><?php _e('Back to Home', 'ts-lms'); ?></a>
        </div>
    <?php else : ?>
        
        <?php if ( $layout === 'modern' ) : ?>
            <div class="ts-profile-header modern">
                <div class="ts-profile-cover"></div>
                <div class="ts-profile-container">
                    <div class="ts-profile-avatar-wrap">
                        <?php echo get_avatar($user_id, 150); ?>
                    </div>
                    <div class="ts-profile-meta">
                        <h1><?php echo esc_html($author->display_name); ?></h1>
                        <p class="ts-designation"><?php echo esc_html(get_user_meta($user_id, '_ts_designation', true) ?: ($is_instructor ? __('Instructor', 'ts-lms') : __('Student', 'ts-lms'))); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="ts-profile-container <?php echo $layout !== 'modern' ? 'standard-padding' : ''; ?>">
            <div class="ts-profile-grid">
                
                <?php if ( $layout === 'classic' ) : ?>
                    <aside class="ts-profile-sidebar">
                        <div class="ts-sidebar-card">
                            <div class="ts-profile-avatar">
                                <?php echo get_avatar($user_id, 200); ?>
                            </div>
                            <div class="ts-profile-basic">
                                <h1><?php echo esc_html($author->display_name); ?></h1>
                                <p class="ts-designation"><?php echo esc_html(get_user_meta($user_id, '_ts_designation', true)); ?></p>
                            </div>
                            <div class="ts-profile-stats">
                                <div class="stat-item">
                                    <span class="count"><?php echo count_user_posts($user_id, 'ts_course'); ?></span>
                                    <span class="label"><?php _e('Courses', 'ts-lms'); ?></span>
                                </div>
                            </div>
                            <div class="ts-profile-social">
                                <!-- Social icons could go here -->
                            </div>
                        </div>
                    </aside>
                <?php endif; ?>

                <main class="ts-profile-content">
                    <?php if ( $layout === 'minimal' ) : ?>
                        <div class="ts-profile-header minimal">
                            <div class="ts-profile-avatar">
                                <?php echo get_avatar($user_id, 120); ?>
                            </div>
                            <h1><?php echo esc_html($author->display_name); ?></h1>
                            <p class="ts-designation"><?php echo esc_html(get_user_meta($user_id, '_ts_designation', true)); ?></p>
                        </div>
                    <?php endif; ?>

                    <section class="ts-profile-section">
                        <h2><?php _e('About Me', 'ts-lms'); ?></h2>
                        <div class="ts-bio">
                            <?php echo wpautop(get_user_meta($user_id, 'description', true) ?: __('No biography provided yet.', 'ts-lms')); ?>
                        </div>
                    </section>

                    <?php if ( $is_instructor ) : ?>
                        <section class="ts-profile-section">
                            <h2><?php _e('My Courses', 'ts-lms'); ?></h2>
                            <div class="ts-author-courses">
                                <?php 
                                $courses = new WP_Query(array(
                                    'post_type' => 'ts_course',
                                    'author' => $user_id,
                                    'posts_per_page' => -1
                                ));
                                if ( $courses->have_posts() ) : ?>
                                    <div class="ts-course-grid">
                                        <?php while ( $courses->have_posts() ) : $courses->the_post(); 
                                            include TS_LMS_PLUGIN_DIR . 'modules/courses/templates/course-card.php';
                                        endwhile; ?>
                                    </div>
                                <?php else : ?>
                                    <p><?php _e('No courses published yet.', 'ts-lms'); ?></p>
                                <?php endif; wp_reset_postdata(); ?>
                            </div>
                        </section>
                    <?php endif; ?>
                </main>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
