<?php
/**
 * Course Card Template - Premium Redesign with Complete Metadata
 *
 * @package TS_LMS\Modules\Courses\Templates
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$course_id   = get_the_ID();
$post_type   = get_post_type( $course_id );
$is_bundle   = ( 'ts_bundle' === $post_type );
$author_id   = get_post_field( 'post_author', $course_id );
$author_name = get_the_author_meta( 'display_name', $author_id );
$thumbnail_url = get_the_post_thumbnail_url( $course_id, 'large' );

// Metadata
$sub_plan = '';
if ( $is_bundle ) {
    $price_type = get_post_meta( $course_id, '_bundle_price_type', true );
    $product_id = get_post_meta( $course_id, '_bundle_product_id', true );
    $price      = get_post_meta( $course_id, '_bundle_price', true );
} else {
    // Get price and price type
    $price_type = get_post_meta( $course_id, '_course_price_type', true );
    $product_id = get_post_meta( $course_id, '_course_product_id', true );
    $price      = 0;
    $sub_plan   = ( $price_type === 'subscription' ) ? get_post_meta( $course_id, '_subscription_plan_type', true ) : '';

    // Get price from WooCommerce product if linked
    if ( $product_id && function_exists( 'wc_get_product' ) ) {
        $product = wc_get_product( $product_id );
        if ( $product ) {
            $price = $product->get_price();
        }
    } else {
        $price = ( $price_type === 'subscription' ) ? get_post_meta( $course_id, '_subscription_price', true ) : get_post_meta( $course_id, '_course_price', true );
    }
}

// Duration
$h = get_post_meta( $course_id, '_total_duration_hours', true );
$m = get_post_meta( $course_id, '_total_duration_minutes', true );

// Video duration (intro video)
$video_duration = get_post_meta( $course_id, '_intro_video_duration', true );

// Level
$level = get_post_meta( $course_id, '_course_level', true );

// Categories
$categories = wp_get_post_terms( $course_id, 'ts_course_category' );
$primary_cat = ! empty( $categories ) ? $categories[0]->name : '';

// Tags
$tags = wp_get_post_terms( $course_id, 'ts_course_tag' );
$primary_tag = ! empty( $tags ) ? $tags[0]->name : '';

// Enrollment count
global $wpdb;
$enrollment_count = $wpdb->get_var( $wpdb->prepare( 
    "SELECT COUNT(*) FROM {$wpdb->prefix}ts_course_enrollments WHERE course_id = %d",
    $course_id
) );
if ( ! $enrollment_count ) $enrollment_count = 0;

// Reviews/Ratings
$rating       = 5.00;  // Placeholder - integrate with review system
$review_count = $enrollment_count > 0 ? max( 1, floor( $enrollment_count / 3 ) ) : 0;

$is_free = ( $price_type === 'free' || empty( $price ) || $price == 0 );
$currency = '৳'; // Customizable or fetched from settings

// Enrollment check
$current_user_id = get_current_user_id();
$is_enrolled = TS_LMS\Modules\Courses\Managers\CourseManager::is_enrolled( $course_id, $current_user_id );

// Admins/Authors are considered enrolled
if ( current_user_can( 'manage_options' ) || get_post_field( 'post_author', $course_id ) == $current_user_id ) {
    $is_enrolled = true;
}

// Get Settings for features
$settings = get_option( 'ts_lms_settings', array() );
$enabled_features = isset( $settings['course_features'] ) ? (array)$settings['course_features'] : array();

$show_feature = function($feature_key) use ($enabled_features) {
    return in_array($feature_key, $enabled_features);
};
?>

<div class="ts-course-card" 
     data-level="<?php echo esc_attr($level); ?>" 
     data-type="<?php echo $product_id ? 'paid' : 'free'; ?>" 
     data-post-type="<?php echo $is_bundle ? 'bundle' : 'course'; ?>"
     data-price="<?php echo esc_attr($price); ?>"
     data-category="<?php echo esc_attr($primary_cat); ?>">
    <div class="ts-course-card-thumb">
        <a href="<?php the_permalink(); ?>">
            <?php if ( $thumbnail_url ) : ?>
                <img src="<?php echo esc_url( $thumbnail_url ); ?>" alt="<?php the_title_attribute(); ?>">
            <?php else : ?>
                <div class="ts-course-placeholder">
                    <span>TS LMS</span>
                </div>
            <?php endif; ?>
        </a>
        <div class="ts-card-badges">
            <?php if ( $is_bundle ) : ?>
                <span class="ts-badge badge-bundle" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);"><?php esc_html_e( 'Bundle', 'ts-lms' ); ?></span>
            <?php endif; ?>
            <?php if ( $level && ! $is_bundle ) : ?>
                <span class="ts-badge badge-level <?php echo esc_attr(strtolower($level)); ?>">
                    <?php echo esc_html( ucfirst($level) ); ?>
                </span>
            <?php endif; ?>
            <?php if ( $is_free ) : ?>
                <span class="ts-badge badge-free"><?php esc_html_e( 'Free', 'ts-lms' ); ?></span>
            <?php endif; ?>
        </div>
        <?php 
        if ( $show_feature('wishlist') ) : 
            $in_wishlist = TS_LMS\Modules\Courses\Managers\WishlistManager::is_in_wishlist( $course_id, $current_user_id );
        ?>
        <button class="ts-wishlist-btn<?php echo $in_wishlist ? ' active' : ''; ?>" 
                data-course-id="<?php echo esc_attr( $course_id ); ?>" 
                title="<?php echo $in_wishlist ? esc_attr__( 'Remove from Wishlist', 'ts-lms' ) : esc_attr__( 'Add to Wishlist', 'ts-lms' ); ?>">
            <span class="dashicons dashicons-heart"></span>
        </button>
        <?php endif; ?>
    </div>
    
    <div class="ts-course-card-body">
        <?php if ( $show_feature('review') ) : ?>
        <div class="ts-course-rating">
            <div class="ts-stars">
                <?php for($i=0; $i<5; $i++): ?>
                    <span class="dashicons dashicons-star-filled"></span>
                <?php endfor; ?>
            </div>
            <span class="ts-rating-value"><?php echo number_format($rating, 2); ?></span>
            <span class="ts-rating-count">(<?php echo esc_html($review_count); ?>)</span>
        </div>
        <?php endif; ?>

        <h3 class="ts-course-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>

        <div class="ts-course-meta-row">
            <?php if ( ( $h || $m ) && $show_feature('duration') ) : ?>
                <div class="ts-course-duration">
                    <span class="dashicons dashicons-clock"></span>
                    <?php 
                    if ($h) echo esc_html($h) . 'h ';
                    if ($m) echo esc_html($m) . 'm';
                    ?>
                </div>
            <?php endif; ?>

            <?php if ( $level && $show_feature('level') ) : ?>
                <div class="ts-course-level">
                    <span class="dashicons dashicons-chart-bar"></span>
                    <?php echo esc_html( ucfirst($level) ); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="ts-course-footer-info">
            <?php if ( $show_feature('author') ) : ?>
            <div class="ts-course-author-wrapper">
                <div class="ts-author-avatar">
                    <?php echo get_avatar( $author_id, 24 ); ?>
                </div>
                <div class="ts-author-info">
                    By <span><?php echo esc_html( $author_name ); ?></span>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( $primary_tag ) : ?>
                <div class="ts-course-stat-item">
                    <span class="dashicons dashicons-tag"></span>
                    <?php echo esc_html( $primary_tag ); ?>
                </div>
            <?php endif; ?>

            <?php if ( $show_feature('total_enrolled') ) : ?>
            <div class="ts-course-stat-item">
                <span class="dashicons dashicons-groups"></span>
                <?php echo number_format_i18n( $enrollment_count ); ?> <?php esc_html_e( 'students', 'ts-lms' ); ?>
            </div>
            <?php endif; ?>

            <?php if ( $review_count > 0 && $show_feature('review') ) : ?>
                <div class="ts-course-stat-item">
                    <span class="dashicons dashicons-star-filled"></span>
                    <?php echo number_format_i18n( $review_count ); ?> <?php esc_html_e( 'reviews', 'ts-lms' ); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="ts-course-card-footer">
            <div class="ts-course-price">
                <?php if ( $is_enrolled ) : ?>
                    <!-- Enrolled -->
                <?php elseif ( $is_free ) : ?>
                    <span class="free"><?php esc_html_e( 'Free', 'ts-lms' ); ?></span>
                <?php else : ?>
                    <span class="price">
                        <?php 
                        $display_price = esc_html($currency) . ' ' . number_format((float)$price, 0);
                        if ( $price_type === 'subscription' && $sub_plan ) {
                            echo sprintf( '%s/%s', $display_price, ucfirst( $sub_plan ) );
                        } else {
                            echo $display_price;
                        }
                        ?>
                    </span>
                <?php endif; ?>
            </div>
            
            <?php 
            $btn_text = esc_html__( 'Enroll now', 'ts-lms' );
            $btn_url = get_permalink();
            $btn_class = 'ts-btn-enroll';

            if ( $is_enrolled ) {
                $btn_text = esc_html__( 'Start Learning', 'ts-lms' );
                $btn_class .= ' ts-btn-full';
            } elseif ( ! is_user_logged_in() ) {
                $btn_class .= ' ts-trigger-auth-modal';
                $btn_url = 'javascript:void(0);';
            } else {
                // Logged in
                if ( ! $is_free && $product_id ) {
                    $btn_url = wc_get_checkout_url() . '?add-to-cart=' . $product_id;
                    $btn_class .= ' ts-btn-cart';
                }
            }
            ?>
            <a href="<?php echo esc_url( $btn_url ); ?>" class="<?php echo esc_attr( $btn_class ); ?>">
                <?php echo $btn_text; ?>
            </a>
        </div>
    </div>
</div>
