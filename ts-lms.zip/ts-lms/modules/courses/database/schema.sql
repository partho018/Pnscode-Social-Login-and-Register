-- TS LMS Course Engine Database Schema
-- This file defines custom tables for the Course Engine module

-- Table: Course Instructors (Many-to-Many relationship)
CREATE TABLE {prefix}ts_course_instructors (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  course_id bigint(20) unsigned NOT NULL,
  instructor_id bigint(20) unsigned NOT NULL,
  role varchar(50) NOT NULL DEFAULT 'instructor',
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY course_id (course_id),
  KEY instructor_id (instructor_id),
  UNIQUE KEY course_instructor (course_id, instructor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: Lesson Order and Hierarchy
CREATE TABLE {prefix}ts_lesson_order (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  course_id bigint(20) unsigned NOT NULL,
  lesson_id bigint(20) unsigned NOT NULL,
  parent_lesson_id bigint(20) unsigned DEFAULT NULL,
  order_index int(11) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY course_id (course_id),
  KEY lesson_id (lesson_id),
  KEY parent_lesson_id (parent_lesson_id),
  UNIQUE KEY course_lesson (course_id, lesson_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: Course Enrollments
CREATE TABLE {prefix}ts_course_enrollments (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  course_id bigint(20) unsigned NOT NULL,
  user_id bigint(20) unsigned NOT NULL,
  enrolled_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status varchar(50) NOT NULL DEFAULT 'active',
  completed_at datetime DEFAULT NULL,
  source_type varchar(50) DEFAULT NULL,
  source_id bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (id),
  KEY course_id (course_id),
  KEY user_id (user_id),
  KEY status (status),
  KEY source_type (source_type),
  KEY source_id (source_id),
  UNIQUE KEY course_user (course_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: Lesson Progress Tracking
CREATE TABLE {prefix}ts_lesson_progress (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  lesson_id bigint(20) unsigned NOT NULL,
  user_id bigint(20) unsigned NOT NULL,
  course_id bigint(20) unsigned NOT NULL,
  status varchar(50) NOT NULL DEFAULT 'not_started',
  completed_at datetime DEFAULT NULL,
  last_accessed datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY lesson_id (lesson_id),
  KEY user_id (user_id),
  KEY course_id (course_id),
  KEY status (status),
  UNIQUE KEY lesson_user (lesson_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: Bundle Courses (Bundle-Course Relationship)
CREATE TABLE {prefix}ts_bundle_courses (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  bundle_id bigint(20) unsigned NOT NULL,
  course_id bigint(20) unsigned NOT NULL,
  course_price decimal(10,2) NOT NULL DEFAULT 0.00,
  order_index int(11) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY bundle_id (bundle_id),
  KEY course_id (course_id),
  UNIQUE KEY bundle_course (bundle_id, course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

