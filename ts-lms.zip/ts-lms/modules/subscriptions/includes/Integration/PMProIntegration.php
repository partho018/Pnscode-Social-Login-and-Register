<?php
/**
 * Paid Memberships Pro Integration
 *
 * Handles Paid Memberships Pro integration for membership-based course access.
 *
 * @package TS_LMS\Modules\Subscriptions\Integration
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions\Integration;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PMProIntegration class.
 */
class PMProIntegration {

	/**
	 * Initialize the integration.
	 *
	 * @return void
	 */
	public static function init() {
		// Check if Paid Memberships Pro is active
		if ( ! function_exists( 'pmpro_hasMembershipLevel' ) ) {
			return;
		}

		// Hook into membership level changes
		add_action( 'pmpro_after_change_membership_level', array( __CLASS__, 'handle_membership_change' ), 10, 2 );
		
		// Hook into membership cancellation
		add_action( 'pmpro_membership_post_membership_expiry', array( __CLASS__, 'handle_membership_expiry' ), 10, 2 );
	}

	/**
	 * Handle membership level change.
	 *
	 * @param int   $level_id Membership level ID.
	 * @param int   $user_id User ID.
	 * @return void
	 */
	public static function handle_membership_change( $level_id, $user_id ) {
		if ( ! $user_id ) {
			return;
		}

		// Get courses linked to this membership level
		$linked_courses = self::get_membership_courses( $level_id );
		
		if ( empty( $linked_courses ) ) {
			return;
		}

		foreach ( $linked_courses as $course_id ) {
			if ( $level_id > 0 ) {
				// User gained membership - enroll them
				self::enroll_user( $user_id, $course_id, $level_id, 'pmpro' );
				// Fire role sync action
				do_action( 'ts_lms_pmpro_level_activated', $level_id, $user_id );
			} else {
				// User lost membership - update status
				self::update_enrollment_status( $user_id, $level_id, 'cancelled' );
				// Fire role sync action
				do_action( 'ts_lms_pmpro_level_expired', $level_id, $user_id );
			}
		}
	}

	/**
	 * Handle membership expiry.
	 *
	 * @param int   $user_id User ID.
	 * @param int   $level_id Membership level ID.
	 * @return void
	 */
	public static function handle_membership_expiry( $user_id, $level_id ) {
		if ( ! $user_id ) {
			return;
		}

		// Update enrollment status to expired
		self::update_enrollment_status( $user_id, $level_id, 'expired' );
		
		// Fire role sync action
		do_action( 'ts_lms_pmpro_level_expired', $level_id, $user_id );
	}

	/**
	 * Get courses linked to a membership level.
	 *
	 * @param int $level_id Membership level ID.
	 * @return array Array of course IDs.
	 */
	private static function get_membership_courses( $level_id ) {
		global $wpdb;
		
		$course_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT post_id FROM {$wpdb->postmeta} 
			WHERE meta_key = '_pmpro_membership_level' 
			AND meta_value = %d",
			$level_id
		) );
		
		return $course_ids ? array_map( 'absint', $course_ids ) : array();
	}

	/**
	 * Enroll user in a course via membership.
	 *
	 * @param int    $user_id User ID.
	 * @param int    $course_id Course ID.
	 * @param int    $membership_id Membership level ID.
	 * @param string $subscription_type Subscription type.
	 * @return bool True on success, false on failure.
	 */
	private static function enroll_user( $user_id, $course_id, $membership_id, $subscription_type = 'pmpro' ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . 'ts_course_enrollments';
		
		// Check if already enrolled
		$existing = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$table_name} WHERE user_id = %d AND course_id = %d",
			$user_id,
			$course_id
		) );
		
		if ( $existing ) {
			// Update existing enrollment
			$wpdb->update(
				$table_name,
				array(
					'status'            => 'active',
					'subscription_id'   => $membership_id,
					'subscription_type' => $subscription_type,
				),
				array(
					'user_id'   => $user_id,
					'course_id' => $course_id,
				),
				array( '%s', '%d', '%s' ),
				array( '%d', '%d' )
			);
			return true;
		}
		
		// Insert new enrollment
		$result = $wpdb->insert(
			$table_name,
			array(
				'user_id'           => $user_id,
				'course_id'         => $course_id,
				'enrolled_at'       => current_time( 'mysql' ),
				'status'            => 'active',
				'subscription_id'   => $membership_id,
				'subscription_type' => $subscription_type,
			),
			array( '%d', '%d', '%s', '%s', '%d', '%s' )
		);
		
		if ( $result ) {
			// Fire action for other plugins/modules to hook into
			do_action( 'ts_lms_user_enrolled_via_membership', $user_id, $course_id, $membership_id, $subscription_type );
			return true;
		}
		
		return false;
	}

	/**
	 * Update enrollment status.
	 *
	 * @param int    $user_id User ID.
	 * @param int    $membership_id Membership level ID.
	 * @param string $status New status.
	 * @return void
	 */
	private static function update_enrollment_status( $user_id, $membership_id, $status ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . 'ts_course_enrollments';
		
		$wpdb->update(
			$table_name,
			array( 'status' => $status ),
			array(
				'user_id'         => $user_id,
				'subscription_id' => $membership_id,
			),
			array( '%s' ),
			array( '%d', '%d' )
		);
		
		do_action( 'ts_lms_enrollment_status_updated_pmpro', $user_id, $membership_id, $status );
	}
}
