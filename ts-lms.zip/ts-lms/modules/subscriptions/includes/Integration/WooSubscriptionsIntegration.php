<?php
/**
 * WooCommerce Subscriptions Integration
 *
 * Handles WooCommerce Subscriptions integration for subscription-based course access.
 *
 * @package TS_LMS\Modules\Subscriptions\Integration
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions\Integration;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WooSubscriptionsIntegration class.
 */
class WooSubscriptionsIntegration {

	/**
	 * Initialize the integration.
	 *
	 * @return void
	 */
	public static function init() {
		// Check if WooCommerce Subscriptions is active
		if ( ! class_exists( 'WC_Subscriptions' ) ) {
			return;
		}

		// Hook into subscription status changes
		add_action( 'woocommerce_subscription_status_active', array( __CLASS__, 'handle_subscription_activated' ), 10, 1 );
		add_action( 'woocommerce_subscription_status_on-hold', array( __CLASS__, 'handle_subscription_on_hold' ), 10, 1 );
		add_action( 'woocommerce_subscription_status_cancelled', array( __CLASS__, 'handle_subscription_cancelled' ), 10, 1 );
		add_action( 'woocommerce_subscription_status_expired', array( __CLASS__, 'handle_subscription_expired' ), 10, 1 );
		
		// Hook into subscription renewal
		add_action( 'woocommerce_subscription_renewal_payment_complete', array( __CLASS__, 'handle_renewal_payment' ), 10, 2 );
	}

	/**
	 * Handle subscription activation.
	 *
	 * @param \WC_Subscription $subscription Subscription object.
	 * @return void
	 */
	public static function handle_subscription_activated( $subscription ) {
		if ( ! $subscription ) {
			return;
		}

		$user_id = $subscription->get_user_id();
		$subscription_id = $subscription->get_id();

		// Get subscription items
		$items = $subscription->get_items();
		
		foreach ( $items as $item ) {
			$product_id = $item->get_product_id();
			
			// Check if this product is linked to a course
			$course_id = get_post_meta( $product_id, '_linked_course', true );
			
			if ( $course_id && get_post_type( $course_id ) === 'ts_course' ) {
				// Enroll or reactivate user in the course
				self::enroll_user( $user_id, $course_id, $subscription_id, 'woo_subscriptions' );
				// Fire role sync action
				do_action( 'ts_lms_woo_subscription_activated', $subscription_id, $user_id );
			}
		}
	}

	/**
	 * Handle subscription on hold.
	 *
	 * @param \WC_Subscription $subscription Subscription object.
	 * @return void
	 */
	public static function handle_subscription_on_hold( $subscription ) {
		if ( ! $subscription ) {
			return;
		}

		$user_id = $subscription->get_user_id();
		$subscription_id = $subscription->get_id();

		// Update enrollment status to on-hold
		self::update_enrollment_status( $user_id, $subscription_id, 'on-hold' );
	}

	/**
	 * Handle subscription cancellation.
	 *
	 * @param \WC_Subscription $subscription Subscription object.
	 * @return void
	 */
	public static function handle_subscription_cancelled( $subscription ) {
		if ( ! $subscription ) {
			return;
		}

		$user_id = $subscription->get_user_id();
		$subscription_id = $subscription->get_id();

		// Update enrollment status to cancelled
		self::update_enrollment_status( $user_id, $subscription_id, 'cancelled' );
		// Fire role sync action
		do_action( 'ts_lms_woo_subscription_expired', $subscription_id, $user_id );
	}

	/**
	 * Handle subscription expiration.
	 *
	 * @param \WC_Subscription $subscription Subscription object.
	 * @return void
	 */
	public static function handle_subscription_expired( $subscription ) {
		if ( ! $subscription ) {
			return;
		}

		$user_id = $subscription->get_user_id();
		$subscription_id = $subscription->get_id();

		// Update enrollment status to expired
		self::update_enrollment_status( $user_id, $subscription_id, 'expired' );
		// Fire role sync action
		do_action( 'ts_lms_woo_subscription_expired', $subscription_id, $user_id );
	}

	/**
	 * Handle renewal payment.
	 *
	 * @param \WC_Subscription $subscription Subscription object.
	 * @param \WC_Order        $order Order object.
	 * @return void
	 */
	public static function handle_renewal_payment( $subscription, $order ) {
		if ( ! $subscription ) {
			return;
		}

		$user_id = $subscription->get_user_id();
		$subscription_id = $subscription->get_id();

		// Reactivate enrollment
		self::update_enrollment_status( $user_id, $subscription_id, 'active' );
		
		// Extend expiration date
		$next_payment = $subscription->get_date( 'next_payment' );
		if ( $next_payment ) {
			self::update_enrollment_expiration( $user_id, $subscription_id, $next_payment );
		}
		// Fire role sync action
		do_action( 'ts_lms_woo_subscription_activated', $subscription_id, $user_id );
	}

	/**
	 * Enroll user in a course via subscription.
	 *
	 * @param int    $user_id User ID.
	 * @param int    $course_id Course ID.
	 * @param int    $subscription_id Subscription ID.
	 * @param string $subscription_type Subscription type.
	 * @return bool True on success, false on failure.
	 */
	private static function enroll_user( $user_id, $course_id, $subscription_id, $subscription_type = 'woo_subscriptions' ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . 'ts_course_enrollments';
		
		// Check if already enrolled
		$existing = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$table_name} WHERE user_id = %d AND course_id = %d",
			$user_id,
			$course_id
		) );
		
		if ( $existing ) {
			// Update existing enrollment
			$wpdb->update(
				$table_name,
				array(
					'status'            => 'active',
					'subscription_id'   => $subscription_id,
					'subscription_type' => $subscription_type,
				),
				array(
					'user_id'   => $user_id,
					'course_id' => $course_id,
				),
				array( '%s', '%d', '%s' ),
				array( '%d', '%d' )
			);
			return true;
		}
		
		// Insert new enrollment
		$result = $wpdb->insert(
			$table_name,
			array(
				'user_id'           => $user_id,
				'course_id'         => $course_id,
				'enrolled_at'       => current_time( 'mysql' ),
				'status'            => 'active',
				'subscription_id'   => $subscription_id,
				'subscription_type' => $subscription_type,
			),
			array( '%d', '%d', '%s', '%s', '%d', '%s' )
		);
		
		if ( $result ) {
			// Fire action for other plugins/modules to hook into
			do_action( 'ts_lms_user_enrolled_via_subscription', $user_id, $course_id, $subscription_id, $subscription_type );
			return true;
		}
		
		return false;
	}

	/**
	 * Update enrollment status.
	 *
	 * @param int    $user_id User ID.
	 * @param int    $subscription_id Subscription ID.
	 * @param string $status New status.
	 * @return void
	 */
	private static function update_enrollment_status( $user_id, $subscription_id, $status ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . 'ts_course_enrollments';
		
		$wpdb->update(
			$table_name,
			array( 'status' => $status ),
			array(
				'user_id'         => $user_id,
				'subscription_id' => $subscription_id,
			),
			array( '%s' ),
			array( '%d', '%d' )
		);
		
		do_action( 'ts_lms_enrollment_status_updated', $user_id, $subscription_id, $status );
	}

	/**
	 * Update enrollment expiration.
	 *
	 * @param int    $user_id User ID.
	 * @param int    $subscription_id Subscription ID.
	 * @param string $expiration_date Expiration date.
	 * @return void
	 */
	private static function update_enrollment_expiration( $user_id, $subscription_id, $expiration_date ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . 'ts_course_enrollments';
		
		$wpdb->update(
			$table_name,
			array( 'expires_at' => $expiration_date ),
			array(
				'user_id'         => $user_id,
				'subscription_id' => $subscription_id,
			),
			array( '%s' ),
			array( '%d', '%d' )
		);
	}
}
