<?php
/**
 * Subscription Settings
 *
 * Admin settings page for subscription configuration.
 *
 * @package TS_LMS\Modules\Subscriptions
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SubscriptionSettings class.
 */
class SubscriptionSettings {

	/**
	 * Initialize settings.
	 *
	 * @return void
	 */
	public static function init() {
		// add_action( 'admin_menu', array( __CLASS__, 'add_settings_page' ), 16 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Add settings page to admin menu.
	 *
	 * @return void
	 */
	public static function add_settings_page() {
		add_submenu_page(
			'ts-lms',
			__( 'Subscription Settings', 'ts-lms' ),
			__( 'Subscriptions', 'ts-lms' ),
			'manage_options',
			'ts-lms-subscriptions',
			array( __CLASS__, 'render_settings_page' )
		);
	}

	/**
	 * Register settings.
	 *
	 * @return void
	 */
	public static function register_settings() {
		// Register settings
		register_setting( 'ts_lms_subscriptions', 'ts_lms_subscription_grace_period_days' );
		register_setting( 'ts_lms_subscriptions', 'ts_lms_subscription_grace_notifications' );
		register_setting( 'ts_lms_subscriptions', 'ts_lms_woo_subscriptions_enabled' );
		register_setting( 'ts_lms_subscriptions', 'ts_lms_pmpro_enabled' );

		// Add settings sections
		add_settings_section(
			'ts_lms_subscription_general',
			__( 'General Settings', 'ts-lms' ),
			array( __CLASS__, 'render_general_section' ),
			'ts_lms_subscriptions'
		);

		add_settings_section(
			'ts_lms_subscription_integrations',
			__( 'Integrations', 'ts-lms' ),
			array( __CLASS__, 'render_integrations_section' ),
			'ts_lms_subscriptions'
		);

		// Add settings fields
		add_settings_field(
			'ts_lms_subscription_grace_period_days',
			__( 'Grace Period (Days)', 'ts-lms' ),
			array( __CLASS__, 'render_grace_period_field' ),
			'ts_lms_subscriptions',
			'ts_lms_subscription_general'
		);

		add_settings_field(
			'ts_lms_subscription_grace_notifications',
			__( 'Grace Period Notifications', 'ts-lms' ),
			array( __CLASS__, 'render_notifications_field' ),
			'ts_lms_subscriptions',
			'ts_lms_subscription_general'
		);

		add_settings_field(
			'ts_lms_woo_subscriptions_enabled',
			__( 'WooCommerce Subscriptions', 'ts-lms' ),
			array( __CLASS__, 'render_woo_enabled_field' ),
			'ts_lms_subscriptions',
			'ts_lms_subscription_integrations'
		);

		add_settings_field(
			'ts_lms_pmpro_enabled',
			__( 'Paid Memberships Pro', 'ts-lms' ),
			array( __CLASS__, 'render_pmpro_enabled_field' ),
			'ts_lms_subscriptions',
			'ts_lms_subscription_integrations'
		);
	}

	/**
	 * Render settings page.
	 *
	 * @return void
	 */
	/**
	 * Render settings page.
	 *
	 * @return void
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'settings';
		
		// Handle Actions
		if ( isset( $_GET['action'], $_GET['sub_id'], $_GET['_wpnonce'] ) && wp_verify_nonce( $_GET['_wpnonce'], 'ts_sub_action' ) ) {
			global $wpdb;
			$table = $wpdb->prefix . 'ts_course_enrollments';
			$sub_id = sanitize_text_field( $_GET['sub_id'] );
			$action = sanitize_text_field( $_GET['action'] );
			
			if ( $action === 'activate' ) {
				$wpdb->update( $table, array( 'status' => 'active' ), array( 'subscription_id' => $sub_id ) );
				echo '<div class="notice notice-success"><p>' . __( 'Subscription activated.', 'ts-lms' ) . '</p></div>';
			} elseif ( $action === 'deactivate' ) {
				$wpdb->update( $table, array( 'status' => 'cancelled' ), array( 'subscription_id' => $sub_id ) );
				echo '<div class="notice notice-success"><p>' . __( 'Subscription deactivated.', 'ts-lms' ) . '</p></div>';
			}
		}

		?>
		<div class="wrap">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			
			<nav class="nav-tab-wrapper">
				<a href="?page=ts-lms-subscriptions&tab=settings" class="nav-tab <?php echo $active_tab === 'settings' ? 'nav-tab-active' : ''; ?>"><?php _e( 'Settings', 'ts-lms' ); ?></a>
				<a href="?page=ts-lms-subscriptions&tab=list" class="nav-tab <?php echo $active_tab === 'list' ? 'nav-tab-active' : ''; ?>"><?php _e( 'All Subscriptions', 'ts-lms' ); ?></a>
			</nav>
			
			<?php if ( $active_tab === 'settings' ) : ?>
				<form method="post" action="options.php">
					<?php
					settings_fields( 'ts_lms_subscriptions' );
					do_settings_sections( 'ts_lms_subscriptions' );
					submit_button();
					?>
				</form>
			<?php else : ?>
				<?php self::render_subscription_list(); ?>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render subscription list table.
	 */
	private static function render_subscription_list() {
		global $wpdb;
		$table = $wpdb->prefix . 'ts_course_enrollments';
		
		// Filter
		$where = "WHERE subscription_id IS NOT NULL";
		if ( ! empty( $_GET['course_filter'] ) ) {
			$where .= $wpdb->prepare( " AND course_id = %d", absint( $_GET['course_filter'] ) );
		}
		
		// Pagination
		$per_page = 20;
		$page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$offset = ( $page - 1 ) * $per_page;
		
		$items = $wpdb->get_results( "SELECT * FROM {$table} {$where} ORDER BY enrolled_at DESC LIMIT {$per_page} OFFSET {$offset}" );
		$total_items = $wpdb->get_var( "SELECT COUNT(*) FROM {$table} {$where}" );
		$total_pages = ceil( $total_items / $per_page );
		
		// Get all courses for filter
		$courses = get_posts( array( 'post_type' => 'ts_course', 'posts_per_page' => -1, 'fields' => 'ids' ) );
		?>
		
		<div class="tablenav top">
			<form method="get">
				<input type="hidden" name="page" value="ts-lms-subscriptions" />
				<input type="hidden" name="tab" value="list" />
				<div class="alignleft actions">
					<select name="course_filter">
						<option value=""><?php _e( 'All Courses', 'ts-lms' ); ?></option>
						<?php foreach ( $courses as $cid ) : ?>
							<option value="<?php echo $cid; ?>" <?php selected( isset($_GET['course_filter']) ? $_GET['course_filter'] : '', $cid ); ?>>
								<?php echo esc_html( get_the_title( $cid ) ); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<button type="submit" class="button"><?php _e( 'Filter', 'ts-lms' ); ?></button>
				</div>
			</form>
			
			<div class="tablenav-pages">
				<span class="displaying-num"><?php echo $total_items; ?> <?php _e( 'items', 'ts-lms' ); ?></span>
				<?php
				echo paginate_links( array(
					'base'    => add_query_arg( 'paged', '%#%' ),
					'format'  => '',
					'prev_text' => '&laquo;',
					'next_text' => '&raquo;',
					'total'   => $total_pages,
					'current' => $page
				) );
				?>
			</div>
		</div>
		
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th><?php _e( 'User', 'ts-lms' ); ?></th>
					<th><?php _e( 'Course', 'ts-lms' ); ?></th>
					<th><?php _e( 'Plan', 'ts-lms' ); ?></th>
					<th><?php _e( 'Status', 'ts-lms' ); ?></th>
					<th><?php _e( 'Expires', 'ts-lms' ); ?></th>
					<th><?php _e( 'Actions', 'ts-lms' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $items ) ) : ?>
					<tr><td colspan="6"><?php _e( 'No subscriptions found.', 'ts-lms' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $items as $item ) : 
						$user = get_user_by( 'id', $item->user_id );
						$course_title = get_the_title( $item->course_id );
						$activate_url = wp_nonce_url( add_query_arg( array( 'action' => 'activate', 'sub_id' => $item->subscription_id ) ), 'ts_sub_action' );
						$deactivate_url = wp_nonce_url( add_query_arg( array( 'action' => 'deactivate', 'sub_id' => $item->subscription_id ) ), 'ts_sub_action' );
					?>
					<tr>
						<td><?php echo esc_html( $user ? $user->display_name : 'Unknown' ); ?> (<?php echo esc_html( $user ? $user->user_email : '' ); ?>)</td>
						<td><?php echo esc_html( $course_title ); ?></td>
						<td><?php echo esc_html( ucfirst( $item->subscription_type ) ); ?></td>
						<td>
							<span class="ts-status-badge <?php echo esc_attr( $item->status ); ?>" style="padding: 3px 8px; border-radius: 4px; background: <?php echo $item->status == 'active' ? '#d1fae5' : '#fee2e2'; ?>; color: <?php echo $item->status == 'active' ? '#065f46' : '#991b1b'; ?>;">
								<?php echo esc_html( ucfirst( $item->status ) ); ?>
							</span>
						</td>
						<td><?php echo $item->expires_at ? date_i18n( get_option('date_format'), strtotime( $item->expires_at ) ) : '-'; ?></td>
						<td>
							<?php if ( $item->status !== 'active' ) : ?>
								<a href="<?php echo esc_url( $activate_url ); ?>" class="button button-small"><?php _e( 'Activate', 'ts-lms' ); ?></a>
							<?php else : ?>
								<a href="<?php echo esc_url( $deactivate_url ); ?>" class="button button-small button-secondary"><?php _e( 'Deactivate', 'ts-lms' ); ?></a>
							<?php endif; ?>
						</td>
					</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Render general section description.
	 *
	 * @return void
	 */
	public static function render_general_section() {
		echo '<p>' . esc_html__( 'Configure general subscription settings.', 'ts-lms' ) . '</p>';
	}

	/**
	 * Render integrations section description.
	 *
	 * @return void
	 */
	public static function render_integrations_section() {
		echo '<p>' . esc_html__( 'Enable or disable subscription plugin integrations.', 'ts-lms' ) . '</p>';
	}

	/**
	 * Render grace period field.
	 *
	 * @return void
	 */
	public static function render_grace_period_field() {
		$value = get_option( 'ts_lms_subscription_grace_period_days', 7 );
		?>
		<input type="number" name="ts_lms_subscription_grace_period_days" value="<?php echo esc_attr( $value ); ?>" min="0" max="90" />
		<p class="description"><?php esc_html_e( 'Number of days users can access courses after subscription expires.', 'ts-lms' ); ?></p>
		<?php
	}

	/**
	 * Render notifications field.
	 *
	 * @return void
	 */
	public static function render_notifications_field() {
		$value = get_option( 'ts_lms_subscription_grace_notifications', 1 );
		?>
		<label>
			<input type="checkbox" name="ts_lms_subscription_grace_notifications" value="1" <?php checked( $value, 1 ); ?> />
			<?php esc_html_e( 'Send email notifications when grace period starts', 'ts-lms' ); ?>
		</label>
		<?php
	}

	/**
	 * Render WooCommerce enabled field.
	 *
	 * @return void
	 */
	public static function render_woo_enabled_field() {
		$value = get_option( 'ts_lms_woo_subscriptions_enabled', 1 );
		$is_active = class_exists( 'WC_Subscriptions' );
		?>
		<label>
			<input type="checkbox" name="ts_lms_woo_subscriptions_enabled" value="1" <?php checked( $value, 1 ); ?> <?php disabled( ! $is_active ); ?> />
			<?php esc_html_e( 'Enable WooCommerce Subscriptions integration', 'ts-lms' ); ?>
		</label>
		<?php if ( ! $is_active ) : ?>
			<p class="description" style="color: #d63638;">
				<?php esc_html_e( 'WooCommerce Subscriptions plugin is not installed or activated.', 'ts-lms' ); ?>
			</p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render PMPro enabled field.
	 *
	 * @return void
	 */
	public static function render_pmpro_enabled_field() {
		$value = get_option( 'ts_lms_pmpro_enabled', 1 );
		$is_active = defined( 'PMPRO_VERSION' );
		?>
		<label>
			<input type="checkbox" name="ts_lms_pmpro_enabled" value="1" <?php checked( $value, 1 ); ?> <?php disabled( ! $is_active ); ?> />
			<?php esc_html_e( 'Enable Paid Memberships Pro integration', 'ts-lms' ); ?>
		</label>
		<?php if ( ! $is_active ) : ?>
			<p class="description" style="color: #d63638;">
				<?php esc_html_e( 'Paid Memberships Pro plugin is not installed or activated.', 'ts-lms' ); ?>
			</p>
		<?php endif; ?>
		<?php
	}
}
