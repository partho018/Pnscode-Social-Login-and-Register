<?php
/**
 * Subscription Admin Page
 *
 * Renders the subscriptions dashboard in WordPress admin.
 *
 * @package TS_LMS\Modules\Subscriptions
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SubscriptionPage class.
 */
class SubscriptionPage {

	/**
	 * Render the subscriptions page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'ts-lms' ) );
		}

		$active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'overview';
		$stats = self::get_subscription_stats();
		?>
		<div class="wrap ts-lms-redesign-wrap">
			<div class="ts-lms-redesign-header">
				<div class="ts-lms-redesign-title">
					<h1>
						<span class="main-title"><?php esc_html_e( 'Subscriptions', 'ts-lms' ); ?></span>
						<span class="separator">/</span>
						<span class="sub-title"><?php echo esc_html( ucfirst( str_replace( '_', ' ', $active_tab ) ) ); ?></span>
					</h1>
				</div>

				<nav class="ts-lms-redesign-nav">
					<a href="?page=ts-lms-subscriptions&tab=overview" class="nav-item <?php echo $active_tab === 'overview' ? 'active' : ''; ?>">
						<?php esc_html_e( 'Overview', 'ts-lms' ); ?>
					</a>

				</nav>
			</div>

			<div class="ts-lms-redesign-content">
				<?php if ( $active_tab === 'overview' ) : ?>
					<div class="ts-lms-stats-grid">
						<!-- Total Subscriptions -->
						<div class="ts-lms-premium-card">
							<div class="ts-lms-stat-box">
								<div class="ts-lms-stat-icon" style="background: #e3f2fd; color: #1976d2;">
									<span class="dashicons dashicons-id"></span>
								</div>
								<div class="ts-lms-stat-info">
									<h3><?php echo esc_html( $stats['total_subscriptions'] ); ?></h3>
									<p><?php esc_html_e( 'Total Subscriptions', 'ts-lms' ); ?></p>
								</div>
							</div>
						</div>

						<!-- Active Subscriptions -->
						<div class="ts-lms-premium-card">
							<div class="ts-lms-stat-box">
								<div class="ts-lms-stat-icon" style="background: #e8f5e9; color: #2e7d32;">
									<span class="dashicons dashicons-yes-alt"></span>
								</div>
								<div class="ts-lms-stat-info">
									<h3><?php echo esc_html( $stats['active_subscriptions'] ); ?></h3>
									<p><?php esc_html_e( 'Active Subscriptions', 'ts-lms' ); ?></p>
								</div>
							</div>
						</div>

						<!-- Expired Subscriptions -->
						<div class="ts-lms-premium-card">
							<div class="ts-lms-stat-box">
								<div class="ts-lms-stat-icon" style="background: #ffebee; color: #c62828;">
									<span class="dashicons dashicons-warning"></span>
								</div>
								<div class="ts-lms-stat-info">
									<h3><?php echo esc_html( $stats['expired_subscriptions'] ); ?></h3>
									<p><?php esc_html_e( 'Expired Subscriptions', 'ts-lms' ); ?></p>
								</div>
							</div>
						</div>

						<!-- In Grace Period -->
						<div class="ts-lms-premium-card">
							<div class="ts-lms-stat-box">
								<div class="ts-lms-stat-icon" style="background: #fff3e0; color: #ef6c00;">
									<span class="dashicons dashicons-clock"></span>
								</div>
								<div class="ts-lms-stat-info">
									<h3><?php echo esc_html( $stats['grace_period_count'] ); ?></h3>
									<p><?php esc_html_e( 'In Grace Period', 'ts-lms' ); ?></p>
								</div>
							</div>
						</div>
					</div>

					<div class="ts-lms-premium-card">
						<h2 style="margin-top:0; margin-bottom:20px; font-size:18px;"><?php esc_html_e( 'Recent Subscriptions', 'ts-lms' ); ?></h2>
						<div class="ts-lms-table-wrapper">
							<table class="ts-lms-modern-table">
								<thead>
									<tr>
										<th><?php esc_html_e( 'User', 'ts-lms' ); ?></th>
										<th><?php esc_html_e( 'Status', 'ts-lms' ); ?></th>
										<th><?php esc_html_e( 'Source', 'ts-lms' ); ?></th>
										<th><?php esc_html_e( 'Expires', 'ts-lms' ); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php
									global $wpdb;
									$table_name = $wpdb->prefix . 'ts_course_enrollments';
									$recent = $wpdb->get_results( "SELECT * FROM {$table_name} WHERE subscription_id IS NOT NULL ORDER BY enrolled_at DESC LIMIT 10" );

									if ( $recent ) :
										foreach ( $recent as $sub ) :
											$user = get_userdata( $sub->user_id );
											$status = 'active';
											$now = current_time( 'timestamp' );
											$expires = $sub->expires_at ? strtotime( $sub->expires_at ) : 0;
											$grace = $sub->grace_period_ends ? strtotime( $sub->grace_period_ends ) : 0;

											if ( $expires && $now > $expires ) {
												$status = ( $grace && $now < $grace ) ? 'grace' : 'expired';
											}
											
											$status_class = 'ts-status-success';
											if ( $status === 'expired' ) $status_class = 'ts-status-danger';
											if ( $status === 'grace' ) $status_class = 'ts-status-warning';
											?>
											<tr>
												<td>
													<strong><?php echo $user ? esc_html( $user->display_name ) : esc_html__( 'Deleted User', 'ts-lms' ); ?></strong>
													<div class="row-actions"><?php echo $user ? esc_html( $user->user_email ) : ''; ?></div>
												</td>
												<td>
													<span class="ts-status <?php echo esc_attr( $status_class ); ?>">
														<?php echo esc_html( ucfirst( $status ) ); ?>
													</span>
												</td>
												<td><?php echo esc_html( ucfirst( $sub->subscription_type ) ); ?></td>
												<td><?php echo $sub->expires_at ? esc_html( date_i18n( get_option( 'date_format' ), $expires ) ) : esc_html__( 'Never', 'ts-lms' ); ?></td>
											</tr>
											<?php
										endforeach;
									else :
										?>
										<tr>
											<td colspan="4" style="text-align: center; padding: 40px; color: #646970;">
												<?php esc_html_e( 'No subscriptions found.', 'ts-lms' ); ?>
											</td>
										</tr>
										<?php
									endif;
									?>
								</tbody>
							</table>
						</div>
					</div>

				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Get subscription statistics.
	 *
	 * @return array
	 */
	private static function get_subscription_stats() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'ts_course_enrollments';
		$now = current_time( 'mysql' );

		// Total Subscriptions (where subscription_id is not null)
		$total = $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name} WHERE subscription_id IS NOT NULL" );

		// Active Subscriptions (not expired)
		$active = $wpdb->get_var( $wpdb->prepare( 
			"SELECT COUNT(*) FROM {$table_name} WHERE subscription_id IS NOT NULL AND (expires_at IS NULL OR expires_at > %s)", 
			$now 
		) );

		// Expired Subscriptions
		$expired = $wpdb->get_var( $wpdb->prepare( 
			"SELECT COUNT(*) FROM {$table_name} WHERE subscription_id IS NOT NULL AND expires_at <= %s AND (grace_period_ends IS NULL OR grace_period_ends <= %s)", 
			$now, $now 
		) );

		// In Grace Period
		$grace = $wpdb->get_var( $wpdb->prepare( 
			"SELECT COUNT(*) FROM {$table_name} WHERE subscription_id IS NOT NULL AND expires_at <= %s AND grace_period_ends > %s", 
			$now, $now 
		) );

		return array(
			'total_subscriptions'   => (int) $total,
			'active_subscriptions'  => (int) $active,
			'expired_subscriptions' => (int) $expired,
			'grace_period_count'    => (int) $grace,
		);
	}
}
