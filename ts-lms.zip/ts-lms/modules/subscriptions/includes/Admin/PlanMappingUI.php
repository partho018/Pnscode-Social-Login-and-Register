<?php
/**
 * Plan Mapping UI
 *
 * Admin UI for mapping subscription plans to courses.
 *
 * @package TS_LMS\Modules\Subscriptions
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions\Admin;

use TS_LMS\Modules\Courses\PostTypes\Course;
use TS_LMS\Modules\Subscriptions\Access\PlanMapper;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PlanMappingUI class.
 */
class PlanMappingUI {

	/**
	 * Initialize UI.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_' . Course::POST_TYPE, array( __CLASS__, 'save_meta_box' ), 10, 2 );
	}

	/**
	 * Add meta box to course edit screen.
	 *
	 * @return void
	 */
	public static function add_meta_box() {
		add_meta_box(
			'ts_lms_subscription_plans',
			__( 'Subscription Plans', 'ts-lms' ),
			array( __CLASS__, 'render_meta_box' ),
			Course::POST_TYPE,
			'side',
			'default'
		);
	}

	/**
	 * Render meta box content.
	 *
	 * @param \WP_Post $post Post object.
	 * @return void
	 */
	public static function render_meta_box( $post ) {
		wp_nonce_field( 'ts_lms_subscription_plans', 'ts_lms_subscription_plans_nonce' );

		$selected_plans = PlanMapper::get_course_plans( $post->ID );
		$selected_woo = array();
		$selected_pmpro = array();

		foreach ( $selected_plans as $plan ) {
			if ( $plan['type'] === 'woo_subscription' ) {
				$selected_woo[] = $plan['id'];
			} elseif ( $plan['type'] === 'pmpro_level' ) {
				$selected_pmpro[] = $plan['id'];
			}
		}

		echo '<div class="ts-lms-subscription-plans">';

		// WooCommerce Subscriptions
		if ( class_exists( 'WC_Subscriptions' ) ) {
			echo '<h4>' . esc_html__( 'WooCommerce Subscriptions', 'ts-lms' ) . '</h4>';
			$woo_products = self::get_woo_subscription_products();

			if ( ! empty( $woo_products ) ) {
				foreach ( $woo_products as $product_id => $product_name ) {
					$checked = in_array( $product_id, $selected_woo ) ? 'checked' : '';
					echo '<label style="display: block; margin-bottom: 5px;">';
					echo '<input type="checkbox" name="ts_lms_woo_subscriptions[]" value="' . esc_attr( $product_id ) . '" ' . $checked . ' />';
					echo ' ' . esc_html( $product_name );
					echo '</label>';
				}
			} else {
				echo '<p class="description">' . esc_html__( 'No subscription products found.', 'ts-lms' ) . '</p>';
			}
		}

		// Paid Memberships Pro
		if ( defined( 'PMPRO_VERSION' ) ) {
			echo '<h4 style="margin-top: 15px;">' . esc_html__( 'Paid Memberships Pro', 'ts-lms' ) . '</h4>';
			$pmpro_levels = self::get_pmpro_levels();

			if ( ! empty( $pmpro_levels ) ) {
				foreach ( $pmpro_levels as $level_id => $level_name ) {
					$checked = in_array( $level_id, $selected_pmpro ) ? 'checked' : '';
					echo '<label style="display: block; margin-bottom: 5px;">';
					echo '<input type="checkbox" name="ts_lms_pmpro_levels[]" value="' . esc_attr( $level_id ) . '" ' . $checked . ' />';
					echo ' ' . esc_html( $level_name );
					echo '</label>';
				}
			} else {
				echo '<p class="description">' . esc_html__( 'No membership levels found.', 'ts-lms' ) . '</p>';
			}
		}

		echo '</div>';
	}

	/**
	 * Save meta box data.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 * @return void
	 */
	public static function save_meta_box( $post_id, $post ) {
		// Check nonce
		if ( ! isset( $_POST['ts_lms_subscription_plans_nonce'] ) || ! wp_verify_nonce( $_POST['ts_lms_subscription_plans_nonce'], 'ts_lms_subscription_plans' ) ) {
			return;
		}

		// Check autosave
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Check permissions
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Get current plans
		$current_plans = PlanMapper::get_course_plans( $post_id );

		// Process WooCommerce subscriptions
		$woo_subscriptions = isset( $_POST['ts_lms_woo_subscriptions'] ) ? array_map( 'intval', $_POST['ts_lms_woo_subscriptions'] ) : array();

		// Process PMPro levels
		$pmpro_levels = isset( $_POST['ts_lms_pmpro_levels'] ) ? array_map( 'intval', $_POST['ts_lms_pmpro_levels'] ) : array();

		// Build new plans array
		$new_plans = array();

		foreach ( $woo_subscriptions as $product_id ) {
			$new_plans[] = array(
				'id'   => $product_id,
				'type' => 'woo_subscription',
			);

			// Update reverse mapping
			PlanMapper::add_course_to_plan( $product_id, 'woo_subscription', $post_id );
		}

		foreach ( $pmpro_levels as $level_id ) {
			$new_plans[] = array(
				'id'   => $level_id,
				'type' => 'pmpro_level',
			);

			// Update reverse mapping
			PlanMapper::add_course_to_plan( $level_id, 'pmpro_level', $post_id );
		}

		// Remove course from plans that were unchecked
		foreach ( $current_plans as $plan ) {
			$still_selected = false;

			if ( $plan['type'] === 'woo_subscription' && in_array( $plan['id'], $woo_subscriptions ) ) {
				$still_selected = true;
			} elseif ( $plan['type'] === 'pmpro_level' && in_array( $plan['id'], $pmpro_levels ) ) {
				$still_selected = true;
			}

			if ( ! $still_selected ) {
				PlanMapper::remove_course_from_plan( $plan['id'], $plan['type'], $post_id );
			}
		}

		// Save new plans
		update_post_meta( $post_id, '_subscription_plans', $new_plans );
	}

	/**
	 * Get WooCommerce subscription products.
	 *
	 * @return array Array of product ID => product name.
	 */
	private static function get_woo_subscription_products() {
		$products = array();

		if ( ! class_exists( 'WC_Subscriptions' ) ) {
			return $products;
		}

		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'tax_query'      => array(
				array(
					'taxonomy' => 'product_type',
					'field'    => 'slug',
					'terms'    => array( 'subscription', 'variable-subscription' ),
				),
			),
		);

		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$products[ get_the_ID() ] = get_the_title();
			}
			wp_reset_postdata();
		}

		return $products;
	}

	/**
	 * Get PMPro membership levels.
	 *
	 * @return array Array of level ID => level name.
	 */
	private static function get_pmpro_levels() {
		$levels = array();

		if ( ! defined( 'PMPRO_VERSION' ) || ! function_exists( 'pmpro_getAllLevels' ) ) {
			return $levels;
		}

		$all_levels = pmpro_getAllLevels( true, true );

		foreach ( $all_levels as $level ) {
			$levels[ $level->id ] = $level->name;
		}

		return $levels;
	}
}
