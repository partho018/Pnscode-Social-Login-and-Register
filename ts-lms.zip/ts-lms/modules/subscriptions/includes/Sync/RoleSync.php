<?php
/**
 * Role Sync
 *
 * Synchronizes WordPress roles based on subscription status.
 *
 * @package TS_LMS\Modules\Subscriptions
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions\Sync;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * RoleSync class.
 */
class RoleSync {

	/**
	 * Initialize role sync.
	 *
	 * @return void
	 */
	public static function init() {
		// Hook into subscription events
		add_action( 'ts_lms_woo_subscription_activated', array( __CLASS__, 'sync_on_change' ), 10, 2 );
		add_action( 'ts_lms_woo_subscription_expired', array( __CLASS__, 'sync_on_change' ), 10, 2 );
		add_action( 'ts_lms_pmpro_level_activated', array( __CLASS__, 'sync_on_change' ), 10, 2 );
		add_action( 'ts_lms_pmpro_level_expired', array( __CLASS__, 'sync_on_change' ), 10, 2 );

		// Hook into general enrollment status changes
		add_action( 'ts_lms_enrollment_status_updated', array( __CLASS__, 'sync_on_status_update' ), 10, 3 );
		add_action( 'ts_lms_enrollment_status_updated_pmpro', array( __CLASS__, 'sync_on_status_update' ), 10, 3 );
		add_action( 'ts_lms_student_unenrolled', array( __CLASS__, 'sync_on_unenroll' ), 10, 2 );
	}

	/**
	 * Wrapper for sync_on_activation/expiry to use common handler.
	 */
	public static function sync_on_change( $id, $user_id ) {
		self::sync_user_role( $user_id );
	}

	/**
	 * Sync on status update.
	 */
	public static function sync_on_status_update( $user_id, $id, $status ) {
		self::sync_user_role( $user_id );
	}

	/**
	 * Sync on unenroll.
	 */
	public static function sync_on_unenroll( $course_id, $user_id ) {
		self::sync_user_role( $user_id );
	}



	/**
	 * Sync user role based on active subscriptions.
	 *
	 * @param int $user_id User ID.
	 * @return void
	 */
	public static function sync_user_role( $user_id ) {
		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return;
		}

		// Get role mappings
		$role_mappings = get_option( 'ts_lms_subscription_role_mappings', array() );

		if ( empty( $role_mappings ) ) {
			return; // No role mappings configured
		}

		// Get user's active subscriptions
		global $wpdb;
		$table = $wpdb->prefix . 'ts_course_enrollments';

		$subscriptions = $wpdb->get_results( $wpdb->prepare(
			"SELECT DISTINCT subscription_id, subscription_type
			FROM {$table}
			WHERE user_id = %d
			AND subscription_id IS NOT NULL
			AND subscription_type IS NOT NULL
			AND status = 'active'",
			$user_id
		) );

		$target_role = null;

		// Find the highest priority role
		foreach ( $subscriptions as $subscription ) {
			$key = $subscription->subscription_type . '_' . $subscription->subscription_id;

			if ( isset( $role_mappings[ $key ] ) ) {
				$target_role = $role_mappings[ $key ];
				break; // Use first matching role (can be enhanced with priority)
			}
		}

		// Update user role
		if ( $target_role ) {
			if ( ! in_array( $target_role, $user->roles ) ) {
				// Remove old subscription-related roles
				foreach ( array_unique( array_values( $role_mappings ) ) as $role ) {
					if ( in_array( $role, $user->roles ) ) {
						$user->remove_role( $role );
					}
				}

				// Add new role
				$user->add_role( $target_role );

				do_action( 'ts_lms_user_role_synced', $user_id, $target_role );
			}
		} else {
			// No active subscription, remove all mapped roles
			$removed = false;
			foreach ( array_unique( array_values( $role_mappings ) ) as $role ) {
				if ( in_array( $role, $user->roles ) ) {
					$user->remove_role( $role );
					$removed = true;
				}
			}

			if ( $removed ) {
				do_action( 'ts_lms_user_role_synced', $user_id, null );
			}
		}
	}

	/**
	 * Add role mapping for a subscription plan.
	 *
	 * @param int    $plan_id   Plan ID.
	 * @param string $plan_type Plan type.
	 * @param string $role      WordPress role.
	 * @return bool True on success, false on failure.
	 */
	public static function add_role_mapping( $plan_id, $plan_type, $role ) {
		$role_mappings = get_option( 'ts_lms_subscription_role_mappings', array() );
		$key = $plan_type . '_' . $plan_id;
		$role_mappings[ $key ] = $role;

		return update_option( 'ts_lms_subscription_role_mappings', $role_mappings );
	}

	/**
	 * Remove role mapping for a subscription plan.
	 *
	 * @param int    $plan_id   Plan ID.
	 * @param string $plan_type Plan type.
	 * @return bool True on success, false on failure.
	 */
	public static function remove_role_mapping( $plan_id, $plan_type ) {
		$role_mappings = get_option( 'ts_lms_subscription_role_mappings', array() );
		$key = $plan_type . '_' . $plan_id;

		if ( isset( $role_mappings[ $key ] ) ) {
			unset( $role_mappings[ $key ] );
			return update_option( 'ts_lms_subscription_role_mappings', $role_mappings );
		}

		return false;
	}

	/**
	 * Get role mapping for a subscription plan.
	 *
	 * @param int    $plan_id   Plan ID.
	 * @param string $plan_type Plan type.
	 * @return string|null Role or null if not mapped.
	 */
	public static function get_role_for_subscription( $plan_id, $plan_type ) {
		$role_mappings = get_option( 'ts_lms_subscription_role_mappings', array() );
		$key = $plan_type . '_' . $plan_id;

		return isset( $role_mappings[ $key ] ) ? $role_mappings[ $key ] : null;
	}
}
