<?php
/**
 * Subscription Resolver
 *
 * Core subscription access resolver that determines if a user can access
 * a course based on their subscription status.
 *
 * @package TS_LMS\Modules\Subscriptions
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions\Access;

use TS_LMS\Modules\Courses\Managers\CourseManager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SubscriptionResolver class.
 */
class SubscriptionResolver {
	/**
	 * Static cache for user subscriptions.
	 * @var array
	 */
	private static $subscription_cache = array();

	/**
	 * Static cache for subscription courses.
	 * @var array
	 */
	private static $course_cache = array();

	/**
	 * Static cache for course access results.
	 * @var array
	 */
	private static $access_cache = array();

	/**
	 * Recursion protection flag.
	 *
	 * @var bool
	 */
	private static $checking = false;


	/**
	 * Initialize resolver.
	 *
	 * @return void
	 */
	public static function init() {
		// Hook into course access filter
		add_filter( 'ts_lms_can_access_course', array( __CLASS__, 'filter_course_access' ), 5, 4 );
	}

	/**
	 * Filter course access based on subscription.
	 *
	 * @param bool   $has_access Current access status.
	 * @param int    $course_id  Course ID.
	 * @param int    $user_id    User ID.
	 * @param string $reason     Access reason.
	 * @return bool Modified access status.
	 */
	public static function filter_course_access( $has_access, $course_id, $user_id, $reason ) {
		// Don't override admin or instructor access
		if ( in_array( $reason, array( 'administrator', 'instructor' ) ) ) {
			return $has_access;
		}

		// Recursion protection
		if ( self::$checking ) {
			return $has_access;
		}

		self::$checking = true;

		// Check subscription access
		$subscription_access = self::can_access_course( $course_id, $user_id );

		self::$checking = false;

		// If subscription grants access, return true
		if ( $subscription_access === true ) {
			return true;
		}

		// Otherwise, fall back to original access check
		return $has_access;
	}

	/**
	 * Check if user can access a course based on subscription.
	 *
	 * @param int $course_id Course ID.
	 * @param int $user_id   User ID.
	 * @return bool True if user has subscription access, false otherwise.
	 */
	public static function can_access_course( $course_id, $user_id ) {
		$cache_key = "{$user_id}_{$course_id}";
		if ( isset( self::$access_cache[ $cache_key ] ) ) {
			return self::$access_cache[ $cache_key ];
		}

		// Get user's active subscriptions
		$subscriptions = self::get_user_subscriptions( $user_id );

		if ( empty( $subscriptions ) ) {
			return self::$access_cache[ $cache_key ] = false;
		}

		// Check each subscription
		foreach ( $subscriptions as $subscription ) {
			$courses = self::get_subscription_courses( $subscription['id'], $subscription['type'] );

			if ( in_array( $course_id, $courses ) ) {
				// Check if subscription is active or in grace period
				if ( self::is_subscription_active( $subscription['id'], $subscription['type'], $user_id ) ) {
					return self::$access_cache[ $cache_key ] = true;
				}

				// Check grace period
				if ( self::is_in_grace_period( $subscription['enrollment_id'] ) ) {
					return self::$access_cache[ $cache_key ] = true;
				}
			}
		}

		return self::$access_cache[ $cache_key ] = false;
	}

	/**
	 * Get user's active subscriptions.
	 *
	 * @param int $user_id User ID.
	 * @return array Array of subscription data.
	 */
	public static function get_user_subscriptions( $user_id ) {
		if ( isset( self::$subscription_cache[ $user_id ] ) ) {
			return self::$subscription_cache[ $user_id ];
		}

		global $wpdb;

		$table = $wpdb->prefix . 'ts_course_enrollments';
		$subscriptions = array();

		// Get enrollments with subscription data
		$results = $wpdb->get_results( $wpdb->prepare(
			"SELECT subscription_id, subscription_type, id as enrollment_id, expires_at, grace_period_ends
			FROM {$table}
			WHERE user_id = %d
			AND subscription_id IS NOT NULL
			AND subscription_type IS NOT NULL
			AND status IN ('active', 'grace_period')",
			$user_id
		) );

		$subscriptions = array();
		foreach ( $results as $row ) {
			$subscriptions[] = array(
				'id'                => $row->subscription_id,
				'type'              => $row->subscription_type,
				'enrollment_id'     => $row->enrollment_id,
				'expires_at'        => $row->expires_at,
				'grace_period_ends' => $row->grace_period_ends,
			);
		}

		self::$subscription_cache[ $user_id ] = $subscriptions;

		return $subscriptions;
	}

	/**
	 * Get courses mapped to a subscription.
	 *
	 * @param int    $subscription_id   Subscription ID.
	 * @param string $type Subscription type.
	 * @return array Array of course IDs.
	 */
	public static function get_subscription_courses( $subscription_id, $type ) {
		$cache_key = "{$type}_{$subscription_id}";
		if ( isset( self::$course_cache[ $cache_key ] ) ) {
			return self::$course_cache[ $cache_key ];
		}

		$courses = PlanMapper::get_plan_courses( $subscription_id, $type );

		$courses = apply_filters( 'ts_lms_subscription_courses', $courses, $subscription_id, $type );

		self::$course_cache[ $cache_key ] = $courses;

		return $courses;
	}

	/**
	 * Check if subscription is active.
	 *
	 * @param int    $subscription_id   Subscription ID.
	 * @param string $subscription_type Subscription type.
	 * @param int    $user_id           User ID.
	 * @return bool True if active, false otherwise.
	 */
	public static function is_subscription_active( $subscription_id, $subscription_type, $user_id = null ) {
		if ( $subscription_type === 'woo_subscriptions' ) {
			return self::is_woo_subscription_active( $subscription_id );
		} elseif ( $subscription_type === 'pmpro' ) {
			return self::is_pmpro_level_active( $subscription_id, $user_id );
		}

		return apply_filters( 'ts_lms_is_subscription_active', false, $subscription_id, $subscription_type, $user_id );
	}

	/**
	 * Check if WooCommerce subscription is active.
	 *
	 * @param int $subscription_id Subscription ID.
	 * @return bool True if active, false otherwise.
	 */
	private static function is_woo_subscription_active( $subscription_id ) {
		if ( ! function_exists( 'wcs_get_subscription' ) ) {
			return false;
		}

		$subscription = wcs_get_subscription( $subscription_id );
		if ( ! $subscription ) {
			return false;
		}

		return $subscription->has_status( array( 'active', 'pending-cancel' ) );
	}

	/**
	 * Check if PMPro membership level is active.
	 *
	 * @param int $level_id Level ID.
	 * @return bool True if active, false otherwise.
	 */
	private static function is_pmpro_level_active( $level_id, $user_id = null ) {
		if ( ! function_exists( 'pmpro_hasMembershipLevel' ) ) {
			return false;
		}

		return pmpro_hasMembershipLevel( $level_id, $user_id );
	}

	/**
	 * Check if enrollment is in grace period.
	 *
	 * @param int $enrollment_id Enrollment ID.
	 * @return bool True if in grace period, false otherwise.
	 */
	public static function is_in_grace_period( $enrollment_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_course_enrollments';

		$grace_period_ends = $wpdb->get_var( $wpdb->prepare(
			"SELECT grace_period_ends FROM {$table} WHERE id = %d",
			$enrollment_id
		) );

		if ( ! $grace_period_ends ) {
			return false;
		}

		$current_time = current_time( 'mysql' );
		return $grace_period_ends > $current_time;
	}

	/**
	 * Get detailed access status for a course.
	 *
	 * @param int $course_id Course ID.
	 * @param int $user_id   User ID.
	 * @return array Access status with reason.
	 */
	public static function get_access_status( $course_id, $user_id ) {
		$status = array(
			'has_access'   => false,
			'reason'       => 'no_subscription',
			'subscription' => null,
			'grace_period' => false,
		);

		$subscriptions = self::get_user_subscriptions( $user_id );

		foreach ( $subscriptions as $subscription ) {
			$courses = self::get_subscription_courses( $subscription['id'], $subscription['type'] );

			if ( in_array( $course_id, $courses ) ) {
				$status['subscription'] = $subscription;

				if ( self::is_subscription_active( $subscription['id'], $subscription['type'] ) ) {
					$status['has_access'] = true;
					$status['reason'] = 'active_subscription';
					return $status;
				}

				if ( self::is_in_grace_period( $subscription['enrollment_id'] ) ) {
					$status['has_access'] = true;
					$status['reason'] = 'grace_period';
					$status['grace_period'] = true;
					return $status;
				}

				$status['reason'] = 'subscription_expired';
			}
		}

		return $status;
	}
}
