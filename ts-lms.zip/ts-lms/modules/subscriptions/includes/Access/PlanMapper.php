<?php
/**
 * Plan Mapper
 *
 * Manages mapping between subscription plans and courses.
 *
 * @package TS_LMS\Modules\Subscriptions
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions\Access;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PlanMapper class.
 */
class PlanMapper {

	/**
	 * Initialize plan mapper.
	 *
	 * @return void
	 */
	public static function init() {
		// Initialization hooks if needed
	}

	/**
	 * Map a subscription plan to courses.
	 *
	 * @param int    $plan_id    Plan ID (subscription product ID or membership level ID).
	 * @param string $plan_type  Plan type ('woo_subscriptions' or 'pmpro').
	 * @param array  $course_ids Array of course IDs.
	 * @return bool True on success, false on failure.
	 */
	public static function map_plan_to_courses( $plan_id, $plan_type, $course_ids ) {
		// Validate plan type
		if ( ! in_array( $plan_type, array( 'woo_subscriptions', 'pmpro' ) ) ) {
			return false;
		}

		// Store mapping in option
		$option_key = self::get_mapping_option_key( $plan_id, $plan_type );
		$result = update_option( $option_key, $course_ids );

		// Also store reverse mapping on each course
		foreach ( $course_ids as $course_id ) {
			self::add_plan_to_course( $course_id, $plan_id, $plan_type );
		}

		do_action( 'ts_lms_plan_mapped', $plan_id, $plan_type, $course_ids );

		return $result;
	}

	/**
	 * Get courses mapped to a plan.
	 *
	 * @param int    $plan_id   Plan ID.
	 * @param string $plan_type Plan type.
	 * @return array Array of course IDs.
	 */
	public static function get_plan_courses( $plan_id, $plan_type ) {
		$option_key = self::get_mapping_option_key( $plan_id, $plan_type );
		$courses = get_option( $option_key, array() );

		return is_array( $courses ) ? $courses : array();
	}

	/**
	 * Remove plan mapping.
	 *
	 * @param int    $plan_id   Plan ID.
	 * @param string $plan_type Plan type.
	 * @return bool True on success, false on failure.
	 */
	public static function remove_plan_mapping( $plan_id, $plan_type ) {
		// Get courses before removing
		$courses = self::get_plan_courses( $plan_id, $plan_type );

		// Remove reverse mappings
		foreach ( $courses as $course_id ) {
			self::remove_plan_from_course( $course_id, $plan_id, $plan_type );
		}

		// Remove main mapping
		$option_key = self::get_mapping_option_key( $plan_id, $plan_type );
		return delete_option( $option_key );
	}

	/**
	 * Get all plans that grant access to a course.
	 *
	 * @param int $course_id Course ID.
	 * @return array Array of plans with 'id' and 'type' keys.
	 */
	public static function get_course_plans( $course_id ) {
		$plans = get_post_meta( $course_id, '_subscription_plans', true );
		return is_array( $plans ) ? $plans : array();
	}

	/**
	 * Add a plan to a course's plan list.
	 *
	 * @param int    $course_id Course ID.
	 * @param int    $plan_id   Plan ID.
	 * @param string $plan_type Plan type.
	 * @return bool True on success, false on failure.
	 */
	private static function add_plan_to_course( $course_id, $plan_id, $plan_type ) {
		$plans = self::get_course_plans( $course_id );

		// Check if plan already exists
		foreach ( $plans as $plan ) {
			if ( $plan['id'] == $plan_id && $plan['type'] === $plan_type ) {
				return true; // Already exists
			}
		}

		// Add new plan
		$plans[] = array(
			'id'   => $plan_id,
			'type' => $plan_type,
		);

		return update_post_meta( $course_id, '_subscription_plans', $plans );
	}

	/**
	 * Remove a plan from a course's plan list.
	 *
	 * @param int    $course_id Course ID.
	 * @param int    $plan_id   Plan ID.
	 * @param string $plan_type Plan type.
	 * @return bool True on success, false on failure.
	 */
	private static function remove_plan_from_course( $course_id, $plan_id, $plan_type ) {
		$plans = self::get_course_plans( $course_id );

		// Filter out the plan
		$plans = array_filter( $plans, function( $plan ) use ( $plan_id, $plan_type ) {
			return ! ( $plan['id'] == $plan_id && $plan['type'] === $plan_type );
		} );

		// Re-index array
		$plans = array_values( $plans );

		return update_post_meta( $course_id, '_subscription_plans', $plans );
	}

	/**
	 * Get option key for plan mapping.
	 *
	 * @param int    $plan_id   Plan ID.
	 * @param string $plan_type Plan type.
	 * @return string Option key.
	 */
	private static function get_mapping_option_key( $plan_id, $plan_type ) {
		return "ts_lms_plan_courses_{$plan_type}_{$plan_id}";
	}

	/**
	 * Add a course to a plan.
	 *
	 * @param int    $plan_id   Plan ID.
	 * @param string $plan_type Plan type.
	 * @param int    $course_id Course ID.
	 * @return bool True on success, false on failure.
	 */
	public static function add_course_to_plan( $plan_id, $plan_type, $course_id ) {
		$courses = self::get_plan_courses( $plan_id, $plan_type );

		if ( ! in_array( $course_id, $courses ) ) {
			$courses[] = $course_id;
			$option_key = self::get_mapping_option_key( $plan_id, $plan_type );
			update_option( $option_key, $courses );

			// Update reverse mapping
			self::add_plan_to_course( $course_id, $plan_id, $plan_type );
		}

		return true;
	}

	/**
	 * Remove a course from a plan.
	 *
	 * @param int    $plan_id   Plan ID.
	 * @param string $plan_type Plan type.
	 * @param int    $course_id Course ID.
	 * @return bool True on success, false on failure.
	 */
	public static function remove_course_from_plan( $plan_id, $plan_type, $course_id ) {
		$courses = self::get_plan_courses( $plan_id, $plan_type );
		$courses = array_diff( $courses, array( $course_id ) );
		$courses = array_values( $courses );

		$option_key = self::get_mapping_option_key( $plan_id, $plan_type );
		update_option( $option_key, $courses );

		// Update reverse mapping
		self::remove_plan_from_course( $course_id, $plan_id, $plan_type );

		return true;
	}
}
