<?php
/**
 * Fallback Handler
 *
 * Handles fallback scenarios when subscriptions expire or fail.
 *
 * @package TS_LMS\Modules\Subscriptions
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions\Fallback;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * FallbackHandler class.
 */
class FallbackHandler {

	/**
	 * Initialize fallback handler.
	 *
	 * @return void
	 */
	public static function init() {
		// Add admin notices for subscription issues
		add_action( 'admin_notices', array( __CLASS__, 'show_admin_notices' ) );
	}

	/**
	 * Show admin notices for subscription issues.
	 *
	 * @return void
	 */
	public static function show_admin_notices() {
		// Check if WooCommerce Subscriptions is enabled but not active
		if ( get_option( 'ts_lms_woo_subscriptions_enabled', 1 ) && ! class_exists( 'WC_Subscriptions' ) ) {
			?>
			<div class="notice notice-warning">
				<p>
					<?php
					printf(
						/* translators: %s: Settings page URL */
						esc_html__( 'TS LMS: WooCommerce Subscriptions integration is enabled but the plugin is not active. %s', 'ts-lms' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=ts-lms-subscriptions' ) ) . '">' . esc_html__( 'Update settings', 'ts-lms' ) . '</a>'
					);
					?>
				</p>
			</div>
			<?php
		}

		// Check if PMPro is enabled but not active
		if ( get_option( 'ts_lms_pmpro_enabled', 1 ) && ! defined( 'PMPRO_VERSION' ) ) {
			?>
			<div class="notice notice-warning">
				<p>
					<?php
					printf(
						/* translators: %s: Settings page URL */
						esc_html__( 'TS LMS: Paid Memberships Pro integration is enabled but the plugin is not active. %s', 'ts-lms' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=ts-lms-subscriptions' ) ) . '">' . esc_html__( 'Update settings', 'ts-lms' ) . '</a>'
					);
					?>
				</p>
			</div>
			<?php
		}
	}

	/**
	 * Handle subscription plugin deactivation.
	 *
	 * @param string $plugin_type Plugin type ('woo' or 'pmpro').
	 * @return void
	 */
	public static function handle_plugin_deactivation( $plugin_type ) {
		// Log deactivation
		error_log( "TS LMS: Subscription plugin deactivated: {$plugin_type}. Falling back to direct enrollment checks." );

		// Optionally disable integration
		if ( $plugin_type === 'woo' ) {
			update_option( 'ts_lms_woo_subscriptions_enabled', 0 );
		} elseif ( $plugin_type === 'pmpro' ) {
			update_option( 'ts_lms_pmpro_enabled', 0 );
		}

		do_action( 'ts_lms_subscription_plugin_deactivated', $plugin_type );
	}

	/**
	 * Get fallback access for a user.
	 *
	 * This is used when subscription plugins are not available.
	 *
	 * @param int $course_id Course ID.
	 * @param int $user_id   User ID.
	 * @return bool True if user has fallback access, false otherwise.
	 */
	public static function get_fallback_access( $course_id, $user_id ) {
		// Fall back to direct enrollment check
		return \TS_LMS\Modules\Courses\Managers\CourseManager::is_enrolled( $course_id, $user_id );
	}
}
