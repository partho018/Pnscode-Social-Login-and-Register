<?php
/**
 * Grace Period Manager
 *
 * Manages grace period logic and notifications for expired subscriptions.
 *
 * @package TS_LMS\Modules\Subscriptions
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions\Managers;

use TS_LMS\Modules\Courses\Managers\CourseManager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * GracePeriodManager class.
 */
class GracePeriodManager {

	/**
	 * Initialize grace period manager.
	 *
	 * @return void
	 */
	public static function init() {
		// Hook into cron job
		add_action( 'ts_lms_check_grace_periods', array( __CLASS__, 'check_grace_periods' ) );
	}

	/**
	 * Start grace period for an enrollment.
	 *
	 * @param int $enrollment_id Enrollment ID.
	 * @param int $days          Grace period duration in days (default: from settings).
	 * @return bool True on success, false on failure.
	 */
	public static function start_grace_period( $enrollment_id, $days = null ) {
		global $wpdb;

		if ( $days === null ) {
			$days = get_option( 'ts_lms_subscription_grace_period_days', 7 );
		}

		$table = $wpdb->prefix . 'ts_course_enrollments';

		// Calculate grace period end date
		$grace_period_ends = date( 'Y-m-d H:i:s', strtotime( "+{$days} days" ) );

		// Update enrollment
		$result = $wpdb->update(
			$table,
			array( 'grace_period_ends' => $grace_period_ends ),
			array( 'id' => $enrollment_id ),
			array( '%s' ),
			array( '%d' )
		);

		if ( $result !== false ) {
			// Get enrollment details for notification
			$enrollment = $wpdb->get_row( $wpdb->prepare(
				"SELECT user_id, course_id FROM {$table} WHERE id = %d",
				$enrollment_id
			) );

			if ( $enrollment ) {
				// Send notification
				if ( get_option( 'ts_lms_subscription_grace_notifications', 1 ) ) {
					self::send_grace_period_notification( $enrollment->user_id, $enrollment->course_id, $days );
				}

				do_action( 'ts_lms_grace_period_started', $enrollment_id, $enrollment->user_id, $enrollment->course_id, $days );
			}

			return true;
		}

		return false;
	}

	/**
	 * End grace period and unenroll user.
	 *
	 * @param int $enrollment_id Enrollment ID.
	 * @return bool True on success, false on failure.
	 */
	public static function end_grace_period( $enrollment_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_course_enrollments';

		// Get enrollment details
		$enrollment = $wpdb->get_row( $wpdb->prepare(
			"SELECT user_id, course_id FROM {$table} WHERE id = %d",
			$enrollment_id
		) );

		if ( ! $enrollment ) {
			return false;
		}

		// Unenroll student
		$result = CourseManager::unenroll_student( $enrollment->course_id, $enrollment->user_id );

		if ( $result ) {
			do_action( 'ts_lms_grace_period_ended', $enrollment_id, $enrollment->user_id, $enrollment->course_id );
		}

		return $result;
	}

	/**
	 * Check and process expired grace periods (cron job).
	 *
	 * @return void
	 */
	public static function check_grace_periods() {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_course_enrollments';
		$current_time = current_time( 'mysql' );

		// Get expired grace periods
		$expired_enrollments = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, user_id, course_id FROM {$table}
			WHERE grace_period_ends IS NOT NULL
			AND grace_period_ends < %s",
			$current_time
		) );

		foreach ( $expired_enrollments as $enrollment ) {
			self::end_grace_period( $enrollment->id );
			error_log( "TS LMS: Grace period expired for enrollment #{$enrollment->id}. User #{$enrollment->user_id} unenrolled from course #{$enrollment->course_id}." );
		}

		// Send reminders for grace periods ending soon (1 day before)
		$reminder_time = date( 'Y-m-d H:i:s', strtotime( '+1 day' ) );
		$reminder_enrollments = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, user_id, course_id, grace_period_ends FROM {$table}
			WHERE grace_period_ends IS NOT NULL
			AND grace_period_ends > %s
			AND grace_period_ends <= %s",
			$current_time,
			$reminder_time
		) );

		foreach ( $reminder_enrollments as $enrollment ) {
			self::send_grace_period_reminder( $enrollment->user_id, $enrollment->course_id, 1 );
		}
	}

	/**
	 * Send grace period notification email.
	 *
	 * @param int $user_id         User ID.
	 * @param int $course_id       Course ID.
	 * @param int $days_remaining  Days remaining in grace period.
	 * @return bool True if email sent, false otherwise.
	 */
	public static function send_grace_period_notification( $user_id, $course_id, $days_remaining ) {
		$user = get_user_by( 'id', $user_id );
		$course = get_post( $course_id );

		if ( ! $user || ! $course ) {
			return false;
		}

		$to = $user->user_email;
		$subject = sprintf(
			__( 'Your subscription for "%s" has expired', 'ts-lms' ),
			$course->post_title
		);

		$message = sprintf(
			__( "Hi %s,\n\nYour subscription for the course \"%s\" has expired. You have %d days of grace period access remaining.\n\nPlease renew your subscription to continue accessing this course.\n\nThank you!", 'ts-lms' ),
			$user->display_name,
			$course->post_title,
			$days_remaining
		);

		$message = apply_filters( 'ts_lms_grace_period_notification_message', $message, $user_id, $course_id, $days_remaining );

		return wp_mail( $to, $subject, $message );
	}

	/**
	 * Send grace period reminder email.
	 *
	 * @param int $user_id         User ID.
	 * @param int $course_id       Course ID.
	 * @param int $days_remaining  Days remaining in grace period.
	 * @return bool True if email sent, false otherwise.
	 */
	public static function send_grace_period_reminder( $user_id, $course_id, $days_remaining ) {
		$user = get_user_by( 'id', $user_id );
		$course = get_post( $course_id );

		if ( ! $user || ! $course ) {
			return false;
		}

		$to = $user->user_email;
		$subject = sprintf(
			__( 'Final reminder: Your access to "%s" expires soon', 'ts-lms' ),
			$course->post_title
		);

		$message = sprintf(
			__( "Hi %s,\n\nThis is a final reminder that your grace period access to the course \"%s\" will expire in %d day(s).\n\nPlease renew your subscription to maintain access.\n\nThank you!", 'ts-lms' ),
			$user->display_name,
			$course->post_title,
			$days_remaining
		);

		$message = apply_filters( 'ts_lms_grace_period_reminder_message', $message, $user_id, $course_id, $days_remaining );

		return wp_mail( $to, $subject, $message );
	}

	/**
	 * Clear grace period for an enrollment.
	 *
	 * @param int $enrollment_id Enrollment ID.
	 * @return bool True on success, false on failure.
	 */
	public static function clear_grace_period( $enrollment_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'ts_course_enrollments';

		$result = $wpdb->update(
			$table,
			array( 'grace_period_ends' => null ),
			array( 'id' => $enrollment_id ),
			array( '%s' ),
			array( '%d' )
		);

		return $result !== false;
	}
}
