<?php
/**
 * Subscriptions Module
 *
 * Manages subscription-based access control for courses.
 *
 * @package TS_LMS\Modules\Subscriptions
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions;

use TS_LMS\Modules\Subscriptions\Access\SubscriptionResolver;
use TS_LMS\Modules\Subscriptions\Access\PlanMapper;
use TS_LMS\Modules\Subscriptions\Integration\WooSubscriptionsIntegration;
use TS_LMS\Modules\Subscriptions\Integration\PMProIntegration;
use TS_LMS\Modules\Subscriptions\Managers\GracePeriodManager;
use TS_LMS\Modules\Subscriptions\Admin\SubscriptionSettings;
use TS_LMS\Modules\Subscriptions\Admin\PlanMappingUI;
use TS_LMS\Modules\Subscriptions\Sync\RoleSync;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Module class.
 */
class Module {

	/**
	 * Module instance.
	 *
	 * @var Module
	 */
	private static $instance = null;

	/**
	 * Get module instance.
	 *
	 * @return Module
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->init();
	}

	/**
	 * Initialize module.
	 *
	 * @return void
	 */
	private function init() {
		// Initialize core components
		SubscriptionResolver::init();
		PlanMapper::init();
		GracePeriodManager::init();

		// Initialize integrations
		WooSubscriptionsIntegration::init();
		PMProIntegration::init();

		// Initialize admin UI
		if ( is_admin() ) {
			SubscriptionSettings::init();
			PlanMappingUI::init();
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		}

		// Initialize role sync
		RoleSync::init();

		// Schedule cron jobs
		$this->schedule_cron_jobs();
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_admin_assets( $hook ) {
		if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'ts-lms-subscriptions' ) {
			return;
		}

		wp_enqueue_style(
			'ts-lms-subscriptions-admin',
			plugin_dir_url( __FILE__ ) . 'assets/css/admin-subscriptions.css',
			array(),
			time()
		);
	}

	/**
	 * Schedule cron jobs.
	 *
	 * @return void
	 */
	private function schedule_cron_jobs() {
		if ( ! wp_next_scheduled( 'ts_lms_check_grace_periods' ) ) {
			wp_schedule_event( time(), 'daily', 'ts_lms_check_grace_periods' );
		}
	}

	/**
	 * Install module.
	 *
	 * @return void
	 */
	public static function install() {
		// Update database schema
		self::update_database_schema();

		// Set default options
		add_option( 'ts_lms_subscription_grace_period_days', 7 );
		add_option( 'ts_lms_subscription_grace_notifications', 1 );
		add_option( 'ts_lms_woo_subscriptions_enabled', 1 );
		add_option( 'ts_lms_pmpro_enabled', 1 );

		// Log installation
		error_log( 'TS LMS Subscriptions Module: Installed successfully.' );
	}

	/**
	 * Update database schema.
	 *
	 * @return void
	 */
	private static function update_database_schema() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'ts_course_enrollments';
		
		// Check if table exists first
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return; // Table doesn't exist yet, it'll be created by Installer
		}

		$charset_collate = $wpdb->get_charset_collate();

		// Check if columns already exist
		$columns = $wpdb->get_results( "DESCRIBE {$table_name}" );
		$column_names = wp_list_pluck( $columns, 'Field' );

		$sql_updates = array();

		if ( ! in_array( 'subscription_id', $column_names ) ) {
			$sql_updates[] = "ALTER TABLE {$table_name} ADD COLUMN subscription_id varchar(100) DEFAULT NULL AFTER source_id";
		}

		if ( ! in_array( 'subscription_type', $column_names ) ) {
			$sql_updates[] = "ALTER TABLE {$table_name} ADD COLUMN subscription_type varchar(50) DEFAULT NULL AFTER subscription_id";
		}

		if ( ! in_array( 'expires_at', $column_names ) ) {
			$sql_updates[] = "ALTER TABLE {$table_name} ADD COLUMN expires_at datetime DEFAULT NULL AFTER subscription_type";
		}

		if ( ! in_array( 'grace_period_ends', $column_names ) ) {
			$sql_updates[] = "ALTER TABLE {$table_name} ADD COLUMN grace_period_ends datetime DEFAULT NULL AFTER expires_at";
		}

		// Execute updates
		foreach ( $sql_updates as $sql ) {
			$wpdb->query( $sql );
		}

		// Add indexes if needed
		if ( ! empty( $sql_updates ) ) {
			$wpdb->query( "ALTER TABLE {$table_name} ADD INDEX idx_subscription_id (subscription_id)" );
			$wpdb->query( "ALTER TABLE {$table_name} ADD INDEX idx_subscription_type (subscription_type)" );
			$wpdb->query( "ALTER TABLE {$table_name} ADD INDEX idx_expires_at (expires_at)" );
			$wpdb->query( "ALTER TABLE {$table_name} ADD INDEX idx_grace_period_ends (grace_period_ends)" );
		}

		update_option( 'ts_lms_subscriptions_schema_version', '1.0.0' );
	}

	/**
	 * Uninstall module.
	 *
	 * @return void
	 */
	public static function uninstall() {
		// Clear scheduled events
		wp_clear_scheduled_hook( 'ts_lms_check_grace_periods' );

		// Delete options
		delete_option( 'ts_lms_subscription_grace_period_days' );
		delete_option( 'ts_lms_subscription_grace_notifications' );
		delete_option( 'ts_lms_woo_subscriptions_enabled' );
		delete_option( 'ts_lms_pmpro_enabled' );
		delete_option( 'ts_lms_subscriptions_schema_version' );

		error_log( 'TS LMS Subscriptions Module: Uninstalled.' );
	}
}
