<?php
/**
 * Subscriptions Module Autoloader
 *
 * PSR-4 autoloader for the Subscriptions module.
 *
 * @package TS_LMS\Modules\Subscriptions
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Subscriptions;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Autoloader class.
 */
class Autoloader {

	/**
	 * Namespace prefix.
	 *
	 * @var string
	 */
	private static $prefix = 'TS_LMS\\Modules\\Subscriptions\\';

	/**
	 * Base directory.
	 *
	 * @var string
	 */
	private static $base_dir;

	/**
	 * Register autoloader.
	 *
	 * @return void
	 */
	public static function register() {
		self::$base_dir = dirname( __FILE__ ) . '/includes/';
		spl_autoload_register( array( __CLASS__, 'autoload' ) );
	}

	/**
	 * Autoload classes.
	 *
	 * @param string $class Class name.
	 * @return void
	 */
	public static function autoload( $class ) {
		// Check if class uses our namespace
		$len = strlen( self::$prefix );
		if ( strncmp( self::$prefix, $class, $len ) !== 0 ) {
			return;
		}

		// Get relative class name
		$relative_class = substr( $class, $len );

		// Convert namespace to file path
		$file = self::$base_dir . str_replace( '\\', '/', $relative_class ) . '.php';

		// Load file if it exists
		if ( file_exists( $file ) ) {
			require $file;
		}
	}
}
