-- AI Studio Module Database Schema
-- Tables for prompt templates, usage tracking, and generated content

-- Prompt Templates Table
CREATE TABLE IF NOT EXISTS `{prefix}ts_lms_ai_prompt_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `template_type` varchar(50) NOT NULL COMMENT 'course_outline, lesson_content, quiz, assignment',
  `template_name` varchar(255) NOT NULL,
  `template_content` longtext NOT NULL,
  `variables` text DEFAULT NULL COMMENT 'JSON array of available variables',
  `is_default` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `template_type` (`template_type`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Usage Logs Table
CREATE TABLE IF NOT EXISTS `{prefix}ts_lms_ai_usage_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `generator_type` varchar(50) NOT NULL COMMENT 'course_outline, lesson_content, quiz, assignment',
  `prompt_tokens` int(11) DEFAULT 0,
  `completion_tokens` int(11) DEFAULT 0,
  `total_tokens` int(11) DEFAULT 0,
  `model_used` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'success' COMMENT 'success, failed, rate_limited',
  `error_message` text DEFAULT NULL,
  `request_data` longtext DEFAULT NULL COMMENT 'JSON of request parameters',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `generator_type` (`generator_type`),
  KEY `created_at` (`created_at`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Generated Content Table
CREATE TABLE IF NOT EXISTS `{prefix}ts_lms_ai_generated_content` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `content_type` varchar(50) NOT NULL COMMENT 'course_outline, lesson_content, quiz, assignment',
  `title` varchar(255) DEFAULT NULL,
  `content` longtext NOT NULL COMMENT 'JSON or HTML content',
  `metadata` longtext DEFAULT NULL COMMENT 'JSON metadata',
  `usage_log_id` bigint(20) unsigned DEFAULT NULL,
  `is_used` tinyint(1) DEFAULT 0 COMMENT 'Whether content was actually used in course',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `content_type` (`content_type`),
  KEY `usage_log_id` (`usage_log_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
