<?php
/**
 * AI Studio Module
 *
 * Main module class for the AI-powered content generation system.
 *
 * @package TS_LMS\Modules\AIStudio
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio;

use TS_LMS\Modules\AIStudio\Admin\AIStudioPage;
use TS_LMS\Modules\AIStudio\API\AIStudioController;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Module class.
 */
class Module {

	/**
	 * Module instance.
	 *
	 * @var Module
	 */
	private static $instance = null;

	/**
	 * Get module instance.
	 *
	 * @return Module
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	private function init_hooks() {
		// Register autoloader
		Autoloader::register();

		// Initialize admin pages
		if ( is_admin() ) {
			// add_action( 'admin_menu', array( $this, 'register_admin_menu' ), 12 );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		}

		// Initialize REST API
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

		// Initialize AJAX handlers
		add_action( 'wp_ajax_ts_lms_ai_generate', array( $this, 'ajax_generate_content' ) );
		add_action( 'wp_ajax_ts_lms_ai_save_template', array( $this, 'ajax_save_template' ) );
		add_action( 'wp_ajax_ts_lms_ai_get_usage_stats', array( $this, 'ajax_get_usage_stats' ) );
	}

	/**
	 * Install module (create database tables).
	 *
	 * @return void
	 */
	public static function install() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$table_prefix = $wpdb->prefix;

		// Read schema file
		$schema_file = __DIR__ . '/database/schema.sql';
		if ( ! file_exists( $schema_file ) ) {
			return;
		}

		$schema = file_get_contents( $schema_file );
		$schema = str_replace( '{prefix}', $table_prefix, $schema );

		// Split into individual statements
		$statements = array_filter(
			array_map(
				'trim',
				explode( ';', $schema )
			)
		);

		// Execute each statement
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		foreach ( $statements as $statement ) {
			// Skip comments and empty statements
			if ( empty( $statement ) || strpos( $statement, '--' ) === 0 ) {
				continue;
			}

			// Only execute CREATE TABLE statements
			if ( strpos( $statement, 'CREATE TABLE' ) !== false ) {
				dbDelta( $statement );
			}
		}

		// Seed default templates
		self::seed_default_templates();

		// Set default options
		add_option( 'ts_lms_ai_studio_enabled', 1 );
		add_option( 'ts_lms_ai_usage_limit_admin', 1000 ); // tokens per day
		add_option( 'ts_lms_ai_usage_limit_instructor', 500 );
		add_option( 'ts_lms_ai_usage_limit_editor', 500 );
		add_option( 'ts_lms_ai_model', 'gpt-3.5-turbo' );
	}

	/**
	 * Seed default prompt templates.
	 *
	 * @return void
	 */
	private static function seed_default_templates() {
		global $wpdb;
		$table = $wpdb->prefix . 'ts_lms_ai_prompt_templates';

		// Check if templates already exist
		$count = $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
		if ( $count > 0 ) {
			return;
		}

		require_once __DIR__ . '/includes/Templates/DefaultTemplates.php';
		$defaults = Templates\DefaultTemplates::get_all();

		foreach ( $defaults as $template ) {
			$wpdb->insert(
				$table,
				array(
					'template_type'    => $template['type'],
					'template_name'    => $template['name'],
					'template_content' => $template['content'],
					'variables'        => wp_json_encode( $template['variables'] ),
					'is_default'       => 1,
					'is_active'        => 1,
				),
				array( '%s', '%s', '%s', '%s', '%d', '%d' )
			);
		}
	}

	/**
	 * Register admin menu.
	 *
	 * @return void
	 */
	public function register_admin_menu() {
		add_submenu_page(
			'ts-lms',
			__( 'AI Studio', 'ts-lms' ),
			__( 'AI Studio', 'ts-lms' ),
			'edit_posts',
			'ts-lms-ai-studio',
			array( AIStudioPage::class, 'render' )
		);
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_admin_assets( $hook ) {
		// Only load on AI Studio page
		if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'ts-lms-ai-studio' ) {
			return;
		}

		// Enqueue CSS
		wp_enqueue_style(
			'ts-lms-ai-studio',
			plugin_dir_url( __FILE__ ) . 'assets/css/admin-ai-studio.css',
			array(),
			time()
		);

		// Enqueue JS
		wp_enqueue_script(
			'ts-lms-ai-studio',
			plugin_dir_url( __FILE__ ) . 'assets/js/admin-ai-studio.js',
			array( 'jquery', 'wp-api' ),
			time(),
			true
		);

		// Localize script
		wp_localize_script(
			'ts-lms-ai-studio',
			'tsLmsAIStudio',
			array(
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'restUrl'  => rest_url( 'ts-lms/v1/ai-studio/' ),
				'nonce'    => wp_create_nonce( 'ts_lms_ai_studio' ),
				'restNonce' => wp_create_nonce( 'wp_rest' ),
				'i18n'     => array(
					'generating'     => __( 'Generating content...', 'ts-lms' ),
					'error'          => __( 'Error generating content. Please try again.', 'ts-lms' ),
					'success'        => __( 'Content generated successfully!', 'ts-lms' ),
					'limitReached'   => __( 'Usage limit reached. Please try again later.', 'ts-lms' ),
					'invalidApiKey'  => __( 'Invalid API key. Please check your settings.', 'ts-lms' ),
					'templateSaved'  => __( 'Template saved successfully!', 'ts-lms' ),
					'confirmReset'   => __( 'Are you sure you want to reset this template to default?', 'ts-lms' ),
				),
			)
		);
	}

	/**
	 * Register REST API routes.
	 *
	 * @return void
	 */
	public function register_rest_routes() {
		$controller = new AIStudioController();
		$controller->register_routes();
	}

	/**
	 * AJAX handler for generating content.
	 *
	 * @return void
	 */
	public function ajax_generate_content() {
		check_ajax_referer( 'ts_lms_ai_studio', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
		}

		$generator_type = sanitize_text_field( $_POST['generator_type'] ?? '' );
		$params = isset( $_POST['params'] ) ? $this->sanitize_params( $_POST['params'] ) : array();

		try {
			$result = $this->generate_content( $generator_type, $params );
			wp_send_json_success( $result );
		} catch ( \Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	/**
	 * AJAX handler for saving templates.
	 *
	 * @return void
	 */
	public function ajax_save_template() {
		check_ajax_referer( 'ts_lms_ai_studio', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
		}

		$template_id = intval( $_POST['template_id'] ?? 0 );
		$template_content = wp_kses_post( $_POST['template_content'] ?? '' );

		try {
			$repository = new Templates\PromptTemplateRepository();
			$repository->update( $template_id, array( 'template_content' => $template_content ) );
			wp_send_json_success( array( 'message' => __( 'Template saved successfully!', 'ts-lms' ) ) );
		} catch ( \Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	/**
	 * AJAX handler for getting usage statistics.
	 *
	 * @return void
	 */
	public function ajax_get_usage_stats() {
		check_ajax_referer( 'ts_lms_ai_studio', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
		}

		$user_id = get_current_user_id();
		$period = sanitize_text_field( $_POST['period'] ?? 'today' );

		try {
			$tracker = new Usage\UsageTracker();
			$stats = $tracker->get_user_usage( $user_id, $period );
			wp_send_json_success( $stats );
		} catch ( \Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}
	}

	/**
	 * Generate content using appropriate generator.
	 *
	 * @param string $generator_type Generator type.
	 * @param array  $params         Parameters.
	 * @return array Generated content.
	 * @throws \Exception If generator type is invalid.
	 */
	private function generate_content( $generator_type, $params ) {
		$generator_map = array(
			'course_outline'  => 'TS_LMS\\Modules\\AIStudio\\Generators\\CourseOutlineGenerator',
			'lesson_content'  => 'TS_LMS\\Modules\\AIStudio\\Generators\\LessonContentGenerator',
			'quiz'            => 'TS_LMS\\Modules\\AIStudio\\Generators\\QuizGenerator',
			'assignment'      => 'TS_LMS\\Modules\\AIStudio\\Generators\\AssignmentGenerator',
		);

		if ( ! isset( $generator_map[ $generator_type ] ) ) {
			throw new \Exception( __( 'Invalid generator type.', 'ts-lms' ) );
		}

		$generator_class = $generator_map[ $generator_type ];
		$generator = new $generator_class();

		return $generator->generate( $params );
	}

	/**
	 * Sanitize parameters.
	 *
	 * @param array $params Raw parameters.
	 * @return array Sanitized parameters.
	 */
	private function sanitize_params( $params ) {
		$sanitized = array();

		foreach ( $params as $key => $value ) {
			if ( is_array( $value ) ) {
				$sanitized[ $key ] = $this->sanitize_params( $value );
			} else {
				$sanitized[ $key ] = sanitize_text_field( $value );
			}
		}

		return $sanitized;
	}
}
