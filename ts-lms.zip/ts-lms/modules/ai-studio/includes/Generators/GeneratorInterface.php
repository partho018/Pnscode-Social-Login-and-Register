<?php
/**
 * Generator Interface
 *
 * Interface defining the contract for all AI content generators.
 *
 * @package TS_LMS\Modules\AIStudio\Generators
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Generators;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * GeneratorInterface interface.
 */
interface GeneratorInterface {

	/**
	 * Generate content based on parameters.
	 *
	 * @param array $params Parameters for generation.
	 * @return array Generated content and metadata.
	 * @throws \Exception On failure.
	 */
	public function generate( array $params ): array;

	/**
	 * Validate parameters.
	 *
	 * @param array $params Parameters to validate.
	 * @return bool|WP_Error True if valid, WP_Error otherwise.
	 */
	public function validate( array $params );

	/**
	 * Get required parameters.
	 *
	 * @return array List of required parameter keys.
	 */
	public function get_required_params(): array;

	/**
	 * Get generator type.
	 *
	 * @return string Generator type.
	 */
	public function get_type(): string;
}
