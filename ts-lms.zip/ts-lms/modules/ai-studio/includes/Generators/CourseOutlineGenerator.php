<?php
/**
 * Course Outline Generator
 *
 * Generates structured course outlines.
 *
 * @package TS_LMS\Modules\AIStudio\Generators
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Generators;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CourseOutlineGenerator class.
 */
class CourseOutlineGenerator extends BaseGenerator {

	/**
	 * Get required parameters.
	 *
	 * @return array List of required parameter keys.
	 */
	public function get_required_params(): array {
		return array(
			'course_title',
			'topic',
			'difficulty_level',
			'target_audience',
			'duration',
		);
	}

	/**
	 * Get generator type.
	 *
	 * @return string Generator type.
	 */
	public function get_type(): string {
		return 'course_outline';
	}
}
