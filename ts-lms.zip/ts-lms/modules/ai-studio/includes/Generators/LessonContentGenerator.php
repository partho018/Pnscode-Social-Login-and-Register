<?php
/**
 * Lesson Content Generator
 *
 * Generates detailed lesson content.
 *
 * @package TS_LMS\Modules\AIStudio\Generators
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Generators;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * LessonContentGenerator class.
 */
class LessonContentGenerator extends BaseGenerator {

	/**
	 * Get required parameters.
	 *
	 * @return array List of required parameter keys.
	 */
	public function get_required_params(): array {
		return array(
			'lesson_title',
			'topic',
			'learning_objectives',
			'target_audience',
			'duration',
			'content_format',
		);
	}

	/**
	 * Get generator type.
	 *
	 * @return string Generator type.
	 */
	public function get_type(): string {
		return 'lesson_content';
	}
}
