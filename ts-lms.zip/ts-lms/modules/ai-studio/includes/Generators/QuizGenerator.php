<?php
/**
 * Quiz Generator
 *
 * Generates quiz questions.
 *
 * @package TS_LMS\Modules\AIStudio\Generators
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Generators;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * QuizGenerator class.
 */
class QuizGenerator extends BaseGenerator {

	/**
	 * Get required parameters.
	 *
	 * @return array List of required parameter keys.
	 */
	public function get_required_params(): array {
		return array(
			'topic',
			'difficulty_level',
			'question_count',
			'question_types',
			'learning_objectives',
		);
	}

	/**
	 * Get generator type.
	 *
	 * @return string Generator type.
	 */
	public function get_type(): string {
		return 'quiz';
	}
}
