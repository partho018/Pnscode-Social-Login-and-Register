<?php
/**
 * Base Generator
 *
 * Abstract base class for all AI content generators.
 *
 * @package TS_LMS\Modules\AIStudio\Generators
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Generators;

use TS_LMS\Modules\AIStudio\API\OpenAIClient;
use TS_LMS\Modules\AIStudio\Templates\PromptTemplateRepository;
use TS_LMS\Modules\AIStudio\Usage\UsageTracker;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * BaseGenerator abstract class.
 */
abstract class BaseGenerator implements GeneratorInterface {

	/**
	 * OpenAI client.
	 *
	 * @var OpenAIClient
	 */
	protected $client;

	/**
	 * Usage tracker.
	 *
	 * @var UsageTracker
	 */
	protected $usage_tracker;

	/**
	 * Template repository.
	 *
	 * @var PromptTemplateRepository
	 */
	protected $template_repository;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->client = new OpenAIClient();
		$this->usage_tracker = new UsageTracker();
		$this->template_repository = new PromptTemplateRepository();
	}

	/**
	 * Validate parameters.
	 *
	 * @param array $params Parameters to validate.
	 * @return bool|WP_Error True if valid, WP_Error otherwise.
	 */
	public function validate( array $params ) {
		$required = $this->get_required_params();
		$missing = array();

		foreach ( $required as $key ) {
			if ( ! isset( $params[ $key ] ) || empty( $params[ $key ] ) ) {
				$missing[] = $key;
			}
		}

		if ( ! empty( $missing ) ) {
			return new \WP_Error(
				'missing_params',
				sprintf(
					/* translators: %s: list of missing parameters */
					__( 'Missing required parameters: %s', 'ts-lms' ),
					implode( ', ', $missing )
				)
			);
		}

		return true;
	}

	/**
	 * Generate content.
	 *
	 * @param array $params Parameters for generation.
	 * @return array Generated content and metadata.
	 * @throws \Exception On failure.
	 */
	public function generate( array $params ): array {
		$user_id = get_current_user_id();

		// 1. Validate parameters
		$validation = $this->validate( $params );
		if ( is_wp_error( $validation ) ) {
			throw new \Exception( $validation->get_error_message() );
		}

		// 2. Check usage limits
		$can_generate = $this->usage_tracker->can_generate( $user_id, $this->get_type() );
		if ( is_wp_error( $can_generate ) ) {
			throw new \Exception( $can_generate->get_error_message() );
		}

		// 3. Load and process template
		$template = $this->template_repository->find_by_type( $this->get_type() );
		if ( ! $template ) {
			throw new \Exception( __( 'Prompt template not found.', 'ts-lms' ) );
		}

		$prompt = $template->replace_variables( $params );

		// 4. Call OpenAI API
		$options = array(
			'response_format' => array( 'type' => 'json_object' ),
		);

		$response = $this->client->send_request(
			array(
				array(
					'role'    => 'system',
					'content' => 'You are a professional educational assistant. Always return response in valid JSON format.',
				),
				array(
					'role'    => 'user',
					'content' => $prompt,
				),
			),
			$options
		);

		if ( is_wp_error( $response ) ) {
			// Log failed usage
			$this->usage_tracker->log_usage(
				$user_id,
				$this->get_type(),
				array( 'prompt_tokens' => 0, 'completion_tokens' => 0, 'total_tokens' => 0 ),
				'failed',
				$params,
				$response->get_error_message()
			);
			throw new \Exception( $response->get_error_message() );
		}

		// 5. Parse response
		$content_json = $response['choices'][0]['message']['content'] ?? '{}';
		$content_data = json_decode( $content_json, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			// Try to recover if it's not perfect JSON
			$content_data = $this->parse_malformed_json( $content_json );
			if ( ! $content_data ) {
				throw new \Exception( __( 'Failed to parse AI response as JSON.', 'ts-lms' ) );
			}
		}

		// 6. Log successful usage
		$token_usage = $this->client->get_token_usage( $response );
		$this->usage_tracker->log_usage(
			$user_id,
			$this->get_type(),
			$token_usage,
			'success',
			$params
		);

		return array(
			'content'     => $content_data,
			'usage'       => $token_usage,
			'model'       => $response['model'] ?? '',
			'finish_reason' => $response['choices'][0]['finish_reason'] ?? '',
		);
	}

	/**
	 * Attempt to parse malformed JSON.
	 *
	 * @param string $json Malformed JSON string.
	 * @return array|null Parsed data or null.
	 */
	protected function parse_malformed_json( $json ) {
		// Try to find JSON block in the text
		if ( preg_match( '/\{.*\}/s', $json, $matches ) ) {
			$data = json_decode( $matches[0], true );
			if ( json_last_error() === JSON_ERROR_NONE ) {
				return $data;
			}
		}

		return null;
	}
}
