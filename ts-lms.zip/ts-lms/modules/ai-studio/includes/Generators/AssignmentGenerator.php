<?php
/**
 * Assignment Generator
 *
 * Generates assignment prompts and rubrics.
 *
 * @package TS_LMS\Modules\AIStudio\Generators
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Generators;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AssignmentGenerator class.
 */
class AssignmentGenerator extends BaseGenerator {

	/**
	 * Get required parameters.
	 *
	 * @return array List of required parameter keys.
	 */
	public function get_required_params(): array {
		return array(
			'topic',
			'assignment_type',
			'difficulty_level',
			'learning_objectives',
			'duration',
			'target_audience',
		);
	}

	/**
	 * Get generator type.
	 *
	 * @return string Generator type.
	 */
	public function get_type(): string {
		return 'assignment';
	}
}
