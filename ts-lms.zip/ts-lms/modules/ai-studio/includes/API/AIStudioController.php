<?php
/**
 * AI Studio REST API Controller
 *
 * REST API endpoints for AI-powered content generation.
 *
 * @package TS_LMS\Modules\AIStudio\API
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\API;

use TS_LMS\Modules\AIStudio\Generators\CourseOutlineGenerator;
use TS_LMS\Modules\AIStudio\Generators\LessonContentGenerator;
use TS_LMS\Modules\AIStudio\Generators\QuizGenerator;
use TS_LMS\Modules\AIStudio\Generators\AssignmentGenerator;
use TS_LMS\Modules\AIStudio\Usage\UsageTracker;
use TS_LMS\Modules\AIStudio\Templates\PromptTemplateRepository;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AIStudioController class.
 */
class AIStudioController extends \WP_REST_Controller {

	/**
	 * Namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'ts-lms/v1';

	/**
	 * Rest base.
	 *
	 * @var string
	 */
	protected $rest_base = 'ai-studio';

	/**
	 * Register routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/generate/(?P<type>[a-z_-]+)',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'generate_content' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'type' => array(
							'required' => true,
							'type'     => 'string',
							'enum'     => array( 'course_outline', 'lesson_content', 'quiz', 'assignment' ),
						),
						'params' => array(
							'required' => true,
							'type'     => 'object',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/usage',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_usage_stats' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'period' => array(
							'type'    => 'string',
							'default' => 'today',
							'enum'    => array( 'today', 'week', 'month', 'all' ),
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/templates',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_templates' ),
					'permission_callback' => array( $this, 'get_admin_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/templates/(?P<id>\d+)',
			array(
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_template' ),
					'permission_callback' => array( $this, 'get_admin_permissions_check' ),
					'args'                => array(
						'template_content' => array(
							'required' => true,
							'type'     => 'string',
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_template' ),
					'permission_callback' => array( $this, 'get_admin_permissions_check' ),
				),
			)
		);
	}

	/**
	 * Check if current user has permission to generate content.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return bool|WP_Error
	 */
	public function get_item_permissions_check( $request ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new \WP_Error(
				'rest_forbidden',
				__( 'Sorry, you are not allowed to access this endpoint.', 'ts-lms' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Check if current user has permission to manage AI settings.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return bool|WP_Error
	 */
	public function get_admin_permissions_check( $request ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'rest_forbidden',
				__( 'Sorry, you are not allowed to access this endpoint.', 'ts-lms' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Generate AI content.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function generate_content( $request ) {
		$type = $request->get_param( 'type' );
		$params = $request->get_param( 'params' );

		$generator_map = array(
			'course_outline'  => CourseOutlineGenerator::class,
			'lesson_content'  => LessonContentGenerator::class,
			'quiz'            => QuizGenerator::class,
			'assignment'      => AssignmentGenerator::class,
		);

		$generator_class = $generator_map[ $type ];
		$generator = new $generator_class();

		try {
			$result = $generator->generate( (array) $params );
			return rest_ensure_response( $result );
		} catch ( \Exception $e ) {
			return new \WP_Error(
				'generation_failed',
				$e->getMessage(),
				array( 'status' => 500 )
			);
		}
	}

	/**
	 * Get usage statistics.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public function get_usage_stats( $request ) {
		$period = $request->get_param( 'period' );
		$user_id = get_current_user_id();

		$tracker = new UsageTracker();
		$stats = $tracker->get_user_usage( $user_id, $period );
		$limit = $tracker->get_user_limit( $user_id );
		$breakdown = $tracker->get_usage_breakdown( $user_id, $period );

		return rest_ensure_response(
			array(
				'stats'     => $stats,
				'limit'     => $limit,
				'breakdown' => $breakdown,
				'remaining' => max( 0, $limit - $stats['total_tokens'] ),
			)
		);
	}

	/**
	 * Get all templates.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public function get_templates( $request ) {
		$repository = new PromptTemplateRepository();
		$templates = $repository->get_all();
		
		$data = array();
		foreach ( $templates as $template ) {
			$data[] = $template->to_array();
		}

		return rest_ensure_response( $data );
	}

	/**
	 * Update template.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function update_template( $request ) {
		$id = $request->get_param( 'id' );
		$content = $request->get_param( 'template_content' );

		$repository = new PromptTemplateRepository();
		$success = $repository->update( $id, array( 'template_content' => $content ) );

		if ( $success ) {
			return rest_ensure_response( array( 'success' => true, 'message' => __( 'Template updated successfully!', 'ts-lms' ) ) );
		}

		return new \WP_Error(
			'update_failed',
			__( 'Failed to update template.', 'ts-lms' ),
			array( 'status' => 500 )
		);
	}

	/**
	 * Delete template.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function delete_template( $request ) {
		$id = $request->get_param( 'id' );

		$repository = new PromptTemplateRepository();
		$success = $repository->delete( $id );

		if ( $success ) {
			return rest_ensure_response( array( 'success' => true, 'message' => __( 'Template deleted successfully!', 'ts-lms' ) ) );
		}

		return new \WP_Error(
			'delete_failed',
			__( 'Failed to delete template. Default templates cannot be deleted.', 'ts-lms' ),
			array( 'status' => 500 )
		);
	}
}
