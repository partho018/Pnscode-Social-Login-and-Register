<?php
/**
 * OpenAI Client
 *
 * Wrapper for OpenAI API integration.
 *
 * @package TS_LMS\Modules\AIStudio\API
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\API;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * OpenAIClient class.
 */
class OpenAIClient {

	/**
	 * API endpoint.
	 *
	 * @var string
	 */
	private $api_endpoint = 'https://api.openai.com/v1/chat/completions';

	/**
	 * API key.
	 *
	 * @var string
	 */
	private $api_key;

	/**
	 * Model to use.
	 *
	 * @var string
	 */
	private $model;

	/**
	 * Max retries.
	 *
	 * @var int
	 */
	private $max_retries = 3;

	/**
	 * Constructor.
	 *
	 * @param string $api_key API key (optional, will use stored key if not provided).
	 * @param string $model   Model to use (optional, will use default if not provided).
	 */
	public function __construct( $api_key = null, $model = null ) {
		$this->api_key = $api_key ?? $this->get_stored_api_key();
		$this->model = $model ?? get_option( 'ts_lms_ai_model', 'gpt-3.5-turbo' );
	}

	/**
	 * Get stored API key.
	 *
	 * @return string API key.
	 */
	private function get_stored_api_key() {
		$encrypted_key = get_option( 'ts_lms_openai_api_key', '' );
		return $this->decrypt_api_key( $encrypted_key );
	}

	/**
	 * Validate API key.
	 *
	 * @param string $api_key API key to validate.
	 * @return bool|WP_Error True if valid, WP_Error otherwise.
	 */
	public static function validate_api_key( $api_key ) {
		if ( empty( $api_key ) ) {
			return new \WP_Error( 'empty_api_key', __( 'API key is required.', 'ts-lms' ) );
		}

		// Basic format validation
		if ( $api_key !== 'demo-key' && ! preg_match( '/^sk-[a-zA-Z0-9]{32,}$/', $api_key ) ) {
			return new \WP_Error( 'invalid_api_key_format', __( 'Invalid API key format.', 'ts-lms' ) );
		}

		// Test API key with a simple request
		if ( $api_key === 'demo-key' ) {
			return true;
		}
		$client = new self( $api_key );
		$response = $client->send_request(
			array(
				array(
					'role'    => 'user',
					'content' => 'Test',
				),
			),
			array(
				'max_tokens'  => 5,
				'temperature' => 0.5,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return true;
	}

	/**
	 * Store API key.
	 *
	 * @param string $api_key API key to store.
	 * @return bool True on success, false on failure.
	 */
	public static function store_api_key( $api_key ) {
		$validation = self::validate_api_key( $api_key );
		if ( is_wp_error( $validation ) ) {
			return false;
		}

		$client = new self();
		$encrypted_key = $client->encrypt_api_key( $api_key );
		return update_option( 'ts_lms_openai_api_key', $encrypted_key );
	}

	/**
	 * Encrypt API key.
	 *
	 * @param string $api_key API key to encrypt.
	 * @return string Encrypted API key.
	 */
	private function encrypt_api_key( $api_key ) {
		if ( $api_key === 'demo-key' ) {
			return $api_key;
		}
		// Simple encryption using WordPress salts
		// For production, consider using a more robust encryption method
		$salt = wp_salt( 'auth' );
		return base64_encode( $api_key ^ $salt );
	}

	/**
	 * Decrypt API key.
	 *
	 * @param string $encrypted_key Encrypted API key.
	 * @return string Decrypted API key.
	 */
	private function decrypt_api_key( $encrypted_key ) {
		if ( empty( $encrypted_key ) ) {
			return '';
		}

		if ( $encrypted_key === 'demo-key' ) {
			return $encrypted_key;
		}

		$salt = wp_salt( 'auth' );
		return base64_decode( $encrypted_key ) ^ $salt;
	}

	/**
	 * Send request to OpenAI API.
	 *
	 * @param array $messages Messages array.
	 * @param array $options  Additional options.
	 * @return array|WP_Error Response data or error.
	 */
	public function send_request( $messages, $options = array() ) {
		if ( empty( $this->api_key ) ) {
			return new \WP_Error(
				'no_api_key',
				__( 'OpenAI API key not configured. Please add your API key in settings.', 'ts-lms' )
			);
		}

		// Handle Demo Mode
		if ( $this->api_key === 'demo-key' ) {
			$type = 'course_outline'; // Default
			foreach ( $messages as $message ) {
				if ( $message['role'] === 'user' ) {
					if ( strpos( $message['content'], 'course_outline' ) !== false ) $type = 'course_outline';
					if ( strpos( $message['content'], 'lesson_content' ) !== false ) $type = 'lesson_content';
					if ( strpos( $message['content'], 'quiz' ) !== false ) $type = 'quiz';
					if ( strpos( $message['content'], 'assignment' ) !== false ) $type = 'assignment';
				}
			}
			return MockResponseHandler::get_mock_response( $type );
		}

		$defaults = array(
			'model'       => $this->model,
			'messages'    => $messages,
			'temperature' => 0.7,
			'max_tokens'  => 2000,
		);

		$body = wp_parse_args( $options, $defaults );

		// Attempt request with retries
		$attempt = 0;
		$last_error = null;

		while ( $attempt < $this->max_retries ) {
			$response = $this->make_http_request( $body );

			if ( ! is_wp_error( $response ) ) {
				return $response;
			}

			$last_error = $response;
			$attempt++;

			// Exponential backoff
			if ( $attempt < $this->max_retries ) {
				sleep( pow( 2, $attempt ) );
			}
		}

		// All retries failed
		return $this->handle_graceful_failure( $last_error );
	}

	/**
	 * Make HTTP request to OpenAI API.
	 *
	 * @param array $body Request body.
	 * @return array|WP_Error Response data or error.
	 */
	private function make_http_request( $body ) {
		$response = wp_remote_post(
			$this->api_endpoint,
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
				'timeout' => 60,
			)
		);

		if ( is_wp_error( $response ) ) {
			return new \WP_Error(
				'http_request_failed',
				sprintf(
					/* translators: %s: error message */
					__( 'HTTP request failed: %s', 'ts-lms' ),
					$response->get_error_message()
				)
			);
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$data = json_decode( $response_body, true );

		// Handle API errors
		if ( $status_code !== 200 ) {
			$error_message = isset( $data['error']['message'] ) ? $data['error']['message'] : __( 'Unknown API error', 'ts-lms' );
			
			return new \WP_Error(
				'api_error',
				sprintf(
					/* translators: 1: status code, 2: error message */
					__( 'OpenAI API error (Status %1$d): %2$s', 'ts-lms' ),
					$status_code,
					$error_message
				),
				array( 'status' => $status_code )
			);
		}

		return $data;
	}

	/**
	 * Handle graceful failure.
	 *
	 * @param WP_Error $error Error object.
	 * @return WP_Error Modified error with fallback message.
	 */
	private function handle_graceful_failure( $error ) {
		// Log the error
		if ( function_exists( 'error_log' ) ) {
			error_log( 'TS LMS AI Studio Error: ' . $error->get_error_message() );
		}

		// Return user-friendly error
		return new \WP_Error(
			'ai_generation_failed',
			__( 'Unable to generate content at this time. Please try again later or contact support if the problem persists.', 'ts-lms' ),
			array( 'original_error' => $error )
		);
	}

	/**
	 * Generate completion.
	 *
	 * @param string $prompt  Prompt text.
	 * @param array  $options Additional options.
	 * @return string|WP_Error Generated text or error.
	 */
	public function generate_completion( $prompt, $options = array() ) {
		$messages = array(
			array(
				'role'    => 'user',
				'content' => $prompt,
			),
		);

		$response = $this->send_request( $messages, $options );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		// Extract the generated text
		if ( isset( $response['choices'][0]['message']['content'] ) ) {
			return trim( $response['choices'][0]['message']['content'] );
		}

		return new \WP_Error(
			'invalid_response',
			__( 'Invalid response from OpenAI API.', 'ts-lms' )
		);
	}

	/**
	 * Get token usage from response.
	 *
	 * @param array $response API response.
	 * @return array Token usage data.
	 */
	public function get_token_usage( $response ) {
		if ( isset( $response['usage'] ) ) {
			return array(
				'prompt_tokens'     => $response['usage']['prompt_tokens'] ?? 0,
				'completion_tokens' => $response['usage']['completion_tokens'] ?? 0,
				'total_tokens'      => $response['usage']['total_tokens'] ?? 0,
			);
		}

		return array(
			'prompt_tokens'     => 0,
			'completion_tokens' => 0,
			'total_tokens'      => 0,
		);
	}

	/**
	 * Check if API key is configured.
	 *
	 * @return bool True if configured, false otherwise.
	 */
	public static function is_configured() {
		$key = get_option( 'ts_lms_openai_api_key', '' );
		return ! empty( $key );
	}
}
