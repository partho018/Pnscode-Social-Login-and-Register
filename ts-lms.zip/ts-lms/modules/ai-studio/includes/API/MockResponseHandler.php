<?php
namespace TS_LMS\Modules\AIStudio\API;

/**
 * MockResponseHandler class.
 */
class MockResponseHandler {

    /**
     * Get mock response for a given type.
     *
     * @param string $type Template type.
     * @return array Mock OpenAI response array.
     */
    public static function get_mock_response( $type ) {
        $content = '';

        switch ( $type ) {
            case 'course_outline':
                $content = json_encode( array(
                    'course_title' => 'Mastering AI with TS LMS',
                    'description' => 'A comprehensive guide to leveraging AI in education.',
                    'learning_objectives' => array(
                        'Understand AI fundamentals',
                        'Integrate AI into curriculum',
                        'Automate content generation'
                    ),
                    'prerequisites' => array( 'Basic computer skills' ),
                    'total_duration' => 10,
                    'modules' => array(
                        array(
                            'title' => 'Introduction to AI',
                            'description' => 'Basics of AI and its history.',
                            'duration' => 2,
                            'learning_outcomes' => array( 'Define AI' ),
                            'lessons' => array(
                                array(
                                    'title' => 'What is AI?',
                                    'description' => 'A brief overview.',
                                    'key_concepts' => array( 'Machine Learning', 'Deep Learning' ),
                                    'duration' => 30
                                )
                            )
                        )
                    ),
                    'assessment_strategy' => array(
                        'types' => array( 'Weekly quizzes', 'Final project' ),
                        'grading_criteria' => 'Participation 20%, Quizzes 40%, Project 40%'
                    ),
                    'resources' => array( 'OpenAI Documentation', 'TS LMS Guide' )
                ) );
                break;

            case 'lesson_content':
                $content = json_encode( array(
                    'lesson_title' => 'The Future of AI in Education',
                    'introduction' => array(
                        'hook' => 'Imagine a world where every student has a personal TS LMS Assistant.',
                        'overview' => 'We will explore how AI is transforming classrooms.',
                        'objectives' => array( 'Identify AI tools', 'Discuss ethics' )
                    ),
                    'main_content' => array(
                        array(
                            'section_title' => 'Personalized Learning',
                            'content' => 'AI allows for tailoring educational experiences to individual student needs.',
                            'examples' => array( 'Adaptive learning platforms' ),
                            'visuals' => array( 'A flowchart showing student paths' ),
                            'interactive_elements' => array( 'Discussion: How would you use a TS LMS Assistant?' )
                        )
                    ),
                    'practice_activities' => array(
                        array(
                            'title' => 'AI Tool Comparison',
                            'description' => 'Compare two popular AI tools.',
                            'steps' => array( 'Research Tool A', 'Research Tool B', 'Write a summary' ),
                            'expected_outcome' => 'A 500-word comparison report.'
                        )
                    ),
                    'summary' => array(
                        'key_takeaways' => array( 'AI is a supplementary tool', 'Ethics are paramount' ),
                        'next_lesson_preview' => 'Next, we look at AI coding assistants.',
                        'reflection_questions' => array( 'Is AI a threat to teachers?' )
                    ),
                    'additional_resources' => array( 'Latest AI Research Papers' )
                ) );
                break;

            case 'quiz':
                $content = json_encode( array(
                    'quiz_title' => 'AI Basics Quiz',
                    'description' => 'Test your knowledge of artificial intelligence.',
                    'total_points' => 100,
                    'passing_score' => 70,
                    'time_limit' => 15,
                    'questions' => array(
                        array(
                            'question_text' => 'What does AI stand for?',
                            'question_type' => 'mcq',
                            'options' => array( 'Automated Intelligence', 'Artificial Intelligence', 'Active Integration', 'Advanced Insight' ),
                            'correct_answer' => 'Artificial Intelligence',
                            'explanation' => 'AI stands for Artificial Intelligence.',
                            'difficulty' => 'easy',
                            'points' => 10,
                            'learning_objective' => 'Define AI'
                        )
                    )
                ) );
                break;

            case 'assignment':
                $content = json_encode( array(
                    'assignment_title' => 'AI Ethics Report',
                    'description' => 'Research and write about the ethics of AI.',
                    'learning_objectives' => array( 'Analyze ethical implications' ),
                    'skills_developed' => array( 'Research', 'Critical thinking' ),
                    'estimated_time' => 5,
                    'instructions' => array(
                        'overview' => 'Write a report on AI ethics.',
                        'steps' => array( 'Choose a topic', 'Research', 'Write' ),
                        'deliverables' => array( 'PDF report' ),
                        'format_requirements' => '12pt font, double spaced',
                        'submission_guidelines' => 'Upload to LMS',
                        'allowed_resources' => array( 'Library', 'Internet' )
                    ),
                    'grading_rubric' => array(
                        'total_points' => 100,
                        'criteria' => array(
                            array(
                                'name' => 'Depth of Research',
                                'description' => 'How deep the research goes.',
                                'weight' => 50,
                                'levels' => array(
                                    array( 'level' => 'excellent', 'points' => 50, 'description' => 'Thorough research' )
                                )
                            )
                        )
                    ),
                    'guidance' => array(
                        'examples' => array( 'Sample ethics report' ),
                        'pitfalls' => array( 'Ignoring bias' ),
                        'tips' => array( 'Use credible sources' ),
                        'faq' => array()
                    ),
                    'timeline' => array(
                        'milestones' => array( 'Proposal', 'Draft', 'Final' ),
                        'due_date_suggestion' => 'EndOfWeek'
                    )
                ) );
                break;
        }

        return array(
            'id' => 'chatcmpl-mock',
            'object' => 'chat.completion',
            'created' => time(),
            'model' => 'gpt-3.5-turbo-mock',
            'choices' => array(
                array(
                    'index' => 0,
                    'message' => array(
                        'role' => 'assistant',
                        'content' => $content,
                    ),
                    'finish_reason' => 'stop',
                ),
            ),
            'usage' => array(
                'prompt_tokens' => 100,
                'completion_tokens' => 200,
                'total_tokens' => 300,
            ),
        );
    }
}
