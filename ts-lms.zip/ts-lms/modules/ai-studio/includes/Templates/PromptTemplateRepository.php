<?php
/**
 * Prompt Template Repository
 *
 * Database operations for prompt templates.
 *
 * @package TS_LMS\Modules\AIStudio\Templates
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Templates;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PromptTemplateRepository class.
 */
class PromptTemplateRepository {

	/**
	 * Table name.
	 *
	 * @var string
	 */
	private $table;

	/**
	 * Constructor.
	 */
	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'ts_lms_ai_prompt_templates';
	}

	/**
	 * Get template by ID.
	 *
	 * @param int $id Template ID.
	 * @return PromptTemplate|null Template object or null.
	 */
	public function find( $id ) {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->table} WHERE id = %d",
				$id
			)
		);

		return $row ? new PromptTemplate( $row ) : null;
	}

	/**
	 * Get template by type.
	 *
	 * @param string $type Template type.
	 * @return PromptTemplate|null Template object or null.
	 */
	public function find_by_type( $type ) {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->table} WHERE template_type = %s AND is_active = 1 ORDER BY is_default DESC, id ASC LIMIT 1",
				$type
			)
		);

		return $row ? new PromptTemplate( $row ) : null;
	}

	/**
	 * Get all templates.
	 *
	 * @param array $args Query arguments.
	 * @return array Array of PromptTemplate objects.
	 */
	public function get_all( $args = array() ) {
		global $wpdb;

		$defaults = array(
			'type'      => '',
			'is_active' => null,
			'orderby'   => 'template_type',
			'order'     => 'ASC',
		);

		$args = wp_parse_args( $args, $defaults );

		$where = array( '1=1' );
		$prepare_args = array();

		if ( ! empty( $args['type'] ) ) {
			$where[] = 'template_type = %s';
			$prepare_args[] = $args['type'];
		}

		if ( ! is_null( $args['is_active'] ) ) {
			$where[] = 'is_active = %d';
			$prepare_args[] = (int) $args['is_active'];
		}

		$where_clause = implode( ' AND ', $where );
		$order_clause = sprintf( 'ORDER BY %s %s', esc_sql( $args['orderby'] ), esc_sql( $args['order'] ) );

		$query = "SELECT * FROM {$this->table} WHERE {$where_clause} {$order_clause}";

		if ( ! empty( $prepare_args ) ) {
			$query = $wpdb->prepare( $query, $prepare_args );
		}

		$rows = $wpdb->get_results( $query );

		return array_map( function( $row ) {
			return new PromptTemplate( $row );
		}, $rows );
	}

	/**
	 * Create new template.
	 *
	 * @param array $data Template data.
	 * @return int|false Template ID or false on failure.
	 */
	public function create( $data ) {
		global $wpdb;

		$template = new PromptTemplate( $data );
		$validation = $template->validate();

		if ( is_wp_error( $validation ) ) {
			return false;
		}

		$result = $wpdb->insert(
			$this->table,
			array(
				'template_type'    => $template->template_type,
				'template_name'    => $template->template_name,
				'template_content' => $template->template_content,
				'variables'        => wp_json_encode( $template->variables ),
				'is_default'       => $template->is_default ? 1 : 0,
				'is_active'        => $template->is_active ? 1 : 0,
			),
			array( '%s', '%s', '%s', '%s', '%d', '%d' )
		);

		return $result ? $wpdb->insert_id : false;
	}

	/**
	 * Update template.
	 *
	 * @param int   $id   Template ID.
	 * @param array $data Template data.
	 * @return bool True on success, false on failure.
	 */
	public function update( $id, $data ) {
		global $wpdb;

		$update_data = array();
		$format = array();

		if ( isset( $data['template_name'] ) ) {
			$update_data['template_name'] = $data['template_name'];
			$format[] = '%s';
		}

		if ( isset( $data['template_content'] ) ) {
			$update_data['template_content'] = $data['template_content'];
			$format[] = '%s';
		}

		if ( isset( $data['variables'] ) ) {
			$update_data['variables'] = is_array( $data['variables'] ) ? wp_json_encode( $data['variables'] ) : $data['variables'];
			$format[] = '%s';
		}

		if ( isset( $data['is_active'] ) ) {
			$update_data['is_active'] = (int) $data['is_active'];
			$format[] = '%d';
		}

		if ( empty( $update_data ) ) {
			return false;
		}

		$result = $wpdb->update(
			$this->table,
			$update_data,
			array( 'id' => $id ),
			$format,
			array( '%d' )
		);

		return $result !== false;
	}

	/**
	 * Delete template.
	 *
	 * @param int $id Template ID.
	 * @return bool True on success, false on failure.
	 */
	public function delete( $id ) {
		global $wpdb;

		// Don't allow deleting default templates
		$template = $this->find( $id );
		if ( $template && $template->is_default ) {
			return false;
		}

		$result = $wpdb->delete(
			$this->table,
			array( 'id' => $id ),
			array( '%d' )
		);

		return $result !== false;
	}

	/**
	 * Reset template to default.
	 *
	 * @param int $id Template ID.
	 * @return bool True on success, false on failure.
	 */
	public function reset_to_default( $id ) {
		$template = $this->find( $id );
		if ( ! $template || ! $template->is_default ) {
			return false;
		}

		// Find the original default template
		$defaults = DefaultTemplates::get_all();
		$default_content = '';

		foreach ( $defaults as $default ) {
			if ( $default['type'] === $template->template_type ) {
				$default_content = $default['content'];
				break;
			}
		}

		if ( empty( $default_content ) ) {
			return false;
		}

		return $this->update( $id, array( 'template_content' => $default_content ) );
	}
}
