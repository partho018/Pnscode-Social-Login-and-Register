<?php
/**
 * Default Prompt Templates
 *
 * Provides default prompt templates for all AI generators.
 *
 * @package TS_LMS\Modules\AIStudio\Templates
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Templates;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default templates class.
 */
class DefaultTemplates {

	/**
	 * Get all default templates.
	 *
	 * @return array Array of default templates.
	 */
	public static function get_all() {
		return array(
			self::get_course_outline_template(),
			self::get_lesson_content_template(),
			self::get_quiz_template(),
			self::get_assignment_template(),
		);
	}

	/**
	 * Get course outline template.
	 *
	 * @return array Template data.
	 */
	private static function get_course_outline_template() {
		return array(
			'type'      => 'course_outline',
			'name'      => 'Default Course Outline Generator',
			'content'   => 'You are an expert instructional designer creating a comprehensive course outline for an online learning platform.

Create a detailed course outline with the following specifications:

Course Title: {course_title}
Topic: {topic}
Difficulty Level: {difficulty_level}
Target Audience: {target_audience}
Estimated Duration: {duration} hours

Please structure the course outline as follows:

1. Course Overview
   - Brief description (2-3 sentences)
   - Learning objectives (4-6 specific, measurable objectives)
   - Prerequisites (if any)

2. Course Modules
   For each module, provide:
   - Module title
   - Module description (1-2 sentences)
   - Estimated time to complete
   - Learning outcomes
   - List of lessons (3-5 lessons per module)
   
   For each lesson, include:
   - Lesson title
   - Brief description
   - Key concepts covered
   - Estimated duration

3. Assessment Strategy
   - Types of assessments (quizzes, assignments, projects)
   - Grading criteria overview

4. Resources and Materials
   - Recommended reading
   - Additional resources

Please ensure the outline is:
- Logically structured and progressive
- Appropriate for the specified difficulty level
- Engaging and practical
- Aligned with modern educational best practices

Return the response in JSON format with the following structure:
{
  "course_title": "",
  "description": "",
  "learning_objectives": [],
  "prerequisites": [],
  "total_duration": 0,
  "modules": [
    {
      "title": "",
      "description": "",
      "duration": 0,
      "learning_outcomes": [],
      "lessons": [
        {
          "title": "",
          "description": "",
          "key_concepts": [],
          "duration": 0
        }
      ]
    }
  ],
  "assessment_strategy": {
    "types": [],
    "grading_criteria": ""
  },
  "resources": []
}',
			'variables' => array(
				'course_title',
				'topic',
				'difficulty_level',
				'target_audience',
				'duration',
			),
		);
	}

	/**
	 * Get lesson content template.
	 *
	 * @return array Template data.
	 */
	private static function get_lesson_content_template() {
		return array(
			'type'      => 'lesson_content',
			'name'      => 'Default Lesson Content Generator',
			'content'   => 'You are an expert educator creating engaging lesson content for an online learning platform.

Create comprehensive lesson content with the following specifications:

Lesson Title: {lesson_title}
Topic: {topic}
Learning Objectives: {learning_objectives}
Target Audience: {target_audience}
Lesson Duration: {duration} minutes
Content Format: {content_format}

Please structure the lesson content as follows:

1. Introduction (10% of content)
   - Hook to engage learners
   - Overview of what will be covered
   - Connection to previous lessons (if applicable)
   - Clear statement of learning objectives

2. Main Content (70% of content)
   - Break down into 3-5 logical sections
   - For each section:
     * Clear heading
     * Detailed explanation with examples
     * Visual descriptions (diagrams, charts, images to include)
     * Real-world applications
     * Common misconceptions to address
   - Include interactive elements suggestions (polls, discussions, activities)

3. Practice Activities (10% of content)
   - 2-3 hands-on exercises or examples
   - Step-by-step guidance
   - Expected outcomes

4. Summary and Review (10% of content)
   - Key takeaways (3-5 bullet points)
   - Connection to next lesson
   - Reflection questions

5. Additional Resources
   - Supplementary reading materials
   - Video suggestions
   - External links

Please ensure the content is:
- Clear and accessible for the target audience
- Engaging with varied teaching methods
- Practical with real-world examples
- Properly paced for the duration
- Inclusive and culturally sensitive

Return the response in JSON format with the following structure:
{
  "lesson_title": "",
  "introduction": {
    "hook": "",
    "overview": "",
    "objectives": []
  },
  "main_content": [
    {
      "section_title": "",
      "content": "",
      "examples": [],
      "visuals": [],
      "interactive_elements": []
    }
  ],
  "practice_activities": [
    {
      "title": "",
      "description": "",
      "steps": [],
      "expected_outcome": ""
    }
  ],
  "summary": {
    "key_takeaways": [],
    "next_lesson_preview": "",
    "reflection_questions": []
  },
  "additional_resources": []
}',
			'variables' => array(
				'lesson_title',
				'topic',
				'learning_objectives',
				'target_audience',
				'duration',
				'content_format',
			),
		);
	}

	/**
	 * Get quiz template.
	 *
	 * @return array Template data.
	 */
	private static function get_quiz_template() {
		return array(
			'type'      => 'quiz',
			'name'      => 'Default Quiz Generator',
			'content'   => 'You are an expert assessment designer creating effective quiz questions for an online learning platform.

Create a quiz with the following specifications:

Topic: {topic}
Difficulty Level: {difficulty_level}
Number of Questions: {question_count}
Question Types: {question_types}
Learning Objectives: {learning_objectives}

Guidelines for question creation:

1. Multiple Choice Questions (MCQ):
   - One correct answer and 3 plausible distractors
   - Distractors should represent common misconceptions
   - Avoid "all of the above" or "none of the above"
   - Question stem should be clear and concise

2. True/False Questions:
   - Avoid absolute terms (always, never) unless accurate
   - Test significant concepts, not trivial details
   - Ensure statements are clearly true or false

3. Short Answer Questions:
   - Clear, specific questions
   - Provide sample correct answers
   - Indicate key points that must be included

For each question, provide:
- Question text
- Question type
- Correct answer(s)
- For MCQ: all options with correct answer marked
- Explanation of the correct answer
- Difficulty level (easy, medium, hard)
- Points value
- Learning objective being assessed

Ensure questions:
- Align with stated learning objectives
- Test understanding, not just memorization
- Are free from bias and cultural assumptions
- Have varied difficulty levels
- Cover different aspects of the topic
- Are grammatically correct and unambiguous

Return the response in JSON format with the following structure:
{
  "quiz_title": "",
  "description": "",
  "total_points": 0,
  "passing_score": 0,
  "time_limit": 0,
  "questions": [
    {
      "question_text": "",
      "question_type": "mcq|true_false|short_answer",
      "options": [],
      "correct_answer": "",
      "explanation": "",
      "difficulty": "easy|medium|hard",
      "points": 0,
      "learning_objective": ""
    }
  ]
}',
			'variables' => array(
				'topic',
				'difficulty_level',
				'question_count',
				'question_types',
				'learning_objectives',
			),
		);
	}

	/**
	 * Get assignment template.
	 *
	 * @return array Template data.
	 */
	private static function get_assignment_template() {
		return array(
			'type'      => 'assignment',
			'name'      => 'Default Assignment Generator',
			'content'   => 'You are an expert educator creating meaningful assignments for an online learning platform.

Create a comprehensive assignment with the following specifications:

Topic: {topic}
Assignment Type: {assignment_type}
Difficulty Level: {difficulty_level}
Learning Objectives: {learning_objectives}
Estimated Time: {duration} hours
Target Audience: {target_audience}

Please structure the assignment as follows:

1. Assignment Overview
   - Title
   - Brief description (2-3 sentences)
   - Learning objectives being assessed
   - Skills developed through this assignment

2. Assignment Instructions
   - Clear, step-by-step instructions
   - Required deliverables
   - Format and length requirements
   - Submission guidelines
   - Resources students can use

3. Assessment Criteria (Grading Rubric)
   Create a detailed rubric with:
   - 4-6 evaluation criteria
   - For each criterion:
     * Description
     * Weight/Points
     * Performance levels (Excellent, Good, Satisfactory, Needs Improvement)
     * Specific descriptors for each level

4. Examples and Guidance
   - Sample outline or structure
   - Common pitfalls to avoid
   - Tips for success
   - FAQ

5. Timeline and Milestones (if applicable)
   - Suggested schedule
   - Key milestones
   - Due date

Ensure the assignment:
- Aligns with learning objectives
- Is appropriate for the difficulty level
- Encourages critical thinking and application
- Is realistic in scope for the time allotted
- Provides clear success criteria
- Promotes academic integrity

Return the response in JSON format with the following structure:
{
  "assignment_title": "",
  "description": "",
  "learning_objectives": [],
  "skills_developed": [],
  "estimated_time": 0,
  "instructions": {
    "overview": "",
    "steps": [],
    "deliverables": [],
    "format_requirements": "",
    "submission_guidelines": "",
    "allowed_resources": []
  },
  "grading_rubric": {
    "total_points": 0,
    "criteria": [
      {
        "name": "",
        "description": "",
        "weight": 0,
        "levels": [
          {
            "level": "excellent|good|satisfactory|needs_improvement",
            "points": 0,
            "description": ""
          }
        ]
      }
    ]
  },
  "guidance": {
    "examples": [],
    "pitfalls": [],
    "tips": [],
    "faq": []
  },
  "timeline": {
    "milestones": [],
    "due_date_suggestion": ""
  }
}',
			'variables' => array(
				'topic',
				'assignment_type',
				'difficulty_level',
				'learning_objectives',
				'duration',
				'target_audience',
			),
		);
	}
}
