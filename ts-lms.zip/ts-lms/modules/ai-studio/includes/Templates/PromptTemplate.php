<?php
/**
 * Prompt Template Model
 *
 * Model class for prompt templates.
 *
 * @package TS_LMS\Modules\AIStudio\Templates
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Templates;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PromptTemplate class.
 */
class PromptTemplate {

	/**
	 * Template ID.
	 *
	 * @var int
	 */
	public $id;

	/**
	 * Template type.
	 *
	 * @var string
	 */
	public $template_type;

	/**
	 * Template name.
	 *
	 * @var string
	 */
	public $template_name;

	/**
	 * Template content.
	 *
	 * @var string
	 */
	public $template_content;

	/**
	 * Available variables.
	 *
	 * @var array
	 */
	public $variables;

	/**
	 * Is default template.
	 *
	 * @var bool
	 */
	public $is_default;

	/**
	 * Is active.
	 *
	 * @var bool
	 */
	public $is_active;

	/**
	 * Created at.
	 *
	 * @var string
	 */
	public $created_at;

	/**
	 * Updated at.
	 *
	 * @var string
	 */
	public $updated_at;

	/**
	 * Constructor.
	 *
	 * @param object|array $data Template data.
	 */
	public function __construct( $data = null ) {
		if ( $data ) {
			$this->fill( $data );
		}
	}

	/**
	 * Fill template with data.
	 *
	 * @param object|array $data Template data.
	 * @return void
	 */
	public function fill( $data ) {
		$data = (object) $data;

		$this->id               = isset( $data->id ) ? (int) $data->id : 0;
		$this->template_type    = isset( $data->template_type ) ? $data->template_type : '';
		$this->template_name    = isset( $data->template_name ) ? $data->template_name : '';
		$this->template_content = isset( $data->template_content ) ? $data->template_content : '';
		$this->variables        = isset( $data->variables ) ? json_decode( $data->variables, true ) : array();
		$this->is_default       = isset( $data->is_default ) ? (bool) $data->is_default : false;
		$this->is_active        = isset( $data->is_active ) ? (bool) $data->is_active : true;
		$this->created_at       = isset( $data->created_at ) ? $data->created_at : '';
		$this->updated_at       = isset( $data->updated_at ) ? $data->updated_at : '';
	}

	/**
	 * Replace variables in template content.
	 *
	 * @param array $values Variable values.
	 * @return string Processed template content.
	 */
	public function replace_variables( $values ) {
		$content = $this->template_content;

		foreach ( $values as $key => $value ) {
			// Handle array values
			if ( is_array( $value ) ) {
				$value = implode( ', ', $value );
			}

			// Replace {variable} with value
			$content = str_replace( '{' . $key . '}', $value, $content );
		}

		return $content;
	}

	/**
	 * Validate template.
	 *
	 * @return bool|WP_Error True if valid, WP_Error otherwise.
	 */
	public function validate() {
		$errors = array();

		if ( empty( $this->template_type ) ) {
			$errors[] = __( 'Template type is required.', 'ts-lms' );
		}

		if ( empty( $this->template_name ) ) {
			$errors[] = __( 'Template name is required.', 'ts-lms' );
		}

		if ( empty( $this->template_content ) ) {
			$errors[] = __( 'Template content is required.', 'ts-lms' );
		}

		// Validate template type
		$valid_types = array( 'course_outline', 'lesson_content', 'quiz', 'assignment' );
		if ( ! in_array( $this->template_type, $valid_types, true ) ) {
			$errors[] = __( 'Invalid template type.', 'ts-lms' );
		}

		if ( ! empty( $errors ) ) {
			return new \WP_Error( 'invalid_template', implode( ' ', $errors ) );
		}

		return true;
	}

	/**
	 * Get missing variables.
	 *
	 * @param array $provided_values Provided variable values.
	 * @return array Missing variables.
	 */
	public function get_missing_variables( $provided_values ) {
		$missing = array();

		foreach ( $this->variables as $variable ) {
			if ( ! isset( $provided_values[ $variable ] ) || empty( $provided_values[ $variable ] ) ) {
				$missing[] = $variable;
			}
		}

		return $missing;
	}

	/**
	 * Convert to array.
	 *
	 * @return array Template data as array.
	 */
	public function to_array() {
		return array(
			'id'               => $this->id,
			'template_type'    => $this->template_type,
			'template_name'    => $this->template_name,
			'template_content' => $this->template_content,
			'variables'        => $this->variables,
			'is_default'       => $this->is_default,
			'is_active'        => $this->is_active,
			'created_at'       => $this->created_at,
			'updated_at'       => $this->updated_at,
		);
	}
}
