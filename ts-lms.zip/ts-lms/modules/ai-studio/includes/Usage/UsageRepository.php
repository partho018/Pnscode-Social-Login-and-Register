<?php
/**
 * Usage Repository
 *
 * Database operations for usage logs.
 *
 * @package TS_LMS\Modules\AIStudio\Usage
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Usage;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * UsageRepository class.
 */
class UsageRepository {

	/**
	 * Table name.
	 *
	 * @var string
	 */
	private $table;

	/**
	 * Constructor.
	 */
	public function __construct() {
		global $wpdb;
		$this->table = $wpdb->prefix . 'ts_lms_ai_usage_logs';
	}

	/**
	 * Create usage log.
	 *
	 * @param array $data Log data.
	 * @return int|false Log ID or false on failure.
	 */
	public function create( $data ) {
		global $wpdb;

		$result = $wpdb->insert(
			$this->table,
			array(
				'user_id'           => $data['user_id'],
				'generator_type'    => $data['generator_type'],
				'prompt_tokens'     => $data['prompt_tokens'] ?? 0,
				'completion_tokens' => $data['completion_tokens'] ?? 0,
				'total_tokens'      => $data['total_tokens'] ?? 0,
				'model_used'        => $data['model_used'] ?? '',
				'status'            => $data['status'] ?? 'success',
				'error_message'     => $data['error_message'] ?? null,
				'request_data'      => $data['request_data'] ?? null,
			),
			array( '%d', '%s', '%d', '%d', '%d', '%s', '%s', '%s', '%s' )
		);

		return $result ? $wpdb->insert_id : false;
	}

	/**
	 * Get usage statistics.
	 *
	 * @param array $args Query arguments.
	 * @return array Usage statistics.
	 */
	public function get_usage_stats( $args = array() ) {
		global $wpdb;

		$where = array( '1=1' );
		$prepare_args = array();

		if ( isset( $args['user_id'] ) ) {
			$where[] = 'user_id = %d';
			$prepare_args[] = $args['user_id'];
		}

		if ( isset( $args['generator_type'] ) ) {
			$where[] = 'generator_type = %s';
			$prepare_args[] = $args['generator_type'];
		}

		if ( isset( $args['status'] ) ) {
			$where[] = 'status = %s';
			$prepare_args[] = $args['status'];
		}

		if ( isset( $args['date_from'] ) ) {
			$where[] = 'created_at >= %s';
			$prepare_args[] = $args['date_from'];
		}

		if ( isset( $args['date_to'] ) ) {
			$where[] = 'created_at <= %s';
			$prepare_args[] = $args['date_to'];
		}

		$where_clause = implode( ' AND ', $where );

		$query = "
			SELECT 
				COUNT(*) as request_count,
				SUM(prompt_tokens) as total_prompt_tokens,
				SUM(completion_tokens) as total_completion_tokens,
				SUM(total_tokens) as total_tokens,
				SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful_requests,
				SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_requests
			FROM {$this->table}
			WHERE {$where_clause}
		";

		if ( ! empty( $prepare_args ) ) {
			$query = $wpdb->prepare( $query, $prepare_args );
		}

		$result = $wpdb->get_row( $query, ARRAY_A );

		return array(
			'request_count'          => (int) ( $result['request_count'] ?? 0 ),
			'total_prompt_tokens'    => (int) ( $result['total_prompt_tokens'] ?? 0 ),
			'total_completion_tokens' => (int) ( $result['total_completion_tokens'] ?? 0 ),
			'total_tokens'           => (int) ( $result['total_tokens'] ?? 0 ),
			'successful_requests'    => (int) ( $result['successful_requests'] ?? 0 ),
			'failed_requests'        => (int) ( $result['failed_requests'] ?? 0 ),
		);
	}

	/**
	 * Get usage breakdown by generator type.
	 *
	 * @param array $args Query arguments.
	 * @return array Usage breakdown.
	 */
	public function get_usage_breakdown( $args = array() ) {
		global $wpdb;

		$where = array( '1=1' );
		$prepare_args = array();

		if ( isset( $args['user_id'] ) ) {
			$where[] = 'user_id = %d';
			$prepare_args[] = $args['user_id'];
		}

		if ( isset( $args['date_from'] ) ) {
			$where[] = 'created_at >= %s';
			$prepare_args[] = $args['date_from'];
		}

		if ( isset( $args['date_to'] ) ) {
			$where[] = 'created_at <= %s';
			$prepare_args[] = $args['date_to'];
		}

		$where_clause = implode( ' AND ', $where );

		$query = "
			SELECT 
				generator_type,
				COUNT(*) as request_count,
				SUM(total_tokens) as total_tokens,
				SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful_requests
			FROM {$this->table}
			WHERE {$where_clause}
			GROUP BY generator_type
			ORDER BY total_tokens DESC
		";

		if ( ! empty( $prepare_args ) ) {
			$query = $wpdb->prepare( $query, $prepare_args );
		}

		$results = $wpdb->get_results( $query, ARRAY_A );

		$breakdown = array();
		foreach ( $results as $row ) {
			$breakdown[ $row['generator_type'] ] = array(
				'request_count'       => (int) $row['request_count'],
				'total_tokens'        => (int) $row['total_tokens'],
				'successful_requests' => (int) $row['successful_requests'],
			);
		}

		return $breakdown;
	}

	/**
	 * Get usage logs.
	 *
	 * @param array $args Query arguments.
	 * @return array Usage logs.
	 */
	public function get_logs( $args = array() ) {
		global $wpdb;

		$defaults = array(
			'limit'  => 50,
			'offset' => 0,
			'orderby' => 'created_at',
			'order'  => 'DESC',
		);

		$args = wp_parse_args( $args, $defaults );

		$where = array( '1=1' );
		$prepare_args = array();

		if ( isset( $args['user_id'] ) ) {
			$where[] = 'user_id = %d';
			$prepare_args[] = $args['user_id'];
		}

		if ( isset( $args['generator_type'] ) ) {
			$where[] = 'generator_type = %s';
			$prepare_args[] = $args['generator_type'];
		}

		if ( isset( $args['status'] ) ) {
			$where[] = 'status = %s';
			$prepare_args[] = $args['status'];
		}

		if ( isset( $args['date_from'] ) ) {
			$where[] = 'created_at >= %s';
			$prepare_args[] = $args['date_from'];
		}

		if ( isset( $args['date_to'] ) ) {
			$where[] = 'created_at <= %s';
			$prepare_args[] = $args['date_to'];
		}

		$where_clause = implode( ' AND ', $where );
		$order_clause = sprintf(
			'ORDER BY %s %s',
			esc_sql( $args['orderby'] ),
			esc_sql( $args['order'] )
		);

		$query = "
			SELECT *
			FROM {$this->table}
			WHERE {$where_clause}
			{$order_clause}
			LIMIT %d OFFSET %d
		";

		$prepare_args[] = $args['limit'];
		$prepare_args[] = $args['offset'];

		$query = $wpdb->prepare( $query, $prepare_args );

		return $wpdb->get_results( $query, ARRAY_A );
	}

	/**
	 * Delete old logs.
	 *
	 * @param string $before_date Delete logs before this date.
	 * @return int Number of deleted rows.
	 */
	public function delete_old_logs( $before_date ) {
		global $wpdb;

		return $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$this->table} WHERE created_at < %s",
				$before_date
			)
		);
	}

	/**
	 * Get total count.
	 *
	 * @param array $args Query arguments.
	 * @return int Total count.
	 */
	public function get_count( $args = array() ) {
		global $wpdb;

		$where = array( '1=1' );
		$prepare_args = array();

		if ( isset( $args['user_id'] ) ) {
			$where[] = 'user_id = %d';
			$prepare_args[] = $args['user_id'];
		}

		if ( isset( $args['generator_type'] ) ) {
			$where[] = 'generator_type = %s';
			$prepare_args[] = $args['generator_type'];
		}

		if ( isset( $args['status'] ) ) {
			$where[] = 'status = %s';
			$prepare_args[] = $args['status'];
		}

		$where_clause = implode( ' AND ', $where );

		$query = "SELECT COUNT(*) FROM {$this->table} WHERE {$where_clause}";

		if ( ! empty( $prepare_args ) ) {
			$query = $wpdb->prepare( $query, $prepare_args );
		}

		return (int) $wpdb->get_var( $query );
	}
}
