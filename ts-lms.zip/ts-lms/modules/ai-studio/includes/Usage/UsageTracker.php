<?php
/**
 * Usage Tracker
 *
 * Tracks and enforces API usage limits.
 *
 * @package TS_LMS\Modules\AIStudio\Usage
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Usage;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * UsageTracker class.
 */
class UsageTracker {

	/**
	 * Usage repository.
	 *
	 * @var UsageRepository
	 */
	private $repository;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->repository = new UsageRepository();
	}

	/**
	 * Check if user can generate content.
	 *
	 * @param int    $user_id       User ID.
	 * @param string $generator_type Generator type.
	 * @return bool|WP_Error True if allowed, WP_Error otherwise.
	 */
	public function can_generate( $user_id, $generator_type ) {
		// Get user's usage limit
		$limit = $this->get_user_limit( $user_id );

		// Get user's usage for today
		$usage = $this->get_user_usage( $user_id, 'today' );

		if ( $usage['total_tokens'] >= $limit ) {
			return new \WP_Error(
				'usage_limit_reached',
				sprintf(
					/* translators: %d: token limit */
					__( 'Daily usage limit of %d tokens reached. Please try again tomorrow.', 'ts-lms' ),
					$limit
				)
			);
		}

		return true;
	}

	/**
	 * Get user's usage limit.
	 *
	 * @param int $user_id User ID.
	 * @return int Token limit.
	 */
	public function get_user_limit( $user_id ) {
		$user = get_userdata( $user_id );
		
		if ( ! $user ) {
			return 0;
		}

		// Check for user-specific limit
		$user_limit = get_user_meta( $user_id, 'ts_lms_ai_usage_limit', true );
		if ( ! empty( $user_limit ) ) {
			return (int) $user_limit;
		}

		// Get limit based on user role
		$roles = $user->roles;
		
		if ( in_array( 'administrator', $roles, true ) ) {
			return (int) get_option( 'ts_lms_ai_usage_limit_admin', 1000 );
		}

		if ( in_array( 'instructor', $roles, true ) || in_array( 'editor', $roles, true ) ) {
			return (int) get_option( 'ts_lms_ai_usage_limit_instructor', 500 );
		}

		// Default limit for other roles
		return (int) get_option( 'ts_lms_ai_usage_limit_default', 100 );
	}

	/**
	 * Log usage.
	 *
	 * @param int    $user_id        User ID.
	 * @param string $generator_type Generator type.
	 * @param array  $token_usage    Token usage data.
	 * @param string $status         Status (success, failed, rate_limited).
	 * @param array  $request_data   Request data.
	 * @param string $error_message  Error message (if any).
	 * @return int|false Log ID or false on failure.
	 */
	public function log_usage( $user_id, $generator_type, $token_usage, $status = 'success', $request_data = array(), $error_message = null ) {
		return $this->repository->create(
			array(
				'user_id'           => $user_id,
				'generator_type'    => $generator_type,
				'prompt_tokens'     => $token_usage['prompt_tokens'] ?? 0,
				'completion_tokens' => $token_usage['completion_tokens'] ?? 0,
				'total_tokens'      => $token_usage['total_tokens'] ?? 0,
				'model_used'        => get_option( 'ts_lms_ai_model', 'gpt-3.5-turbo' ),
				'status'            => $status,
				'error_message'     => $error_message,
				'request_data'      => wp_json_encode( $request_data ),
			)
		);
	}

	/**
	 * Get user usage statistics.
	 *
	 * @param int    $user_id User ID.
	 * @param string $period  Period (today, week, month, all).
	 * @return array Usage statistics.
	 */
	public function get_user_usage( $user_id, $period = 'today' ) {
		$date_range = $this->get_date_range( $period );
		
		return $this->repository->get_usage_stats(
			array(
				'user_id'    => $user_id,
				'date_from'  => $date_range['from'],
				'date_to'    => $date_range['to'],
			)
		);
	}

	/**
	 * Get usage statistics by generator type.
	 *
	 * @param int    $user_id        User ID.
	 * @param string $generator_type Generator type.
	 * @param string $period         Period.
	 * @return array Usage statistics.
	 */
	public function get_usage_by_type( $user_id, $generator_type, $period = 'today' ) {
		$date_range = $this->get_date_range( $period );
		
		return $this->repository->get_usage_stats(
			array(
				'user_id'        => $user_id,
				'generator_type' => $generator_type,
				'date_from'      => $date_range['from'],
				'date_to'        => $date_range['to'],
			)
		);
	}

	/**
	 * Get all users usage statistics.
	 *
	 * @param string $period Period.
	 * @return array Usage statistics.
	 */
	public function get_all_usage( $period = 'today' ) {
		$date_range = $this->get_date_range( $period );
		
		return $this->repository->get_usage_stats(
			array(
				'date_from' => $date_range['from'],
				'date_to'   => $date_range['to'],
			)
		);
	}

	/**
	 * Get usage breakdown by generator type.
	 *
	 * @param int    $user_id User ID (optional).
	 * @param string $period  Period.
	 * @return array Usage breakdown.
	 */
	public function get_usage_breakdown( $user_id = null, $period = 'today' ) {
		$date_range = $this->get_date_range( $period );
		
		$args = array(
			'date_from' => $date_range['from'],
			'date_to'   => $date_range['to'],
		);

		if ( $user_id ) {
			$args['user_id'] = $user_id;
		}

		return $this->repository->get_usage_breakdown( $args );
	}

	/**
	 * Get date range for period.
	 *
	 * @param string $period Period.
	 * @return array Date range with 'from' and 'to' keys.
	 */
	private function get_date_range( $period ) {
		$now = current_time( 'mysql' );
		
		switch ( $period ) {
			case 'today':
				return array(
					'from' => gmdate( 'Y-m-d 00:00:00' ),
					'to'   => gmdate( 'Y-m-d 23:59:59' ),
				);

			case 'week':
				return array(
					'from' => gmdate( 'Y-m-d 00:00:00', strtotime( '-7 days' ) ),
					'to'   => $now,
				);

			case 'month':
				return array(
					'from' => gmdate( 'Y-m-d 00:00:00', strtotime( '-30 days' ) ),
					'to'   => $now,
				);

			case 'all':
			default:
				return array(
					'from' => '1970-01-01 00:00:00',
					'to'   => $now,
				);
		}
	}

	/**
	 * Set user-specific limit.
	 *
	 * @param int $user_id User ID.
	 * @param int $limit   Token limit.
	 * @return bool True on success, false on failure.
	 */
	public function set_user_limit( $user_id, $limit ) {
		return update_user_meta( $user_id, 'ts_lms_ai_usage_limit', (int) $limit );
	}

	/**
	 * Remove user-specific limit.
	 *
	 * @param int $user_id User ID.
	 * @return bool True on success, false on failure.
	 */
	public function remove_user_limit( $user_id ) {
		return delete_user_meta( $user_id, 'ts_lms_ai_usage_limit' );
	}

	/**
	 * Get usage history.
	 *
	 * @param int   $user_id User ID.
	 * @param array $args    Query arguments.
	 * @return array Usage history.
	 */
	public function get_usage_history( $user_id, $args = array() ) {
		$defaults = array(
			'limit'  => 50,
			'offset' => 0,
		);

		$args = wp_parse_args( $args, $defaults );
		$args['user_id'] = $user_id;

		return $this->repository->get_logs( $args );
	}

	/**
	 * Cleanup old logs.
	 *
	 * @param int $days Number of days to keep.
	 * @return int Number of deleted rows.
	 */
	public function cleanup_old_logs( $days = 90 ) {
		$date = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );
		return $this->repository->delete_old_logs( $date );
	}
}
