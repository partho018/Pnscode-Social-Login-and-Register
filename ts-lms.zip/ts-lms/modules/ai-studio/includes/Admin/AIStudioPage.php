<?php
/**
 * AI Studio Admin Page
 *
 * Renderer and controller for the AI Studio admin interface.
 *
 * @package TS_LMS\Modules\AIStudio\Admin
 * @since 1.0.0
 */

namespace TS_LMS\Modules\AIStudio\Admin;

use TS_LMS\Modules\AIStudio\Templates\PromptTemplateRepository;
use TS_LMS\Modules\AIStudio\Usage\UsageTracker;
use TS_LMS\Modules\AIStudio\API\OpenAIClient;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AIStudioPage class.
 */
class AIStudioPage {

	/**
	 * Render the AI Studio page.
	 *
	 * @return void
	 */
	public static function render() {
		$active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : 'generators';
		
		// Handle settings saving
		if ( isset( $_POST['ts_lms_ai_save_settings'] ) && check_admin_referer( 'ts_lms_ai_settings_nonce', 'ts_lms_ai_nonce' ) ) {
			self::save_settings();
		}

		?>
		<!-- Coming Soon Modal - Covers only page content -->
		<div id="ts-lms-coming-soon-modal" style="display: none; position: fixed; z-index: 99999; left: 160px; top: 32px; right: 0; bottom: 0; overflow: auto; background-color: rgba(0,0,0,0.85);">
			<div onclick="event.stopPropagation();" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); margin: 10% auto; padding: 0; border-radius: 20px; width: 90%; max-width: 500px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); animation: slideDown 0.4s ease-out;">
				<div style="padding: 40px; text-align: center; color: white;">
					<div style="font-size: 80px; margin-bottom: 20px; animation: bounce 2s infinite;">
						🚀
					</div>
					<h2 style="margin: 0 0 15px 0; font-size: 32px; font-weight: 700; color: white;">Coming Soon!</h2>
					<p style="font-size: 18px; margin: 0 0 30px 0; opacity: 0.95; line-height: 1.6;">
						AI Studio features will be available in the <strong>next version</strong>.<br>
						Stay tuned for amazing AI-powered content generation!
					</p>
					<div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 10px; margin-top: 20px;">
						<p style="font-size: 14px; margin: 0; opacity: 0.9;">
							✨ This feature is under development
						</p>
					</div>
				</div>
			</div>
		</div>

		<style>
			@keyframes slideDown {
				from {
					transform: translateY(-100px);
					opacity: 0;
				}
				to {
					transform: translateY(0);
					opacity: 1;
				}
			}
			@keyframes bounce {
				0%, 20%, 50%, 80%, 100% {
					transform: translateY(0);
				}
				40% {
					transform: translateY(-20px);
				}
				60% {
					transform: translateY(-10px);
				}
			}
			/* Only cover the content area, not admin bar or sidebar */
			#ts-lms-coming-soon-modal {
				pointer-events: auto !important;
			}
			
			/* Adjust for folded admin menu */
			@media screen and (max-width: 960px) {
				#ts-lms-coming-soon-modal {
					left: 36px !important;
				}
			}
			
			/* Adjust for mobile */
			@media screen and (max-width: 782px) {
				#ts-lms-coming-soon-modal {
					left: 0 !important;
					top: 46px !important;
				}
			}
		</style>

		<script>
			document.addEventListener('DOMContentLoaded', function() {
				var modal = document.getElementById('ts-lms-coming-soon-modal');
				modal.style.display = 'block';
				
				// Prevent closing on any click within modal
				modal.addEventListener('click', function(e) {
					e.preventDefault();
					e.stopPropagation();
					return false;
				});
				
				// Prevent ESC key from closing
				document.addEventListener('keydown', function(e) {
					if (e.key === 'Escape') {
						e.preventDefault();
						return false;
					}
				});
			});
		</script>

		<div class="wrap ts-lms-ai-studio-redesign">
			<div class="ts-lms-ai-studio-header">
				<div class="ts-lms-ai-studio-title">
					<h1>
						<span class="main-title"><?php esc_html_e( 'AI Studio', 'ts-lms' ); ?></span>
						<span class="separator">/</span>
						<span class="sub-title"><?php echo esc_html( ucfirst( str_replace( '_', ' ', $active_tab ) ) ); ?></span>
					</h1>
				</div>

				<nav class="ts-lms-ai-studio-nav">
					<a href="?page=ts-lms-ai-studio&tab=generators" class="nav-item <?php echo $active_tab === 'generators' ? 'active' : ''; ?>">
						<?php esc_html_e( 'Generators', 'ts-lms' ); ?>
					</a>
					<a href="?page=ts-lms-ai-studio&tab=templates" class="nav-item <?php echo $active_tab === 'templates' ? 'active' : ''; ?>">
						<?php esc_html_e( 'Templates', 'ts-lms' ); ?>
					</a>
					<a href="?page=ts-lms-ai-studio&tab=usage" class="nav-item <?php echo $active_tab === 'usage' ? 'active' : ''; ?>">
						<?php esc_html_e( 'Usage Stats', 'ts-lms' ); ?>
					</a>
					<a href="?page=ts-lms-ai-studio&tab=settings" class="nav-item <?php echo $active_tab === 'settings' ? 'active' : ''; ?>">
						<?php esc_html_e( 'Settings', 'ts-lms' ); ?>
					</a>
				</nav>
			</div>

			<div class="ts-lms-ai-studio-content-area">
				<?php
				switch ( $active_tab ) {
					case 'generators':
						self::render_generators_tab();
						break;
					case 'templates':
						self::render_templates_tab();
						break;
					case 'usage':
						self::render_usage_tab();
						break;
					case 'settings':
						self::render_settings_tab();
						break;
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Save AI settings.
	 *
	 * @return void
	 */
	private static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$api_key = sanitize_text_field( $_POST['openai_api_key'] ?? '' );
		if ( ! empty( $api_key ) ) {
			OpenAIClient::store_api_key( $api_key );
		}

		update_option( 'ts_lms_ai_model', sanitize_text_field( $_POST['ai_model'] ?? 'gpt-3.5-turbo' ) );
		update_option( 'ts_lms_ai_usage_limit_admin', intval( $_POST['limit_admin'] ?? 1000 ) );
		update_option( 'ts_lms_ai_usage_limit_instructor', intval( $_POST['limit_instructor'] ?? 500 ) );
		update_option( 'ts_lms_ai_usage_limit_default', intval( $_POST['limit_default'] ?? 100 ) );

		echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Settings saved successfully!', 'ts-lms' ) . '</p></div>';
	}

	/**
	 * Render Generators tab.
	 *
	 * @return void
	 */
	private static function render_generators_tab() {
		if ( ! OpenAIClient::is_configured() ) {
			?>
			<div class="notice notice-warning inline">
				<p>
					<?php _e( 'OpenAI API key is not configured. Please go to Settings tab to set up your API key.', 'ts-lms' ); ?>
				</p>
			</div>
			<?php
			return;
		}

		$generators = array(
			array(
				'id'          => 'course_outline',
				'title'       => __( 'Course Outline Generator', 'ts-lms' ),
				'description' => __( 'Generate a complete course structure including modules and lessons.', 'ts-lms' ),
				'icon'        => 'layout',
			),
			array(
				'id'          => 'lesson_content',
				'title'       => __( 'Lesson Content Generator', 'ts-lms' ),
				'description' => __( 'Create detailed content for your lessons based on topic and duration.', 'ts-lms' ),
				'icon'        => 'welcome-learn-more',
			),
			array(
				'id'          => 'quiz',
				'title'       => __( 'Quiz Generator', 'ts-lms' ),
				'description' => __( 'Generate multiple choice and true/false questions for your assessments.', 'ts-lms' ),
				'icon'        => 'playlist-audio',
			),
			array(
				'id'          => 'assignment',
				'title'       => __( 'Assignment Generator', 'ts-lms' ),
				'description' => __( 'Create assignment prompts and grading rubrics for your students.', 'ts-lms' ),
				'icon'        => 'clipboard',
			),
		);
		?>
		<div class="ts-lms-ai-generators-grid">
			<?php foreach ( $generators as $gen ) : ?>
				<div class="ts-lms-generator-card" data-type="<?php echo esc_attr( $gen['id'] ); ?>">
					<div class="card-icon">
						<span class="dashicons dashicons-<?php echo esc_attr( $gen['icon'] ); ?>"></span>
					</div>
					<h3><?php echo esc_html( $gen['title'] ); ?></h3>
					<p><?php echo esc_html( $gen['description'] ); ?></p>
					<button class="button button-primary open-generator" data-type="<?php echo esc_attr( $gen['id'] ); ?>">
						<?php _e( 'Open Generator', 'ts-lms' ); ?>
					</button>
				</div>
			<?php endforeach; ?>
		</div>

		<!-- Generator Modal Overlay -->
		<div id="ts-lms-ai-modal" class="ts-lms-ai-modal" style="display:none;">
			<div class="ts-lms-ai-modal-content">
				<div class="modal-header">
					<h2 id="modal-title"></h2>
					<span class="close-modal">&times;</span>
				</div>
				<div class="modal-body">
					<div class="generator-form-container">
						<form id="generator-form"></form>
					</div>
					<div class="generator-preview-container" style="display:none;">
						<div class="preview-header">
							<h3><?php _e( 'Generated Content', 'ts-lms' ); ?></h3>
							<div class="preview-actions">
								<button class="button copy-content"><?php _e( 'Copy to Clipboard', 'ts-lms' ); ?></button>
								<button class="button save-as-draft"><?php _e( 'Save as Draft', 'ts-lms' ); ?></button>
							</div>
						</div>
						<div id="content-preview" class="content-preview"></div>
					</div>
				</div>
				<div class="modal-footer">
					<button id="submit-generation" class="button button-primary button-large"><?php _e( 'Generate Content', 'ts-lms' ); ?></button>
					<div class="generation-status" style="display:none;">
						<span class="spinner is-active"></span>
						<span class="status-text"><?php _e( 'AI is thinking...', 'ts-lms' ); ?></span>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render Templates tab.
	 *
	 * @return void
	 */
	private static function render_templates_tab() {
		if ( ! current_user_can( 'manage_options' ) ) {
			_e( 'You do not have permission to edit prompt templates.', 'ts-lms' );
			return;
		}

		$repository = new PromptTemplateRepository();
		$templates = $repository->get_all();
		?>
		<div class="ts-lms-ai-templates-list">
			<?php foreach ( $templates as $template ) : ?>
				<div class="postbox ts-lms-template-box" data-id="<?php echo esc_attr( $template->id ); ?>">
					<div class="postbox-header">
						<h2><?php echo esc_html( $template->template_name ); ?> <span class="badge"><?php echo esc_html( $template->template_type ); ?></span></h2>
						<div class="handle-actions">
							<button class="button reset-template" data-id="<?php echo esc_attr( $template->id ); ?>"><?php _e( 'Reset to Default', 'ts-lms' ); ?></button>
						</div>
					</div>
					<div class="inside">
						<div class="template-editor-wrap">
							<textarea class="widefat template-content" rows="15"><?php echo esc_textarea( $template->template_content ); ?></textarea>
							<div class="template-variables">
								<strong><?php _e( 'Available Variables:', 'ts-lms' ); ?></strong>
								<code><?php echo implode( '</code>, <code>', array_map( function( $v ) { return '{' . $v . '}'; }, $template->variables ) ); ?></code>
							</div>
						</div>
						<div class="template-actions mt-2">
							<button class="button button-primary save-template" data-id="<?php echo esc_attr( $template->id ); ?>"><?php _e( 'Save changes', 'ts-lms' ); ?></button>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Render Usage tab.
	 *
	 * @return void
	 */
	private static function render_usage_tab() {
		$tracker = new UsageTracker();
		$user_id = get_current_user_id();
		
		$stats_today = $tracker->get_user_usage( $user_id, 'today' );
		$stats_month = $tracker->get_user_usage( $user_id, 'month' );
		$limit = $tracker->get_user_limit( $user_id );
		$breakdown = $tracker->get_usage_breakdown( $user_id, 'month' );

		?>
		<div class="ts-lms-ai-usage-dashboard">
			<div class="stats-cards-grid">
				<div class="stats-card">
					<h4><?php _e( 'Today\'s Usage', 'ts-lms' ); ?></h4>
					<div class="stats-value"><?php echo number_format( $stats_today['total_tokens'] ); ?> <span class="unit">tokens</span></div>
					<div class="stats-limit"><?php echo sprintf( __( 'of %s daily limit', 'ts-lms' ), number_format( $limit ) ); ?></div>
					<div class="progress-bar">
						<div class="progress-fill" style="width: <?php echo min( 100, ( $stats_today['total_tokens'] / max( 1, $limit ) ) * 100 ); ?>%;"></div>
					</div>
				</div>
				<div class="stats-card">
					<h4><?php _e( 'Monthly Usage', 'ts-lms' ); ?></h4>
					<div class="stats-value"><?php echo number_format( $stats_month['total_tokens'] ); ?> <span class="unit">tokens</span></div>
					<div class="stats-info"><?php echo sprintf( __( '%s requests this month', 'ts-lms' ), number_format( $stats_month['request_count'] ) ); ?></div>
				</div>
				<div class="stats-card">
					<h4><?php _e( 'Success Rate', 'ts-lms' ); ?></h4>
					<div class="stats-value">
						<?php 
						$success_rate = $stats_month['request_count'] > 0 ? ( $stats_month['successful_requests'] / $stats_month['request_count'] ) * 100 : 100;
						echo round( $success_rate, 1 ); 
						?>%
					</div>
					<div class="stats-info"><?php echo sprintf( __( '%s successful operations', 'ts-lms' ), number_format( $stats_month['successful_requests'] ) ); ?></div>
				</div>
			</div>

			<div class="mt-4">
				<h3><?php _e( 'Usage Breakdown by Generator', 'ts-lms' ); ?></h3>
				<table class="wp-list-table widefat fixed striped">
					<thead>
						<tr>
							<th><?php _e( 'Generator', 'ts-lms' ); ?></th>
							<th><?php _e( 'Requests', 'ts-lms' ); ?></th>
							<th><?php _e( 'Total Tokens', 'ts-lms' ); ?></th>
							<th><?php _e( 'Success Rate', 'ts-lms' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( empty( $breakdown ) ) : ?>
							<tr>
								<td colspan="4"><?php _e( 'No usage data available for this period.', 'ts-lms' ); ?></td>
							</tr>
						<?php else : ?>
							<?php foreach ( $breakdown as $type => $data ) : ?>
								<tr>
									<td><strong><?php echo ucwords( str_replace( '_', ' ', $type ) ); ?></strong></td>
									<td><?php echo number_format( $data['request_count'] ); ?></td>
									<td><?php echo number_format( $data['total_tokens'] ); ?></td>
									<td><?php echo round( ( $data['successful_requests'] / max( 1, $data['request_count'] ) ) * 100, 1 ); ?>%</td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	/**
	 * Render Settings tab.
	 *
	 * @return void
	 */
	private static function render_settings_tab() {
		if ( ! current_user_can( 'manage_options' ) ) {
			_e( 'You do not have permission to access AI settings.', 'ts-lms' );
			return;
		}

		$api_key = get_option( 'ts_lms_openai_api_key', '' );
		$is_key_set = ! empty( $api_key );
		$model = get_option( 'ts_lms_ai_model', 'gpt-3.5-turbo' );
		
		$limit_admin = get_option( 'ts_lms_ai_usage_limit_admin', 1000 );
		$limit_instructor = get_option( 'ts_lms_ai_usage_limit_instructor', 500 );
		$limit_default = get_option( 'ts_lms_ai_usage_limit_default', 100 );

		?>
		<form method="post" action="">
			<?php wp_nonce_field( 'ts_lms_ai_settings_nonce', 'ts_lms_ai_nonce' ); ?>
			
			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="openai_api_key"><?php _e( 'OpenAI API Key', 'ts-lms' ); ?></label>
					</th>
					<td>
						<input type="password" id="openai_api_key" name="openai_api_key" value="" class="regular-text" placeholder="<?php echo $is_key_set ? '******** (Already Set)' : 'sk-...'; ?>" />
						<p class="description">
							<?php _e( 'Enter your OpenAI API key. You can find it in your', 'ts-lms' ); ?> 
							<a href="https://platform.openai.com/api-keys" target="_blank"><?php _e( 'OpenAI dashboard', 'ts-lms' ); ?></a>.
						</p>
						<p class="description" style="color: #2271b1; font-weight: 500;">
							<span class="dashicons dashicons-info" style="font-size: 16px; vertical-align: middle;"></span>
							<?php _e( 'Tip: Enter <code>demo-key</code> to enable Demo Mode and test generation with mock data.', 'ts-lms' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="ai_model"><?php _e( 'AI Model', 'ts-lms' ); ?></label>
					</th>
					<td>
						<select id="ai_model" name="ai_model">
							<option value="gpt-3.5-turbo" <?php selected( $model, 'gpt-3.5-turbo' ); ?>>GPT-3.5 Turbo (Fast & Cheap)</option>
							<option value="gpt-4o" <?php selected( $model, 'gpt-4o' ); ?>>GPT-4o (New, Fast & Smart)</option>
							<option value="gpt-4-turbo" <?php selected( $model, 'gpt-4-turbo' ); ?>>GPT-4 Turbo (High quality)</option>
						</select>
						<p class="description"><?php _e( 'Select the OpenAI model to use for content generation.', 'ts-lms' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label><?php _e( 'Daily Token Limits', 'ts-lms' ); ?></label>
					</th>
					<td>
						<fieldset>
							<p>
								<label for="limit_admin"><?php _e( 'Administrator', 'ts-lms' ); ?>:</label>
								<input type="number" id="limit_admin" name="limit_admin" value="<?php echo esc_attr( $limit_admin ); ?>" class="small-text" />
							</p>
							<p>
								<label for="limit_instructor"><?php _e( 'Instructor / Editor', 'ts-lms' ); ?>:</label>
								<input type="number" id="limit_instructor" name="limit_instructor" value="<?php echo esc_attr( $limit_instructor ); ?>" class="small-text" />
							</p>
							<p>
								<label for="limit_default"><?php _e( 'Other Roles', 'ts-lms' ); ?>:</label>
								<input type="number" id="limit_default" name="limit_default" value="<?php echo esc_attr( $limit_default ); ?>" class="small-text" />
							</p>
							<p class="description"><?php _e( 'Maximum number of tokens each user role can consume per day.', 'ts-lms' ); ?></p>
						</fieldset>
					</td>
				</tr>
			</table>

			<p class="submit">
				<input type="submit" name="ts_lms_ai_save_settings" class="button button-primary" value="<?php _e( 'Save AI Settings', 'ts-lms' ); ?>" />
			</p>
		</form>
		<?php
	}
}
