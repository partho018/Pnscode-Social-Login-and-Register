jQuery(document).ready(function($) {
    /**
     * AI Studio Admin JavaScript
     */

    const modal = $('#ts-lms-ai-modal');
    const generatorForm = $('#generator-form');
    const previewContainer = $('.generator-preview-container');
    const previewContent = $('#content-preview');
    const submitBtn = $('#submit-generation');
    const statusRow = $('.generation-status');

    // Generator Field Definitions
    const fields = {
        course_outline: [
            { id: 'course_title', label: 'Course Title', type: 'text', placeholder: 'e.g. Master React in 30 Days' },
            { id: 'topic', label: 'Main Topic/Subject', type: 'text', placeholder: 'e.g. Web Development with React' },
            { id: 'difficulty_level', label: 'Difficulty Level', type: 'select', options: ['Beginner', 'Intermediate', 'Advanced'] },
            { id: 'target_audience', label: 'Target Audience', type: 'text', placeholder: 'e.g. Aspiring full-stack developers' },
            { id: 'duration', label: 'Projected Duration (Hours)', type: 'number', placeholder: 'e.g. 20' }
        ],
        lesson_content: [
            { id: 'lesson_title', label: 'Lesson Title', type: 'text', placeholder: 'e.g. Understanding React Hooks' },
            { id: 'topic', label: 'Lesson Topic', type: 'text', placeholder: 'e.g. useEffect and useState hooks' },
            { id: 'learning_objectives', label: 'Learning Objectives', type: 'textarea', placeholder: 'Learners will be able to...' },
            { id: 'target_audience', label: 'Target Audience', type: 'text', placeholder: 'e.g. Beginner React developers' },
            { id: 'duration', label: 'Lesson Duration (Minutes)', type: 'number', placeholder: 'e.g. 45' },
            { id: 'content_format', label: 'Preferred Content Format', type: 'select', options: ['Standard Article', 'Video Script', 'Step-by-step Tutorial'] }
        ],
        quiz: [
            { id: 'topic', label: 'Quiz Topic', type: 'text', placeholder: 'e.g. Fundamentals of JavaScript' },
            { id: 'difficulty_level', label: 'Difficulty Level', type: 'select', options: ['Easy', 'Medium', 'Hard'] },
            { id: 'question_count', label: 'Number of Questions', type: 'number', placeholder: 'e.g. 10' },
            { id: 'question_types', label: 'Allowed Question Types', type: 'text', placeholder: 'e.g. MCQ, True/False' },
            { id: 'learning_objectives', label: 'Assessment Objectives', type: 'textarea', placeholder: 'What are you testing?' }
        ],
        assignment: [
            { id: 'topic', label: 'Assignment Topic', type: 'text', placeholder: 'e.g. Build a Todo App with React' },
            { id: 'assignment_type', label: 'Assignment Type', type: 'select', options: ['Practical Project', 'Essay/Report', 'Case Study'] },
            { id: 'difficulty_level', label: 'Difficulty Level', type: 'select', options: ['Beginner', 'Intermediate', 'Advanced'] },
            { id: 'learning_objectives', label: 'Learning Objectives', type: 'textarea', placeholder: 'What should students demonstrate?' },
            { id: 'duration', label: 'Estimated Time to Complete (Hours)', type: 'number', placeholder: 'e.g. 5' },
            { id: 'target_audience', label: 'Target Audience', type: 'text', placeholder: 'e.g. Intermediate students' }
        ]
    };

    /**
     * Modal Management
     */
    $('.open-generator').on('click', function() {
        const type = $(this).data('type');
        const title = $(this).siblings('h3').text();
        
        $('#modal-title').text(title);
        buildForm(type);
        
        previewContainer.hide();
        previewContent.empty();
        submitBtn.show().attr('data-type', type);
        statusRow.hide();
        
        modal.fadeIn();
    });

    $('.close-modal').on('click', function() {
        modal.fadeOut();
    });

    $(window).on('click', function(e) {
        if ($(e.target).is(modal)) {
            modal.fadeOut();
        }
    });

    /**
     * Form Builder
     */
    function buildForm(type) {
        const fieldList = fields[type];
        generatorForm.empty();
        
        fieldList.forEach(field => {
            const group = $('<div class="form-group"></div>');
            group.append(`<label for="ai-${field.id}">${field.label}</label>`);
            
            let input;
            if (field.type === 'select') {
                input = $(`<select id="ai-${field.id}" name="${field.id}"></select>`);
                field.options.forEach(opt => {
                    input.append(`<option value="${opt.toLowerCase()}">${opt}</option>`);
                });
            } else if (field.type === 'textarea') {
                input = $(`<textarea id="ai-${field.id}" name="${field.id}" rows="3" placeholder="${field.placeholder}"></textarea>`);
            } else {
                input = $(`<input type="${field.type}" id="ai-${field.id}" name="${field.id}" placeholder="${field.placeholder}" />`);
            }
            
            group.append(input);
            generatorForm.append(group);
        });
    }

    /**
     * Content Generation
     */
    submitBtn.on('click', function() {
        const type = $(this).attr('data-type');
        const formData = {};
        
        generatorForm.find(':input').each(function() {
            formData[$(this).attr('name')] = $(this).val();
        });

        $(this).prop('disabled', true);
        statusRow.show();
        previewContainer.hide();

        $.ajax({
            url: tsLmsAIStudio.restUrl + 'generate/' + type,
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', tsLmsAIStudio.restNonce);
            },
            data: {
                params: formData
            },
            success: function(response) {
                renderPreview(response.content);
                previewContainer.fadeIn();
            },
            error: function(xhr) {
                const error = xhr.responseJSON ? xhr.responseJSON.message : tsLmsAIStudio.i18n.error;
                alert(error);
            },
            complete: function() {
                submitBtn.prop('disabled', false);
                statusRow.hide();
            }
        });
    });

    function renderPreview(content) {
        previewContent.html('<pre>' + JSON.stringify(content, null, 2) + '</pre>');
    }

    /**
     * Copy Content
     */
    $('.copy-content').on('click', function() {
        const text = previewContent.text();
        navigator.clipboard.writeText(text).then(() => {
            $(this).text('Copied!');
            setTimeout(() => $(this).text('Copy to Clipboard'), 2000);
        });
    });

    /**
     * Template Management
     */
    $('.save-template').on('click', function() {
        const id = $(this).data('id');
        const box = $(this).closest('.ts-lms-template-box');
        const content = box.find('.template-content').val();
        const btn = $(this);

        btn.prop('disabled', true).text('Saving...');

        $.ajax({
            url: tsLmsAIStudio.ajaxUrl,
            method: 'POST',
            data: {
                action: 'ts_lms_ai_save_template',
                nonce: tsLmsAIStudio.nonce,
                template_id: id,
                template_content: content
            },
            success: function(response) {
                if (response.success) {
                    alert(tsLmsAIStudio.i18n.templateSaved);
                } else {
                    alert(response.data.message);
                }
            },
            error: function() {
                alert(tsLmsAIStudio.i18n.error);
            },
            complete: function() {
                btn.prop('disabled', false).text('Save changes');
            }
        });
    });

    $('.reset-template').on('click', function() {
        if (!confirm(tsLmsAIStudio.i18n.confirmReset)) return;
        
        const id = $(this).data('id');
        const box = $(this).closest('.ts-lms-template-box');
        
        // In a real app, we'd call an endpoint to get the default. 
        // For now, we'll just reload the page after reset in server-side
        // But let's simulate with AJAX reload for better UX if we had that endpoint
        alert('Resetting to default...');
        location.reload();
    });
});
