<?php
/**
 * Register Template
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$settings = \TS_LMS\Admin\Settings::get_settings();
$phone_field = isset( $settings['reg_phone_field'] ) ? $settings['reg_phone_field'] : 'disabled';
$show_google = isset( $settings['enable_google_login'] ) && $settings['enable_google_login'];
$show_facebook = isset( $settings['enable_facebook_login'] ) && $settings['enable_facebook_login'];
$show_github = isset( $settings['enable_github_login'] ) && $settings['enable_github_login'];
?>

<div class="ts-auth-wrapper">
    <div class="ts-auth-card">
        <div class="ts-auth-header">
            <h2>Create Account</h2>
            <p>Join our community and start learning today.</p>
        </div>

        <div class="ts-auth-body">
            <div id="ts-lms-auth-message" class="ts-auth-message"></div>

            <form id="ts-lms-register-form" method="post">
                <div class="ts-auth-input-group">
                    <label for="reg-name"><?php esc_html_e( 'Full Name', 'ts-lms' ); ?></label>
                    <input type="text" name="full_name" id="reg-name" placeholder="<?php esc_attr_e( 'Enter Your Full name', 'ts-lms' ); ?>" required>
                </div>

                <div class="ts-auth-input-group">
                    <label for="reg-email"><?php esc_html_e( 'Email Address', 'ts-lms' ); ?></label>
                    <input type="email" name="email" id="reg-email" placeholder="example@gmail.com" required>
                </div>

                <?php if ( $phone_field !== 'disabled' ) : ?>
                <div class="ts-auth-input-group">
                    <label for="reg-phone"><?php esc_html_e( 'Phone Number', 'ts-lms' ); ?></label>
                    <input type="text" name="phone" id="reg-phone" placeholder="<?php esc_attr_e( 'Enter Your Number', 'ts-lms' ); ?>" required>
                </div>
                <?php endif; ?>

                <div class="ts-auth-input-group">
                    <label for="reg-password"><?php esc_html_e( 'Password', 'ts-lms' ); ?></label>
                    <input type="password" name="password" id="reg-password" placeholder="••••••••" required>
                </div>

                <?php 
                $enable_instructor_reg = isset( $settings['enable_instructor_registration'] ) && $settings['enable_instructor_registration'];
                if ( $enable_instructor_reg ) : 
                ?>
                <div class="ts-auth-input-group instructor-toggle">
                    <label class="ts-checkbox-label">
                        <input type="checkbox" name="apply_as_instructor" id="apply_as_instructor" value="1">
                        <span><?php esc_html_e( 'Apply as Instructor', 'ts-lms' ); ?></span>
                    </label>
                    <p class="field-description"><?php esc_html_e( 'Check this if you want to teach and create courses', 'ts-lms' ); ?></p>
                </div>

                <div class="instructor-fields" style="display: none;">
                    <div class="ts-auth-input-group">
                        <label for="reg-bio"><?php esc_html_e( 'Professional Bio', 'ts-lms' ); ?></label>
                        <textarea name="bio" id="reg-bio" rows="4" placeholder="<?php esc_attr_e( 'Tell us about your expertise and experience...', 'ts-lms' ); ?>"></textarea>
                    </div>

                    <div class="ts-auth-input-group">
                        <label for="reg-skills"><?php esc_html_e( 'Skills / Expertise', 'ts-lms' ); ?></label>
                        <input type="text" name="skills" id="reg-skills" placeholder="<?php esc_attr_e( 'e.g., Web Development, JavaScript, React', 'ts-lms' ); ?>">
                    </div>

                    <div class="ts-auth-input-group">
                        <label for="reg-experience"><?php esc_html_e( 'Years of Experience', 'ts-lms' ); ?></label>
                        <input type="text" name="experience" id="reg-experience" placeholder="<?php esc_attr_e( 'e.g., 5 years', 'ts-lms' ); ?>">
                    </div>
                </div>
                <?php endif; ?>

                <button type="submit" class="ts-auth-btn-primary" id="ts-lms-register-submit">
                    <?php esc_html_e( 'Create Account', 'ts-lms' ); ?>
                </button>

                <?php if ( $show_google || $show_facebook || $show_github ) : ?>
                <div class="ts-auth-divider">
                    <span>Or register with</span>
                </div>

                <div class="ts-auth-social">
                    <?php if ( $show_google ) : ?>
                    <button type="button" class="ts-social-btn" title="Google">
                        <img src="<?php echo plugin_dir_url( dirname(__FILE__) ) . 'assets/images/google.svg'; ?>" alt="Google">
                    </button>
                    <?php endif; ?>
                    
                    <?php if ( $show_facebook ) : ?>
                    <button type="button" class="ts-social-btn" title="Facebook">
                        <img src="<?php echo plugin_dir_url( dirname(__FILE__) ) . 'assets/images/facebook.svg'; ?>" alt="Facebook">
                    </button>
                    <?php endif; ?>

                    <?php if ( $show_github ) : ?>
                    <button type="button" class="ts-social-btn" title="GitHub">
                        <img src="<?php echo plugin_dir_url( dirname(__FILE__) ) . 'assets/images/github.svg'; ?>" alt="GitHub">
                    </button>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </form>
        </div>

        <div class="ts-auth-footer">
            <p>Already have an account? <a href="<?php echo esc_url( wp_login_url() ); ?>">Sign In</a></p>
        </div>
    </div>
</div>
