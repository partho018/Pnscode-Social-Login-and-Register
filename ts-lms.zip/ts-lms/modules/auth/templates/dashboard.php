<?php
/**
 * Student Dashboard Template - Premium Redesign
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Get current user
$user = wp_get_current_user();
$user_id = $user->ID;

// Check if user is approved instructor
if ( in_array( 'instructor', $user->roles ) ) {
    // Load InstructorManager if not already loaded
    if ( ! class_exists( '\TS_LMS\Modules\Auth\InstructorManager' ) ) {
        $instructor_manager_file = plugin_dir_path( dirname( __FILE__ ) ) . 'includes/InstructorManager.php';
        if ( file_exists( $instructor_manager_file ) ) {
            require_once $instructor_manager_file;
        }
    }
    
    // Check if approved
    if ( class_exists( '\TS_LMS\Modules\Auth\InstructorManager' ) && 
         \TS_LMS\Modules\Auth\InstructorManager::is_approved_instructor( $user_id ) ) {
        // Load instructor dashboard
        include plugin_dir_path( __FILE__ ) . 'dashboard-instructor.php';
        return;
    }
}

$full_name = !empty($user->display_name) ? $user->display_name : $user->user_login;

// Get avatar or initials
$avatar_id = get_user_meta($user_id, 'ts_lms_avatar_id', true);
$avatar_url = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : get_avatar_url($user_id);

// Get current section from URL
$current_section = isset($_GET['section']) ? sanitize_text_field($_GET['section']) : 'dashboard';

// Stats for sidebar display
global $wpdb;
$enrolled_count = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}ts_course_enrollments WHERE user_id = %d AND status != 'cancelled'",
    $user_id
));

// Dashboard URL base
$dashboard_page_id = \TS_LMS\Admin\Settings::get_setting( 'dashboard_page' );
$dashboard_url = $dashboard_page_id ? get_permalink( $dashboard_page_id ) : home_url( '/dashboard/' );
?>

<div class="ts-lms-dashboard-container student-dashboard">
    <!-- Sidebar -->
    <aside class="ts-lms-dashboard-sidebar">
        <div class="sidebar-header">
            <div class="user-avatar">
                <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($full_name); ?>">
            </div>
            <h3><?php echo esc_html($full_name); ?></h3>
            <p class="user-role"><?php esc_html_e('Student', 'ts-lms'); ?></p>
        </div>
        
        <nav class="dashboard-nav">
            <ul>
                <li class="<?php echo ($current_section === 'dashboard') ? 'active' : ''; ?>">
                    <a href="<?php echo esc_url(add_query_arg('section', 'dashboard', $dashboard_url)); ?>">
                        <span class="dashicons dashicons-dashboard"></span>
                        <?php esc_html_e('Dashboard', 'ts-lms'); ?>
                    </a>
                </li>
                <li class="<?php echo ($current_section === 'enrolled-courses') ? 'active' : ''; ?>">
                    <a href="<?php echo esc_url(add_query_arg('section', 'enrolled-courses', $dashboard_url)); ?>">
                        <span class="dashicons dashicons-welcome-learn-more"></span>
                        <?php esc_html_e('Enrolled Courses', 'ts-lms'); ?>
                    </a>
                </li>
                <li class="<?php echo ($current_section === 'profile') ? 'active' : ''; ?>">
                    <a href="<?php echo esc_url(add_query_arg('section', 'profile', $dashboard_url)); ?>">
                        <span class="dashicons dashicons-admin-users"></span>
                        <?php esc_html_e('My Profile', 'ts-lms'); ?>
                    </a>
                </li>
                <li class="<?php echo ($current_section === 'wishlist') ? 'active' : ''; ?>">
                    <a href="<?php echo esc_url(add_query_arg('section', 'wishlist', $dashboard_url)); ?>">
                        <span class="dashicons dashicons-heart"></span>
                        <?php esc_html_e('Wishlist', 'ts-lms'); ?>
                    </a>
                </li>
                <li class="<?php echo ($current_section === 'reviews') ? 'active' : ''; ?>">
                    <a href="<?php echo esc_url(add_query_arg('section', 'reviews', $dashboard_url)); ?>">
                        <span class="dashicons dashicons-star-filled"></span>
                        <?php esc_html_e('Reviews', 'ts-lms'); ?>
                    </a>
                </li>
                <li class="<?php echo ($current_section === 'quiz-attempts') ? 'active' : ''; ?>">
                    <a href="<?php echo esc_url(add_query_arg('section', 'quiz-attempts', $dashboard_url)); ?>">
                        <span class="dashicons dashicons-welcome-write-blog"></span>
                        <?php esc_html_e('Quiz Attempts', 'ts-lms'); ?>
                    </a>
                </li>
                <li class="<?php echo ($current_section === 'certificates') ? 'active' : ''; ?>">
                    <a href="<?php echo esc_url(add_query_arg('section', 'certificates', $dashboard_url)); ?>">
                        <span class="dashicons dashicons-awards"></span>
                        <?php esc_html_e('Certificates', 'ts-lms'); ?>
                    </a>
                </li>
                <li class="<?php echo ($current_section === 'qa') ? 'active' : ''; ?>">
                    <a href="<?php echo esc_url(add_query_arg('section', 'qa', $dashboard_url)); ?>">
                        <span class="dashicons dashicons-format-chat"></span>
                        <?php esc_html_e('Q&A', 'ts-lms'); ?>
                    </a>
                </li>
                <li class="<?php echo ($current_section === 'order-history') ? 'active' : ''; ?>">
                    <a href="<?php echo esc_url(add_query_arg('section', 'order-history', $dashboard_url)); ?>">
                        <span class="dashicons dashicons-cart"></span>
                        <?php esc_html_e('Order History', 'ts-lms'); ?>
                    </a>
                </li>
                <li class="<?php echo ($current_section === 'subscriptions') ? 'active' : ''; ?>">
                    <a href="<?php echo esc_url(add_query_arg('section', 'subscriptions', $dashboard_url)); ?>">
                        <span class="dashicons dashicons-calendar-alt"></span>
                        <?php esc_html_e('My Subscriptions', 'ts-lms'); ?>
                    </a>
                </li>
                <li class="<?php echo ($current_section === 'settings') ? 'active' : ''; ?>">
                    <a href="<?php echo esc_url(add_query_arg('section', 'settings', $dashboard_url)); ?>">
                        <span class="dashicons dashicons-admin-settings"></span>
                        <?php esc_html_e('Settings', 'ts-lms'); ?>
                    </a>
                </li>

                <!-- Become an Instructor Option -->
                <?php 
                $show_instructor_btn = \TS_LMS\Admin\Settings::get_setting('become_instructor_button');
                $instructor_status = get_user_meta($user_id, 'ts_instructor_status', true);
                
                // Show if enabled in settings OR if user has a pending application
                if ($show_instructor_btn || $instructor_status === 'pending') :
                    // Extra Check: Hide button if limit is reached AND user hasn't applied yet
                    $limit_reached = \TS_LMS\Modules\Auth\InstructorManager::is_limit_reached();
                    
                    if ($instructor_status !== 'approved' && !($limit_reached && empty($instructor_status))) :
                        $apply_url = get_permalink(\TS_LMS\Admin\Settings::get_setting('instructor_reg_page')) ?: home_url('/become-an-instructor/');
                ?>
                <li class="apply-instructor-li">
                    <a href="<?php echo esc_url($apply_url); ?>" class="apply-instructor-link">
                        <span class="dashicons dashicons-welcome-education"></span>
                        <?php echo ($instructor_status === 'pending') ? __('Status: Pending', 'ts-lms') : __('Become Instructor', 'ts-lms'); ?>
                    </a>
                </li>
                <?php 
                    endif;
                endif; 
                ?>
            </ul>
        </nav>
        
        <div class="sidebar-footer">
            <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="logout-link">
                <span class="dashicons dashicons-exit"></span>
                <?php esc_html_e('Logout', 'ts-lms'); ?>
            </a>
        </div>
    </aside>
    
    <!-- Main Content -->
    <main class="ts-lms-dashboard-main">
        <?php
        $section_file = __DIR__ . '/sections/' . ($current_section === 'dashboard' ? 'dashboard' : $current_section) . '.php';
        if (file_exists($section_file)) {
            include $section_file;
        } else {
            include __DIR__ . '/sections/dashboard.php';
        }
        ?>
    </main>
</div>

<style>
/* Dashboard Base Layout - Matching Instructor Design */
.student-dashboard {
    display: flex;
    gap: 30px;
    max-width: 1400px;
    margin: 40px auto;
    padding: 0 20px;
    font-family: 'Inter', sans-serif;
}

.student-dashboard a {
    text-decoration: none !important;
    box-shadow: none !important;
}

.ts-lms-dashboard-sidebar {
    width: 280px;
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    height: fit-content;
    position: sticky;
    top: 30px;
}

.sidebar-header {
    text-align: center;
    padding: 40px 20px;
}

.user-avatar img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    border: 4px solid #f8f9ff;
    object-fit: cover;
    margin-bottom: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.sidebar-header h3 {
    margin: 0 0 5px;
    font-size: 18px;
    color: #1f2937;
    font-weight: 700;
}

.user-role {
    color: var(--ts-primary);
    background: #f0f7ff;
    padding: 4px 15px;
    border-radius: 20px;
    font-size: 13px;
    display: inline-block;
    font-weight: 600;
}

.dashboard-nav ul {
    list-style: none;
    margin: 0;
    padding: 0 10px 30px;
}

.dashboard-nav li a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 12px 20px;
    color: #6b7280;
    text-decoration: none;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    border-radius: 12px;
    font-weight: 500;
    font-size: 14px;
}

.dashboard-nav li.active a {
    background: var(--ts-primary);
    color: #fff;
    box-shadow: 0 10px 20px -5px rgba(var(--ts-primary-rgb, 79, 70, 229), 0.4);
}

.dashboard-nav li:not(.active) a:hover {
    background: #f8f9ff;
    color: var(--ts-primary);
    padding-left: 25px;
}

.apply-instructor-link {
    background: #fdf2f2 !important;
    color: #dc2626 !important;
    margin-top: 15px;
    border: 1px dashed #f87171 !important;
}
.apply-instructor-link:hover {
    background: #dc2626 !important;
    color: #fff !important;
}

.sidebar-footer {
    padding: 20px;
    border-top: 1px dotted #e5e7eb;
}

.logout-link {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #ef4444;
    text-decoration: none;
    font-weight: 600;
    padding: 12px 20px;
    border-radius: 12px;
    transition: 0.3s;
}

.logout-link:hover {
    background: #fff5f5;
}

.ts-lms-dashboard-main {
    flex: 1;
}

@media (max-width: 992px) {
    .student-dashboard { flex-direction: column; }
    .ts-lms-dashboard-sidebar { width: 100%; position: relative; top: 0; }
}

/* Hide page title on dashboard */
.page-template-default.page-id-<?php echo $dashboard_page_id; ?> .entry-title,
.page-template-default.page-id-<?php echo $dashboard_page_id; ?> .page-title {
    display: none;
}
</style>
