<?php
/**
 * Login Template
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$settings = \TS_LMS\Admin\Settings::get_settings();
$show_google = isset( $settings['enable_google_login'] ) && $settings['enable_google_login'];
$show_facebook = isset( $settings['enable_facebook_login'] ) && $settings['enable_facebook_login'];
$show_github = isset( $settings['enable_github_login'] ) && $settings['enable_github_login'];
?>

<div class="ts-auth-wrapper">
    <div class="ts-auth-card">
        <div class="ts-auth-header">
            <h2>Welcome Back</h2>
            <p>Please enter your details to sign in.</p>
        </div>

        <div class="ts-auth-body">
            <div id="ts-lms-auth-message" class="ts-auth-message"></div>

            <form id="ts-lms-login-form" method="post">
                <div id="ts-login-fields">
                <div class="ts-auth-input-group">
                    <label for="login-username"><?php esc_html_e( 'Email or Username', 'ts-lms' ); ?></label>
                    <input type="text" name="username" id="login-username" placeholder="Username or Email" required>
                </div>

                <div class="ts-auth-input-group">
                    <label for="login-password"><?php esc_html_e( 'Password', 'ts-lms' ); ?></label>
                    <input type="password" name="password" id="login-password" placeholder="••••••••" required>
                </div>

                <div class="ts-auth-extra">
                    <label class="ts-auth-remember">
                        <input type="checkbox" name="remember" value="true" checked>
                        <span>Remember me</span>
                    </label>
                    <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>" class="ts-auth-forgot">Forgot Password?</a>
                </div>

                <button type="submit" class="ts-auth-btn-primary" id="ts-lms-login-submit">
                    <?php esc_html_e( 'Sign In', 'ts-lms' ); ?>
                </button>

                <?php if ( $show_google || $show_facebook || $show_github ) : ?>
                <div class="ts-auth-divider">
                    <span>Or sign in with</span>
                </div>

                <div class="ts-auth-social">
                    <?php if ( $show_google ) : ?>
                    <button type="button" class="ts-social-btn" title="Google">
                        <img src="<?php echo plugin_dir_url( dirname(__FILE__) ) . 'assets/images/google.svg'; ?>" alt="Google">
                    </button>
                    <?php endif; ?>
                    
                    <?php if ( $show_facebook ) : ?>
                    <button type="button" class="ts-social-btn" title="Facebook">
                        <img src="<?php echo plugin_dir_url( dirname(__FILE__) ) . 'assets/images/facebook.svg'; ?>" alt="Facebook">
                    </button>
                    <?php endif; ?>

                    <?php if ( $show_github ) : ?>
                    <button type="button" class="ts-social-btn" title="GitHub">
                        <img src="<?php echo plugin_dir_url( dirname(__FILE__) ) . 'assets/images/github.svg'; ?>" alt="GitHub">
                    </button>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                </div>

                <div id="ts-2fa-fields" style="display: none;">
                    <div class="ts-auth-input-group">
                        <label for="login-2fa"><?php esc_html_e( 'Verification Code', 'ts-lms' ); ?></label>
                        <input type="text" name="2fa_code" id="login-2fa" placeholder="6-digit code">
                        <p class="description" style="font-size: 12px; margin-top: 5px; color: #64748b;">
                            <?php esc_html_e( 'Enter the 6-digit code sent to your email.', 'ts-lms' ); ?>
                        </p>
                    </div>
                    <button type="button" class="ts-auth-btn-primary" id="ts-lms-2fa-submit">
                        <?php esc_html_e( 'Verify & Sign In', 'ts-lms' ); ?>
                    </button>
                    <div style="text-align: center; margin-top: 15px;">
                        <a href="javascript:void(0)" id="ts-lms-2fa-back" style="font-size: 14px; color: #64748b; text-decoration: none;">
                            <?php esc_html_e( '← Back to Login', 'ts-lms' ); ?>
                        </a>
                    </div>
                </div>
            </form>
        </div>

        <div class="ts-auth-footer">
            <p>Don't have an account? <a href="<?php echo esc_url( wp_registration_url() ); ?>">Create Account</a></p>
        </div>
    </div>
</div>
