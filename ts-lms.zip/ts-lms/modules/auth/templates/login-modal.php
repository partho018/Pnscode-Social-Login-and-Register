<?php
/**
 * Login Modal Template
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div id="ts-lms-auth-modal" class="ts-modal-overlay">
    <div class="ts-modal-container">
        <button type="button" class="ts-modal-close" id="ts-auth-modal-close">
            <span class="dashicons dashicons-no-alt"></span>
        </button>
        <div class="ts-modal-content">
            <?php include plugin_dir_path( __FILE__ ) . 'login.php'; ?>
        </div>
    </div>
</div>
<?php
