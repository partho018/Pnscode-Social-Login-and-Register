<?php
/**
 * Instructor Dashboard Template
 *
 * @package TS_LMS\Modules\Auth\Templates
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$user = wp_get_current_user();
$user_id = get_current_user_id();

// Get instructor status
$instructor_status = get_user_meta( $user_id, 'ts_instructor_status', true );

// If pending or rejected, show appropriate message
if ( $instructor_status !== 'approved' ) {
    ?>
    <div class="ts-lms-dashboard-container">
        <div class="ts-lms-pending-approval">
            <div class="pending-icon">
                <span class="dashicons <?php echo $instructor_status === 'rejected' ? 'dashicons-dismiss' : 'dashicons-clock'; ?>"></span>
            </div>
            <h2><?php 
                if ($instructor_status === 'rejected') {
                    _e( 'Application Rejected', 'ts-lms' );
                } else {
                    _e( 'Instructor Application Pending', 'ts-lms' );
                }
            ?></h2>
            <p><?php 
                if ($instructor_status === 'rejected') {
                    _e( 'Sorry, your instructor application has been rejected. You can contact support for more information.', 'ts-lms' );
                    $reason = get_user_meta($user_id, 'ts_instructor_rejection_reason', true);
                    if ($reason) {
                        echo '<br><strong>' . __('Reason:', 'ts-lms') . '</strong> ' . esc_html($reason);
                    }
                } else {
                    _e( 'Your instructor application is currently under review. You will receive an email notification once it has been approved.', 'ts-lms' );
                }
            ?></p>
            <p><strong><?php esc_html_e( 'Status:', 'ts-lms' ); ?></strong> <span class="status-badge status-<?php echo esc_attr( $instructor_status ); ?>"><?php echo esc_html( ucfirst( $instructor_status ) ); ?></span></p>
        </div>
    </div>
    <?php
    return;
}

// Get active section
$active_section = isset( $_GET['section'] ) ? sanitize_text_field( $_GET['section'] ) : 'overview';

// Get user info
$first_name = $user->first_name ? $user->first_name : $user->display_name;
$avatar_url = get_avatar_url( $user_id, array( 'size' => 120 ) );
$avatar_id = get_user_meta($user_id, 'ts_lms_avatar_id', true);
if ($avatar_id) {
    $avatar_url = wp_get_attachment_image_url($avatar_id, 'thumbnail');
}
?>

<div class="ts-lms-dashboard-container instructor-dashboard">
    <!-- Sidebar -->
    <aside class="ts-lms-dashboard-sidebar">
        <div class="sidebar-header">
            <div class="user-avatar">
                <img src="<?php echo esc_url( $avatar_url ); ?>" alt="<?php echo esc_attr( $user->display_name ); ?>">
            </div>
            <h3><?php echo esc_html( $user->display_name ); ?></h3>
            <p class="user-role"><?php esc_html_e( 'Instructor', 'ts-lms' ); ?></p>
        </div>
        
        <nav class="dashboard-nav">
            <ul>
                <li class="<?php echo $active_section === 'overview' ? 'active' : ''; ?>">
                    <a href="?section=overview">
                        <span class="dashicons dashicons-dashboard"></span>
                        <?php esc_html_e( 'Dashboard', 'ts-lms' ); ?>
                    </a>
                </li>
                <li class="<?php echo $active_section === 'courses' ? 'active' : ''; ?>">
                    <a href="?section=courses">
                        <span class="dashicons dashicons-welcome-learn-more"></span>
                        <?php esc_html_e( 'My Courses', 'ts-lms' ); ?>
                    </a>
                </li>
                <li class="<?php echo $active_section === 'students' ? 'active' : ''; ?>">
                    <a href="?section=students">
                        <span class="dashicons dashicons-groups"></span>
                        <?php esc_html_e( 'Students', 'ts-lms' ); ?>
                    </a>
                </li>
                <li class="<?php echo $active_section === 'earnings' ? 'active' : ''; ?>">
                    <a href="?section=earnings">
                        <span class="dashicons dashicons-money-alt"></span>
                        <?php esc_html_e( 'Earnings', 'ts-lms' ); ?>
                    </a>
                </li>
                <li class="<?php echo $active_section === 'subscriptions' ? 'active' : ''; ?>">
                    <a href="?section=subscriptions">
                        <span class="dashicons dashicons-calendar-alt"></span>
                        <?php esc_html_e( 'Subscriptions', 'ts-lms' ); ?>
                    </a>
                </li>
                <li class="<?php echo $active_section === 'reviews' ? 'active' : ''; ?>">
                    <a href="?section=reviews">
                        <span class="dashicons dashicons-star-filled"></span>
                        <?php esc_html_e( 'Reviews & Q&A', 'ts-lms' ); ?>
                    </a>
                </li>
                <li class="<?php echo $active_section === 'assignments' ? 'active' : ''; ?>">
                    <a href="?section=assignments">
                        <span class="dashicons dashicons-portfolio"></span>
                        <?php esc_html_e( 'Assignments', 'ts-lms' ); ?>
                    </a>
                </li>
                <li class="<?php echo $active_section === 'reports' ? 'active' : ''; ?>">
                    <a href="?section=reports">
                        <span class="dashicons dashicons-chart-bar"></span>
                        <?php esc_html_e( 'Reports', 'ts-lms' ); ?>
                    </a>
                </li>
                <li class="<?php echo $active_section === 'settings' ? 'active' : ''; ?>">
                    <a href="?section=settings">
                        <span class="dashicons dashicons-admin-settings"></span>
                        <?php esc_html_e( 'Profile Settings', 'ts-lms' ); ?>
                    </a>
                </li>
            </ul>
        </nav>
        
        <div class="sidebar-footer">
            <a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>" class="logout-link">
                <span class="dashicons dashicons-exit"></span>
                <?php esc_html_e( 'Logout', 'ts-lms' ); ?>
            </a>
        </div>
    </aside>
    
    <!-- Main Content -->
    <main class="ts-lms-dashboard-main">
        <?php
        // Load section template
        $section_file = plugin_dir_path( __FILE__ ) . "sections/instructor-{$active_section}.php";
        
        if ( file_exists( $section_file ) ) {
            include $section_file;
        } else {
            // Default to overview or show "coming soon"
            echo '<div class="coming-soon"><h1>Section ' . esc_html($active_section) . ' coming soon</h1></div>';
        }
        ?>
    </main>
</div>

<style>
/* Dashboard Base Layout */
.instructor-dashboard {
    display: flex;
    gap: 30px;
    max-width: 1400px;
    margin: 40px auto;
    padding: 0 20px;
    font-family: 'Inter', sans-serif;
}

.ts-lms-dashboard-sidebar {
    width: 280px;
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    height: fit-content;
    position: sticky;
    top: 30px;
}

.sidebar-header {
    text-align: center;
    padding: 40px 20px;
}

.user-avatar img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    border: 4px solid #f8f9ff;
    object-fit: cover;
    margin-bottom: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.sidebar-header h3 {
    margin: 0 0 5px;
    font-size: 20px;
    color: #1f2937;
    font-weight: 700;
}

.user-role {
    color: var(--ts-primary);
    background: #f0f7ff;
    padding: 4px 15px;
    border-radius: 20px;
    font-size: 13px;
    display: inline-block;
    font-weight: 600;
}

.dashboard-nav ul {
    list-style: none;
    margin: 0;
    padding: 0 10px 30px;
}

.dashboard-nav li a {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 14px 20px;
    color: #6b7280;
    text-decoration: none;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    border-radius: 12px;
    font-weight: 500;
}

.dashboard-nav li.active a {
    background: var(--ts-primary);
    color: #fff;
    box-shadow: 0 10px 20px -5px rgba(var(--ts-primary-rgb, 79, 70, 229), 0.4);
}

.dashboard-nav li:not(.active) a:hover {
    background: #f8f9ff;
    color: var(--ts-primary);
    padding-left: 25px;
}

.dashboard-nav .dashicons {
    font-size: 20px;
    width: 20px;
    height: 20px;
}

.sidebar-footer {
    padding: 20px;
    border-top: 1px dotted #e5e7eb;
}

.logout-link {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #ef4444;
    text-decoration: none;
    font-weight: 600;
    padding: 12px 20px;
    border-radius: 12px;
    transition: 0.3s;
}

.logout-link:hover {
    background: #fff5f5;
}

.ts-lms-dashboard-main {
    flex: 1;
}

/* Animations */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

.ts-lms-dashboard-main > div {
    animation: fadeIn 0.4s ease-out;
}

/* Pending Message Styles */
.ts-lms-pending-approval {
    background: #fff;
    padding: 80px 40px;
    border-radius: 24px;
    text-align: center;
    box-shadow: 0 10px 40px rgba(0,0,0,0.05);
    max-width: 600px;
    margin: 100px auto;
}

.pending-icon {
    width: 120px;
    height: 120px;
    background: #fff8eb;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 30px;
}

.pending-icon .dashicons {
    font-size: 60px;
    color: #f59e0b;
    width: 60px;
    height: 60px;
}

.ts-lms-pending-approval h2 {
    font-size: 32px;
    margin-bottom: 20px;
    color: #111827;
}

.ts-lms-pending-approval p {
    color: #6b7280;
    font-size: 16px;
    line-height: 1.6;
}

.status-badge {
    padding: 6px 16px;
    border-radius: 50px;
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
}

.status-pending { background: #fef3c7; color: #92400e; }
.status-approved { background: #d1fae5; color: #065f46; }
.status-rejected { background: #fee2e2; color: #991b1b; }
</style>
