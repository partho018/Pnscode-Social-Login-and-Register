<?php
/**
 * Reviews Section
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$user_id = get_current_user_id();

// Get user's course reviews
$reviews = get_comments([
    'user_id' => $user_id,
    'type' => 'ts_course_review',
    'status' => 'approve',
    'orderby' => 'comment_date',
    'order' => 'DESC',
]);
?>

<div class="ts-section-reviews">
    <div class="ts-section-header">
        <h3 class="ts-section-title">
            <span class="dashicons dashicons-star-filled"></span>
            <?php esc_html_e('My Reviews', 'ts-lms'); ?>
        </h3>
        <p class="ts-section-subtitle"><?php esc_html_e('Your feedback on courses you\'ve taken', 'ts-lms'); ?></p>
    </div>

    <?php if (!empty($reviews)): ?>
        <div class="ts-reviews-list">
            <?php foreach ($reviews as $review): 
                $course_id = $review->comment_post_ID;
                $course = get_post($course_id);
                if (!$course) continue;
                
                $rating = get_comment_meta($review->comment_ID, 'rating', true);
                $thumbnail_id = get_post_thumbnail_id($course_id);
                $thumbnail_url = $thumbnail_id ? wp_get_attachment_image_url($thumbnail_id, 'thumbnail') : '';
            ?>
                <div class="ts-review-item">
                    <div class="ts-review-course">
                        <?php if ($thumbnail_url): ?>
                            <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr($course->post_title); ?>">
                        <?php else: ?>
                            <div class="ts-course-thumb-placeholder">
                                <span class="dashicons dashicons-book"></span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="ts-review-content">
                        <div class="ts-review-header">
                            <h4><?php echo esc_html($course->post_title); ?></h4>
                            <div class="ts-review-rating">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <span class="dashicons dashicons-star-<?php echo $i <= $rating ? 'filled' : 'empty'; ?>"></span>
                                <?php endfor; ?>
                            </div>
                        </div>
                        
                        <p class="ts-review-text"><?php echo esc_html($review->comment_content); ?></p>
                        
                        <div class="ts-review-meta">
                            <span class="ts-review-date">
                                <span class="dashicons dashicons-calendar-alt"></span>
                                <?php echo date_i18n(get_option('date_format'), strtotime($review->comment_date)); ?>
                            </span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="ts-empty-state-large">
            <div class="ts-empty-icon">
                <span class="dashicons dashicons-star-empty"></span>
            </div>
            <h4><?php esc_html_e('No Reviews Yet', 'ts-lms'); ?></h4>
            <p><?php esc_html_e('You haven\'t reviewed any courses yet. Share your experience to help others!', 'ts-lms'); ?></p>
        </div>
    <?php endif; ?>
</div>
