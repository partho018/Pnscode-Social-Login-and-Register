<?php
/**
 * Instructor Dashboard - Earnings
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$user_id = get_current_user_id();

$total_balance = get_user_meta($user_id, 'ts_instructor_earnings_balance', true) ?: 0;
$total_withdrawn = get_user_meta($user_id, 'ts_instructor_earnings_withdrawn', true) ?: 0;
$total_earnings = get_user_meta($user_id, 'ts_instructor_earnings_total', true) ?: 0;
?>

<div class="dashboard-header">
    <h1><?php esc_html_e( 'Earnings & Payouts', 'ts-lms' ); ?></h1>
    <p><?php esc_html_e( 'Track your revenue and manage your withdrawal requests.', 'ts-lms' ); ?></p>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon bg-green">
            <span class="dashicons dashicons-money-alt"></span>
        </div>
        <div class="stat-content">
            <h3><?php echo '$' . number_format($total_balance, 2); ?></h3>
            <p><?php esc_html_e( 'Current Balance', 'ts-lms' ); ?></p>
        </div>
        <button class="ts-lms-btn ts-lms-btn-sm withdraw-btn" <?php echo $total_balance <= 0 ? 'disabled' : ''; ?>><?php _e('Withdraw', 'ts-lms'); ?></button>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon bg-blue">
            <span class="dashicons dashicons-bank"></span>
        </div>
        <div class="stat-content">
            <h3><?php echo '$' . number_format($total_withdrawn, 2); ?></h3>
            <p><?php esc_html_e( 'Total Withdrawn', 'ts-lms' ); ?></p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon bg-purple">
            <span class="dashicons dashicons-chart-area"></span>
        </div>
        <div class="stat-content">
            <h3><?php echo '$' . number_format($total_earnings, 2); ?></h3>
            <p><?php esc_html_e( 'Lifetime Earnings', 'ts-lms' ); ?></p>
        </div>
    </div>
</div>

<div class="ts-lms-premium-card">
    <div class="card-header">
        <h2><?php _e('Withdrawal History', 'ts-lms'); ?></h2>
    </div>
    <div class="card-body">
        <table class="modern-table">
            <thead>
                <tr>
                    <th><?php _e('ID', 'ts-lms'); ?></th>
                    <th><?php _e('Date', 'ts-lms'); ?></th>
                    <th><?php _e('Amount', 'ts-lms'); ?></th>
                    <th><?php _e('Method', 'ts-lms'); ?></th>
                    <th><?php _e('Status', 'ts-lms'); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="5" class="empty-row"><?php _e('No withdrawal history found.', 'ts-lms'); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<style>
.withdraw-btn { margin-left: auto; padding: 8px 15px; font-size: 13px; }
.ts-lms-btn-sm { background: var(--ts-primary); color: #fff; border: none; border-radius: 8px; cursor: pointer; transition: 0.3s; }
.ts-lms-btn-sm:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 5px 10px rgba(0,0,0,0.1); }
.ts-lms-btn-sm:disabled { background: #e5e7eb; cursor: not-allowed; }
</style>
