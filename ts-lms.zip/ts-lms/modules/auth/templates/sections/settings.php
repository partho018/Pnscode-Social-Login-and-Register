<?php
/**
 * Settings Section
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$user_id = get_current_user_id();

// Handle settings update
if (isset($_POST['ts_update_settings']) && wp_verify_nonce($_POST['ts_settings_nonce'], 'ts_update_settings_action')) {
    // Email notifications
    $email_course_updates = isset($_POST['email_course_updates']) ? 1 : 0;
    $email_new_lessons = isset($_POST['email_new_lessons']) ? 1 : 0;
    $email_quiz_results = isset($_POST['email_quiz_results']) ? 1 : 0;
    $email_instructor_messages = isset($_POST['email_instructor_messages']) ? 1 : 0;
    
    update_user_meta($user_id, 'ts_email_course_updates', $email_course_updates);
    update_user_meta($user_id, 'ts_email_new_lessons', $email_new_lessons);
    update_user_meta($user_id, 'ts_email_quiz_results', $email_quiz_results);
    update_user_meta($user_id, 'ts_email_instructor_messages', $email_instructor_messages);
    
    echo '<div class="ts-notice ts-notice-success">' . esc_html__('Settings updated successfully!', 'ts-lms') . '</div>';
}

// Get current settings
$email_course_updates = get_user_meta($user_id, 'ts_email_course_updates', true);
$email_new_lessons = get_user_meta($user_id, 'ts_email_new_lessons', true);
$email_quiz_results = get_user_meta($user_id, 'ts_email_quiz_results', true);
$email_instructor_messages = get_user_meta($user_id, 'ts_email_instructor_messages', true);

// Default to true if not set
if ($email_course_updates === '') $email_course_updates = 1;
if ($email_new_lessons === '') $email_new_lessons = 1;
if ($email_quiz_results === '') $email_quiz_results = 1;
if ($email_instructor_messages === '') $email_instructor_messages = 1;
?>

<div class="ts-section-settings">
    <div class="ts-section-header">
        <h3 class="ts-section-title">
            <span class="dashicons dashicons-admin-generic"></span>
            <?php esc_html_e('Settings', 'ts-lms'); ?>
        </h3>
        <p class="ts-section-subtitle"><?php esc_html_e('Manage your preferences and notifications', 'ts-lms'); ?></p>
    </div>

    <div class="ts-settings-container">
        <form method="post" class="ts-settings-form">
            <?php wp_nonce_field('ts_update_settings_action', 'ts_settings_nonce'); ?>
            
            <!-- Email Notifications -->
            <div class="ts-settings-section">
                <h4 class="ts-settings-heading">
                    <span class="dashicons dashicons-email"></span>
                    <?php esc_html_e('Email Notifications', 'ts-lms'); ?>
                </h4>
                <p class="ts-settings-description"><?php esc_html_e('Choose which emails you want to receive', 'ts-lms'); ?></p>
                
                <div class="ts-settings-group">
                    <label class="ts-toggle-label">
                        <input type="checkbox" name="email_course_updates" value="1" 
                               <?php checked($email_course_updates, 1); ?> class="ts-toggle-input">
                        <span class="ts-toggle-switch"></span>
                        <span class="ts-toggle-text">
                            <strong><?php esc_html_e('Course Updates', 'ts-lms'); ?></strong>
                            <small><?php esc_html_e('Receive notifications when enrolled courses are updated', 'ts-lms'); ?></small>
                        </span>
                    </label>
                </div>

                <div class="ts-settings-group">
                    <label class="ts-toggle-label">
                        <input type="checkbox" name="email_new_lessons" value="1" 
                               <?php checked($email_new_lessons, 1); ?> class="ts-toggle-input">
                        <span class="ts-toggle-switch"></span>
                        <span class="ts-toggle-text">
                            <strong><?php esc_html_e('New Lessons', 'ts-lms'); ?></strong>
                            <small><?php esc_html_e('Get notified when new lessons are added to your courses', 'ts-lms'); ?></small>
                        </span>
                    </label>
                </div>

                <div class="ts-settings-group">
                    <label class="ts-toggle-label">
                        <input type="checkbox" name="email_quiz_results" value="1" 
                               <?php checked($email_quiz_results, 1); ?> class="ts-toggle-input">
                        <span class="ts-toggle-switch"></span>
                        <span class="ts-toggle-text">
                            <strong><?php esc_html_e('Quiz Results', 'ts-lms'); ?></strong>
                            <small><?php esc_html_e('Receive quiz result notifications', 'ts-lms'); ?></small>
                        </span>
                    </label>
                </div>

                <div class="ts-settings-group">
                    <label class="ts-toggle-label">
                        <input type="checkbox" name="email_instructor_messages" value="1" 
                               <?php checked($email_instructor_messages, 1); ?> class="ts-toggle-input">
                        <span class="ts-toggle-switch"></span>
                        <span class="ts-toggle-text">
                            <strong><?php esc_html_e('Instructor Messages', 'ts-lms'); ?></strong>
                            <small><?php esc_html_e('Get notified when instructors reply to your questions', 'ts-lms'); ?></small>
                        </span>
                    </label>
                </div>
            </div>

            <!-- Account Management -->
            <div class="ts-settings-section">
                <h4 class="ts-settings-heading">
                    <span class="dashicons dashicons-admin-users"></span>
                    <?php esc_html_e('Account Management', 'ts-lms'); ?>
                </h4>
                <p class="ts-settings-description"><?php esc_html_e('Manage your account settings', 'ts-lms'); ?></p>
                
                <div class="ts-settings-actions">
                    <a href="<?php echo esc_url(add_query_arg('section', 'profile', get_permalink())); ?>" class="ts-btn-secondary">
                        <span class="dashicons dashicons-edit"></span>
                        <?php esc_html_e('Edit Profile', 'ts-lms'); ?>
                    </a>
                    
                    <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="ts-btn-secondary">
                        <span class="dashicons dashicons-migrate"></span>
                        <?php esc_html_e('Logout', 'ts-lms'); ?>
                    </a>
                </div>
            </div>

            <div class="ts-form-actions">
                <button type="submit" name="ts_update_settings" class="ts-btn-primary">
                    <span class="dashicons dashicons-yes"></span>
                    <?php esc_html_e('Save Settings', 'ts-lms'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
