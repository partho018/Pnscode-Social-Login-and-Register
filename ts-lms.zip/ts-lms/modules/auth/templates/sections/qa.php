<?php
/**
 * Question & Answer Section
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$user_id = get_current_user_id();

// Get user's questions and answers
$questions = get_comments([
    'user_id' => $user_id,
    'type' => 'ts_course_question',
    'status' => 'approve',
    'orderby' => 'comment_date',
    'order' => 'DESC',
]);
?>

<div class="ts-section-qa">
    <div class="ts-section-header">
        <h3 class="ts-section-title">
            <span class="dashicons dashicons-format-chat"></span>
            <?php esc_html_e('Question & Answer', 'ts-lms'); ?>
        </h3>
        <p class="ts-section-subtitle"><?php esc_html_e('Your questions and discussions from courses', 'ts-lms'); ?></p>
    </div>

    <?php if (!empty($questions)): ?>
        <div class="ts-qa-list">
            <?php foreach ($questions as $question): 
                $course_id = $question->comment_post_ID;
                $course = get_post($course_id);
                if (!$course) continue;
                
                // Get replies to this question
                $replies = get_comments([
                    'parent' => $question->comment_ID,
                    'status' => 'approve',
                    'orderby' => 'comment_date',
                    'order' => 'ASC',
                ]);
            ?>
                <div class="ts-qa-item">
                    <div class="ts-qa-header">
                        <div class="ts-qa-course-info">
                            <span class="dashicons dashicons-book"></span>
                            <a href="<?php echo esc_url(get_permalink($course_id)); ?>">
                                <?php echo esc_html($course->post_title); ?>
                            </a>
                        </div>
                        <span class="ts-qa-date">
                            <?php echo human_time_diff(strtotime($question->comment_date), current_time('timestamp')) . ' ' . __('ago', 'ts-lms'); ?>
                        </span>
                    </div>
                    
                    <div class="ts-qa-question">
                        <div class="ts-qa-avatar">
                            <?php echo get_avatar($question->user_id, 48); ?>
                        </div>
                        <div class="ts-qa-content">
                            <div class="ts-qa-author">
                                <strong><?php echo esc_html($question->comment_author); ?></strong>
                                <span class="ts-qa-badge"><?php esc_html_e('You', 'ts-lms'); ?></span>
                            </div>
                            <p><?php echo nl2br(esc_html($question->comment_content)); ?></p>
                        </div>
                    </div>

                    <?php if (!empty($replies)): ?>
                        <div class="ts-qa-replies">
                            <div class="ts-replies-header">
                                <span class="dashicons dashicons-admin-comments"></span>
                                <?php printf(_n('%d Reply', '%d Replies', count($replies), 'ts-lms'), count($replies)); ?>
                            </div>
                            
                            <?php foreach ($replies as $reply): 
                                $is_instructor = user_can($reply->user_id, 'edit_ts-courses');
                            ?>
                                <div class="ts-qa-reply">
                                    <div class="ts-qa-avatar">
                                        <?php echo get_avatar($reply->user_id, 40); ?>
                                    </div>
                                    <div class="ts-qa-content">
                                        <div class="ts-qa-author">
                                            <strong><?php echo esc_html($reply->comment_author); ?></strong>
                                            <?php if ($is_instructor): ?>
                                                <span class="ts-qa-badge ts-badge-instructor"><?php esc_html_e('Instructor', 'ts-lms'); ?></span>
                                            <?php endif; ?>
                                            <span class="ts-qa-time">
                                                <?php echo human_time_diff(strtotime($reply->comment_date), current_time('timestamp')) . ' ' . __('ago', 'ts-lms'); ?>
                                            </span>
                                        </div>
                                        <p><?php echo nl2br(esc_html($reply->comment_content)); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="ts-empty-state-large">
            <div class="ts-empty-icon">
                <span class="dashicons dashicons-format-chat"></span>
            </div>
            <h4><?php esc_html_e('No Questions Yet', 'ts-lms'); ?></h4>
            <p><?php esc_html_e('You haven\'t asked any questions yet. Feel free to ask questions in your courses!', 'ts-lms'); ?></p>
        </div>
    <?php endif; ?>
</div>
