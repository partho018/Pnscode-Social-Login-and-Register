<?php
/**
 * Instructor Dashboard Overview
 */
if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;
$user_id = get_current_user_id();

// Stats calculation
$total_courses = $wpdb->get_var( $wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'ts_course' AND post_author = %d AND post_status = 'publish'",
    $user_id
) );

$courses_table = $wpdb->prefix . 'posts';
$enrollments_table = $wpdb->prefix . 'ts_course_enrollments';

$total_students = $wpdb->get_var( $wpdb->prepare(
    "SELECT COUNT(DISTINCT e.user_id) 
    FROM {$enrollments_table} e
    INNER JOIN {$courses_table} c ON e.course_id = c.ID
    WHERE c.post_author = %d",
    $user_id
) );

$total_earnings = get_user_meta($user_id, 'ts_instructor_earnings_total', true) ?: 0;
$this_month_sales = 0; // Placeholder for now
$avg_rating = 0; // Placeholder for now

?>

<div class="dashboard-header">
    <h1><?php esc_html_e( 'Dashboard Overview', 'ts-lms' ); ?></h1>
    <p><?php printf( esc_html__( 'Welcome back, %s! Here is your performance overview.', 'ts-lms' ), esc_html( wp_get_current_user()->display_name ) ); ?></p>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon bg-blue">
            <span class="dashicons dashicons-welcome-learn-more"></span>
        </div>
        <div class="stat-content">
            <h3><?php echo esc_html( $total_courses ); ?></h3>
            <p><?php esc_html_e( 'Total Courses', 'ts-lms' ); ?></p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon bg-green">
            <span class="dashicons dashicons-groups"></span>
        </div>
        <div class="stat-content">
            <h3><?php echo esc_html( $total_students ); ?></h3>
            <p><?php esc_html_e( 'Total Students', 'ts-lms' ); ?></p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon bg-purple">
            <span class="dashicons dashicons-money-alt"></span>
        </div>
        <div class="stat-content">
            <h3><?php echo ts_lms_format_price($total_earnings); ?></h3>
            <p><?php esc_html_e( 'Total Earnings', 'ts-lms' ); ?></p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon bg-orange">
            <span class="dashicons dashicons-chart-line"></span>
        </div>
        <div class="stat-content">
            <h3><?php echo ts_lms_format_price($this_month_sales); ?></h3>
            <p><?php esc_html_e( 'This Month Sales', 'ts-lms' ); ?></p>
        </div>
    </div>
</div>

<div class="dashboard-grid-two">
    <div class="recent-courses-card">
        <div class="card-header">
            <h2><?php esc_html_e( 'My Courses', 'ts-lms' ); ?></h2>
            <a href="?section=courses" class="view-all"><?php esc_html_e( 'View All', 'ts-lms' ); ?></a>
        </div>
        <?php
        $recent_courses = get_posts( array(
            'post_type'      => 'ts_course',
            'author'         => $user_id,
            'posts_per_page' => 5,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ) );
        
        if ( $recent_courses ) :
        ?>
            <table class="modern-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Course', 'ts-lms' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'ts-lms' ); ?></th>
                        <th><?php esc_html_e( 'Enrolled', 'ts-lms' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $recent_courses as $course ) : 
                        $enrolled = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$enrollments_table} WHERE course_id = %d", $course->ID ) );
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html( $course->post_title ); ?></strong></td>
                        <td><span class="status-badge status-<?php echo esc_attr( $course->post_status ); ?>"><?php echo esc_html( ucfirst( $course->post_status ) ); ?></span></td>
                        <td><?php echo esc_html( $enrolled ); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p class="empty-msg"><?php esc_html_e( 'No courses created yet.', 'ts-lms' ); ?></p>
        <?php endif; ?>
    </div>

    <div class="earnings-chart-card">
        <div class="card-header">
            <h2><?php esc_html_e( 'Sales Performance', 'ts-lms' ); ?></h2>
        </div>
        <div class="chart-placeholder">
            <span class="dashicons dashicons-chart-area"></span>
            <p><?php esc_html_e( 'Sales data will appear here', 'ts-lms' ); ?></p>
        </div>
    </div>
</div>

<style>
.dashboard-header { margin-bottom: 40px; }
.dashboard-header h1 { font-size: 32px; color: #111827; margin: 0 0 5px; font-weight: 800; }
.dashboard-header p { color: #6b7280; font-size: 16px; }

.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 40px; }
.stat-card { background: #fff; padding: 25px; border-radius: 20px; display: flex; align-items: center; gap: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); transition: 0.3s; }
.stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.08); }

.stat-icon { width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center; color: #fff; }
.stat-icon .dashicons { font-size: 28px; width: 28px; height: 28px; }
.bg-blue { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); }
.bg-green { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
.bg-purple { background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); }
.bg-orange { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }

.stat-content h3 { font-size: 24px; color: #111827; margin: 0; font-weight: 700; }
.stat-content p { color: #6b7280; margin: 0; font-size: 14px; }

.dashboard-grid-two { display: grid; grid-template-columns: 1.5fr 1fr; gap: 30px; }
@media (max-width: 1024px) { .dashboard-grid-two { grid-template-columns: 1fr; } }

.recent-courses-card, .earnings-chart-card { background: #fff; padding: 30px; border-radius: 24px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); }
.card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
.card-header h2 { font-size: 20px; color: #111827; font-weight: 700; margin: 0; }
.view-all { color: var(--ts-primary); text-decoration: none; font-size: 14px; font-weight: 600; }

.modern-table { width: 100%; border-collapse: collapse; }
.modern-table th { text-align: left; padding: 12px; color: #9ca3af; font-size: 13px; text-transform: uppercase; font-weight: 600; }
.modern-table td { padding: 15px 12px; border-bottom: 1px solid #f3f4f6; font-size: 14px; }
.modern-table tr:last-child td { border-bottom: none; }

.chart-placeholder { height: 300px; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #f9fafb; border-radius: 16px; color: #9ca3af; }
.chart-placeholder .dashicons { font-size: 50px; width: 50px; height: 50px; margin-bottom: 15px; }
</style>
