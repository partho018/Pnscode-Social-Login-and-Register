<?php
/**
 * Instructor Dashboard - Students
 */
if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;
$user_id = get_current_user_id();

// Get courses by this instructor
$courses = get_posts( array(
    'post_type'      => 'ts_course',
    'author'         => $user_id,
    'posts_per_page' => -1,
    'fields'         => 'ids',
) );

$course_ids = ! empty( $courses ) ? implode( ',', array_map( 'intval', $courses ) ) : '0';

$enrollments_table = $wpdb->prefix . 'ts_course_enrollments';
$course_filter = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

$query = "SELECT e.*, u.display_name, u.user_email 
          FROM {$enrollments_table} e 
          JOIN {$wpdb->users} u ON e.user_id = u.ID 
          WHERE e.course_id IN ({$course_ids})";

if ( $course_filter ) {
    $query .= $wpdb->prepare( " AND e.course_id = %d", $course_filter );
}

$query .= " ORDER BY e.enrolled_at DESC";
$students = $wpdb->get_results( $query );
?>

<div class="dashboard-header-flex">
    <div class="header-left">
        <h1><?php esc_html_e( 'Students', 'ts-lms' ); ?></h1>
        <p><?php esc_html_e( 'Manage and track your students\' progress.', 'ts-lms' ); ?></p>
    </div>
    <div class="header-right">
        <form method="get" class="filter-form">
            <input type="hidden" name="section" value="students">
            <select name="course_id" onchange="this.form.submit()">
                <option value="0"><?php _e('All Courses', 'ts-lms'); ?></option>
                <?php 
                $instructor_courses = get_posts(array('post_type' => 'ts_course', 'author' => $user_id, 'posts_per_page' => -1));
                foreach ($instructor_courses as $c) : ?>
                    <option value="<?php echo $c->ID; ?>" <?php selected($course_filter, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
</div>

<div class="ts-lms-premium-card">
    <table class="modern-table">
        <thead>
            <tr>
                <th><?php _e('Student Name', 'ts-lms'); ?></th>
                <th><?php _e('Course', 'ts-lms'); ?></th>
                <th><?php _e('Enrolled Date', 'ts-lms'); ?></th>
                <th><?php _e('Progress', 'ts-lms'); ?></th>
                <th><?php _e('Status', 'ts-lms'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if ($students) : ?>
                <?php foreach ($students as $s) : 
                    $course_title = get_the_title($s->course_id);
                    $progress = 0; // Placeholder
                ?>
                <tr>
                    <td>
                        <div class="student-meta">
                            <strong><?php echo esc_html($s->display_name); ?></strong>
                            <span><?php echo esc_html($s->user_email); ?></span>
                        </div>
                    </td>
                    <td><?php echo esc_html($course_title); ?></td>
                    <td><?php echo date_i18n(get_option('date_format'), strtotime($s->enrolled_at)); ?></td>
                    <td>
                        <div class="progress-bar-small">
                            <div class="progress-fill" style="width: <?php echo $progress; ?>%"></div>
                            <span><?php echo $progress; ?>%</span>
                        </div>
                    </td>
                    <td><span class="status-badge status-active"><?php _e('Active', 'ts-lms'); ?></span></td>
                </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="5" class="empty-row"><?php _e('No students found.', 'ts-lms'); ?></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<style>
.student-meta { display: flex; flex-direction: column; }
.student-meta span { font-size: 12px; color: #9ca3af; }

.progress-bar-small { width: 100px; height: 8px; background: #f3f4f6; border-radius: 4px; position: relative; }
.progress-fill { height: 100%; background: var(--ts-primary); border-radius: 4px; }
.progress-bar-small span { position: absolute; right: -35px; top: -5px; font-size: 11px; font-weight: 600; color: #6b7280; }

.empty-row { text-align: center; padding: 50px !important; color: #9ca3af; }

.status-active { background: #d1fae5; color: #065f46; }

.filter-form select { 
    padding: 10px 15px; 
    border-radius: 10px; 
    border: 1px solid #e5e7eb; 
    min-width: 250px;
    font-size: 14px;
}
</style>
