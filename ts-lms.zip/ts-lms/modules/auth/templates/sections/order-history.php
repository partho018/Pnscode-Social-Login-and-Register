<?php
/**
 * Order History Section
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$user_id = get_current_user_id();

// Check if WooCommerce is active
$has_woocommerce = function_exists('wc_get_orders');
$orders = [];

if ($has_woocommerce) {
    $orders = wc_get_orders([
        'customer_id' => $user_id,
        'limit' => -1,
        'orderby' => 'date',
        'order' => 'DESC',
    ]);
}
?>

<div class="ts-section-order-history">
    <div class="ts-section-header">
        <h3 class="ts-section-title">
            <span class="dashicons dashicons-cart"></span>
            <?php esc_html_e('Order History', 'ts-lms'); ?>
        </h3>
        <p class="ts-section-subtitle"><?php esc_html_e('View your course purchase history', 'ts-lms'); ?></p>
    </div>

    <?php if ($has_woocommerce && !empty($orders)): ?>
        <div class="ts-orders-table">
            <table class="ts-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Order', 'ts-lms'); ?></th>
                        <th><?php esc_html_e('Date', 'ts-lms'); ?></th>
                        <th><?php esc_html_e('Status', 'ts-lms'); ?></th>
                        <th><?php esc_html_e('Total', 'ts-lms'); ?></th>
                        <th><?php esc_html_e('Actions', 'ts-lms'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>
                                <div class="ts-order-number">
                                    <strong>#<?php echo esc_html($order->get_order_number()); ?></strong>
                                </div>
                            </td>
                            <td>
                                <span class="ts-date-text">
                                    <?php echo esc_html($order->get_date_created()->date_i18n(get_option('date_format'))); ?>
                                </span>
                            </td>
                            <td>
                                <span class="ts-status-badge ts-status-<?php echo esc_attr($order->get_status()); ?>">
                                    <?php echo esc_html(wc_get_order_status_name($order->get_status())); ?>
                                </span>
                            </td>
                            <td>
                                <strong><?php echo wp_kses_post($order->get_formatted_order_total()); ?></strong>
                            </td>
                            <td>
                                <a href="<?php echo esc_url($order->get_view_order_url()); ?>" class="ts-btn-small">
                                    <?php esc_html_e('View', 'ts-lms'); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php elseif (!$has_woocommerce): ?>
        <div class="ts-empty-state-large">
            <div class="ts-empty-icon">
                <span class="dashicons dashicons-cart"></span>
            </div>
            <h4><?php esc_html_e('WooCommerce Not Active', 'ts-lms'); ?></h4>
            <p><?php esc_html_e('Order history requires WooCommerce to be installed and activated.', 'ts-lms'); ?></p>
        </div>
    <?php else: ?>
        <div class="ts-empty-state-large">
            <div class="ts-empty-icon">
                <span class="dashicons dashicons-cart"></span>
            </div>
            <h4><?php esc_html_e('No Orders Yet', 'ts-lms'); ?></h4>
            <p><?php esc_html_e('You haven\'t made any purchases yet.', 'ts-lms'); ?></p>
            <a href="<?php echo esc_url(get_permalink(get_option('ts_lms_course_catalog_page_id'))); ?>" class="ts-btn-primary">
                <span class="dashicons dashicons-search"></span>
                <?php esc_html_e('Browse Courses', 'ts-lms'); ?>
            </a>
        </div>
    <?php endif; ?>
</div>
