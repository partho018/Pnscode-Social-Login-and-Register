<?php
/**
 * Dashboard Section
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
$user_id = get_current_user_id();

// Get enrollment data with course details
$enrolled_courses_data = $wpdb->get_results($wpdb->prepare(
    "SELECT e.*, p.post_title, p.post_name, 
            (SELECT COUNT(*) FROM {$wpdb->prefix}ts_lesson_progress lp 
             WHERE lp.user_id = e.user_id AND lp.course_id = e.course_id AND lp.status = 'completed') as completed_lessons,
            (SELECT COUNT(*) FROM {$wpdb->prefix}posts 
             WHERE post_parent = e.course_id AND post_type = 'ts-lesson' AND post_status = 'publish') as total_lessons
     FROM {$wpdb->prefix}ts_course_enrollments e
     INNER JOIN {$wpdb->prefix}posts p ON e.course_id = p.ID
     WHERE e.user_id = %d AND e.status != 'cancelled'
     ORDER BY e.enrolled_at DESC
     LIMIT 6",
    $user_id
));

// Get recent quiz attempts
$recent_quizzes = $wpdb->get_results($wpdb->prepare(
    "SELECT c.*, p.post_title as quiz_title, p2.post_title as course_title
     FROM {$wpdb->prefix}comments c
     INNER JOIN {$wpdb->prefix}posts p ON c.comment_post_ID = p.ID
     LEFT JOIN {$wpdb->prefix}posts p2 ON p.post_parent = p2.ID
     WHERE c.user_id = %d AND c.comment_type = 'ts_quiz_attempt'
     ORDER BY c.comment_date DESC
     LIMIT 5",
    $user_id
));

// Stats for cards
$enrolled_courses = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}ts_course_enrollments WHERE user_id = %d AND status != 'cancelled'",
    $user_id
));

$active_courses = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}ts_course_enrollments WHERE user_id = %d AND status = 'active' AND completed_at IS NULL",
    $user_id
));

$completed_courses = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}ts_course_enrollments WHERE user_id = %d AND completed_at IS NOT NULL",
    $user_id
));

$quiz_attempts = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}comments WHERE user_id = %d AND comment_type = 'ts_quiz_attempt'",
    $user_id
));
?>

<div class="ts-section-dashboard">
    <div class="ts-section-header">
        <h3 class="ts-section-title">
            <span class="dashicons dashicons-dashboard"></span>
            <?php esc_html_e('Dashboard Overview', 'ts-lms'); ?>
        </h3>
        <p class="ts-section-subtitle"><?php esc_html_e('Track your learning progress and achievements', 'ts-lms'); ?></p>
    </div>
    
    <!-- Statistics Cards -->
    <div class="ts-stat-cards">
        <div class="ts-stat-card ts-stat-enrolled">
            <div class="ts-stat-icon enrolled">
                <span class="dashicons dashicons-book"></span>
            </div>
            <div class="ts-stat-data">
                <span class="ts-stat-number"><?php echo esc_html($enrolled_courses); ?></span>
                <span class="ts-stat-label"><?php esc_html_e('Enrolled Courses', 'ts-lms'); ?></span>
            </div>
        </div>

        <div class="ts-stat-card ts-stat-active">
            <div class="ts-stat-icon active">
                <span class="dashicons dashicons-welcome-learn-more"></span>
            </div>
            <div class="ts-stat-data">
                <span class="ts-stat-number"><?php echo esc_html($active_courses); ?></span>
                <span class="ts-stat-label"><?php esc_html_e('Active Courses', 'ts-lms'); ?></span>
            </div>
        </div>

        <div class="ts-stat-card ts-stat-completed">
            <div class="ts-stat-icon completed">
                <span class="dashicons dashicons-awards"></span>
            </div>
            <div class="ts-stat-data">
                <span class="ts-stat-number"><?php echo esc_html($completed_courses); ?></span>
                <span class="ts-stat-label"><?php esc_html_e('Completed Courses', 'ts-lms'); ?></span>
            </div>
        </div>
        
        <div class="ts-stat-card ts-stat-quizzes">
            <div class="ts-stat-icon quizzes">
                <span class="dashicons dashicons-welcome-write-blog"></span>
            </div>
            <div class="ts-stat-data">
                <span class="ts-stat-number"><?php echo esc_html($quiz_attempts); ?></span>
                <span class="ts-stat-label"><?php esc_html_e('Quiz Attempts', 'ts-lms'); ?></span>
            </div>
        </div>
    </div>

    <!-- Dashboard Grid -->
    <div class="ts-dashboard-grid-layout">
        <!-- Enrolled Courses -->
        <div class="ts-dashboard-widget">
            <div class="ts-widget-header">
                <h4><?php esc_html_e('Continue Learning', 'ts-lms'); ?></h4>
                <a href="<?php echo esc_url(add_query_arg('section', 'enrolled-courses', get_permalink())); ?>" class="ts-view-all">
                    <?php esc_html_e('View All', 'ts-lms'); ?> →
                </a>
            </div>
            <div class="ts-widget-body">
                <?php if (!empty($enrolled_courses_data)): ?>
                    <div class="ts-course-list">
                        <?php foreach ($enrolled_courses_data as $enrollment): 
                            $course_id = $enrollment->course_id;
                            $thumbnail_id = get_post_thumbnail_id($course_id);
                            $thumbnail_url = $thumbnail_id ? wp_get_attachment_image_url($thumbnail_id, 'thumbnail') : '';
                            $progress = $enrollment->total_lessons > 0 ? 
                                round(($enrollment->completed_lessons / $enrollment->total_lessons) * 100) : 0;
                        ?>
                            <div class="ts-course-item-dashboard">
                                <div class="ts-course-thumbnail">
                                    <?php if ($thumbnail_url): ?>
                                        <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr($enrollment->post_title); ?>">
                                    <?php else: ?>
                                        <div class="ts-course-placeholder">
                                            <span class="dashicons dashicons-book"></span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="ts-course-info">
                                    <h5><?php echo esc_html($enrollment->post_title); ?></h5>
                                    <div class="ts-course-progress-bar">
                                        <div class="ts-progress-fill" style="width: <?php echo esc_attr($progress); ?>%"></div>
                                    </div>
                                    <span class="ts-progress-text"><?php echo esc_html($progress); ?>% <?php esc_html_e('Complete', 'ts-lms'); ?></span>
                                </div>
                                <a href="<?php echo esc_url(get_permalink($course_id)); ?>" class="ts-course-continue">
                                    <?php esc_html_e('Continue', 'ts-lms'); ?> →
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="ts-empty-state">
                        <span class="dashicons dashicons-book-alt"></span>
                        <p><?php esc_html_e('No enrolled courses yet. Start learning today!', 'ts-lms'); ?></p>
                        <a href="<?php echo esc_url(get_permalink(get_option('ts_lms_course_catalog_page_id'))); ?>" class="ts-btn-primary">
                            <?php esc_html_e('Browse Courses', 'ts-lms'); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Quiz Activity -->
        <div class="ts-dashboard-widget">
            <div class="ts-widget-header">
                <h4><?php esc_html_e('Recent Quiz Activity', 'ts-lms'); ?></h4>
                <a href="<?php echo esc_url(add_query_arg('section', 'quiz-attempts', get_permalink())); ?>" class="ts-view-all">
                    <?php esc_html_e('View All', 'ts-lms'); ?> →
                </a>
            </div>
            <div class="ts-widget-body">
                <?php if (!empty($recent_quizzes)): ?>
                    <div class="ts-quiz-list">
                        <?php foreach ($recent_quizzes as $quiz): 
                            $meta = maybe_unserialize($quiz->comment_content);
                            $score = isset($meta['score']) ? $meta['score'] : 0;
                            $total = isset($meta['total']) ? $meta['total'] : 100;
                            $percentage = $total > 0 ? round(($score / $total) * 100) : 0;
                        ?>
                            <div class="ts-quiz-item">
                                <div class="ts-quiz-icon">
                                    <span class="dashicons dashicons-clipboard"></span>
                                </div>
                                <div class="ts-quiz-details">
                                    <h5><?php echo esc_html($quiz->quiz_title); ?></h5>
                                    <p class="ts-quiz-course"><?php echo esc_html($quiz->course_title); ?></p>
                                    <span class="ts-quiz-date"><?php echo human_time_diff(strtotime($quiz->comment_date), current_time('timestamp')) . ' ' . __('ago', 'ts-lms'); ?></span>
                                </div>
                                <div class="ts-quiz-score <?php echo $percentage >= 70 ? 'ts-score-pass' : 'ts-score-fail'; ?>">
                                    <span class="ts-score-number"><?php echo esc_html($percentage); ?>%</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="ts-empty-state">
                        <span class="dashicons dashicons-clipboard"></span>
                        <p><?php esc_html_e('No quiz attempts yet.', 'ts-lms'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Become an Instructor CTA -->
    <?php 
    $show_instructor_btn = \TS_LMS\Admin\Settings::get_setting('become_instructor_button');
    // Show if enabled in settings OR if user has a pending application
    $limit_reached = \TS_LMS\Modules\Auth\InstructorManager::is_limit_reached();
    
    if (($show_instructor_btn || $instructor_status === 'pending') && $instructor_status !== 'approved' && !($limit_reached && empty($instructor_status))) :
        $apply_url = get_permalink(\TS_LMS\Admin\Settings::get_setting('instructor_reg_page'));
        if (!$apply_url) {
            $apply_url = home_url('/become-an-instructor/');
        }
    ?>
    <div class="ts-instructor-cta-card">
        <div class="ts-cta-content">
            <div class="ts-cta-icon">
                <span class="dashicons dashicons-welcome-learn-more"></span>
            </div>
            <div class="ts-cta-text">
                <?php if ($instructor_status === 'pending') : ?>
                    <h4><?php esc_html_e('Your Application is Under Review', 'ts-lms'); ?></h4>
                    <p><?php esc_html_e('We are currently processing your request to become an instructor. We will notify you via email shortly!', 'ts-lms'); ?></p>
                <?php else : ?>
                    <h4><?php esc_html_e('Want to share your knowledge?', 'ts-lms'); ?></h4>
                    <p><?php esc_html_e('Apply to become an instructor today and start earning by teaching your expertise to thousands of students.', 'ts-lms'); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="ts-cta-action">
            <?php if ($instructor_status === 'pending') : ?>
                <span class="ts-status-label pending"><?php esc_html_e('Status: Pending', 'ts-lms'); ?></span>
            <?php else : ?>
                <a href="<?php echo esc_url($apply_url); ?>" class="ts-btn-primary">
                    <?php esc_html_e('Become an Instructor', 'ts-lms'); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <style>
    .ts-instructor-cta-card {
        background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
        border-radius: 20px;
        padding: 35px;
        margin-top: 40px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        color: #fff;
        box-shadow: 0 10px 30px rgba(79, 70, 229, 0.2);
        gap: 30px;
    }
    .ts-cta-content { display: flex; align-items: center; gap: 25px; flex: 1; }
    .ts-cta-icon {
        width: 64px;
        height: 64px;
        background: rgba(255, 255, 255, 0.2);
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    .ts-cta-icon .dashicons { font-size: 32px; width: 32px; height: 32px; }
    .ts-cta-text { flex: 1; }
    .ts-cta-text h4 { margin: 0 0 8px; font-size: 22px; font-weight: 700; color: #fff; line-height: 1.2; }
    .ts-cta-text p { 
        margin: 0; 
        opacity: 0.9; 
        font-size: 15px; 
        line-height: 1.6;
        max-width: 500px;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    
    .ts-cta-action { flex-shrink: 0; }
    .ts-instructor-cta-card .ts-btn-primary {
        background: #fff;
        color: #4f46e5;
        padding: 14px 28px;
        border-radius: 12px;
        text-decoration: none;
        font-weight: 700;
        transition: all 0.3s;
        display: inline-block;
        white-space: nowrap;
        font-size: 15px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .ts-instructor-cta-card .ts-btn-primary:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        background: #f8fafc;
    }
    
    .ts-status-label.pending {
        background: rgba(255, 255, 255, 0.2);
        padding: 12px 24px;
        border-radius: 50px;
        font-weight: 600;
        font-size: 14px;
        white-space: nowrap;
    }

    @media (max-width: 1100px) {
        .ts-instructor-cta-card { padding: 30px; }
        .ts-cta-text h4 { font-size: 20px; }
    }

    @media (max-width: 992px) {
        .ts-instructor-cta-card { flex-direction: column; text-align: center; gap: 25px; }
        .ts-cta-content { flex-direction: column; text-align: center; }
        .ts-cta-text p { max-width: 100%; -webkit-line-clamp: unset; }
        .ts-cta-action { width: 100%; }
        .ts-instructor-cta-card .ts-btn-primary { width: 100%; text-align: center; }
    }
    </style>
    <?php endif; ?>
</div>
