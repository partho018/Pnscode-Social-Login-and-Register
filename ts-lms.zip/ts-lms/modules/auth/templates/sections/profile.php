<?php
/**
 * My Profile Section
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$user_id = get_current_user_id();
$user = get_userdata($user_id);

// Handle form submission
if (isset($_POST['ts_update_profile']) && wp_verify_nonce($_POST['ts_profile_nonce'], 'ts_update_profile_action')) {
    $first_name = sanitize_text_field($_POST['first_name']);
    $last_name = sanitize_text_field($_POST['last_name']);
    $display_name = sanitize_text_field($_POST['display_name']);
    $description = sanitize_textarea_field($_POST['description']);
    $errors = [];
    
    // Update basic user data
    $user_data = [
        'ID' => $user_id,
        'first_name' => $first_name,
        'last_name' => $last_name,
        'display_name' => $display_name,
        'description' => $description,
    ];

    // Handle Password Change
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    if (!empty($new_password)) {
        if ($new_password !== $confirm_password) {
            $errors[] = __('New passwords do not match.', 'ts-lms');
        } elseif (strlen($new_password) < 6) {
            $errors[] = __('Password must be at least 6 characters.', 'ts-lms');
        } else {
            $user_data['user_pass'] = $new_password;
        }
    }

    // Handle Profile Photo Upload
    if (!empty($_FILES['profile_photo']['name'])) {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        
        $attachment_id = media_handle_upload('profile_photo', 0);
        
        if (is_wp_error($attachment_id)) {
            $errors[] = $attachment_id->get_error_message();
        } else {
            update_user_meta($user_id, 'ts_lms_avatar_id', $attachment_id);
        }
    }

    if (empty($errors)) {
        wp_update_user($user_data);
        echo '<div class="ts-notice ts-notice-success">' . esc_html__('Profile updated successfully!', 'ts-lms') . '</div>';
    } else {
        foreach ($errors as $error) {
            echo '<div class="ts-notice ts-notice-error">' . esc_html($error) . '</div>';
        }
    }
    
    $user = get_userdata($user_id); // Refresh user data
}
?>

<div class="ts-section-profile">
    <div class="ts-section-header">
        <h3 class="ts-section-title">
            <span class="dashicons dashicons-admin-users"></span>
            <?php esc_html_e('My Profile', 'ts-lms'); ?>
        </h3>
        <p class="ts-section-subtitle"><?php esc_html_e('Manage your personal information', 'ts-lms'); ?></p>
    </div>

    <div class="ts-profile-container">
        <form method="post" class="ts-profile-form" enctype="multipart/form-data">
            <?php wp_nonce_field('ts_update_profile_action', 'ts_profile_nonce'); ?>
            
            <div class="ts-profile-avatar-header">
                <div class="ts-avatar-upload-wrapper">
                    <div class="ts-avatar-preview-container" id="avatarPreviewContainer">
                        <?php 
                        $avatar_id = get_user_meta($user_id, 'ts_lms_avatar_id', true);
                        if ($avatar_id) {
                            echo wp_get_attachment_image($avatar_id, [150, 150], false, ['class' => 'ts-avatar-img', 'id' => 'profileAvatarImg']);
                        } else {
                            echo get_avatar($user_id, 150, '', '', ['class' => 'ts-avatar-img', 'id' => 'profileAvatarImg']);
                        }
                        ?>
                    </div>
                    <label for="profile_photo" class="ts-avatar-upload-trigger">
                        <span class="dashicons dashicons-camera"></span>
                        <input type="file" id="profile_photo" name="profile_photo" accept="image/*" style="display: none !important;">
                    </label>
                </div>
                <div class="ts-user-meta-info">
                    <h2 class="ts-display-name"><?php echo esc_html($user->display_name); ?></h2>
                    <p class="ts-user-email"><?php echo esc_html($user->user_email); ?></p>
                    <span class="ts-join-date"><?php printf(esc_html__('Member since %s', 'ts-lms'), date_i18n(get_option('date_format'), strtotime($user->user_registered))); ?></span>
                </div>
            </div>

            <style>
                .ts-profile-avatar-header {
                    display: flex;
                    align-items: center;
                    gap: 30px;
                    padding: 30px;
                    background: #fff;
                    border-radius: 20px;
                    border: 1px solid #f1f5f9;
                    margin-bottom: 30px;
                    box-shadow: 0 4px 15px rgba(0,0,0,0.02);
                }
                .ts-avatar-upload-wrapper {
                    position: relative;
                    width: 120px;
                    height: 120px;
                }
                .ts-avatar-preview-container {
                    width: 100%;
                    height: 100%;
                    border-radius: 50%;
                    overflow: hidden;
                    border: 4px solid #fff;
                    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
                }
                .ts-avatar-img {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                }
                .ts-avatar-upload-trigger {
                    position: absolute;
                    bottom: 0;
                    right: 0;
                    width: 36px;
                    height: 36px;
                    background: #4f46e5;
                    color: #fff;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    cursor: pointer;
                    border: 3px solid #fff;
                    transition: 0.3s;
                    box-shadow: 0 4px 10px rgba(79, 70, 229, 0.3);
                }
                .ts-avatar-upload-trigger:hover {
                    transform: scale(1.1);
                    background: #4338ca;
                }
                .ts-avatar-upload-trigger .dashicons {
                    font-size: 18px;
                    width: 18px;
                    height: 18px;
                }
                .ts-user-meta-info {
                    flex: 1;
                }
                .ts-display-name {
                    margin: 0 0 5px;
                    font-size: 24px;
                    font-weight: 800;
                    color: #1e293b;
                }
                .ts-user-email {
                    margin: 0 0 8px;
                    color: #64748b;
                    font-size: 16px;
                }
                .ts-join-date {
                    font-size: 13px;
                    color: #94a3b8;
                    font-weight: 500;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                }
            </style>

            <script>
                document.getElementById('profile_photo').addEventListener('change', function(e) {
                    if (this.files && this.files[0]) {
                        var reader = new FileReader();
                        reader.onload = function(e) {
                            document.getElementById('profileAvatarImg').src = e.target.result;
                        };
                        reader.readAsDataURL(this.files[0]);
                    }
                });
            </script>

            <div class="ts-form-grid">
                <div class="ts-form-group">
                    <label for="first_name"><?php esc_html_e('First Name', 'ts-lms'); ?></label>
                    <input type="text" id="first_name" name="first_name" 
                           value="<?php echo esc_attr($user->first_name); ?>" 
                           class="ts-form-input" required>
                </div>

                <div class="ts-form-group">
                    <label for="last_name"><?php esc_html_e('Last Name', 'ts-lms'); ?></label>
                    <input type="text" id="last_name" name="last_name" 
                           value="<?php echo esc_attr($user->last_name); ?>" 
                           class="ts-form-input" required>
                </div>

                <div class="ts-form-group">
                    <label for="display_name"><?php esc_html_e('Display Name', 'ts-lms'); ?></label>
                    <input type="text" id="display_name" name="display_name" 
                           value="<?php echo esc_attr($user->display_name); ?>" 
                           class="ts-form-input" required>
                </div>

                <div class="ts-form-group">
                    <label for="user_email"><?php esc_html_e('Email Address', 'ts-lms'); ?></label>
                    <input type="email" id="user_email" name="user_email" 
                           value="<?php echo esc_attr($user->user_email); ?>" 
                           class="ts-form-input" disabled>
                    <small class="ts-help-text"><?php esc_html_e('Contact admin to change email', 'ts-lms'); ?></small>
                </div>
            </div>

            <div class="ts-form-group mb-6">
                <label for="description"><?php esc_html_e('Biography', 'ts-lms'); ?></label>
                <textarea id="description" name="description" rows="5" 
                          class="ts-form-textarea w-full" placeholder="<?php esc_attr_e('Write something about yourself...', 'ts-lms'); ?>"><?php echo esc_textarea($user->description); ?></textarea>
            </div>

            <div class="ts-password-section mt-8 pt-8 border-t border-gray-100">
                <h4 class="text-lg font-bold text-gray-800 mb-6 flex items-center gap-2">
                    <span class="dashicons dashicons-lock"></span>
                    <?php esc_html_e('Change Password', 'ts-lms'); ?>
                </h4>
                <div class="ts-form-grid">
                    <div class="ts-form-group">
                        <label for="new_password"><?php esc_html_e('New Password', 'ts-lms'); ?></label>
                        <input type="password" id="new_password" name="new_password" 
                               class="ts-form-input" placeholder="<?php esc_attr_e('Leave blank to keep current', 'ts-lms'); ?>">
                    </div>

                    <div class="ts-form-group">
                        <label for="confirm_password"><?php esc_html_e('Confirm New Password', 'ts-lms'); ?></label>
                        <input type="password" id="confirm_password" name="confirm_password" 
                               class="ts-form-input" placeholder="<?php esc_attr_e('Repeat new password', 'ts-lms'); ?>">
                    </div>
                </div>
            </div>

            <div class="ts-form-actions">
                <button type="submit" name="ts_update_profile" class="ts-btn-primary">
                    <span class="dashicons dashicons-yes"></span>
                    <?php esc_html_e('Save Changes', 'ts-lms'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
