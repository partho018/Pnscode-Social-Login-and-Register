<?php
/**
 * Quiz Attempts Section
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
$user_id = get_current_user_id();

// Get quiz attempts
$quiz_attempts = $wpdb->get_results($wpdb->prepare(
    "SELECT c.*, p.post_title as quiz_title, p2.post_title as course_title, p2.ID as course_id
     FROM {$wpdb->prefix}comments c
     INNER JOIN {$wpdb->prefix}posts p ON c.comment_post_ID = p.ID
     LEFT JOIN {$wpdb->prefix}posts p2 ON p.post_parent = p2.ID
     WHERE c.user_id = %d AND c.comment_type = 'ts_quiz_attempt'
     ORDER BY c.comment_date DESC",
    $user_id
));
?>

<div class="ts-section-quiz-attempts">
    <div class="ts-section-header">
        <h3 class="ts-section-title">
            <span class="dashicons dashicons-welcome-write-blog"></span>
            <?php esc_html_e('My Quiz Attempts', 'ts-lms'); ?>
        </h3>
        <p class="ts-section-subtitle"><?php esc_html_e('Track your quiz performance and progress', 'ts-lms'); ?></p>
    </div>

    <?php if (!empty($quiz_attempts)): ?>
        <div class="ts-quiz-attempts-table">
            <table class="ts-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Quiz', 'ts-lms'); ?></th>
                        <th><?php esc_html_e('Course', 'ts-lms'); ?></th>
                        <th><?php esc_html_e('Score', 'ts-lms'); ?></th>
                        <th><?php esc_html_e('Status', 'ts-lms'); ?></th>
                        <th><?php esc_html_e('Date', 'ts-lms'); ?></th>
                        <th><?php esc_html_e('Actions', 'ts-lms'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($quiz_attempts as $attempt): 
                        $meta = maybe_unserialize($attempt->comment_content);
                        $score = isset($meta['score']) ? $meta['score'] : 0;
                        $total = isset($meta['total']) ? $meta['total'] : 100;
                        $percentage = $total > 0 ? round(($score / $total) * 100) : 0;
                        $passing_grade = 70; // Default passing grade
                        $status = $percentage >= $passing_grade ? 'passed' : 'failed';
                    ?>
                        <tr>
                            <td>
                                <div class="ts-quiz-name">
                                    <span class="dashicons dashicons-clipboard"></span>
                                    <?php echo esc_html($attempt->quiz_title); ?>
                                </div>
                            </td>
                            <td><?php echo esc_html($attempt->course_title); ?></td>
                            <td>
                                <div class="ts-score-display">
                                    <strong><?php echo esc_html($percentage); ?>%</strong>
                                    <span class="ts-score-detail">(<?php echo esc_html($score); ?>/<?php echo esc_html($total); ?>)</span>
                                </div>
                            </td>
                            <td>
                                <span class="ts-status-badge ts-status-<?php echo esc_attr($status); ?>">
                                    <?php echo $status === 'passed' ? esc_html__('Passed', 'ts-lms') : esc_html__('Failed', 'ts-lms'); ?>
                                </span>
                            </td>
                            <td>
                                <span class="ts-date-text">
                                    <?php echo date_i18n(get_option('date_format'), strtotime($attempt->comment_date)); ?>
                                </span>
                                <span class="ts-time-text">
                                    <?php echo human_time_diff(strtotime($attempt->comment_date), current_time('timestamp')) . ' ' . __('ago', 'ts-lms'); ?>
                                </span>
                            </td>
                            <td>
                                <a href="<?php echo esc_url(get_permalink($attempt->course_id)); ?>" class="ts-btn-small">
                                    <?php esc_html_e('View Course', 'ts-lms'); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="ts-empty-state-large">
            <div class="ts-empty-icon">
                <span class="dashicons dashicons-clipboard"></span>
            </div>
            <h4><?php esc_html_e('No Quiz Attempts', 'ts-lms'); ?></h4>
            <p><?php esc_html_e('You haven\'t attempted any quizzes yet. Enroll in courses and test your knowledge!', 'ts-lms'); ?></p>
        </div>
    <?php endif; ?>
</div>
