<?php
/**
 * Instructor Dashboard - My Courses
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$user_id = get_current_user_id();

// Filter by status if needed
$status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'any';

$args = array(
    'post_type'      => 'ts_course',
    'author'         => $user_id,
    'posts_per_page' => -1,
    'post_status'    => $status === 'any' ? array('publish', 'pending', 'draft') : $status,
);

$courses = get_posts( $args );
?>

<div class="dashboard-header-flex">
    <div class="header-left">
        <h1><?php esc_html_e( 'My Courses', 'ts-lms' ); ?></h1>
        <p><?php esc_html_e( 'Manage your published and draft courses.', 'ts-lms' ); ?></p>
    </div>
    <div class="header-right">
        <a href="<?php echo admin_url('post-new.php?post_type=ts_course'); ?>" class="ts-lms-btn ts-lms-btn-primary">
            <span class="dashicons dashicons-plus"></span>
            <?php esc_html_e( 'Create New Course', 'ts-lms' ); ?>
        </a>
    </div>
</div>

<div class="filter-bar">
    <nav class="filter-nav">
        <a href="?section=courses&status=any" class="<?php echo $status === 'any' ? 'active' : ''; ?>"><?php esc_html_e( 'All Courses', 'ts-lms' ); ?></a>
        <a href="?section=courses&status=publish" class="<?php echo $status === 'publish' ? 'active' : ''; ?>"><?php esc_html_e( 'Published', 'ts-lms' ); ?></a>
        <a href="?section=courses&status=pending" class="<?php echo $status === 'pending' ? 'active' : ''; ?>"><?php esc_html_e( 'Pending Review', 'ts-lms' ); ?></a>
        <a href="?section=courses&status=draft" class="<?php echo $status === 'draft' ? 'active' : ''; ?>"><?php esc_html_e( 'Drafts', 'ts-lms' ); ?></a>
    </nav>
</div>

<div class="course-list-grid">
    <?php if ($courses) : ?>
        <?php foreach ($courses as $course) : 
            $thumbnail = get_the_post_thumbnail_url($course->ID, 'medium') ?: TS_LMS_PLUGIN_URL . 'assets/images/course-placeholder.jpg';
            $price = get_post_meta($course->ID, 'ts_course_price', true);
            $sales = 0; // Placeholder
            $students = 0; // Placeholder
        ?>
            <div class="course-card-horizontal">
                <div class="course-image">
                    <img src="<?php echo esc_url($thumbnail); ?>" alt="<?php echo esc_attr($course->post_title); ?>">
                </div>
                <div class="course-info">
                    <div class="course-meta-top">
                        <span class="status-badge status-<?php echo esc_attr($course->post_status); ?>"><?php echo esc_html(ucfirst($course->post_status)); ?></span>
                        <span class="course-date"><?php printf(__('Last updated %s', 'ts-lms'), human_time_diff(get_the_modified_time('U', $course->ID), current_time('timestamp')) . ' ago'); ?></span>
                    </div>
                    <h3><?php echo esc_html($course->post_title); ?></h3>
                    <div class="course-stats">
                        <div class="stat"><span class="dashicons dashicons-groups"></span> <?php printf(__('%d Students', 'ts-lms'), $students); ?></div>
                        <div class="stat"><span class="dashicons dashicons-star-filled"></span> 4.5</div>
                        <div class="stat"><span class="dashicons dashicons-money-alt"></span> <?php echo $price ? '$' . $price : __('Free', 'ts-lms'); ?></div>
                    </div>
                </div>
                <div class="course-actions">
                    <a href="<?php echo get_edit_post_link($course->ID); ?>" class="action-btn edit" title="<?php esc_attr_e('Edit', 'ts-lms'); ?>"><span class="dashicons dashicons-edit"></span></a>
                    <a href="<?php echo get_permalink($course->ID); ?>" class="action-btn view" title="<?php esc_attr_e('Preview', 'ts-lms'); ?>"><span class="dashicons dashicons-visibility"></span></a>
                    <a href="#" class="action-btn analytics" title="<?php esc_attr_e('Analytics', 'ts-lms'); ?>"><span class="dashicons dashicons-chart-bar"></span></a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else : ?>
        <div class="empty-state">
            <span class="dashicons dashicons-welcome-learn-more"></span>
            <h3><?php esc_html_e( 'No courses found', 'ts-lms' ); ?></h3>
            <p><?php esc_html_e( 'You haven\'t created any courses yet. Start sharing your knowledge today!', 'ts-lms' ); ?></p>
            <a href="<?php echo admin_url('post-new.php?post_type=ts_course'); ?>" class="ts-lms-btn ts-lms-btn-primary"><?php esc_html_e( 'Create Your First Course', 'ts-lms' ); ?></a>
        </div>
    <?php endif; ?>
</div>

<style>
.dashboard-header-flex { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 30px; }
.header-left h1 { font-size: 28px; margin: 0 0 5px; color: #111827; }
.header-left p { color: #6b7280; margin: 0; }

.filter-bar { background: #fff; padding: 10px; border-radius: 12px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); }
.filter-nav { display: flex; gap: 10px; }
.filter-nav a { padding: 8px 16px; text-decoration: none; color: #6b7280; font-size: 14px; font-weight: 500; border-radius: 8px; transition: 0.3s; }
.filter-nav a:hover { color: var(--ts-primary); background: #f8f9ff; }
.filter-nav a.active { background: var(--ts-primary); color: #fff; }

.course-list-grid { display: flex; flex-direction: column; gap: 20px; }
.course-card-horizontal { background: #fff; border-radius: 20px; overflow: hidden; display: flex; box-shadow: 0 4px 15px rgba(0,0,0,0.03); transition: 0.3s; }
.course-card-horizontal:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.08); }

.course-image { width: 220px; min-width: 220px; position: relative; }
.course-image img { width: 100%; height: 100%; object-fit: cover; }

.course-info { flex: 1; padding: 25px; }
.course-meta-top { display: flex; gap: 15px; align-items: center; margin-bottom: 15px; }
.course-date { font-size: 12px; color: #9ca3af; }

.course-info h3 { font-size: 18px; margin: 0 0 15px; color: #111827; font-weight: 700; }
.course-stats { display: flex; gap: 20px; }
.course-stats .stat { display: flex; align-items: center; gap: 6px; font-size: 13px; color: #6b7280; }
.course-stats .stat .dashicons { font-size: 16px; width: 16px; height: 16px; color: #9ca3af; }

.course-actions { display: flex; flex-direction: column; padding: 15px; background: #f9fafb; border-left: 1px solid #f3f4f6; justify-content: center; gap: 10px; }
.action-btn { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; text-decoration: none; color: #6b7280; background: #fff; border: 1px solid #e5e7eb; transition: 0.3s; }
.action-btn:hover { background: var(--ts-primary); color: #fff; border-color: var(--ts-primary); transform: scale(1.1); }
.action-btn.edit:hover { background: #3b82f6; border-color: #3b82f6; }
.action-btn.view:hover { background: #10b981; border-color: #10b981; }

.empty-state { text-align: center; padding: 80px 40px; background: #f9fafb; border-radius: 24px; border: 2px dashed #e5e7eb; }
.empty-state .dashicons { font-size: 64px; width: 64px; height: 64px; color: #d1d5db; margin-bottom: 20px; }
.empty-state h3 { font-size: 20px; color: #111827; margin-bottom: 10px; }
.empty-state p { color: #6b7280; margin-bottom: 30px; }
</style>
