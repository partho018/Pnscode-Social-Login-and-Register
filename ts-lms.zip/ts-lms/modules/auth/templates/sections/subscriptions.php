<?php
if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;
$user_id = get_current_user_id();

// Fetch subscriptions
$table = $wpdb->prefix . 'ts_course_enrollments';
$subscriptions = $wpdb->get_results( $wpdb->prepare(
    "SELECT * FROM {$table} WHERE user_id = %d AND subscription_id IS NOT NULL ORDER BY enrolled_at DESC",
    $user_id
) );
?>
<div class="ts-dashboard-section">
    <div class="section-header">
        <h2 class="section-title"><?php _e('My Subscriptions', 'ts-lms'); ?></h2>
        <p class="section-subtitle"><?php _e('Manage your active course plans and billing.', 'ts-lms'); ?></p>
    </div>
    
    <?php if ( empty( $subscriptions ) ) : ?>
        <div class="ts-empty-state">
            <span class="dashicons dashicons-calendar-alt" style="font-size: 48px; width: 48px; height: 48px; color: #cbd5e1;"></span>
            <p><?php _e( 'You have no active subscriptions.', 'ts-lms' ); ?></p>
            <a href="<?php echo home_url('/courses'); ?>" class="ts-btn-primary"><?php _e('Browse Courses', 'ts-lms'); ?></a>
        </div>
    <?php else : ?>
        <div class="ts-subscriptions-list">
            <?php foreach ( $subscriptions as $sub ) : 
                $course = get_post( $sub->course_id );
                if ( ! $course ) continue;
                
                $expires = $sub->expires_at ? strtotime( $sub->expires_at ) : 0;
                $remaining = $expires > time() ? ($expires - time()) / DAY_IN_SECONDS : 0;
                $remaining = max( 0, round( $remaining ) );
                
                $status_class = $sub->status;
                if ($remaining == 0 && $sub->status == 'active') $status_class = 'expiring';
            ?>
            <div class="ts-sub-card">
                <div class="ts-sub-header">
                    <h3 class="ts-sub-course-title">
                        <a href="<?php echo get_permalink($course->ID); ?>"><?php echo esc_html( $course->post_title ); ?></a>
                    </h3>
                    <span class="ts-sub-status <?php echo esc_attr( $status_class ); ?>"><?php echo esc_html( ucfirst( $sub->status ) ); ?></span>
                </div>
                
                <div class="ts-sub-grid">
                    <div class="ts-sub-item">
                        <span class="ts-sub-label"><?php _e('Plan Type', 'ts-lms'); ?></span>
                        <span class="ts-sub-value"><?php echo esc_html( ucfirst( $sub->subscription_type ) ); ?></span>
                    </div>
                    <div class="ts-sub-item">
                        <span class="ts-sub-label"><?php _e('Start Date', 'ts-lms'); ?></span>
                        <span class="ts-sub-value"><?php echo date_i18n( get_option('date_format'), strtotime( $sub->enrolled_at ) ); ?></span>
                    </div>
                    <div class="ts-sub-item">
                        <span class="ts-sub-label"><?php _e('Expires', 'ts-lms'); ?></span>
                        <span class="ts-sub-value"><?php echo $sub->expires_at ? date_i18n( get_option('date_format'), strtotime( $sub->expires_at ) ) : 'N/A'; ?></span>
                    </div>
                    <div class="ts-sub-item">
                        <span class="ts-sub-label"><?php _e('Remaining Days', 'ts-lms'); ?></span>
                        <span class="ts-sub-value <?php echo $remaining < 3 ? 'text-danger' : ''; ?>"><?php echo $remaining; ?> <?php _e('Days', 'ts-lms'); ?></span>
                    </div>
                </div>

                <div class="ts-sub-footer">
                    <div class="ts-auto-renew-toggle">
                        <label class="ts-toggle-switch-sm">
                            <input type="checkbox" checked disabled title="Auto-renew managed by payment provider">
                            <span class="ts-toggle-slider-sm"></span>
                        </label>
                        <span class="ts-toggle-label"><?php _e('Auto-renew', 'ts-lms'); ?></span>
                    </div>

                    <div class="ts-sub-actions">
                        <?php if ($sub->status === 'active') : ?>
                            <button type="button" class="ts-btn-outline-danger ts-cancel-sub" data-id="<?php echo esc_attr($sub->subscription_id); ?>"><?php _e('Cancel', 'ts-lms'); ?></button>
                            <!-- <button type="button" class="ts-btn-outline-primary"><?php _e('Upgrade', 'ts-lms'); ?></button> -->
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <style>
            .ts-subscriptions-list { display: flex; flex-direction: column; gap: 20px; }
            .ts-sub-card { 
                background: #fff; 
                border-radius: 16px; 
                border: 1px solid #e5e7eb; 
                padding: 24px; 
                transition: 0.3s;
            }
            .ts-sub-card:hover { border-color: var(--ts-primary); box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
            
            .ts-sub-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; }
            .ts-sub-course-title { margin: 0; font-size: 18px; font-weight: 700; }
            .ts-sub-course-title a { color: #1f2937; text-decoration: none; }
            
            .ts-sub-status { padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
            .ts-sub-status.active { background: #dcfce7; color: #166534; }
            .ts-sub-status.expired { background: #fee2e2; color: #991b1b; }
            .ts-sub-status.cancelled { background: #f3f4f6; color: #374151; }
            
            .ts-sub-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 24px; padding-bottom: 24px; border-bottom: 1px dashed #e5e7eb; }
            .ts-sub-item { display: flex; flex-direction: column; gap: 4px; }
            .ts-sub-label { font-size: 12px; color: #6b7280; text-transform: uppercase; font-weight: 500; }
            .ts-sub-value { font-size: 15px; font-weight: 600; color: #111827; }
            .text-danger { color: #ef4444; }
            
            .ts-sub-footer { display: flex; justify-content: space-between; align-items: center; }
            .ts-auto-renew-toggle { display: flex; align-items: center; gap: 10px; opacity: 0.7; }
            .ts-toggle-label { font-size: 14px; color: #374151; font-weight: 500; }
            
            .ts-btn-outline-danger { 
                background: transparent; 
                border: 1px solid #fee2e2; 
                color: #ef4444; 
                padding: 8px 16px; 
                border-radius: 8px; 
                font-weight: 600; 
                cursor: pointer; 
                transition: 0.2s; 
            }
            .ts-btn-outline-danger:hover { background: #fee2e2; border-color: #ef4444; }
            
            @media (max-width: 768px) {
                .ts-sub-grid { grid-template-columns: repeat(2, 1fr); }
            }
        </style>
    <?php endif; ?>
</div>
