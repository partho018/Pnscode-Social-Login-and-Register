<?php
if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;
$user_id = get_current_user_id();

// Get Instructor Courses
$courses = get_posts( array(
    'post_type'      => 'ts_course',
    'author'         => $user_id,
    'posts_per_page' => -1,
    'fields'         => 'ids'
) );

if ( empty( $courses ) ) {
    ?>
    <div class="ts-dashboard-section">
        <h2><?php _e('Subscription Analytics', 'ts-lms'); ?></h2>
        <div class="ts-empty-state">
            <p><?php _e( 'You have no courses yet.', 'ts-lms' ); ?></p>
        </div>
    </div>
    <?php
    return;
}

$course_ids_str = implode(',', $courses);

// Get Subscription Enrollments
$table = $wpdb->prefix . 'ts_course_enrollments';
$subscriptions = $wpdb->get_results( "SELECT * FROM {$table} WHERE course_id IN ({$course_ids_str}) AND subscription_id IS NOT NULL ORDER BY enrolled_at DESC" );

$active_subscribers = 0;
$total_subscribers = count($subscriptions);
$monthly_revenue = 0;

foreach ($subscriptions as $sub) {
    if ($sub->status === 'active') {
        $active_subscribers++;
        // Calculate Revenue
        $price = get_post_meta($sub->course_id, '_subscription_price', true);
        $plan = get_post_meta($sub->course_id, '_subscription_plan_type', true);
        
        if (is_numeric($price)) {
            if ($plan === 'weekly') $monthly_revenue += ($price * 4);
            elseif ($plan === 'monthly') $monthly_revenue += $price;
            elseif ($plan === 'yearly') $monthly_revenue += ($price / 12);
        }
    }
}

$retention = $total_subscribers > 0 ? round(($active_subscribers / $total_subscribers) * 100, 1) : 0;
?>

<div class="ts-dashboard-section">
    <div class="section-header">
        <h2 class="section-title"><?php _e('Subscription Analytics', 'ts-lms'); ?></h2>
        <p class="section-subtitle"><?php _e('Track your recurring revenue and subscriber growth.', 'ts-lms'); ?></p>
    </div>
    
    <div class="ts-stats-grid">
        <div class="ts-stat-card">
            <div class="stat-icon icon-blue"><span class="dashicons dashicons-groups"></span></div>
            <div class="stat-info">
                <span class="stat-label"><?php _e('Active Subscribers', 'ts-lms'); ?></span>
                <span class="stat-value"><?php echo $active_subscribers; ?></span>
            </div>
        </div>
        <div class="ts-stat-card">
            <div class="stat-icon icon-green"><span class="dashicons dashicons-money-alt"></span></div>
            <div class="stat-info">
                <span class="stat-label"><?php _e('Est. Monthly Revenue', 'ts-lms'); ?></span>
                <span class="stat-value">
                    <?php 
                    if ( function_exists('wc_price') ) {
                        echo wc_price($monthly_revenue); 
                    } else {
                        echo '$' . number_format($monthly_revenue, 2);
                    }
                    ?>
                </span>
            </div>
        </div>
        <div class="ts-stat-card">
            <div class="stat-icon icon-purple"><span class="dashicons dashicons-chart-pie"></span></div>
            <div class="stat-info">
                <span class="stat-label"><?php _e('Retention Rate', 'ts-lms'); ?></span>
                <span class="stat-value"><?php echo $retention; ?>%</span>
            </div>
        </div>
    </div>
    
    <h3><?php _e('Recent Subscribers', 'ts-lms'); ?></h3>
    
    <?php if ( ! empty($subscriptions) ) : ?>
        <div class="ts-table-responsive">
            <table class="ts-table">
                <thead>
                    <tr>
                        <th><?php _e('Student', 'ts-lms'); ?></th>
                        <th><?php _e('Course', 'ts-lms'); ?></th>
                        <th><?php _e('Plan', 'ts-lms'); ?></th>
                        <th><?php _e('Status', 'ts-lms'); ?></th>
                        <th><?php _e('Started', 'ts-lms'); ?></th>
                        <th><?php _e('Expires', 'ts-lms'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $recent_subs = array_slice($subscriptions, 0, 10);
                    foreach ($recent_subs as $sub) : 
                        $user = get_user_by('id', $sub->user_id);
                        $course_title = get_the_title($sub->course_id);
                    ?>
                    <tr>
                        <td>
                            <div class="ts-user-cell">
                                <?php echo get_avatar($sub->user_id, 32); ?>
                                <span><?php echo esc_html($user ? $user->display_name : 'Unknown'); ?></span>
                            </div>
                        </td>
                        <td><?php echo esc_html($course_title); ?></td>
                        <td><?php echo esc_html(ucfirst($sub->subscription_type)); ?></td>
                        <td><span class="status-badge status-<?php echo esc_attr($sub->status); ?>"><?php echo esc_html(ucfirst($sub->status)); ?></span></td>
                        <td><?php echo date_i18n(get_option('date_format'), strtotime($sub->enrolled_at)); ?></td>
                        <td><?php echo $sub->expires_at ? date_i18n(get_option('date_format'), strtotime($sub->expires_at)) : '-'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p><?php _e( 'No subscribers found yet.', 'ts-lms' ); ?></p>
    <?php endif; ?>

</div>
<style>
    .ts-stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; margin-bottom: 40px; }
    .ts-stat-card { background: #fff; padding: 30px; border-radius: 20px; border: 1px solid #f0f2f5; display: flex; align-items: center; gap: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.02); transition: 0.3s; }
    .ts-stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
    
    .stat-icon { width: 64px; height: 64px; border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: 28px; }
    .icon-blue { background: #eff6ff; color: #3b82f6; }
    .icon-green { background: #ecfdf5; color: #10b981; }
    .icon-purple { background: #f5f3ff; color: #8b5cf6; }
    
    .stat-info { display: flex; flex-direction: column; gap: 5px; }
    .stat-label { color: #6b7280; font-size: 14px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.5px; }
    .stat-value { color: #1f2937; font-size: 28px; font-weight: 800; }
    
    .ts-table-responsive { overflow-x: auto; background: #fff; border-radius: 16px; border: 1px solid #f0f2f5; box-shadow: 0 4px 10px rgba(0,0,0,0.02); }
    .ts-table { width: 100%; border-collapse: collapse; min-width: 800px; }
    .ts-table th { text-align: left; padding: 20px 24px; background: #f9fafb; color: #6b7280; font-weight: 600; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #e5e7eb; }
    .ts-table td { padding: 20px 24px; border-bottom: 1px solid #f3f4f6; color: #374151; font-size: 15px; }
    .ts-table tr:last-child td { border-bottom: none; }
    .ts-user-cell { display: flex; align-items: center; gap: 12px; font-weight: 500; color: #1f2937; }
    .ts-user-cell img { border-radius: 50%; }
    
    .status-badge { padding: 6px 14px; border-radius: 30px; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
    .status-active { background: #dcfce7; color: #166534; }
    .status-expired { background: #fee2e2; color: #991b1b; }
</style>
