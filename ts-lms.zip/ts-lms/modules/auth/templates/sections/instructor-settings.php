<?php
/**
 * Instructor Dashboard - Settings
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$user_id = get_current_user_id();
$user = get_userdata($user_id);

$bio = get_user_meta($user_id, 'ts_instructor_bio', true);
$skills = get_user_meta($user_id, 'ts_instructor_skills', true);
$phone = get_user_meta($user_id, 'ts_instructor_phone', true);
$portfolio = get_user_meta($user_id, 'ts_instructor_portfolio', true);
$payout_method = get_user_meta($user_id, 'ts_instructor_payout_method', true) ?: 'bank';
$payout_details = get_user_meta($user_id, 'ts_instructor_payout_details', true) ?: array();
?>

<div class="dashboard-header">
    <h1><?php esc_html_e( 'Profile Settings', 'ts-lms' ); ?></h1>
    <p><?php esc_html_e( 'Update your instructor profile and payment information.', 'ts-lms' ); ?></p>
</div>

<div class="settings-grid">
    <!-- Profile Info -->
    <div class="settings-card">
        <form id="instructor-profile-form">
            <div class="card-header">
                <h2><span class="dashicons dashicons-admin-users"></span> <?php esc_html_e( 'Public Profile', 'ts-lms' ); ?></h2>
            </div>
            <div class="card-body">
                <div class="form-row">
                    <div class="ts-lms-form-group">
                        <label><?php esc_html_e( 'Display Name', 'ts-lms' ); ?></label>
                        <input type="text" name="display_name" value="<?php echo esc_attr($user->display_name); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="ts-lms-form-group">
                        <label><?php esc_html_e( 'Phone Number', 'ts-lms' ); ?></label>
                        <input type="text" name="phone" value="<?php echo esc_attr($phone); ?>">
                    </div>
                </div>
                <div class="ts-lms-form-group">
                    <label><?php esc_html_e( 'Short Bio', 'ts-lms' ); ?></label>
                    <textarea name="bio" rows="4"><?php echo esc_textarea($bio); ?></textarea>
                </div>
                <div class="ts-lms-form-group">
                    <label><?php esc_html_e( 'Skills (Comma separated)', 'ts-lms' ); ?></label>
                    <input type="text" name="skills" value="<?php echo esc_attr($skills); ?>" placeholder="e.g. Design, PHP, Marketing">
                </div>
                <div class="ts-lms-form-group">
                    <label><?php esc_html_e( 'Portfolio / Website URL', 'ts-lms' ); ?></label>
                    <input type="url" name="portfolio" value="<?php echo esc_attr($portfolio); ?>">
                </div>
                
                <button type="submit" class="ts-lms-btn ts-lms-btn-primary"><?php esc_html_e( 'Save Changes', 'ts-lms' ); ?></button>
            </div>
        </form>
    </div>

    <!-- Payout Settings -->
    <div class="settings-card">
        <form id="instructor-payout-form">
            <div class="card-header">
                <h2><span class="dashicons dashicons-money-alt"></span> <?php esc_html_e( 'Withdrawal Settings', 'ts-lms' ); ?></h2>
            </div>
            <div class="card-body">
                <div class="ts-lms-form-group">
                    <label><?php esc_html_e( 'Preferred Method', 'ts-lms' ); ?></label>
                    <select name="payout_method" class="payout-toggle">
                        <option value="bank" <?php selected($payout_method, 'bank'); ?>><?php _e('Bank Transfer', 'ts-lms'); ?></option>
                        <option value="bkash" <?php selected($payout_method, 'bkash'); ?>><?php _e('bKash', 'ts-lms'); ?></option>
                        <option value="paypal" <?php selected($payout_method, 'paypal'); ?>><?php _e('PayPal', 'ts-lms'); ?></option>
                    </select>
                </div>

                <div class="payout-details bank-details" style="<?php echo $payout_method === 'bank' ? '' : 'display:none;'; ?>">
                    <div class="ts-lms-form-group">
                        <label><?php esc_html_e( 'Bank Name', 'ts-lms' ); ?></label>
                        <input type="text" name="details[bank_name]" value="<?php echo esc_attr($payout_details['bank_name'] ?? ''); ?>">
                    </div>
                    <div class="ts-lms-form-group">
                        <label><?php esc_html_e( 'Account Number', 'ts-lms' ); ?></label>
                        <input type="text" name="details[acc_number]" value="<?php echo esc_attr($payout_details['acc_number'] ?? ''); ?>">
                    </div>
                </div>

                <div class="payout-details bkash-details" style="<?php echo $payout_method === 'bkash' ? '' : 'display:none;'; ?>">
                    <div class="ts-lms-form-group">
                        <label><?php esc_html_e( 'bKash Number', 'ts-lms' ); ?></label>
                        <input type="text" name="details[bkash_number]" value="<?php echo esc_attr($payout_details['bkash_number'] ?? ''); ?>">
                    </div>
                </div>

                <div class="payout-details paypal-details" style="<?php echo $payout_method === 'paypal' ? '' : 'display:none;'; ?>">
                    <div class="ts-lms-form-group">
                        <label><?php esc_html_e( 'PayPal Email', 'ts-lms' ); ?></label>
                        <input type="email" name="details[paypal_email]" value="<?php echo esc_attr($payout_details['paypal_email'] ?? ''); ?>">
                    </div>
                </div>
                
                <button type="submit" class="ts-lms-btn ts-lms-btn-primary"><?php esc_html_e( 'Update Payout Info', 'ts-lms' ); ?></button>
            </div>
        </form>
    </div>
</div>

<style>
.settings-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
@media (max-width: 900px) { .settings-grid { grid-template-columns: 1fr; } }

.settings-card { background: #fff; border-radius: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); overflow: hidden; }
.settings-card .card-header { padding: 25px; border-bottom: 1px solid #f3f4f6; }
.settings-card .card-header h2 { font-size: 18px; margin: 0; display: flex; align-items: center; gap: 10px; color: #111827; }
.settings-card .card-header .dashicons { color: var(--ts-primary); }

.card-body { padding: 30px; }
.form-row { display: grid; grid-template-columns: 1fr; gap: 20px; }

.payout-details { margin-top: 20px; padding: 20px; background: #f9fafb; border-radius: 12px; }
</style>

<script>
jQuery(document).ready(function($) {
    $('.payout-toggle').on('change', function() {
        const val = $(this).val();
        $('.payout-details').hide();
        $('.' + val + '-details').fadeIn();
    });
});
</script>
