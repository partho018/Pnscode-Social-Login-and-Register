<?php
/**
 * Enrolled Courses Section
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
$user_id = get_current_user_id();

// Get all enrolled courses with details
$enrolled_courses = $wpdb->get_results($wpdb->prepare(
    "SELECT e.*, p.post_title, p.post_name, p.ID as course_id,
            (SELECT COUNT(*) FROM {$wpdb->prefix}ts_lesson_progress lp 
             WHERE lp.user_id = e.user_id AND lp.course_id = e.course_id AND lp.status = 'completed') as completed_lessons,
            (SELECT COUNT(*) FROM {$wpdb->prefix}posts 
             WHERE post_parent = e.course_id AND post_type = 'ts-lesson' AND post_status = 'publish') as total_lessons
     FROM {$wpdb->prefix}ts_course_enrollments e
     INNER JOIN {$wpdb->prefix}posts p ON e.course_id = p.ID
     WHERE e.user_id = %d AND e.status != 'cancelled'
     ORDER BY e.enrolled_at DESC",
    $user_id
));
?>

<div class="ts-section-enrolled-courses">
    <div class="ts-section-header">
        <h3 class="ts-section-title">
            <span class="dashicons dashicons-welcome-learn-more"></span>
            <?php esc_html_e('Enrolled Courses', 'ts-lms'); ?>
        </h3>
        <p class="ts-section-subtitle"><?php esc_html_e('Manage and continue your learning journey', 'ts-lms'); ?></p>
    </div>

    <?php if (!empty($enrolled_courses)): ?>
        <!-- Filter Tabs -->
        <div class="ts-course-filters">
            <button class="ts-filter-btn active" data-filter="all">
                <?php esc_html_e('All Courses', 'ts-lms'); ?> 
                <span class="ts-count"><?php echo count($enrolled_courses); ?></span>
            </button>
            <button class="ts-filter-btn" data-filter="active">
                <?php esc_html_e('Active', 'ts-lms'); ?>
            </button>
            <button class="ts-filter-btn" data-filter="completed">
                <?php esc_html_e('Completed', 'ts-lms'); ?>
            </button>
        </div>

        <div class="ts-enrolled-courses-grid">
            <?php foreach ($enrolled_courses as $enrollment): 
                $course_id = $enrollment->course_id;
                $thumbnail_id = get_post_thumbnail_id($course_id);
                $thumbnail_url = $thumbnail_id ? wp_get_attachment_image_url($thumbnail_id, 'medium') : '';
                $progress = $enrollment->total_lessons > 0 ? 
                    round(($enrollment->completed_lessons / $enrollment->total_lessons) * 100) : 0;
                $is_completed = $enrollment->completed_at !== null;
                $status = $is_completed ? 'completed' : 'active';
            ?>
                <div class="ts-enrolled-course-card" data-status="<?php echo esc_attr($status); ?>">
                    <div class="ts-course-card-image">
                        <?php if ($thumbnail_url): ?>
                            <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr($enrollment->post_title); ?>">
                        <?php else: ?>
                            <div class="ts-course-placeholder-large">
                                <span class="dashicons dashicons-book"></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($is_completed): ?>
                            <div class="ts-course-badge ts-badge-completed">
                                <span class="dashicons dashicons-yes-alt"></span>
                                <?php esc_html_e('Completed', 'ts-lms'); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="ts-course-card-content">
                        <h4><?php echo esc_html($enrollment->post_title); ?></h4>
                        
                        <div class="ts-course-meta">
                            <span class="ts-meta-item">
                                <span class="dashicons dashicons-category"></span>
                                <?php 
                                $categories = get_the_terms($course_id, 'ts-course-category');
                                if ($categories && !is_wp_error($categories)) {
                                    echo esc_html($categories[0]->name);
                                } else {
                                    esc_html_e('Uncategorized', 'ts-lms');
                                }
                                ?>
                            </span>
                            <span class="ts-meta-item">
                                <span class="dashicons dashicons-calendar-alt"></span>
                                <?php echo human_time_diff(strtotime($enrollment->enrolled_at), current_time('timestamp')) . ' ' . __('ago', 'ts-lms'); ?>
                            </span>
                        </div>

                        <div class="ts-course-progress-section">
                            <div class="ts-progress-header">
                                <span><?php esc_html_e('Progress', 'ts-lms'); ?></span>
                                <strong><?php echo esc_html($progress); ?>%</strong>
                            </div>
                            <div class="ts-course-progress-bar">
                                <div class="ts-progress-fill" style="width: <?php echo esc_attr($progress); ?>%"></div>
                            </div>
                            <div class="ts-lesson-count">
                                <?php 
                                printf(
                                    esc_html__('%1$d of %2$d lessons completed', 'ts-lms'),
                                    $enrollment->completed_lessons,
                                    $enrollment->total_lessons
                                ); 
                                ?>
                            </div>
                        </div>

                        <div class="ts-course-actions">
                            <a href="<?php echo esc_url(get_permalink($course_id)); ?>" class="ts-btn-primary">
                                <?php echo $is_completed ? esc_html__('Review Course', 'ts-lms') : esc_html__('Continue Learning', 'ts-lms'); ?> →
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="ts-empty-state-large">
            <div class="ts-empty-icon">
                <span class="dashicons dashicons-book-alt"></span>
            </div>
            <h4><?php esc_html_e('No Enrolled Courses', 'ts-lms'); ?></h4>
            <p><?php esc_html_e('You haven\'t enrolled in any courses yet. Explore our course catalog and start learning today!', 'ts-lms'); ?></p>
            <a href="<?php echo esc_url(get_permalink(get_option('ts_lms_course_catalog_page_id'))); ?>" class="ts-btn-primary">
                <span class="dashicons dashicons-search"></span>
                <?php esc_html_e('Browse Courses', 'ts-lms'); ?>
            </a>
        </div>
    <?php endif; ?>
</div>
