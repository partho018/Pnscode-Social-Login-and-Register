<?php
/**
 * Wishlist Section
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$user_id = get_current_user_id();
$wishlist_manager = 'TS_LMS\Modules\Courses\Managers\WishlistManager';

// Handle remove from wishlist
if (isset($_POST['remove_from_wishlist']) && isset($_POST['course_id'])) {
    $remove_id = intval($_POST['course_id']);
    if (class_exists($wishlist_manager)) {
        $wishlist_manager::remove_from_wishlist($remove_id, $user_id);
    }
}

// Get wishlist courses
$wishlist = class_exists($wishlist_manager) ? $wishlist_manager::get_wishlist($user_id) : [];

// Get course details for wishlist items
$wishlist_courses = [];
if (!empty($wishlist)) {
    $wishlist_courses = get_posts([
        'post_type' => 'ts_course', // FIXED: was ts-course
        'post__in' => $wishlist,
        'posts_per_page' => -1,
        'orderby' => 'post__in',
    ]);
}
?>

<div class="ts-section-wishlist">
    <div class="ts-section-header">
        <h3 class="ts-section-title">
            <span class="dashicons dashicons-heart"></span>
            <?php esc_html_e('My Wishlist', 'ts-lms'); ?>
        </h3>
        <p class="ts-section-subtitle"><?php esc_html_e('Courses you want to take later', 'ts-lms'); ?></p>
    </div>

    <?php if (!empty($wishlist_courses)): ?>
        <div class="ts-wishlist-grid">
            <?php foreach ($wishlist_courses as $course): 
                $course_id = $course->ID;
                $thumbnail_id = get_post_thumbnail_id($course_id);
                $thumbnail_url = $thumbnail_id ? wp_get_attachment_image_url($thumbnail_id, 'medium') : '';
                
                // Get course price
                $pricing_model = get_post_meta($course_id, '_ts_pricing_model', true);
                $woo_product_id = get_post_meta($course_id, '_ts_woo_product_id', true);
                $price_text = $pricing_model === 'free' ? __('Free', 'ts-lms') : __('Paid', 'ts-lms');
                
                if ($woo_product_id && function_exists('wc_get_product')) {
                    $product = wc_get_product($woo_product_id);
                    if ($product) {
                        $price_text = $product->get_price_html();
                    }
                }
            ?>
                <div class="ts-wishlist-item">
                    <div class="ts-wishlist-image">
                        <?php if ($thumbnail_url): ?>
                            <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr($course->post_title); ?>">
                        <?php else: ?>
                            <div class="ts-course-placeholder-large">
                                <span class="dashicons dashicons-book"></span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="ts-wishlist-content">
                        <h4><?php echo esc_html($course->post_title); ?></h4>
                        
                        <div class="ts-course-meta">
                            <span class="ts-meta-item">
                                <span class="dashicons dashicons-admin-users"></span>
                                <?php 
                                if (class_exists('TS_LMS\Modules\Courses\Managers\CourseManager')) {
                                    $instructors = \TS_LMS\Modules\Courses\Managers\CourseManager::get_instructors($course_id);
                                    if (!empty($instructors)) {
                                        echo esc_html($instructors[0]['name']);
                                    } else {
                                        echo esc_html__('No Instructor', 'ts-lms');
                                    }
                                }
                                ?>
                            </span>
                        </div>
                        
                        <div class="ts-wishlist-price">
                            <?php echo wp_kses_post($price_text); ?>
                        </div>
                        
                        <div class="ts-wishlist-actions">
                            <a href="<?php echo esc_url(get_permalink($course_id)); ?>" class="ts-btn-primary">
                                <span class="dashicons dashicons-visibility"></span>
                                <?php esc_html_e('View Course', 'ts-lms'); ?>
                            </a>
                            
                            <form method="post" style="display: inline;">
                                <input type="hidden" name="course_id" value="<?php echo esc_attr($course_id); ?>">
                                <button type="submit" name="remove_from_wishlist" class="ts-btn-remove">
                                    <span class="dashicons dashicons-trash"></span>
                                    <?php esc_html_e('Remove', 'ts-lms'); ?>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="ts-empty-state-large">
            <div class="ts-empty-icon">
                <span class="dashicons dashicons-heart"></span>
            </div>
            <h4><?php esc_html_e('No Courses in Wishlist', 'ts-lms'); ?></h4>
            <p><?php esc_html_e('Start adding courses to your wishlist to save them for later!', 'ts-lms'); ?></p>
            <a href="<?php echo esc_url(get_permalink(get_option('ts_lms_course_catalog_page_id'))); ?>" class="ts-btn-primary">
                <span class="dashicons dashicons-search"></span>
                <?php esc_html_e('Browse Courses', 'ts-lms'); ?>
            </a>
        </div>
    <?php endif; ?>
</div>
