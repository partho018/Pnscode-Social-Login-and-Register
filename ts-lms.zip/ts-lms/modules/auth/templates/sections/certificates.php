<?php
/**
 * Certificates Section
 *
 * @package TS_LMS\Modules\Auth
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
$user_id = get_current_user_id();

// Get enrolled courses that have certificates enabled
$enrolled_courses = $wpdb->get_results($wpdb->prepare(
    "SELECT e.*, p.post_title, p.ID as course_id
     FROM {$wpdb->prefix}ts_course_enrollments e
     INNER JOIN {$wpdb->prefix}posts p ON e.course_id = p.ID
     WHERE e.user_id = %d AND e.status != 'cancelled'
     ORDER BY e.enrolled_at DESC",
    $user_id
));

// Show all enrolled courses as requested
$certificate_courses = $enrolled_courses;
?>

<div class="ts-section-certificates">
    <div class="ts-section-header">
        <h3 class="ts-section-title">
            <span class="dashicons dashicons-awards"></span>
            <?php esc_html_e('My Certificates', 'ts-lms'); ?>
        </h3>
        <p class="ts-section-subtitle"><?php esc_html_e('View and download your earned course certificates', 'ts-lms'); ?></p>
    </div>

    <?php if (!empty($certificate_courses)): ?>
        <div class="ts-certificates-grid">
            <?php foreach ($certificate_courses as $enrollment): 
                $course_id = $enrollment->course_id;
                $thumbnail_id = get_post_thumbnail_id($course_id);
                $thumbnail_url = $thumbnail_id ? wp_get_attachment_image_url($thumbnail_id, 'medium') : '';
                
                // Progress check
                $progress = \TS_LMS\Modules\Courses\Managers\CourseManager::get_course_progress($course_id, $user_id);
                
                // Completion check
                $is_completed = get_user_meta($user_id, '_ts_course_completed_' . $course_id, true);
                if (!$is_completed && $enrollment->status === 'completed') {
                    $is_completed = true;
                }

                // Certificate Enabled check
                $selected_cert = get_post_meta($course_id, '_selected_certificate', true);
                $has_cert_enabled = ($selected_cert && $selected_cert !== 'none');
            ?>
                <div class="ts-certificate-card <?php echo $is_completed ? 'earned' : ($has_cert_enabled ? 'locked' : 'no-cert'); ?>">
                    <div class="ts-cert-card-visual">
                        <?php if ($thumbnail_url): ?>
                            <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr($enrollment->post_title); ?>">
                        <?php else: ?>
                            <div class="ts-cert-placeholder">
                                <span class="dashicons dashicons-awards"></span>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($is_completed && $has_cert_enabled): ?>
                            <div class="ts-cert-earned-badge">
                                <span class="dashicons dashicons-yes-alt"></span>
                                <?php esc_html_e('Earned', 'ts-lms'); ?>
                            </div>
                        <?php elseif ($has_cert_enabled): ?>
                            <div class="ts-cert-locked-overlay">
                                <span class="dashicons dashicons-lock"></span>
                                <div class="progress-info"><?php echo esc_html($progress); ?>%</div>
                            </div>
                        <?php else: ?>
                            <div class="ts-cert-locked-overlay no-cert">
                                <span class="dashicons dashicons-info"></span>
                                <div class="progress-info"><?php _e('No Certificate', 'ts-lms'); ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="ts-cert-card-content">
                        <h4><?php echo esc_html($enrollment->post_title); ?></h4>
                        
                        <div class="ts-cert-meta">
                            <?php if ($is_completed && $has_cert_enabled): ?>
                                <span class="ts-cert-date">
                                    <span class="dashicons dashicons-calendar-alt"></span>
                                    <?php 
                                    $completed_date = $enrollment->completed_at;
                                    if (!$completed_date) {
                                        $completed_date = get_user_meta($user_id, '_ts_course_completed_' . $course_id, true);
                                    }
                                    if ($completed_date) {
                                        echo sprintf(__('Earned on %s', 'ts-lms'), date_i18n(get_option('date_format'), is_numeric($completed_date) ? $completed_date : strtotime($completed_date)));
                                    } else {
                                        esc_html_e('Completed', 'ts-lms');
                                    }
                                    ?>
                                </span>
                            <?php elseif ($has_cert_enabled): ?>
                                <div class="ts-cert-progress">
                                    <div class="ts-cert-progress-bar">
                                        <div class="ts-cert-progress-fill" style="width: <?php echo esc_attr($progress); ?>%"></div>
                                    </div>
                                    <span class="progress-text"><?php printf(esc_html__('%d%% complete', 'ts-lms'), $progress); ?></span>
                                </div>
                            <?php else: ?>
                                <span class="ts-cert-date">
                                    <span class="dashicons dashicons-info"></span>
                                    <?php _e('Certificate not available for this course.', 'ts-lms'); ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="ts-cert-actions">
                            <?php if ($is_completed && $has_cert_enabled): 
                                $cert_url = \TS_LMS\Courses\CertificateGenerator::get_certificate_url($user_id, $course_id);
                            ?>
                                <a href="<?php echo esc_url($cert_url); ?>" class="ts-btn ts-btn-primary" target="_blank">
                                    <span class="dashicons dashicons-download"></span>
                                    <?php esc_html_e('Download Certificate', 'ts-lms'); ?>
                                </a>
                            <?php elseif ($has_cert_enabled): ?>
                                <a href="<?php echo esc_url(get_permalink($course_id)); ?>" class="ts-btn ts-btn-outline">
                                    <?php esc_html_e('Continue Learning', 'ts-lms'); ?>
                                </a>
                            <?php else: ?>
                                <a href="<?php echo esc_url(get_permalink($course_id)); ?>" class="ts-btn ts-btn-outline">
                                    <?php esc_html_e('View Course', 'ts-lms'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="ts-empty-state-large">
            <div class="ts-empty-icon">
                <span class="dashicons dashicons-awards"></span>
            </div>
            <h4><?php esc_html_e('No Certificates Yet', 'ts-lms'); ?></h4>
            <p><?php esc_html_e('Complete courses to earn certificates and showcase your skills.', 'ts-lms'); ?></p>
            <a href="<?php echo esc_url(get_permalink(get_option('ts_lms_course_catalog_page_id'))); ?>" class="ts-btn ts-btn-primary">
                <?php esc_html_e('Start Learning', 'ts-lms'); ?>
            </a>
        </div>
    <?php endif; ?>
</div>

<style>
.ts-certificates-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 25px;
    margin-top: 30px;
}

.ts-certificate-card {
    background: #fff;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    border: 1px solid #f1f5f9;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.ts-certificate-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.ts-cert-card-visual {
    position: relative;
    height: 180px;
    background: #f8fafc;
    overflow: hidden;
}

.ts-cert-card-visual img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.ts-cert-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
    color: #94a3b8;
}

.ts-cert-placeholder .dashicons {
    font-size: 64px;
    width: 64px;
    height: 64px;
}

.ts-cert-earned-badge {
    position: absolute;
    top: 15px;
    right: 15px;
    background: #10b981;
    color: #fff;
    padding: 6px 15px;
    border-radius: 50px;
    font-size: 12px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 5px;
    box-shadow: 0 4px 10px rgba(16, 185, 129, 0.3);
}

.ts-cert-locked-overlay {
    position: absolute;
    inset: 0;
    background: rgba(15, 23, 42, 0.6);
    backdrop-filter: blur(4px);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #fff;
}

.ts-cert-locked-overlay .dashicons {
    font-size: 32px;
    width: 32px;
    height: 32px;
    margin-bottom: 10px;
}

.ts-cert-locked-overlay .progress-info {
    font-size: 18px;
    font-weight: 700;
}

.ts-cert-card-content {
    padding: 20px;
}

.ts-cert-card-content h4 {
    margin: 0 0 15px 0;
    font-size: 18px;
    font-weight: 700;
    color: #1e293b;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    height: 2.8em;
}

.ts-cert-meta {
    margin-bottom: 20px;
}

.ts-cert-date {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #64748b;
    font-size: 14px;
}

.ts-cert-progress {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.ts-cert-progress-bar {
    height: 6px;
    background: #f1f5f9;
    border-radius: 3px;
    overflow: hidden;
}

.ts-cert-progress-fill {
    height: 100%;
    background: var(--ts-primary, #4f46e5);
}

.progress-text {
    font-size: 13px;
    color: #64748b;
}

.ts-cert-actions .ts-btn {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px;
    border-radius: 10px;
    font-weight: 600;
    font-size: 14px;
    text-decoration: none;
    transition: 0.2s;
}

.ts-btn-primary {
    background: var(--ts-primary, #4f46e5);
    color: #fff;
    border: none;
}

.ts-btn-primary:hover {
    background: var(--ts-primary-dark, #4338ca);
}

.ts-btn-outline {
    background: transparent;
    border: 1px solid #e2e8f0;
    color: #475569;
}

.ts-btn-outline:hover {
    background: #f8fafc;
    border-color: #cbd5e1;
}

.ts-empty-state-large {
    text-align: center;
    padding: 60px 20px;
    background: #fff;
    border-radius: 20px;
    border: 2px dashed #e2e8f0;
    margin-top: 30px;
}

.ts-empty-icon {
    width: 80px;
    height: 80px;
    background: #f8fafc;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    color: #94a3b8;
}

.ts-empty-icon .dashicons {
    font-size: 40px;
    width: 40px;
    height: 40px;
}

.ts-empty-state-large h4 {
    font-size: 20px;
    color: #1e293b;
    margin-bottom: 10px;
}

.ts-empty-state-large p {
    color: #64748b;
    margin-bottom: 25px;
    max-width: 400px;
    margin-left: auto;
    margin-right: auto;
}
    .ts-certificate-card.no-cert .ts-cert-card-visual::after {
        background: rgba(0, 0, 0, 0.4);
    }
    .ts-cert-locked-overlay.no-cert {
        background: rgba(0, 0, 0, 0.4);
    }
    .ts-certificate-card.no-cert .ts-cert-card-content h4 {
        opacity: 0.8;
    }
</style>
