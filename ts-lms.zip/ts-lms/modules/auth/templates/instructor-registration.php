<?php
/**
 * Instructor Registration Template - Premium Redesign
 *
 * @package TS_LMS\Modules\Auth\Templates
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$user = wp_get_current_user();
$is_logged_in = is_user_logged_in();
?>

<div class="ts-instructor-reg-wrapper">
    <div class="ts-instructor-reg-container">
        <!-- Decoration Elements -->
        <div class="ts-decor-circle ts-decor-1"></div>
        <div class="ts-decor-circle ts-decor-2"></div>
        
        <div class="ts-reg-content-box">
            <div class="ts-reg-header">
                <div class="ts-header-icon">
                    <span class="dashicons dashicons-welcome-education"></span>
                </div>
                <h1><?php esc_html_e( 'Become an Instructor', 'ts-lms' ); ?></h1>
                <p><?php esc_html_e( 'Join our community of world-class educators and start sharing your expertise with thousands of students.', 'ts-lms' ); ?></p>
            </div>

            <form id="ts-lms-instructor-reg-form" class="ts-premium-form" method="post" enctype="multipart/form-data">
                <div class="ts-form-layout">
                    <!-- Column 1: Personal Info -->
                    <div class="ts-form-col">
                        <h3 class="ts-section-title">
                            <span class="dashicons dashicons-admin-users"></span>
                            <?php esc_html_e( 'Personal Information', 'ts-lms' ); ?>
                        </h3>
                        
                        <div class="ts-input-group">
                            <label><?php esc_html_e( 'Full Name', 'ts-lms' ); ?> <span class="ts-required">*</span></label>
                            <input type="text" name="full_name" value="<?php echo $is_logged_in ? esc_attr( $user->display_name ) : ''; ?>" placeholder="e.g. John Doe" required>
                        </div>

                        <div class="ts-input-group">
                            <label><?php esc_html_e( 'Email Address', 'ts-lms' ); ?> <span class="ts-required">*</span></label>
                            <input type="email" name="email" value="<?php echo $is_logged_in ? esc_attr( $user->user_email ) : ''; ?>" <?php echo $is_logged_in ? 'readonly' : ''; ?> placeholder="example@mail.com" required>
                            <?php if ( $is_logged_in ) : ?>
                                <small class="ts-hint-text"><?php esc_html_e( 'Linked to your current account', 'ts-lms' ); ?></small>
                            <?php endif; ?>
                        </div>

                        <?php if ( ! $is_logged_in ) : ?>
                        <div class="ts-input-group">
                            <label><?php esc_html_e( 'Account Password', 'ts-lms' ); ?> <span class="ts-required">*</span></label>
                            <input type="password" name="password" placeholder="Create a secure password" required>
                        </div>
                        <?php endif; ?>

                        <div class="ts-input-group">
                            <label><?php esc_html_e( 'Phone Number', 'ts-lms' ); ?> <span class="ts-required">*</span></label>
                            <input type="tel" name="phone" placeholder="+880 1XXX XXXXXX" required>
                        </div>
                        
                        <div class="ts-input-group">
                            <label><?php esc_html_e( 'Profile Photo', 'ts-lms' ); ?></label>
                            <div class="ts-photo-uploader" id="photoDropArea">
                                <input type="file" id="profile_photo" name="profile_photo" accept="image/*">
                                <div class="ts-upload-placeholder">
                                    <div class="ts-upload-icon">
                                        <span class="dashicons dashicons-camera"></span>
                                    </div>
                                    <p><?php esc_html_e( 'Upload Photo', 'ts-lms' ); ?></p>
                                    <span><?php esc_html_e( 'PNG, JPG up to 5MB', 'ts-lms' ); ?></span>
                                </div>
                                <div id="ts-photo-preview" class="ts-photo-preview"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Column 2: Professional Info -->
                    <div class="ts-form-col">
                        <h3 class="ts-section-title">
                            <span class="dashicons dashicons-id"></span>
                            <?php esc_html_e( 'Professional Details', 'ts-lms' ); ?>
                        </h3>

                        <div class="ts-input-group">
                            <label><?php esc_html_e( 'Professional Bio', 'ts-lms' ); ?> <span class="ts-required">*</span></label>
                            <textarea name="bio" rows="4" placeholder="Tell us about yourself and your background..." required></textarea>
                        </div>

                        <div class="ts-input-group">
                            <label><?php esc_html_e( 'Key Expertise / Skills', 'ts-lms' ); ?></label>
                            <input type="text" name="skills" placeholder="e.g. Graphic Design, Web Development, Marketing">
                            <small class="ts-hint-text"><?php esc_html_e( 'Separate skills with commas', 'ts-lms' ); ?></small>
                        </div>

                        <div class="ts-input-group">
                            <label><?php esc_html_e( 'Teaching Experience', 'ts-lms' ); ?></label>
                            <textarea name="experience" rows="3" placeholder="Do you have any prior teaching experience?"></textarea>
                        </div>

                        <div class="ts-input-group">
                            <label><?php esc_html_e( 'Social/Portfolio Link', 'ts-lms' ); ?></label>
                            <input type="url" name="portfolio" placeholder="https://linkedin.com/in/username">
                        </div>
                    </div>
                </div>

                <div class="ts-reg-footer">
                    <div class="ts-terms-agreement">
                        <label class="ts-custom-check">
                            <input type="checkbox" name="terms" required>
                            <span class="ts-check-box"></span>
                            <span class="ts-check-text"><?php printf( esc_html__( 'I am ready to share my knowledge and I agree to the %s.', 'ts-lms' ), '<a href="#">' . esc_html__( 'Instructor Terms', 'ts-lms' ) . '</a>' ); ?></span>
                        </label>
                    </div>

                    <div class="ts-submit-zone">
                        <button type="submit" class="ts-submit-btn">
                            <span class="btn-text"><?php esc_html_e( 'Submit Application', 'ts-lms' ); ?></span>
                            <div class="ts-loader" style="display: none;"></div>
                        </button>
                        <p class="ts-status-output"></p>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

.ts-instructor-reg-wrapper {
    background: #f8faff;
    min-height: 100vh;
    padding: 60px 20px;
    font-family: 'Inter', sans-serif;
    position: relative;
    overflow: hidden;
}

.ts-decor-circle {
    position: absolute;
    background: linear-gradient(135deg, #4f46e510, #7c3aed10);
    border-radius: 50%;
    z-index: 0;
}
.ts-decor-1 { width: 400px; height: 400px; top: -100px; left: -100px; }
.ts-decor-2 { width: 300px; height: 300px; bottom: -50px; right: -50px; }

.ts-instructor-reg-container {
    max-width: 1000px;
    margin: 0 auto;
    position: relative;
    z-index: 1;
}

.ts-reg-content-box {
    background: #ffffff;
    border-radius: 30px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.05);
    padding: 50px;
    border: 1px solid #f1f5f9;
}

.ts-reg-header {
    text-align: center;
    margin-bottom: 50px;
}

.ts-header-icon {
    width: 70px;
    height: 70px;
    background: linear-gradient(135deg, #4f46e5, #7c3aed);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    box-shadow: 0 10px 20px rgba(79, 70, 229, 0.2);
}

.ts-header-icon .dashicons {
    color: #fff;
    font-size: 36px;
    width: 36px;
    height: 36px;
}

.ts-reg-header h1 {
    font-size: 32px;
    font-weight: 800;
    color: #1e293b;
    margin: 0 0 10px;
}

.ts-reg-header p {
    color: #64748b;
    font-size: 16px;
    max-width: 500px;
    margin: 0 auto;
}

.ts-form-layout {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 50px;
}

.ts-section-title {
    font-size: 18px;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 10px;
    border-bottom: 2px solid #f1f5f9;
    padding-bottom: 12px;
}

.ts-section-title .dashicons {
    color: #4f46e5;
    font-size: 20px;
    width: 20px;
    height: 20px;
}

.ts-input-group {
    margin-bottom: 20px;
}

.ts-input-group label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #475569;
    margin-bottom: 8px;
}

.ts-required {
    color: #ef4444;
}

.ts-input-group input,
.ts-input-group textarea {
    width: 100%;
    padding: 12px 16px;
    border: 1.5px solid #e2e8f0;
    border-radius: 12px;
    font-size: 15px;
    color: #1e293b;
    transition: 0.3s;
    background: #f8fafc;
}

.ts-input-group input:focus,
.ts-input-group textarea:focus {
    background: #fff;
    border-color: #4f46e5;
    box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
    outline: none;
}

.ts-hint-text {
    font-size: 12px;
    color: #94a3b8;
    margin-top: 5px;
    display: block;
}

/* Photo Uploader Styling */
.ts-photo-uploader {
    height: 140px;
    background: #f8fafc;
    border: 2px dashed #cbd5e1;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    cursor: pointer;
    transition: 0.3s;
    overflow: hidden;
}

.ts-photo-uploader:hover {
    border-color: #4f46e5;
    background: #f5f3ff;
}

.ts-photo-uploader input {
    position: absolute;
    width: 100%;
    height: 100%;
    opacity: 0;
    cursor: pointer;
    z-index: 5;
}

.ts-upload-placeholder {
    text-align: center;
}

.ts-upload-icon {
    width: 40px;
    height: 40px;
    background: #fff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 10px;
    color: #64748b;
    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
}

.ts-upload-placeholder p {
    font-weight: 600;
    color: #475569;
    margin: 0;
    font-size: 14px;
}

.ts-upload-placeholder span {
    font-size: 11px;
    color: #94a3b8;
}

.ts-photo-preview {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-size: cover;
    background-position: center;
    display: none;
    z-index: 4;
}

/* Registration Footer */
.ts-reg-footer {
    margin-top: 40px;
    padding-top: 30px;
    border-top: 2px solid #f1f5f9;
}

.ts-custom-check {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    cursor: pointer;
    margin-bottom: 30px;
}

.ts-custom-check input {
    display: none;
}

.ts-check-box {
    width: 22px;
    height: 22px;
    border: 2px solid #cbd5e1;
    border-radius: 6px;
    flex-shrink: 0;
    position: relative;
    transition: 0.2s;
    background: #fff;
}

.ts-custom-check input:checked + .ts-check-box {
    background: #4f46e5;
    border-color: #4f46e5;
}

.ts-check-box::after {
    content: '\f15e';
    font-family: 'dashicons';
    position: absolute;
    color: #fff;
    font-size: 14px;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    display: none;
}

.ts-custom-check input:checked + .ts-check-box::after {
    display: block;
}

.ts-check-text {
    font-size: 14px;
    color: #475569;
    line-height: 1.5;
}

.ts-check-text a {
    color: #4f46e5;
    text-decoration: none;
    font-weight: 600;
}

.ts-submit-btn {
    width: 100%;
    background: linear-gradient(135deg, #4f46e5, #7c3aed);
    color: #fff;
    padding: 16px 30px;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 700;
    border: none;
    cursor: pointer;
    transition: 0.3s;
    box-shadow: 0 10px 20px rgba(79, 70, 229, 0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.ts-submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 15px 30px rgba(79, 70, 229, 0.3);
}

.ts-submit-btn:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    transform: none;
}

.ts-status-output {
    margin-top: 15px;
    text-align: center;
    font-size: 14px;
    font-weight: 600;
}

.ts-status-output.success { color: #059669; }
.ts-status-output.error { color: #dc2626; }

.ts-loader {
    width: 20px;
    height: 20px;
    border: 3px solid rgba(255,255,255,0.3);
    border-top-color: #fff;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin { to { transform: rotate(360deg); } }

@media (max-width: 850px) {
    .ts-form-layout { grid-template-columns: 1fr; gap: 30px; }
    .ts-reg-content-box { padding: 30px; }
    .ts-reg-header h1 { font-size: 26px; }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Photo preview functionality
    $('#profile_photo').on('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#ts-photo-preview').css('background-image', 'url(' + e.target.result + ')').fadeIn();
                $('.ts-upload-placeholder').hide();
            }
            reader.readAsDataURL(file);
        }
    });

    // Submitting the application
    $('#ts-lms-instructor-reg-form').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const submitBtn = form.find('.ts-submit-btn');
        const statusMsg = form.find('.ts-status-output');
        const formData = new FormData(this);
        
        formData.append('action', 'ts_lms_instructor_register');
        formData.append('nonce', ts_lms_auth.nonce);

        submitBtn.prop('disabled', true).find('.btn-text').css('opacity', '0.5');
        submitBtn.find('.ts-loader').show();
        statusMsg.hide().removeClass('success error');

        $.ajax({
            url: ts_lms_auth.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    statusMsg.show().addClass('success').text(response.data.message);
                    setTimeout(function() {
                        window.location.href = response.data.redirect;
                    }, 2000);
                } else {
                    statusMsg.show().addClass('error').text(response.data.message);
                    submitBtn.prop('disabled', false).find('.btn-text').css('opacity', '1');
                    submitBtn.find('.ts-loader').hide();
                }
            },
            error: function() {
                statusMsg.show().addClass('error').text('An error occurred. Please try again.');
                submitBtn.prop('disabled', false).find('.btn-text').css('opacity', '1');
                submitBtn.find('.ts-loader').hide();
            }
        });
    });
});
</script>
