<?php
/**
 * Instructor Manager
 *
 * Handles instructor registration, approval, and management.
 *
 * @package TS_LMS\Modules\Auth
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Auth;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * InstructorManager class.
 */
class InstructorManager {
    
    /**
     * Singleton instance.
     *
     * @var InstructorManager
     */
    private static $instance = null;
    
    /**
     * Get singleton instance.
     *
     * @return InstructorManager
     */
    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor.
     */
    private function __construct() {
        $this->init();
    }
    
    /**
     * Initialize hooks.
     */
    private function init() {
        // AJAX handlers for instructor registration
        add_action( 'wp_ajax_ts_lms_instructor_register', array( $this, 'handle_instructor_registration' ) );
        add_action( 'wp_ajax_nopriv_ts_lms_instructor_register', array( $this, 'handle_instructor_registration' ) );
        
        // Ensure role exists with correct caps
        if ( is_admin() ) {
            self::create_instructor_role();
        }

        // Auto-fix role for approved instructors
        if ( is_user_logged_in() ) {
            $user_id = get_current_user_id();
            if ( get_user_meta( $user_id, 'ts_instructor_status', true ) === 'approved' ) {
                $user = wp_get_current_user();
                if ( ! in_array( 'instructor', (array) $user->roles ) ) {
                    $user->add_role( 'instructor' );
                    // Also remove old role name if it was ts_instructor
                    if ( in_array( 'ts_instructor', (array) $user->roles ) ) {
                        $user->remove_role( 'ts_instructor' );
                    }
                }
            }
        }

        // Admin approval actions
        add_action( 'wp_ajax_ts_lms_approve_instructor', array( $this, 'approve_instructor' ) );
        add_action( 'wp_ajax_ts_lms_reject_instructor', array( $this, 'reject_instructor' ) );
        add_action( 'wp_ajax_ts_lms_suspend_instructor', array( $this, 'suspend_instructor' ) );

        // Hide Admin Bar for instructors - Disabled
        // add_filter( 'show_admin_bar', array( $this, 'hide_admin_bar_for_instructors' ) );
        // add_action( 'admin_head', array( $this, 'hide_admin_bar_css' ) );
        // add_action( 'wp_head', array( $this, 'hide_admin_bar_css' ) );
    }

    /**
     * Hide admin bar with CSS for instructors.
     */
    public function hide_admin_bar_css() {
        if ( is_user_logged_in() && in_array( 'instructor', (array) wp_get_current_user()->roles ) && ! current_user_can( 'manage_options' ) ) {
            echo '<style>
                #wpadminbar { display: none !important; } 
                html.wp-toolbar { padding-top: 0 !important; } 
                #wpwrap { margin-top: 0 !important; }
                .ts-builder-header { top: 0 !important; }
                body.ts-lms-fullscreen #wpadminbar { display: none !important; }
                body.ts-lms-fullscreen { margin-top: 0 !important; padding-top: 0 !important; }
                #wpcontent { margin-top: 0 !important; }
            </style>';
        }
    }

    /**
     * Hide admin bar for instructors on the frontend and custom editor.
     */
    public function hide_admin_bar_for_instructors( $show ) {
        if ( is_user_logged_in() && in_array( 'instructor', (array) wp_get_current_user()->roles ) ) {
            return false;
        }
        return $show;
    }
    
    /**
     * Create instructor role with capabilities.
     * This should be called during plugin activation only.
     * FIXED: Using minimal capabilities to prevent memory exhaustion
     */
    public static function create_instructor_role() {
        // Create pending_instructor role
        if ( ! get_role( 'pending_instructor' ) ) {
            add_role( 'pending_instructor', __( 'Pending Instructor', 'ts-lms' ), array( 'read' => true ) );
        }

        $role = get_role( 'instructor' );
        if ( ! $role ) {
            $role = add_role( 'instructor', __( 'Instructor', 'ts-lms' ), array( 'read' => true ) );
        }
        
        if ( $role ) {
            // Basic WordPress caps
            $role->add_cap( 'upload_files' );
            $role->add_cap( 'edit_posts' );
            $role->add_cap( 'publish_posts' );
            $role->add_cap( 'delete_posts' );
            $role->add_cap( 'read' );
            $role->add_cap( 'level_0' );

            // Custom LMS Capabilities - own content only
            $caps_to_add = array(
                // Courses
                'edit_ts_course', 'read_ts_course', 'delete_ts_course', 'edit_ts_courses', 
                'publish_ts_courses', 'delete_published_ts_courses', 'delete_ts_courses', 'edit_published_ts_courses',
                
                // Lessons
                'edit_ts_lesson', 'read_ts_lesson', 'delete_ts_lesson', 'edit_ts_lessons', 
                'publish_ts_lessons', 'delete_published_ts_lessons', 'delete_ts_lessons', 'edit_published_ts_lessons',

                // Quizzes
                'edit_ts_quiz', 'read_ts_quiz', 'delete_ts_quiz', 'edit_ts_quizzes', 
                'publish_ts_quizzes', 'delete_published_ts_quizzes', 'delete_ts_quizzes', 'edit_published_ts_quizzes',

                // Assignments
                'edit_ts_assignment', 'read_ts_assignment', 'delete_ts_assignment', 'edit_ts_assignments', 
                'publish_ts_assignments', 'delete_published_ts_assignments', 'delete_ts_assignments', 'edit_published_ts_assignments',
            );

            foreach ( $caps_to_add as $cap ) {
                $role->add_cap( $cap );
            }
        }
    }
    
    /**
     * Handle instructor registration.
     */
    public function handle_instructor_registration() {
        check_ajax_referer( 'ts_lms_auth_nonce', 'nonce' );
        
        $user_id = get_current_user_id();
        $is_new_user = ! $user_id;

        // Check registration limit
        if ( self::is_limit_reached() ) {
            wp_send_json_error( array( 'message' => __( 'Instructor registration is currently closed as the maximum limit has been reached.', 'ts-lms' ) ) );
        }

        // Validation
        $name = sanitize_text_field( $_POST['full_name'] ?? '' );
        $email = sanitize_email( $_POST['email'] ?? '' );
        
        if ( $is_new_user ) {
            $password = $_POST['password'] ?? '';
            if ( empty( $name ) || empty( $email ) || empty( $password ) ) {
                wp_send_json_error( array( 'message' => __( 'Please fill all required fields.', 'ts-lms' ) ) );
            }
            if ( email_exists( $email ) ) {
                wp_send_json_error( array( 'message' => __( 'Email already registered.', 'ts-lms' ) ) );
            }
            $user_id = wp_create_user( $email, $password, $email );
            if ( is_wp_error( $user_id ) ) {
                wp_send_json_error( array( 'message' => $user_id->get_error_message() ) );
            }
        }

        // Get additional fields
        $phone = sanitize_text_field( $_POST['phone'] ?? '' );
        $bio = sanitize_textarea_field( $_POST['bio'] ?? '' );
        $skills = sanitize_text_field( $_POST['skills'] ?? '' );
        $experience = sanitize_textarea_field( $_POST['experience'] ?? '' );
        $portfolio = esc_url_raw( $_POST['portfolio'] ?? '' );
        $motivation = sanitize_textarea_field( $_POST['motivation'] ?? '' );
        
        // Profile Photo handling
        $photo_id = 0;
        if ( ! empty( $_FILES['profile_photo'] ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            
            $photo_id = media_handle_upload( 'profile_photo', 0 );
            if ( is_wp_error( $photo_id ) ) {
                $photo_id = 0;
            }
        }

        // Save application meta
        update_user_meta( $user_id, 'ts_instructor_status', 'pending' );
        update_user_meta( $user_id, 'ts_instructor_full_name', $name );
        update_user_meta( $user_id, 'ts_instructor_phone', $phone );
        update_user_meta( $user_id, 'ts_instructor_bio', $bio );
        update_user_meta( $user_id, 'ts_instructor_skills', $skills );
        update_user_meta( $user_id, 'ts_instructor_experience', $experience );
        update_user_meta( $user_id, 'ts_instructor_portfolio', $portfolio );
        update_user_meta( $user_id, 'ts_instructor_motivation', $motivation );
        update_user_meta( $user_id, 'ts_instructor_applied_date', current_time( 'mysql' ) );
        
        if ( $photo_id ) {
            update_user_meta( $user_id, 'ts_instructor_photo_id', $photo_id );
            set_user_meta( $user_id, 'ts_lms_avatar_id', $photo_id );
        }

        // Change role to pending_instructor
        $user = new \WP_User( $user_id );
        $user->set_role( 'pending_instructor' );

        // Send notification to admin
        $this->notify_admin_new_application( $user_id );

        // If new user, handle email verification based on settings (Forced off)
        if ( $is_new_user ) {
            $email_verify_enabled = false;

            if ( $email_verify_enabled ) {
                $activation_key = wp_generate_password( 20, false );
                update_user_meta( $user_id, 'ts_lms_activation_key', $activation_key );
                update_user_meta( $user_id, 'ts_lms_user_status', 'pending' );

                $verify_link = add_query_arg(
                    array(
                        'uid'   => $user_id,
                        'token' => $activation_key,
                    ),
                    home_url( '/ts-lms/auth/verify/' )
                );

                $subject = esc_html__( 'Verify your account', 'ts-lms' );
                $message = sprintf(
                    esc_html__( 'Hi %s,', 'ts-lms' ) . "\r\n\r\n" .
                    esc_html__( 'Thanks for registering as an instructor. Please click the link below to verify your account:', 'ts-lms' ) . "\r\n\r\n" .
                    '%s' . "\r\n\r\n" .
                    esc_html__( 'If you did not register, please ignore this email.', 'ts-lms' ),
                    $name,
                    $verify_link
                );

                // Log for debugging
                error_log( "TS LMS Instructor Verification Link for {$email}: " . $verify_link );

                wp_mail( $email, $subject, $message );

                $response_data = array(
                    'message'  => __( 'Your application has been submitted! Please check your email to verify your account.', 'ts-lms' ),
                    'redirect' => false,
                    'verification_required' => true
                );

                if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                    $response_data['debug_verify_link'] = $verify_link;
                }

                wp_send_json_success( $response_data );
                return;
            } else {
                // No verification required
                update_user_meta( $user_id, 'ts_lms_user_status', 'active' );
                
                // Auto-login the user
                wp_set_current_user( $user_id );
                wp_set_auth_cookie( $user_id, true );

                wp_send_json_success( array(
                    'message'  => __( 'Your application has been submitted successfully and is pending approval. Redirecting...', 'ts-lms' ),
                    'redirect' => home_url( '/dashboard/' ),
                    'verification_required' => false
                ) );
                return;
            }
        }

        wp_send_json_success( array(
            'message'  => __( 'Your application has been submitted successfully and is pending approval.', 'ts-lms' ),
            'redirect' => home_url( '/dashboard/' )
        ) );
    }
    
    /**
     * Save instructor application data.
     */
    private function save_instructor_application( $user_id, $data ) {
        $settings = \TS_LMS\Admin\Settings::get_settings();
        $auto_approve = isset( $settings['instructor_auto_approve'] ) && $settings['instructor_auto_approve'];
        
        // Set initial status
        $status = $auto_approve ? 'approved' : 'pending';
        
        update_user_meta( $user_id, 'ts_instructor_status', $status );
        update_user_meta( $user_id, 'ts_instructor_bio', $data['bio'] );
        update_user_meta( $user_id, 'ts_instructor_skills', $data['skills'] );
        update_user_meta( $user_id, 'ts_instructor_experience', $data['experience'] );
        update_user_meta( $user_id, 'ts_instructor_phone', $data['phone'] );
        update_user_meta( $user_id, 'ts_instructor_applied_date', current_time( 'mysql' ) );
        
        // If auto-approved, upgrade role immediately
        if ( $auto_approve ) {
            $user = new \WP_User( $user_id );
            $user->add_role( 'ts_instructor' );
            update_user_meta( $user_id, 'ts_instructor_approved_date', current_time( 'mysql' ) );
        }
    }
    
    /**
     * Approve instructor application.
     */
    public function approve_instructor() {
        check_ajax_referer( 'ts_lms_admin_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
        }
        
        $user_id = intval( $_POST['user_id'] ?? 0 );
        
        if ( ! $user_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid user ID.', 'ts-lms' ) ) );
        }
        
        // Update status
        update_user_meta( $user_id, 'ts_instructor_status', 'approved' );
        update_user_meta( $user_id, 'ts_instructor_approved_date', current_time( 'mysql' ) );
        
        // Add instructor role
        $user = new \WP_User( $user_id );
        $user->set_role( 'instructor' );

        // Double check instructor role caps
        self::create_instructor_role();
        
        // Send email notification
        $this->notify_instructor_approved( $user_id );
        
        wp_send_json_success( array( 'message' => __( 'Instructor approved successfully!', 'ts-lms' ) ) );
    }
    
    /**
     * Reject instructor application.
     */
    public function reject_instructor() {
        check_ajax_referer( 'ts_lms_admin_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
        }
        
        $user_id = intval( $_POST['user_id'] ?? 0 );
        $reason = sanitize_textarea_field( $_POST['reason'] ?? '' );
        
        if ( ! $user_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid user ID.', 'ts-lms' ) ) );
        }
        
        update_user_meta( $user_id, 'ts_instructor_status', 'rejected' );
        update_user_meta( $user_id, 'ts_instructor_rejection_reason', $reason );
        
        // Send email notification
        $this->notify_instructor_rejected( $user_id, $reason );
        
        wp_send_json_success( array( 'message' => __( 'Instructor application rejected.', 'ts-lms' ) ) );
    }
    
    /**
     * Suspend instructor.
     */
    public function suspend_instructor() {
        check_ajax_referer( 'ts_lms_admin_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
        }
        
        $user_id = intval( $_POST['user_id'] ?? 0 );
        
        if ( ! $user_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid user ID.', 'ts-lms' ) ) );
        }
        
        update_user_meta( $user_id, 'ts_instructor_status', 'suspended' );
        
        // Remove instructor role but keep student role
        $user = new \WP_User( $user_id );
        $user->set_role( 'subscriber' );
        
        wp_send_json_success( array( 'message' => __( 'Instructor suspended.', 'ts-lms' ) ) );
    }
    
    /**
     * Check if user is approved instructor.
     */
    public static function is_approved_instructor( $user_id = null ) {
        if ( ! $user_id ) {
            $user_id = get_current_user_id();
        }
        
        $status = get_user_meta( $user_id, 'ts_instructor_status', true );
        return $status === 'approved' && user_can( $user_id, 'instructor' );
    }
    
    /**
     * Get instructor status.
     */
    public static function get_instructor_status( $user_id ) {
        return get_user_meta( $user_id, 'ts_instructor_status', true );
    }

    /**
     * Check if instructor registration limit is reached.
     *
     * @return bool
     */
    public static function is_limit_reached() {
        $limit = intval( \TS_LMS\Admin\Settings::get_setting( 'instructor_registration_limit' ) );
        if ( $limit <= 0 ) {
            return false;
        }

        $instructor_count = count( get_users( array( 
            'meta_key'   => 'ts_instructor_status', 
            'meta_value' => 'approved',
            'fields'     => 'ID'
        ) ) );

        return $instructor_count >= $limit;
    }

    private function notify_admin_new_application( $user_id ) {
        if ( ! ts_lms_is_notification_enabled( 'new_instructor', 'email', 'admin' ) ) {
            return;
        }

        $user = get_userdata( $user_id );
        $admin_email = get_option( 'admin_email' );
        
        $subject = sprintf( __( 'New Instructor Application - %s', 'ts-lms' ), get_bloginfo( 'name' ) );
        $message = sprintf(
            __( 'A new instructor application has been submitted by %s (%s). Please review and approve/reject from the admin panel.', 'ts-lms' ),
            $user->display_name,
            $user->user_email
        );
        
        wp_mail( $admin_email, $subject, $message );
    }
    
    private function notify_instructor_approved( $user_id ) {
        if ( ! ts_lms_is_notification_enabled( 'inst_app_accepted', 'email', 'instructor' ) ) {
            return;
        }

        $user = get_userdata( $user_id );
        
        $subject = sprintf( __( 'Your Instructor Application Approved - %s', 'ts-lms' ), get_bloginfo( 'name' ) );
        $message = sprintf(
            __( 'Congratulations %s! Your instructor application has been approved. You can now start creating courses.', 'ts-lms' ),
            $user->display_name
        );
        
        wp_mail( $user->user_email, $subject, $message );
    }
    
    private function notify_instructor_rejected( $user_id, $reason ) {
        if ( ! ts_lms_is_notification_enabled( 'inst_app_rejected', 'email', 'instructor' ) ) {
            return;
        }

        $user = get_userdata( $user_id );
        
        $subject = sprintf( __( 'Your Instructor Application Status - %s', 'ts-lms' ), get_bloginfo( 'name' ) );
        $message = sprintf(
            __( 'Dear %s, Unfortunately, your instructor application has been rejected. Reason: %s', 'ts-lms' ),
            $user->display_name,
            $reason
        );
        
        wp_mail( $user->user_email, $subject, $message );
    }
}
