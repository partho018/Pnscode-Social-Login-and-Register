<?php
namespace TS_LMS\Modules\Auth;

/**
 * Social Auth Handler
 */
class SocialAuth {

    /**
     * Get instance.
     */
    public static function instance() {
        static $instance = null;
        if ( is_null( $instance ) ) {
            $instance = new self();
        }
        return $instance;
    }

    /**
     * Handle social login requests.
     */
    public function handle_request( $provider ) {
        $settings = \TS_LMS\Admin\Settings::get_settings();
        
        if ( ! isset( $settings["enable_{$provider}_login"] ) || ! $settings["enable_{$provider}_login"] ) {
            wp_die( esc_html__( 'Social login for this provider is currently disabled.', 'ts-lms' ) );
        }

        $app_id = isset( $settings["{$provider}_app_id"] ) ? $settings["{$provider}_app_id"] : '';
        $app_secret = isset( $settings["{$provider}_app_secret"] ) ? $settings["{$provider}_app_secret"] : '';

        if ( empty( $app_id ) || empty( $app_secret ) ) {
            wp_die( esc_html__( 'Social login is not properly configured. Please contact administrator.', 'ts-lms' ) );
        }

        $callback_url = $this->get_callback_url( $provider );
        $state = wp_create_nonce( 'ts_social_auth_' . $provider );
        set_transient( 'ts_social_state_' . $state, 1, 10 * MINUTE_IN_SECONDS );

        if ( $provider === 'google' ) {
            $auth_url = 'https://accounts.google.com/o/oauth2/v2/auth';
            $params = array(
                'client_id'     => $app_id,
                'redirect_uri'  => $callback_url,
                'phrase'        => 'select_account',
                'response_type' => 'code',
                'scope'         => 'email profile openid',
                'state'         => $state,
                'access_type'   => 'online',
                'prompt'        => 'select_account'
            );

            wp_redirect( add_query_arg( $params, $auth_url ) );
            exit;
        } elseif ( $provider === 'facebook' ) {
            $auth_url = 'https://www.facebook.com/v12.0/dialog/oauth';
            $params = array(
                'client_id'     => $app_id,
                'redirect_uri'  => $callback_url,
                'state'         => $state,
                'scope'         => 'email,public_profile',
                'response_type' => 'code'
            );

            wp_redirect( add_query_arg( $params, $auth_url ) );
            exit;
        } elseif ( $provider === 'github' ) {
            $auth_url = 'https://github.com/login/oauth/authorize';
            $params = array(
                'client_id'    => $app_id,
                'redirect_uri' => $callback_url,
                'state'        => $state,
                'scope'        => 'user:email'
            );

            wp_redirect( add_query_arg( $params, $auth_url ) );
            exit;
        }

        wp_die( esc_html__( 'Provider not implemented yet.', 'ts-lms' ) );
    }

    /**
     * Handle social callback.
     */
    public function handle_callback( $provider ) {
        if ( ! isset( $_GET['code'] ) || ! isset( $_GET['state'] ) ) {
            wp_redirect( home_url( '/login/?login=failed&error=invalid_social_response' ) );
            exit;
        }

        $state = sanitize_text_field( $_GET['state'] );
        if ( ! get_transient( 'ts_social_state_' . $state ) ) {
            wp_redirect( home_url( '/login/?login=failed&error=invalid_state' ) );
            exit;
        }
        delete_transient( 'ts_social_state_' . $state );

        $settings = \TS_LMS\Admin\Settings::get_settings();
        $app_id = isset( $settings["{$provider}_app_id"] ) ? $settings["{$provider}_app_id"] : '';
        $app_secret = isset( $settings["{$provider}_app_secret"] ) ? $settings["{$provider}_app_secret"] : '';

        $user_data = array();

        if ( $provider === 'google' ) {
            $token_url = 'https://oauth2.googleapis.com/token';
            $response = wp_remote_post( $token_url, array(
                'body' => array(
                    'client_id'     => $app_id,
                    'client_secret' => $app_secret,
                    'code'          => sanitize_text_field( $_GET['code'] ),
                    'redirect_uri'  => $this->get_callback_url( $provider ),
                    'grant_type'    => 'authorization_code',
                ),
            ) );

            if ( is_wp_error( $response ) ) {
                wp_die( $response->get_error_message() );
            }

            $body = json_decode( wp_remote_retrieve_body( $response ), true );
            
            if ( ! isset( $body['access_token'] ) ) {
                wp_redirect( home_url( '/login/?login=failed&error=token_error' ) );
                exit;
            }

            $access_token = $body['access_token'];

            // Get user info
            $info_url = 'https://www.googleapis.com/oauth2/v3/userinfo';
            $info_response = wp_remote_get( add_query_arg( 'access_token', $access_token, $info_url ) );

            if ( is_wp_error( $info_response ) ) {
                wp_die( $info_response->get_error_message() );
            }

            $user_info = json_decode( wp_remote_retrieve_body( $info_response ), true );

            if ( ! isset( $user_info['email'] ) ) {
                 wp_redirect( home_url( '/login/?login=failed&error=user_info_error' ) );
                 exit;
            }

            $user_data = array(
                'email' => $user_info['email'],
                'name'  => isset( $user_info['name'] ) ? $user_info['name'] : $user_info['email'],
                'id'    => $user_info['sub'],
            );
        } elseif ( $provider === 'facebook' ) {
            $token_url = 'https://graph.facebook.com/v12.0/oauth/access_token';
            $response = wp_remote_get( add_query_arg( array(
                'client_id'     => $app_id,
                'client_secret' => $app_secret,
                'redirect_uri'  => $this->get_callback_url( $provider ),
                'code'          => sanitize_text_field( $_GET['code'] ),
            ), $token_url ) );

            if ( is_wp_error( $response ) ) {
                wp_die( $response->get_error_message() );
            }

            $body = json_decode( wp_remote_retrieve_body( $response ), true );
            
            if ( ! isset( $body['access_token'] ) ) {
                wp_redirect( home_url( '/login/?login=failed&error=token_error' ) );
                exit;
            }

            $access_token = $body['access_token'];

            // Get user info
            $info_url = 'https://graph.facebook.com/me';
            $info_response = wp_remote_get( add_query_arg( array(
                'fields'       => 'id,name,email',
                'access_token' => $access_token,
            ), $info_url ) );

            if ( is_wp_error( $info_response ) ) {
                wp_die( $info_response->get_error_message() );
            }

            $user_info = json_decode( wp_remote_retrieve_body( $info_response ), true );

            if ( ! isset( $user_info['email'] ) ) {
                 wp_redirect( home_url( '/login/?login=failed&error=user_info_error' ) );
                 exit;
            }

            $user_data = array(
                'email' => $user_info['email'],
                'name'  => isset( $user_info['name'] ) ? $user_info['name'] : $user_info['email'],
                'id'    => $user_info['id'],
            );
        } elseif ( $provider === 'github' ) {
            $token_url = 'https://github.com/login/oauth/access_token';
            $response = wp_remote_post( $token_url, array(
                'headers' => array(
                    'Accept' => 'application/json',
                ),
                'body' => array(
                    'client_id'     => $app_id,
                    'client_secret' => $app_secret,
                    'code'          => sanitize_text_field( $_GET['code'] ),
                    'redirect_uri'  => $this->get_callback_url( $provider ),
                ),
            ) );

            if ( is_wp_error( $response ) ) {
                wp_die( $response->get_error_message() );
            }

            $body = json_decode( wp_remote_retrieve_body( $response ), true );
            
            if ( ! isset( $body['access_token'] ) ) {
                wp_redirect( home_url( '/login/?login=failed&error=token_error' ) );
                exit;
            }

            $access_token = $body['access_token'];

            // Get user info
            $info_url = 'https://api.github.com/user';
            $info_response = wp_remote_get( $info_url, array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                    'User-Agent'    => 'TS-LMS',
                ),
            ) );

            if ( is_wp_error( $info_response ) ) {
                wp_die( $info_response->get_error_message() );
            }

            $user_info = json_decode( wp_remote_retrieve_body( $info_response ), true );

            // GitHub might not return email if it's private, we might need to fetch it
            if ( empty( $user_info['email'] ) ) {
                $emails_url = 'https://api.github.com/user/emails';
                $emails_response = wp_remote_get( $emails_url, array(
                    'headers' => array(
                        'Authorization' => 'Bearer ' . $access_token,
                        'User-Agent'    => 'TS-LMS',
                    ),
                ) );
                
                if ( ! is_wp_error( $emails_response ) ) {
                    $emails = json_decode( wp_remote_retrieve_body( $emails_response ), true );
                    if ( is_array( $emails ) ) {
                        foreach ( $emails as $email ) {
                            if ( $email['primary'] ) {
                                $user_info['email'] = $email['email'];
                                break;
                            }
                        }
                    }
                }
            }

            if ( ! isset( $user_info['email'] ) ) {
                 wp_redirect( home_url( '/login/?login=failed&error=user_info_error' ) );
                 exit;
            }

            $user_data = array(
                'email' => $user_info['email'],
                'name'  => ! empty( $user_info['name'] ) ? $user_info['name'] : $user_info['login'],
                'id'    => $user_info['id'],
            );
        }

        if ( ! empty( $user_data ) ) {
            $user = $this->get_or_create_user( $user_data['email'], $user_data['name'], $provider, $user_data['id'] );
            
            if ( is_wp_error( $user ) ) {
                wp_die( $user->get_error_message() );
            }

            wp_set_current_user( $user->ID );
            wp_set_auth_cookie( $user->ID, true );

            $login_redirect = \TS_LMS\Admin\Settings::get_setting( 'login_redirect_url', '/dashboard/' );
            $redirect_url = home_url( $login_redirect );
            wp_redirect( $redirect_url );
            exit;
        }

        wp_redirect( home_url( '/login/?login=failed' ) );
        exit;
    }

    /**
     * Get callback URL.
     */
    public function get_callback_url( $provider ) {
        if ( get_option( 'permalink_structure' ) ) {
            return home_url( '/ts-lms/auth/' . $provider . '/callback' );
        }
        return add_query_arg( 'ts_lms_auth_callback', $provider, home_url( '/' ) );
    }

    /**
     * Get or create user from social data.
     */
    private function get_or_create_user( $email, $name, $provider, $social_id ) {
        $user = get_user_by( 'email', $email );
        
        if ( ! $user ) {
            $username = strtolower( str_replace( ' ', '', $name ) ) . rand( 100, 999 );
            $password = wp_generate_password();
            $user_id = wp_create_user( $username, $password, $email );
            
            if ( is_wp_error( $user_id ) ) {
                return $user_id;
            }
            
            $user = get_user_by( 'id', $user_id );
            
            // Set student role
            $user->set_role( 'student' );

            wp_update_user( array(
                'ID'           => $user_id,
                'display_name' => $name,
                'nickname'     => $name,
                'first_name'   => $name,
            ) );
        }
        
        // Store social ID for mapping
        update_user_meta( $user->ID, "ts_lms_{$provider}_id", $social_id );
        
        // Mark as active since social providers verify email
        update_user_meta( $user->ID, 'ts_lms_user_status', 'active' );
        
        return $user;
    }
}
