<?php
namespace TS_LMS\Modules\Auth\Admin;

/**
 * Instructor Applications Admin Page
 */
class InstructorApplications {

    public static function render() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $action = isset( $_GET['action'] ) ? $_GET['action'] : 'list';
        $user_id = isset( $_GET['user_id'] ) ? intval( $_GET['user_id'] ) : 0;

        if ( $action === 'view' && $user_id ) {
            self::render_view_application( $user_id );
        } else {
            self::render_list();
        }
    }

    private static function render_list() {
        $args = array(
            'meta_key'     => 'ts_instructor_status',
            'meta_value'   => 'pending',
            'meta_compare' => '=',
        );
        $pending_users = get_users( $args );

        $all_instructors = get_users( array( 'role' => 'instructor' ) );
        ?>
        <div class="wrap ts-lms-redesign-wrap">
            <div class="ts-lms-redesign-header">
                <div class="ts-lms-redesign-title">
                    <h1>
                        <span class="main-title"><?php _e( 'Instructors', 'ts-lms' ); ?></span>
                        <span class="separator">/</span>
                        <span class="sub-title"><?php _e( 'Applications', 'ts-lms' ); ?></span>
                    </h1>
                </div>
            </div>

            <div class="ts-lms-redesign-content">
                <div class="ts-lms-stats-grid">
                    <div class="ts-lms-premium-card">
                        <div class="ts-lms-stat-box">
                            <div class="ts-lms-stat-icon"><span class="dashicons dashicons-clock"></span></div>
                            <div class="ts-lms-stat-info">
                                <h3><?php echo count( $pending_users ); ?></h3>
                                <p><?php _e( 'Pending Applications', 'ts-lms' ); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="ts-lms-premium-card">
                        <div class="ts-lms-stat-box">
                            <div class="ts-lms-stat-icon"><span class="dashicons dashicons-businessman"></span></div>
                            <div class="ts-lms-stat-info">
                                <h3><?php echo count( $all_instructors ); ?></h3>
                                <p><?php _e( 'Total Instructors', 'ts-lms' ); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="ts-lms-premium-card">
                    <h2 class="card-title"><?php _e( 'Pending Applications', 'ts-lms' ); ?></h2>
                    <table class="ts-lms-modern-table">
                        <thead>
                            <tr>
                                <th><?php _e( 'Name', 'ts-lms' ); ?></th>
                                <th><?php _e( 'Email', 'ts-lms' ); ?></th>
                                <th><?php _e( 'Applied Date', 'ts-lms' ); ?></th>
                                <th><?php _e( 'Actions', 'ts-lms' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ( $pending_users ) : ?>
                                <?php foreach ( $pending_users as $user ) : ?>
                                    <tr>
                                        <td><strong><?php echo esc_html( $user->display_name ); ?></strong></td>
                                        <td><?php echo esc_html( $user->user_email ); ?></td>
                                        <td><?php echo esc_html( get_user_meta( $user->ID, 'ts_instructor_applied_date', true ) ); ?></td>
                                        <td>
                                            <a href="?page=ts-lms-instructors&action=view&user_id=<?php echo $user->ID; ?>" class="button button-small">
                                                <?php _e( 'View Details', 'ts-lms' ); ?>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="4" style="text-align:center; padding: 40px;">
                                        <?php _e( 'No pending applications found.', 'ts-lms' ); ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    private static function render_view_application( $user_id ) {
        $user = get_userdata( $user_id );
        if ( ! $user ) return;

        $meta = get_user_meta( $user_id );
        $skills = isset( $meta['ts_instructor_skills'][0] ) ? $meta['ts_instructor_skills'][0] : '';
        $bio = isset( $meta['ts_instructor_bio'][0] ) ? $meta['ts_instructor_bio'][0] : '';
        $experience = isset( $meta['ts_instructor_experience'][0] ) ? $meta['ts_instructor_experience'][0] : '';
        $portfolio = isset( $meta['ts_instructor_portfolio'][0] ) ? $meta['ts_instructor_portfolio'][0] : '';
        $motivation = isset( $meta['ts_instructor_motivation'][0] ) ? $meta['ts_instructor_motivation'][0] : '';
        $phone = isset( $meta['ts_instructor_phone'][0] ) ? $meta['ts_instructor_phone'][0] : '';
        $photo_id = isset( $meta['ts_instructor_photo_id'][0] ) ? $meta['ts_instructor_photo_id'][0] : 0;
        ?>
        <div class="wrap ts-lms-redesign-wrap">
            <div class="ts-lms-redesign-header">
                <div class="ts-lms-redesign-title">
                    <h1>
                        <a href="?page=ts-lms-instructors" class="back-link"><span class="dashicons dashicons-arrow-left-alt2"></span></a>
                        <span class="main-title"><?php _e( 'Application Details', 'ts-lms' ); ?></span>
                        <span class="separator">/</span>
                        <span class="sub-title"><?php echo esc_html( $user->display_name ); ?></span>
                    </h1>
                </div>
            </div>

            <div class="ts-lms-redesign-content">
                <div class="ts-lms-premium-card application-details-card">
                    <div class="app-header">
                        <div class="app-avatar">
                            <?php if ( $photo_id ) : ?>
                                <?php echo wp_get_attachment_image( $photo_id, 'thumbnail' ); ?>
                            <?php else : ?>
                                <?php echo get_avatar( $user_id, 100 ); ?>
                            <?php endif; ?>
                        </div>
                        <div class="app-title-info">
                            <h2><?php echo esc_html( $user->display_name ); ?></h2>
                            <p class="app-email"><?php echo esc_html( $user->user_email ); ?></p>
                            <p class="app-phone"><?php echo esc_html( $phone ); ?></p>
                        </div>
                        <div class="app-actions">
                            <button class="button button-primary approve-btn" data-user-id="<?php echo $user_id; ?>"><?php _e( 'Approve', 'ts-lms' ); ?></button>
                            <button class="button button-secondary reject-btn" data-user-id="<?php echo $user_id; ?>"><?php _e( 'Reject', 'ts-lms' ); ?></button>
                        </div>
                    </div>

                    <div class="app-body">
                        <div class="info-group">
                            label><?php _e( 'Expertise / Skills', 'ts-lms' ); ?></label>
                            <p><?php echo esc_html( $skills ); ?></p>
                        </div>
                        <div class="info-group">
                            <label><?php _e( 'Bio', 'ts-lms' ); ?></label>
                            <p><?php echo nl2br( esc_html( $bio ) ); ?></p>
                        </div>
                        <div class="info-group">
                            <label><?php _e( 'Teaching Experience', 'ts-lms' ); ?></label>
                            <p><?php echo nl2br( esc_html( $experience ) ); ?></p>
                        </div>
                        <div class="info-group">
                            <label><?php _e( 'Portfolio / Website', 'ts-lms' ); ?></label>
                            <p><a href="<?php echo esc_url( $portfolio ); ?>" target="_blank"><?php echo esc_html( $portfolio ); ?></a></p>
                        </div>
                        <div class="info-group">
                            <label><?php _e( 'Motivation', 'ts-lms' ); ?></label>
                            <p><?php echo nl2br( esc_html( $motivation ) ); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <style>
        .application-details-card {
            max-width: 800px;
            margin: 0 auto;
        }
        .app-header {
            display: flex;
            align-items: center;
            gap: 30px;
            margin-bottom: 30px;
            border-bottom: 1px solid #eee;
            padding-bottom: 30px;
        }
        .app-avatar img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
        }
        .app-title-info h2 {
            margin: 0 0 10px;
            font-size: 24px;
        }
        .app-email, .app-phone {
            margin: 0;
            color: #666;
        }
        .app-actions {
            margin-left: auto;
            display: flex;
            gap: 10px;
        }
        .info-group {
            margin-bottom: 25px;
        }
        .info-group label {
            display: block;
            font-weight: 600;
            font-size: 14px;
            color: #999;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        .info-group p {
            margin: 0;
            font-size: 16px;
            line-height: 1.6;
        }
        .back-link {
            text-decoration: none;
            color: inherit;
            margin-right: 15px;
        }
        </style>

        <script>
        jQuery(document).ready(function($) {
            $('.approve-btn').on('click', function() {
                if ( ! confirm('Are you sure you want to approve this instructor?') ) return;
                
                const userId = $(this).data('user-id');
                const btn = $(this);
                
                $.post(ajaxurl, {
                    action: 'ts_lms_approve_instructor',
                    user_id: userId,
                    nonce: '<?php echo wp_create_nonce("ts_lms_admin_nonce"); ?>'
                }, function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        window.location.href = '?page=ts-lms-instructors';
                    } else {
                        alert(response.data.message);
                    }
                });
            });

            $('.reject-btn').on('click', function() {
                const reason = prompt('Reason for rejection (optional):');
                if ( reason === null ) return;
                
                const userId = $(this).data('user-id');
                
                $.post(ajaxurl, {
                    action: 'ts_lms_reject_instructor',
                    user_id: userId,
                    reason: reason,
                    nonce: '<?php echo wp_create_nonce("ts_lms_admin_nonce"); ?>'
                }, function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        window.location.href = '?page=ts-lms-instructors';
                    } else {
                        alert(response.data.message);
                    }
                });
            });
        });
        </script>
        <?php
    }
}
