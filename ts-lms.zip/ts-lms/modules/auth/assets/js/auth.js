jQuery(document).ready(function($) {
    /**
     * AJAX Auth System
     */
    
    let tempUserId = 0;
    let tempRemember = false;

    // Login Handler
    $(document).on('submit', '#ts-lms-login-form', function(e) {
        e.preventDefault();

        const $form = $(this);
        const $submitBtn = $form.find('#ts-lms-login-submit');
        const $message = $('#ts-lms-auth-message');

        // Clear previous messages
        $message.removeClass('success error').html('').hide();

        // Loading state
        const originalBtnText = $submitBtn.text();
        $submitBtn.text('Signing in...').prop('disabled', true);

        // Gather data
        const urlParams = new URLSearchParams(window.location.search);
        const formData = {
            action: 'ts_lms_login',
            nonce: ts_lms_auth.nonce,
            username: $form.find('input[name="username"]').val(),
            password: $form.find('input[name="password"]').val(),
            remember: $form.find('input[name="remember"]').is(':checked'),
            redirect_to: urlParams.get('redirect_to') || $form.find('input[name="redirect_to"]').val() || ''
        };
        
        $.ajax({
            url: ts_lms_auth.ajax_url,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    if (response.data['2fa_required']) {
                        // Switch to 2FA view
                        tempUserId = response.data.user_id;
                        tempRemember = response.data.remember;
                        
                        $('#ts-login-fields').fadeOut(200, function() {
                            $('#ts-2fa-fields').fadeIn(200);
                            $message.addClass('success').html(response.data.message).show();
                        });
                        
                        $submitBtn.text(originalBtnText).prop('disabled', false);
                    } else {
                        $message.addClass('success').html(response.data.message).show();
                        setTimeout(function() {
                            const redirectUrl = urlParams.get('redirect_to') || response.data.redirect || ts_lms_auth.redirect;
                            window.location.href = redirectUrl;
                        }, 1500);
                    }
                } else {
                    const errorMsg = (response.data && response.data.message) ? response.data.message : 'Invalid credentials. Please try again.';
                    $message.addClass('error').html(errorMsg).show();
                    $submitBtn.text(originalBtnText).prop('disabled', false);
                }
            },
            error: function(xhr) {
                let errorMsg = 'An error occurred. Please try again.';
                if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    errorMsg = xhr.responseJSON.data.message;
                }
                $message.addClass('error').html(errorMsg).show();
                $submitBtn.text(originalBtnText).prop('disabled', false);
            }
        });
    });

    // 2FA Submit Handler
    $(document).on('click', '#ts-lms-2fa-submit', function() {
        const $btn = $(this);
        const $message = $('#ts-lms-auth-message');
        const code = $('#login-2fa').val();

        if (!code) {
            $message.addClass('error').html('Please enter the verification code.').show();
            return;
        }

        const originalBtnText = $btn.text();
        $btn.text('Verifying...').prop('disabled', true);
        $message.removeClass('success error').hide();

        $.ajax({
            url: ts_lms_auth.ajax_url,
            type: 'POST',
            data: {
                action: 'ts_lms_verify_2fa',
                nonce: ts_lms_auth.nonce,
                user_id: tempUserId,
                code: code,
                remember: tempRemember
            },
            success: function(response) {
                if (response.success) {
                    $message.addClass('success').html(response.data.message).show();
                    setTimeout(function() {
                        window.location.href = response.data.redirect || ts_lms_auth.redirect;
                    }, 1500);
                } else {
                    $message.addClass('error').html(response.data.message).show();
                    $btn.text(originalBtnText).prop('disabled', false);
                }
            },
            error: function() {
                $message.addClass('error').html('An error occurred. Please try again.').show();
                $btn.text(originalBtnText).prop('disabled', false);
            }
        });
    });

    // 2FA Back Handler
    $(document).on('click', '#ts-lms-2fa-back', function() {
        $('#ts-2fa-fields').fadeOut(200, function() {
            $('#ts-login-fields').fadeIn(200);
            $('#ts-lms-auth-message').hide();
        });
    });

    // Toggle Instructor Fields
    $(document).on('change', '#apply_as_instructor', function() {
        if ($(this).is(':checked')) {
            $('.instructor-fields').slideDown(300);
        } else {
            $('.instructor-fields').slideUp(300);
        }
    });

    // Register Handler
    $(document).on('submit', '#ts-lms-register-form', function(e) {
        e.preventDefault();

        const $form = $(this);
        const $submitBtn = $form.find('button[type="submit"]');
        const $message = $('#ts-lms-auth-message');

        // Clear previous messages
        $message.removeClass('success error').html('').hide();

        // Loading state
        const originalBtnText = $submitBtn.text();
        $submitBtn.text('Creating account...').prop('disabled', true);

        // Check if applying as instructor
        const applyAsInstructor = $('#apply_as_instructor').is(':checked');
        
        // Gather data
        const formData = {
            action: applyAsInstructor ? 'ts_lms_instructor_register' : 'ts_lms_register',
            nonce: ts_lms_auth.nonce,
            full_name: $form.find('input[name="full_name"]').val(),
            email: $form.find('input[name="email"]').val(),
            phone: $form.find('input[name="phone"]').val(),
            password: $form.find('input[name="password"]').val(),
            apply_as_instructor: applyAsInstructor
        };
        
        // Add instructor fields if applying
        if (applyAsInstructor) {
            formData.bio = $form.find('textarea[name="bio"]').val();
            formData.skills = $form.find('input[name="skills"]').val();
            formData.experience = $form.find('input[name="experience"]').val();
        }

        $.ajax({
            url: ts_lms_auth.ajax_url,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    $message.addClass('success').html(response.data.message).show();
                    
                    if (response.data.verification_required) {
                        $submitBtn.text('Sent').prop('disabled', true);
                    } else {
                        setTimeout(function() {
                            window.location.href = response.data.redirect || ts_lms_auth.redirect;
                        }, 1500);
                    }
                } else {
                    $message.addClass('error').html(response.data.message).show();
                    $submitBtn.text(originalBtnText).prop('disabled', false);
                }
            },
            error: function() {
                $message.addClass('error').html('An error occurred. Please try again.').show();
                $submitBtn.text(originalBtnText).prop('disabled', false);
            }
        });
    });

    // Social Login Buttons
    $(document).on('click', '.ts-social-btn', function() {
        const provider = $(this).attr('title').toLowerCase();
        const ajaxUrl = ts_lms_auth.ajax_url.replace('admin-ajax.php', '');
        window.location.href = window.location.origin + window.location.pathname + '?ts-lms-auth-login=' + provider;
    });

    /**
     * Modal Toggle Logic
     */
    $(document).on('click', '.ts-trigger-auth-modal', function(e) {
        e.preventDefault();
        $('#ts-lms-auth-modal').addClass('active');
        $('body').css('overflow', 'hidden'); // Prevent scrolling
    });

    $(document).on('click', '#ts-auth-modal-close, .ts-modal-overlay', function(e) {
        if (e.target !== this) return;
        $('#ts-lms-auth-modal').removeClass('active');
        $('body').css('overflow', '');
    });
});
