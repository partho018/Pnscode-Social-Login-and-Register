/**
 * Student Dashboard JavaScript
 * Handles interactive features for the student dashboard
 */

(function($) {
    'use strict';

    // Course Filter functionality
    function initCourseFilters() {
        const filterButtons = document.querySelectorAll('.ts-filter-btn');
        const courseCards = document.querySelectorAll('.ts-enrolled-course-card');

        if (filterButtons.length === 0 || courseCards.length === 0) return;

        filterButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const filter = this.getAttribute('data-filter');

                // Update active button
                filterButtons.forEach(function(btn) {
                    btn.classList.remove('active');
                });
                this.classList.add('active');

                // Filter courses
                courseCards.forEach(function(card) {
                    const status = card.getAttribute('data-status');
                    
                    if (filter === 'all') {
                        card.style.display = '';
                    } else if (status === filter) {
                        card.style.display = '';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }

    // Smooth section transitions
    function initSectionTransitions() {
        const navItems = document.querySelectorAll('.ts-nav-item[data-section]');
        
        if (navItems.length === 0) return;

        navItems.forEach(function(item) {
            item.addEventListener('click', function(e) {
                // Optional: Add loading animation
                const content = document.getElementById('ts-dashboard-main-content');
                if (content) {
                    content.style.opacity = '0.5';
                    setTimeout(function() {
                        content.style.opacity = '1';
                    }, 100);
                }
            });
        });
    }

    // Progress bar animations
    function animateProgressBars() {
        const progressBars = document.querySelectorAll('.ts-progress-fill');
        
        if (progressBars.length === 0) return;

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    const progressBar = entry.target;
                    const width = progressBar.style.width;
                    progressBar.style.width = '0%';
                    
                    setTimeout(function() {
                        progressBar.style.width = width;
                    }, 100);
                    
                    observer.unobserve(progressBar);
                }
            });
        }, {
            threshold: 0.1
        });

        progressBars.forEach(function(bar) {
            observer.observe(bar);
        });
    }

    // Stat cards counter animation
    function animateStatCards() {
        const statNumbers = document.querySelectorAll('.ts-stat-number');
        
        if (statNumbers.length === 0) return;

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    const statNumber = entry.target;
                    const targetValue = parseInt(statNumber.textContent);
                    
                    if (isNaN(targetValue)) return;
                    
                    let currentValue = 0;
                    const increment = Math.ceil(targetValue / 30);
                    const duration = 1000;
                    const stepTime = duration / (targetValue / increment);
                    
                    const counter = setInterval(function() {
                        currentValue += increment;
                        if (currentValue >= targetValue) {
                            statNumber.textContent = targetValue;
                            clearInterval(counter);
                        } else {
                            statNumber.textContent = currentValue;
                        }
                    }, stepTime);
                    
                    observer.unobserve(statNumber);
                }
            });
        }, {
            threshold: 0.1
        });

        statNumbers.forEach(function(number) {
            observer.observe(number);
        });
    }

    // Wishlist remove confirmation
    function initWishlistConfirmation() {
        const removeForms = document.querySelectorAll('form:has(button[name="remove_from_wishlist"])');
        
        removeForms.forEach(function(form) {
            form.addEventListener('submit', function(e) {
                if (!confirm('Are you sure you want to remove this course from your wishlist?')) {
                    e.preventDefault();
                }
            });
        });
    }

    // Auto-hide notices after 5 seconds
    function initNoticeAutohide() {
        const notices = document.querySelectorAll('.ts-notice');
        
        notices.forEach(function(notice) {
            setTimeout(function() {
                notice.style.opacity = '0';
                notice.style.transform = 'translateY(-10px)';
                notice.style.transition = 'all 0.3s ease';
                
                setTimeout(function() {
                    notice.style.display = 'none';
                }, 300);
            }, 5000);
        });
    }

    // Initialize all functions when DOM is ready
    $(document).ready(function() {
        initCourseFilters();
        initSectionTransitions();
        animateProgressBars();
        animateStatCards();
        initWishlistConfirmation();
        initNoticeAutohide();

        // Add smooth scroll behavior
        document.documentElement.style.scrollBehavior = 'smooth';
    });

})(jQuery);
