<?php
/**
 * Auth Module
 *
 * Main module class that bootstraps the Auth module.
 *
 * @package TS_LMS\Modules\Auth
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Auth;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Module class.
 */
class Module {

    /**
     * Module version.
     *
     * @var string
     */
    const VERSION = '1.0.0';

    /**
     * Singleton instance.
     *
     * @var Module
     */
    private static $instance = null;

    /**
     * Get singleton instance.
     *
     * @return Module
     */
    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->init();
    }

    /**
     * Initialize the module.
     *
     * @return void
     */
    private function init() {
        // Enqueue assets
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        
        // Extend session duration
        add_filter( 'auth_cookie_expiration', array( $this, 'extend_login_session' ), 10, 3 );

        // Register shortcodes
        add_shortcode( 'ts_lms_login', array( $this, 'login_shortcode' ) );
        add_shortcode( 'ts_lms_register', array( $this, 'register_shortcode' ) );
        add_shortcode( 'ts_lms_dashboard', array( $this, 'dashboard_shortcode' ) );
        add_shortcode( 'ts_instructor_registration', array( $this, 'instructor_reg_shortcode' ) );

        // Auth handlers
        add_action( 'wp_ajax_ts_lms_login', array( $this, 'handle_login' ) );
        add_action( 'wp_ajax_nopriv_ts_lms_login', array( $this, 'handle_login' ) );
        add_action( 'wp_ajax_ts_lms_register', array( $this, 'handle_register' ) );
        add_action( 'wp_ajax_nopriv_ts_lms_register', array( $this, 'handle_register' ) );

        // 2FA Handlers
        add_action( 'wp_ajax_ts_lms_verify_2fa', array( $this, 'handle_verify_2fa' ) );
        add_action( 'wp_ajax_nopriv_ts_lms_verify_2fa', array( $this, 'handle_verify_2fa' ) );

        // Overrides & Redirects
        add_action( 'init', array( $this, 'redirect_login_page' ) );
        add_action( 'wp_logout', array( $this, 'clear_sessions_on_logout' ) );
        add_action( 'wp_login_failed', array( $this, 'handle_login_failed' ) );
        add_filter( 'login_url', array( $this, 'custom_login_url' ), 10, 3 );
        add_filter( 'register_url', array( $this, 'custom_register_url' ), 10, 1 );

        // Social Login Callbacks & Rewrite Rules
        add_action( 'template_redirect', array( $this, 'handle_social_callbacks' ) );
        add_action( 'init', array( $this, 'add_rewrite_rules' ) );
        add_filter( 'query_vars', array( $this, 'add_query_vars' ) );
        add_action( 'template_redirect', array( $this, 'handle_email_verification' ) );
        
        // Hide Admin Bar for non-admins
        add_filter( 'show_admin_bar', array( $this, 'hide_admin_bar_for_non_admins' ) );

        // Flush rules on activation
        register_activation_hook( TS_LMS_PLUGIN_DIR . 'ts-lms.php', array( $this, 'flush_rules' ) );

        add_filter( 'body_class', array( $this, 'add_auth_body_class' ) );

        // Print modal in footer
        add_action( 'wp_footer', array( $this, 'print_login_modal' ) );
        
        // Initialize Instructor Manager
        if ( file_exists( plugin_dir_path( __FILE__ ) . 'includes/InstructorManager.php' ) ) {
            require_once plugin_dir_path( __FILE__ ) . 'includes/InstructorManager.php';
            InstructorManager::instance();
        }

        // Flush rules once for verification endpoint
        add_action( 'init', array( $this, 'maybe_flush_rules' ), 20 );
    }

    /**
     * Maybe flush rewrite rules if needed.
     */
    public function maybe_flush_rules() {
        if ( ! get_option( 'ts_lms_rules_flushed_verify' ) ) {
            flush_rewrite_rules();
            update_option( 'ts_lms_rules_flushed_verify', true );
        }
    }

    /**
     * Print login modal in footer.
     */
    public function print_login_modal() {
        if ( is_user_logged_in() ) {
            return;
        }
        include plugin_dir_path( __FILE__ ) . 'templates/login-modal.php';
    }

    /**
     * Add custom body class for auth pages.
     */
    public function add_auth_body_class( $classes ) {
        $login_page_id = \TS_LMS\Admin\Settings::get_setting( 'login_page' );
        $reg_page_id = \TS_LMS\Admin\Settings::get_setting( 'student_reg_page' );

        if ( is_page( $login_page_id ) || is_page( $reg_page_id ) ) {
            $classes[] = 'ts-auth-page';
        }

        return $classes;
    }

    /**
     * Add custom rewrite rules for social auth.
     */
    public function add_rewrite_rules() {
        add_rewrite_rule( '^ts-lms/auth/([^/]+)/callback/?$', 'index.php?ts_lms_auth_callback=$matches[1]', 'top' );
        add_rewrite_rule( '^ts-lms/auth/verify/?$', 'index.php?ts_lms_action=verify_email', 'top' );
    }

    /**
     * Add custom query vars.
     */
    public function add_query_vars( $vars ) {
        $vars[] = 'ts_lms_auth_callback';
        $vars[] = 'ts_lms_action';
        $vars[] = 'token';
        $vars[] = 'uid';
        return $vars;
    }

    /**
     * Redirect wp-login.php to our custom login page.
     */
    public function redirect_login_page() {
        global $pagenow;
        
        $settings = \TS_LMS\Admin\Settings::get_settings();
        $is_enabled = isset( $settings['enable_custom_login'] ) ? (bool)$settings['enable_custom_login'] : true;

        if ( ! $is_enabled ) {
            return;
        }

        $login_url = $this->get_custom_login_url();
        $register_url = $this->get_custom_register_url();

        if ( $pagenow == "wp-login.php" ) {
            $action = isset( $_REQUEST['action'] ) ? $_REQUEST['action'] : 'login';
            
            if ( $action == 'login' ) {
                wp_redirect( $login_url );
                exit;
            } elseif ( $action == 'register' ) {
                wp_redirect( $register_url );
                exit;
            }
        }
    }

    /**
     * Handle failed logins.
     */
    public function handle_login_failed() {
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
            return;
        }
        $referrer = wp_get_referer();
        if ( $referrer && ! strpos( $referrer, 'wp-login.php' ) ) {
            wp_redirect( add_query_arg( 'login', 'failed', $referrer ) );
            exit;
        }
    }

    /**
     * Filter the standard login URL.
     */
    public function custom_login_url( $login_url, $redirect, $force_reauth ) {
        return $this->get_custom_login_url( $redirect );
    }

    /**
     * Filter the registration URL.
     */
    public function custom_register_url( $register_url ) {
        return $this->get_custom_register_url();
    }

    /**
     * Extend login session to 1 year regardless of remember me setting.
     */
    public function extend_login_session( $seconds, $user_id, $remember ) {
        return 365 * DAY_IN_SECONDS;
    }

    /**
     * Get the custom login page URL.
     */
    private function get_custom_login_url( $redirect = '' ) {
        $login_page_id = \TS_LMS\Admin\Settings::get_setting( 'login_page' );
        $url = $login_page_id ? get_permalink( $login_page_id ) : home_url( '/login/' );

        if ( ! empty( $redirect ) ) {
            $url = add_query_arg( 'redirect_to', urlencode( $redirect ), $url );
        }

        return $url;
    }

    /**
     * Get the custom register page URL.
     */
    private function get_custom_register_url() {
        $reg_page_id = \TS_LMS\Admin\Settings::get_setting( 'student_reg_page' );
        return $reg_page_id ? get_permalink( $reg_page_id ) : home_url( '/register/' );
    }

    /**
     * Enqueue assets.
     */
    public function enqueue_assets() {
        wp_enqueue_style(
            'ts-lms-auth',
            plugin_dir_url( __FILE__ ) . 'assets/css/auth.css',
            array( 'dashicons' ),
            self::VERSION
        );

        wp_enqueue_script(
            'ts-lms-auth',
            plugin_dir_url( __FILE__ ) . 'assets/js/auth.js',
            array( 'jquery' ),
            self::VERSION,
            true
        );

        // Enqueue dashboard styles and scripts on dashboard page
        $dashboard_page_id = \TS_LMS\Admin\Settings::get_setting( 'dashboard_page' );
        if ( is_page( $dashboard_page_id ) || is_user_logged_in() ) {
            wp_enqueue_style(
                'ts-lms-dashboard',
                plugin_dir_url( __FILE__ ) . 'assets/css/dashboard.css',
                array( 'dashicons', 'ts-lms-auth' ),
                self::VERSION
            );

            wp_enqueue_script(
                'ts-lms-dashboard',
                plugin_dir_url( __FILE__ ) . 'assets/js/dashboard.js',
                array( 'jquery' ),
                self::VERSION,
                true
            );
        }

        $settings = \TS_LMS\Admin\Settings::get_settings();
        $login_redirect = isset( $settings['login_redirect_url'] ) ? $settings['login_redirect_url'] : '/dashboard/';

        wp_localize_script( 'ts-lms-auth', 'ts_lms_auth', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'ts_lms_auth_nonce' ),
            'redirect' => home_url( $login_redirect ),
        ) );
    }

    /**
     * Login shortcode.
     */
    public function login_shortcode() {
        if ( is_user_logged_in() ) {
            return '<script>window.location.href="' . home_url( '/dashboard/' ) . '";</script>';
        }
        ob_start();
        include plugin_dir_path( __FILE__ ) . 'templates/login.php';
        return ob_get_clean();
    }

    /**
     * Register shortcode.
     */
    public function register_shortcode() {
        if ( is_user_logged_in() ) {
            return '<script>window.location.href="' . home_url( '/dashboard/' ) . '";</script>';
        }
        ob_start();
        include plugin_dir_path( __FILE__ ) . 'templates/register.php';
        return ob_get_clean();
    }

    /**
     * Dashboard shortcode.
     */
    public function dashboard_shortcode() {
        if ( ! is_user_logged_in() ) {
            return '<script>window.location.href="' . $this->get_custom_login_url( get_permalink() ) . '";</script>';
        }
        ob_start();
        include plugin_dir_path( __FILE__ ) . 'templates/dashboard.php';
        return ob_get_clean();
    }

    /**
     * Instructor Registration shortcode.
     */
    public function instructor_reg_shortcode() {
        if ( is_user_logged_in() && current_user_can( 'instructor' ) ) {
            return '<p>' . esc_html__( 'You are already registered as an instructor.', 'ts-lms' ) . '</p>';
        }
        ob_start();
        include plugin_dir_path( __FILE__ ) . 'templates/instructor-registration.php';
        return ob_get_clean();
    }

    /**
     * Clear all sessions on logout.
     */
    public function clear_sessions_on_logout( $user_id = 0 ) {
        if ( ! $user_id ) {
            $user_id = get_current_user_id();
        }
        
        if ( $user_id ) {
            $manager = \WP_Session_Tokens::get_instance( $user_id );
            $manager->destroy_all();
            
            // Unset cookie manually just in case
            unset($_COOKIE[AUTH_COOKIE]);
            unset($_COOKIE[SECURE_AUTH_COOKIE]);
            setcookie(AUTH_COOKIE, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
            setcookie(SECURE_AUTH_COOKIE, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
        }
    }

    /**
     * Handle login form submission.
     */
    public function handle_login() {
        // Clear any previous output to ensure a clean JSON response
        if ( ob_get_level() ) {
            ob_clean();
        }
        
        // Verify Security Nonce
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'ts_lms_auth_nonce' ) ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Security check failed. Please refresh the page.', 'ts-lms' ) ) );
        }

        $username = sanitize_text_field( $_POST['username'] ?? '' );
        $password = $_POST['password'] ?? '';
        
        // Check for 'true', '1', or just presence if implied
        $remember = isset( $_POST['remember'] ) && ( $_POST['remember'] === 'true' || $_POST['remember'] === '1' );

        if ( empty( $username ) || empty( $password ) ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Username and password are required.', 'ts-lms' ) ) );
        }

        // 1. Authenticate credentials
        $user_obj = wp_authenticate( $username, $password );

        if ( is_wp_error( $user_obj ) ) {
            wp_send_json_error( array( 'message' => $user_obj->get_error_message() ) );
        }

        $settings = \TS_LMS\Admin\Settings::get_settings();
        $email_verify_enabled = isset( $settings['enable_email_verification'] ) && $settings['enable_email_verification'];
        
        $user_status = get_user_meta( $user_obj->ID, 'ts_lms_user_status', true );
        if ( $email_verify_enabled && $user_status === 'pending' ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Please verify your email address to log in.', 'ts-lms' ) ) );
        }

        // 1.5 Check for 2FA
        $enable_2fa = isset( $settings['enable_2fa'] ) && $settings['enable_2fa'];
        if ( $enable_2fa ) {
            $code = rand( 100000, 999999 );
            update_user_meta( $user_obj->ID, 'ts_lms_2fa_code', $code );
            update_user_meta( $user_obj->ID, 'ts_lms_2fa_expiry', time() + 600 ); // 10 minutes

            // Send Email using NotificationHandler
            if ( class_exists( '\TS_LMS\Setup\NotificationHandler' ) ) {
                 do_action( 'ts_lms_send_2fa_email', $user_obj->ID, $code );
            } else {
                $subject = __( 'Your Verification Code', 'ts-lms' );
                $message = sprintf( __( 'Your login verification code is: %s', 'ts-lms' ), $code );
                wp_mail( $user_obj->user_email, $subject, $message );
            }

            wp_send_json_success( array(
                'message'      => esc_html__( 'Confirmation code sent to your email.', 'ts-lms' ),
                '2fa_required' => true,
                'user_id'      => $user_obj->ID,
                'remember'     => $remember
            ) );
        }

        // 2. Session Limit Rule: Check for maximum concurrent sessions (Except Admins)
        $limit_enabled = isset( $settings['limit_active_sessions'] ) ? (bool)$settings['limit_active_sessions'] : true;
        $max_sessions = isset( $settings['max_active_sessions'] ) ? absint( $settings['max_active_sessions'] ) : 1;

        if ( $limit_enabled && ! in_array( 'administrator', (array) $user_obj->roles ) ) {
            $manager = \WP_Session_Tokens::get_instance( $user_obj->ID );
            $sessions = $manager->get_all();
            
            if ( count( $sessions ) >= $max_sessions ) {
                wp_send_json_error( array( 
                    'message' => sprintf(
                        esc_html__( 'Maximum login limit reached. You can only be logged in on %d device(s) at a time. Please log out from another device first.', 'ts-lms' ),
                        $max_sessions
                    )
                ) );
            }
        }

        // 3. Perform the Sign-on
        $creds = array(
            'user_login'    => $user_obj->user_login,
            'user_password' => $password,
            'remember'      => true, // Always remember
        );

        $user = wp_signon( $creds, is_ssl() );

        if ( is_wp_error( $user ) ) {
            wp_send_json_error( array( 'message' => $user->get_error_message() ) );
        }

        // Trigger wp_login action for hooks
        do_action( 'wp_login', $user->user_login, $user );

        $redirect = home_url( \TS_LMS\Admin\Settings::get_setting( 'login_redirect_url', '/dashboard/' ) );
        if ( ! empty( $_POST['redirect_to'] ) ) {
            $redirect = wp_validate_redirect( $_POST['redirect_to'], $redirect );
        }

        wp_send_json_success( array( 
            'message'  => esc_html__( 'Login successful! Redirecting...', 'ts-lms' ),
            'redirect' => $redirect
        ) );
    }

    /**
     * Handle 2FA Verification.
     */
    public function handle_verify_2fa() {
        check_ajax_referer( 'ts_lms_auth_nonce', 'nonce' );

        $user_id = absint( $_POST['user_id'] ?? 0 );
        $code    = sanitize_text_field( $_POST['code'] ?? '' );
        $remember = isset( $_POST['remember'] ) && $_POST['remember'] === 'true';

        if ( ! $user_id || ! $code ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Invalid request.', 'ts-lms' ) ) );
        }

        $stored_code = (string)get_user_meta( $user_id, 'ts_lms_2fa_code', true );
        $expiry      = get_user_meta( $user_id, 'ts_lms_2fa_expiry', true );

        if ( time() > $expiry ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Verification code expired.', 'ts-lms' ) ) );
        }

        if ( $stored_code !== $code ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Invalid verification code.', 'ts-lms' ) ) );
        }

        // Code is valid
        $user = get_userdata( $user_id );
        $settings = \TS_LMS\Admin\Settings::get_settings();
        $limit_enabled = isset( $settings['limit_active_sessions'] ) ? (bool)$settings['limit_active_sessions'] : true;
        $max_sessions = isset( $settings['max_active_sessions'] ) ? absint( $settings['max_active_sessions'] ) : 1;

        if ( $limit_enabled && ! in_array( 'administrator', (array) $user->roles ) ) {
            $manager = \WP_Session_Tokens::get_instance( $user_id );
            $sessions = $manager->get_all();
            
            if ( count( $sessions ) >= $max_sessions ) {
                wp_send_json_error( array( 
                    'message' => sprintf(
                        esc_html__( 'Maximum login limit reached. You can only be logged in on %d device(s) at a time. Please log out from another device first.', 'ts-lms' ),
                        $max_sessions
                    )
                ) );
            }
        }

        delete_user_meta( $user_id, 'ts_lms_2fa_code' );
        delete_user_meta( $user_id, 'ts_lms_2fa_expiry' );

        $user = get_userdata( $user_id );
        wp_set_current_user( $user_id );
        wp_set_auth_cookie( $user_id, $remember );
        do_action( 'wp_login', $user->user_login, $user );

        $redirect = home_url( \TS_LMS\Admin\Settings::get_setting( 'login_redirect_url', '/dashboard/' ) );
        wp_send_json_success( array(
            'message'  => esc_html__( 'Login successful! Redirecting...', 'ts-lms' ),
            'redirect' => $redirect
        ) );
    }

    public function handle_register() {
        check_ajax_referer( 'ts_lms_auth_nonce', 'nonce' );

        $name     = sanitize_text_field( $_POST['full_name'] ?? '' );
        $email    = sanitize_email( $_POST['email'] ?? '' );
        $phone    = sanitize_text_field( $_POST['phone'] ?? '' );
        $password = $_POST['password'] ?? '';

        $settings = \TS_LMS\Admin\Settings::get_settings();
        $phone_req = isset( $settings['reg_phone_field'] ) && $settings['reg_phone_field'] === 'required';

        if ( empty( $name ) || empty( $email ) || empty( $password ) ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Please fill all required fields.', 'ts-lms' ) ) );
        }

        if ( $phone_req && empty( $phone ) ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Phone number is required.', 'ts-lms' ) ) );
        }

        if ( ! is_email( $email ) ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Invalid email address.', 'ts-lms' ) ) );
        }

        if ( email_exists( $email ) ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Email already registered.', 'ts-lms' ) ) );
        }

        $user_id = wp_create_user( $email, $password, $email );

        if ( is_wp_error( $user_id ) ) {
            wp_send_json_error( array( 'message' => $user_id->get_error_message() ) );
        }

        // Update user meta and set role to student
        wp_update_user( array(
            'ID'           => $user_id,
            'display_name' => $name,
            'first_name'   => $name,
            'role'         => 'student',
        ) );

        if ( ! empty( $phone ) ) {
            update_user_meta( $user_id, 'ts_lms_phone', $phone );
        }

        // Check if email verification is enabled
        $email_verify_enabled = isset( $settings['enable_email_verification'] ) && $settings['enable_email_verification'];

        if ( $email_verify_enabled ) {
            // Send Verification Email
            $activation_key = wp_generate_password( 20, false );
            update_user_meta( $user_id, 'ts_lms_activation_key', $activation_key );
            update_user_meta( $user_id, 'ts_lms_user_status', 'pending' );

            $verify_link = add_query_arg(
                array(
                    'uid'   => $user_id,
                    'token' => $activation_key,
                ),
                home_url( '/ts-lms/auth/verify/' )
            );

            $subject = esc_html__( 'Verify your account', 'ts-lms' );
            $message = sprintf(
                esc_html__( 'Hi %s,', 'ts-lms' ) . "\r\n\r\n" .
                esc_html__( 'Thanks for registering. Please click the link below to verify your account:', 'ts-lms' ) . "\r\n\r\n" .
                '%s' . "\r\n\r\n" .
                esc_html__( 'If you did not register, please ignore this email.', 'ts-lms' ),
                $name,
                $verify_link
            );

            // Log for debugging (helpful on localhost)
            error_log( "TS LMS Verification Link for {$email}: " . $verify_link );

            wp_mail( $email, $subject, $message );

            $response_data = array( 
                'message'  => esc_html__( 'Registration successful! Please check your email to verify your account.', 'ts-lms' ),
                'redirect' => false,
                'verification_required' => true
            );

            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                $response_data['debug_verify_link'] = $verify_link;
            }
        } else {
            // No verification required
            update_user_meta( $user_id, 'ts_lms_user_status', 'active' );

            // Auto-login the user
            wp_set_current_user( $user_id );
            wp_set_auth_cookie( $user_id, true );

            $redirect = home_url( \TS_LMS\Admin\Settings::get_setting( 'reg_redirect_url', '/dashboard/' ) );
            if ( ! empty( $_POST['redirect_to'] ) ) {
                $redirect = wp_validate_redirect( $_POST['redirect_to'], $redirect );
            }

            $response_data = array( 
                'message'  => esc_html__( 'Registration successful! Redirecting...', 'ts-lms' ),
                'redirect' => $redirect,
                'verification_required' => false
            );
        }

        wp_send_json_success( $response_data );
    }

    /**
     * Handle social login callbacks.
     */
    public function handle_social_callbacks() {
        $provider_callback = get_query_var( 'ts_lms_auth_callback' );
        
        if ( ! isset( $_GET['ts-lms-auth-login'] ) && ! $provider_callback ) {
            return;
        }

        $social_auth = \TS_LMS\Modules\Auth\SocialAuth::instance();

        if ( isset( $_GET['ts-lms-auth-login'] ) ) {
            $provider = sanitize_text_field( $_GET['ts-lms-auth-login'] );
            $social_auth->handle_request( $provider );
        }

        if ( $provider_callback ) {
            $social_auth->handle_callback( $provider_callback );
        }
    }

    /**
     * Flush rewrite rules.
     */
    public function flush_rules() {
        $this->add_rewrite_rules();
        flush_rewrite_rules();
    }

    /**
     * Handle email verification.
     */
    public function handle_email_verification() {
        if ( get_query_var( 'ts_lms_action' ) !== 'verify_email' ) {
            return;
        }

        $user_id = absint( get_query_var( 'uid' ) );
        $token   = get_query_var( 'token' );

        if ( empty( $user_id ) || empty( $token ) ) {
            wp_die( esc_html__( 'Invalid verification link.', 'ts-lms' ) );
        }

        $stored_token = get_user_meta( $user_id, 'ts_lms_activation_key', true );
        $user_status  = get_user_meta( $user_id, 'ts_lms_user_status', true );

        if ( $user_status !== 'pending' && ! empty( $stored_token ) ) {
             // Already verified?
             wp_redirect( home_url( '/login/?message=already_verified' ) );
             exit;
        }

        if ( $stored_token === $token ) {
            delete_user_meta( $user_id, 'ts_lms_activation_key' );
            update_user_meta( $user_id, 'ts_lms_user_status', 'active' );

            // Auto login
            wp_set_current_user( $user_id );
            wp_set_auth_cookie( $user_id, true );

            $dashboard = \TS_LMS\Admin\Settings::get_setting( 'dashboard_page' );
            $url = $dashboard ? get_permalink( $dashboard ) : home_url( '/dashboard/' );
            
            wp_redirect( $url );
            exit;
        } else {
            wp_die( esc_html__( 'Invalid or expired verification token.', 'ts-lms' ) );
        }
    }

    /**
     * Install the module.
     */
    public static function install() {
        $pages = array(
            'login_page' => array(
                'title'   => 'Login',
                'content' => '[ts_lms_login]',
            ),
            'student_reg_page' => array(
                'title'   => 'Register',
                'content' => '[ts_lms_register]',
            ),
            'dashboard_page' => array(
                'title'   => 'Dashboard',
                'content' => '[ts_lms_dashboard]',
            ),
        );

        $settings = \TS_LMS\Admin\Settings::get_settings();
        $updated = false;

        foreach ( $pages as $key => $page ) {
            // Check if page already exists in settings
            if ( ! empty( $settings[$key] ) ) {
                $post = get_post( $settings[$key] );
                if ( $post && $post->post_status !== 'trash' ) {
                    continue;
                }
            }

            // Create page
            $page_id = wp_insert_post( array(
                'post_title'   => $page['title'],
                'post_content' => $page['content'],
                'post_status'  => 'publish',
                'post_type'    => 'page',
            ) );

            if ( ! is_wp_error( $page_id ) ) {
                $settings[$key] = $page_id;
                $updated = true;
            }
        }

        // Set default settings
        if ( ! isset( $settings['limit_active_sessions'] ) ) {
            $settings['limit_active_sessions'] = 1;
            $updated = true;
        }

        if ( $updated ) {
            update_option( 'ts_lms_settings', $settings );
        }
        
        // Create instructor role - RE-ENABLED with minimal capabilities
        if ( file_exists( plugin_dir_path( __FILE__ ) . 'includes/InstructorManager.php' ) ) {
            require_once plugin_dir_path( __FILE__ ) . 'includes/InstructorManager.php';
            InstructorManager::create_instructor_role();
        }
    }

    /**
     * Hide admin bar for non-administrators.
     */
    public function hide_admin_bar_for_non_admins( $show ) {
        if ( ! current_user_can( 'administrator' ) ) {
            return false;
        }
        return $show;
    }
}

