<?php
/**
 * Elementor Integration Module
 *
 * Main module class that bootstraps the Elementor integration.
 *
 * @package TS_LMS\Modules\Elementor
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Elementor;

use TS_LMS\Modules\Elementor\Widgets\Course_Card_Wrapper;
use TS_LMS\Modules\Elementor\Widgets\Course_Media;
use TS_LMS\Modules\Elementor\Widgets\Course_Meta;
use TS_LMS\Modules\Elementor\Widgets\Course_Content;
use TS_LMS\Modules\Elementor\Widgets\Course_Action;
use TS_LMS\Modules\Elementor\Widgets\Course_About;
use TS_LMS\Modules\Elementor\Widgets\Course_Title;
use TS_LMS\Modules\Elementor\Widgets\Course_Rating;
use TS_LMS\Modules\Elementor\Widgets\Course_Price;
use TS_LMS\Modules\Elementor\Widgets\Course_Author;
use TS_LMS\Modules\Elementor\Widgets\Course_Level;
use TS_LMS\Modules\Elementor\Widgets\Course_Categories;
use TS_LMS\Modules\Elementor\Widgets\Course_Duration;
use TS_LMS\Modules\Elementor\Widgets\Course_Total_Enrolled;
use TS_LMS\Modules\Elementor\Widgets\Course_Last_Update;
use TS_LMS\Modules\Elementor\Widgets\Course_Status;
use TS_LMS\Modules\Elementor\Widgets\Course_Thumbnail;
use TS_LMS\Modules\Elementor\Widgets\Course_Social_Share;
use TS_LMS\Modules\Elementor\Widgets\Course_Wishlist;
use TS_LMS\Modules\Elementor\Widgets\Course_Purchase;
use TS_LMS\Modules\Elementor\Widgets\Course_Materials;
use TS_LMS\Modules\Elementor\Widgets\Course_Requirements;
use TS_LMS\Modules\Elementor\Widgets\Course_Tags;
use TS_LMS\Modules\Elementor\Widgets\Course_Target_Audience;
use TS_LMS\Modules\Elementor\Widgets\Course_Description;
use TS_LMS\Modules\Elementor\Widgets\Course_Benefits;
use TS_LMS\Modules\Elementor\Widgets\Course_Curriculum;
use TS_LMS\Modules\Elementor\Widgets\Course_Instructors;
use TS_LMS\Modules\Elementor\Widgets\Course_Reviews;
use TS_LMS\Modules\Elementor\Widgets\Course_Carousel;
use TS_LMS\Modules\Elementor\Widgets\Course_List;
use TS_LMS\Modules\Elementor\Widgets\Course_Enrolment_Box;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Module class.
 */
class Module {

    /**
     * Module version.
     *
     * @var string
     */
    const VERSION = '1.0.0';

    /**
     * Singleton instance.
     *
     * @var Module
     */
    private static $instance = null;

    /**
     * Get singleton instance.
     *
     * @return Module
     */
    public static function instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->init();
    }

    /**
     * Initialize the module.
     *
     * @return void
     */
    private function init() {
        // Check if Elementor is active
        if ( ! did_action( 'elementor/loaded' ) ) {
            return;
        }

        // Register widget category
        add_action( 'elementor/elements/categories_registered', array( $this, 'register_widget_category' ) );

        // Register widgets
        add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );

        // Enqueue assets
        add_action( 'elementor/frontend/after_enqueue_styles', array( $this, 'enqueue_frontend_styles' ) );
        add_action( 'elementor/frontend/after_register_scripts', array( $this, 'enqueue_frontend_scripts' ) );
        
        // Enqueue editor assets
        add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'enqueue_editor_styles' ) );
    }

    /**
     * Register custom widget category.
     *
     * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager.
     * @return void
     */
    public function register_widget_category( $elements_manager ) {
        $elements_manager->add_category(
            '0-ts-lms',
            array(
                'title' => __( 'TS LMS', 'ts-lms' ),
                'icon'  => 'fa fa-graduation-cap',
            )
        );
    }

    /**
     * Register widgets.
     *
     * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
     * @return void
     */
    public function register_widgets( $widgets_manager ) {
        // Core Card Widgets
        $widgets_manager->register( new Course_Card_Wrapper() );
        $widgets_manager->register( new Course_Media() );
        $widgets_manager->register( new Course_Meta() );
        $widgets_manager->register( new Course_Content() );
        $widgets_manager->register( new Course_Action() );

        // Atomic Course Page Widgets
        $widgets_manager->register( new Course_Title() );
        $widgets_manager->register( new Course_Rating() );
        $widgets_manager->register( new Course_Price() );
        $widgets_manager->register( new Course_Author() );
        $widgets_manager->register( new Course_Level() );
        $widgets_manager->register( new Course_Categories() );
        $widgets_manager->register( new Course_Duration() );
        $widgets_manager->register( new Course_Total_Enrolled() );
        $widgets_manager->register( new Course_Last_Update() );
        $widgets_manager->register( new Course_Status() );
        $widgets_manager->register( new Course_Thumbnail() );
        $widgets_manager->register( new Course_Social_Share() );
        $widgets_manager->register( new Course_Wishlist() );
        $widgets_manager->register( new Course_Purchase() );
        
        // Content/Info Widgets
        // $widgets_manager->register( new Course_About() );
        // $widgets_manager->register( new Course_Description() );
        // $widgets_manager->register( new Course_Benefits() );
        $widgets_manager->register( new Course_Materials() );
        $widgets_manager->register( new Course_Requirements() );
        $widgets_manager->register( new Course_Tags() );
        $widgets_manager->register( new Course_Target_Audience() );
        
        // Complex Widgets
        // $widgets_manager->register( new Course_Curriculum() );
        $widgets_manager->register( new Course_Instructors() );
        // $widgets_manager->register( new Course_Reviews() );
        $widgets_manager->register( new Course_Enrolment_Box() );
        
        // Listing Widgets
        $widgets_manager->register( new Course_Carousel() );
        $widgets_manager->register( new Course_List() );
    }

    /**
     * Enqueue frontend styles.
     *
     * @return void
     */
    public function enqueue_frontend_styles() {
        wp_enqueue_style(
            'ts-lms-elementor-widgets',
            TS_LMS_PLUGIN_URL . 'modules/elementor/assets/css/elementor-widgets.css',
            array(),
            self::VERSION
        );
    }

    /**
     * Enqueue frontend scripts.
     *
     * @return void
     */
    public function enqueue_frontend_scripts() {
        wp_enqueue_script(
            'ts-lms-elementor-widgets',
            TS_LMS_PLUGIN_URL . 'modules/elementor/assets/js/elementor-widgets.js',
            array( 'jquery' ),
            self::VERSION,
            true
        );

        // Localize script for AJAX
        wp_localize_script( 'ts-lms-elementor-widgets', 'ts_lms_elementor', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'ts_lms_elementor_nonce' ),
        ) );
    }

    /**
     * Enqueue editor styles.
     *
     * @return void
     */
    public function enqueue_editor_styles() {
        wp_enqueue_style(
            'ts-lms-elementor-editor',
            TS_LMS_PLUGIN_URL . 'modules/elementor/assets/css/elementor-widgets.css',
            array(),
            self::VERSION
        );
    }

    /**
     * Get module version.
     *
     * @return string Module version.
     */
    public static function get_version() {
        return self::VERSION;
    }
}
