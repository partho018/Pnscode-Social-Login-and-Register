/**
 * TS LMS Elementor Widgets JavaScript
 *
 * @package TS_LMS\Modules\Elementor
 * @since 1.0.0
 */

(function($) {
    'use strict';

    /**
     * Initialize bookmark functionality
     */
    function initBookmarks() {
        $('.ts-bookmark-btn').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            var $btn = $(this);
            var $icon = $btn.find('.dashicons');
            
            // Toggle bookmark state
            if ($icon.hasClass('dashicons-heart')) {
                $icon.removeClass('dashicons-heart').addClass('dashicons-heart');
                $btn.addClass('bookmarked');
                
                // Here you can add AJAX call to save bookmark
                // $.post(ts_lms_elementor.ajax_url, {
                //     action: 'ts_lms_toggle_bookmark',
                //     nonce: ts_lms_elementor.nonce,
                //     course_id: $(this).data('course-id')
                // });
            } else {
                $icon.removeClass('dashicons-heart').addClass('dashicons-heart');
                $btn.removeClass('bookmarked');
            }
        });
    }

    /**
     * Initialize progress bar animations
     */
    function initProgressBars() {
        $('.ts-progress-bar').each(function() {
            var $bar = $(this);
            var width = $bar.attr('style').match(/width:\s*(\d+)/);
            
            if (width && width[1]) {
                $bar.css('width', '0%');
                setTimeout(function() {
                    $bar.css('width', width[1] + '%');
                }, 100);
            }
        });
    }

    /**
     * Initialize on document ready
     */
    $(document).ready(function() {
        initBookmarks();
        initProgressBars();
    });

    /**
     * Reinitialize on Elementor frontend (required for preview)
     */
    $(window).on('elementor/frontend/init', function() {
        if (typeof elementorFrontend !== 'undefined') {
            elementorFrontend.hooks.addAction('frontend/element_ready/widget', function($scope) {
                initBookmarks();
                initProgressBars();
            });
        }
    });

})(jQuery);
