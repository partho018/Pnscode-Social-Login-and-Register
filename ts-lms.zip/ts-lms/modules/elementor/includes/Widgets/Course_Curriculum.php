<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use TS_LMS\Modules\Courses\PostTypes\Topic;
use TS_LMS\Modules\Courses\PostTypes\Lesson;
use TS_LMS\Modules\Courses\PostTypes\Quiz;
use TS_LMS\Modules\Courses\PostTypes\Assignment;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Curriculum extends Base_Widget {

    public function get_name() {
        return 'ts-course-curriculum';
    }

    public function get_title() {
        return __( 'Course Curriculum', 'ts-lms' );
    }

    public function get_icon() {
        return 'eicon-accordion';
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'topic_bg',
            array(
                'label'     => __( 'Topic Background', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#f8fafc',
                'selectors' => array(
                    '{{WRAPPER}} .ts-curriculum-topic-header' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'topic_title_color',
            array(
                'label'     => __( 'Topic Title Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#1e293b',
                'selectors' => array(
                    '{{WRAPPER}} .ts-curriculum-topic-title' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'topic_typography',
                'label'    => __( 'Topic Typography', 'ts-lms' ),
                'selector' => '{{WRAPPER}} .ts-curriculum-topic-title',
            )
        );

        $this->add_control(
            'item_color',
            array(
                'label'     => __( 'Item Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#64748b',
                'selectors' => array(
                    '{{WRAPPER}} .ts-curriculum-item-title' => 'color: {{VALUE}};',
                ),
                'separator' => 'before',
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'item_typography',
                'label'    => __( 'Item Typography', 'ts-lms' ),
                'selector' => '{{WRAPPER}} .ts-curriculum-item-title',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;

        $topics = get_posts( array(
            'post_type'      => Topic::POST_TYPE,
            'posts_per_page' => -1,
            'post_parent'    => $course_id,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ) );

        if ( empty( $topics ) ) {
            echo '<p>' . esc_html__( 'No curriculum data available.', 'ts-lms' ) . '</p>';
            return;
        }

        ?>
        <div class="ts-curriculum-wrapper">
            <?php foreach ( $topics as $topic ) : 
                $items = get_posts( array(
                    'post_type'      => array( Lesson::POST_TYPE, Quiz::POST_TYPE, Assignment::POST_TYPE ),
                    'posts_per_page' => -1,
                    'post_parent'    => $topic->ID,
                    'orderby'        => 'menu_order',
                    'order'          => 'ASC',
                ) );
            ?>
                <div class="ts-curriculum-topic" style="border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 12px; overflow: hidden;">
                    <div class="ts-curriculum-topic-header" style="padding: 16px; cursor: pointer; display: flex; align-items: center; justify-content: space-between;">
                        <h4 class="ts-curriculum-topic-title" style="margin: 0; font-size: 16px; font-weight: 600;"><?php echo esc_html( $topic->post_title ); ?></h4>
                        <span class="ts-topic-count" style="font-size: 13px; opacity: 0.7;"><?php echo count($items); ?> <?php _e('Lessons', 'ts-lms'); ?></span>
                    </div>
                    <?php if ( ! empty( $items ) ) : ?>
                        <div class="ts-curriculum-items" style="border-top: 1px solid #e2e8f0; background: #fff;">
                            <?php foreach ( $items as $item ) : 
                                $icon = 'dashicons-media-document';
                                if ($item->post_type === Quiz::POST_TYPE) $icon = 'dashicons-forms';
                                if ($item->post_type === Assignment::POST_TYPE) $icon = 'dashicons-clipboard';
                                if ($item->post_type === Lesson::POST_TYPE) $icon = 'dashicons-video-alt3';

                                $is_enrolled = TS_LMS\Modules\Courses\Managers\CourseManager::is_enrolled( $course_id, get_current_user_id() );
                                $can_view = $is_enrolled || current_user_can('manage_options') || get_post_field('post_author', $course_id) == get_current_user_id();
                                $is_preview = get_post_meta($item->ID, '_lesson_preview', true);
                                $has_access = $can_view || $is_preview;
                            ?>
                                <div class="ts-curriculum-item" style="padding: 12px 16px; display: flex; align-items: center; gap: 12px; border-bottom: 1px solid #f1f5f9;">
                                    <span class="dashicons <?php echo esc_attr($icon); ?>" style="font-size: 18px; color: #94a3b8;"></span>
                                    
                                    <?php if ( $has_access ) : ?>
                                        <a href="<?php echo get_permalink($item->ID); ?>" class="ts-curriculum-item-title" style="font-size: 14px; flex: 1; text-decoration: none; color: inherit;"><?php echo esc_html($item->post_title); ?></a>
                                    <?php else : ?>
                                        <span class="ts-curriculum-item-title" style="font-size: 14px; flex: 1; opacity: 0.6; cursor: not-allowed;"><?php echo esc_html($item->post_title); ?></span>
                                        <span class="dashicons dashicons-lock" style="font-size: 14px; color: #94a3b8;"></span>
                                    <?php endif; ?>

                                    <?php if ( $is_preview && ! $can_view ) : ?>
                                        <span class="ts-badge" style="background: #dcfce7; color: #166534; font-size: 11px; padding: 2px 8px; border-radius: 999px;"><?php _e('Preview', 'ts-lms'); ?></span>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }
}
