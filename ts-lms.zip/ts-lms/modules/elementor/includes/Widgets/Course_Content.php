<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use TS_LMS\Modules\Courses\PostTypes\Topic;
use TS_LMS\Modules\Courses\PostTypes\Lesson;
use TS_LMS\Modules\Courses\PostTypes\Quiz;
use TS_LMS\Modules\Courses\PostTypes\Assignment;
use TS_LMS\Modules\Courses\Managers\CourseManager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Course Content Widget class.
 */
class Course_Content extends Base_Widget {

    public function get_name() {
        return 'ts-course-content';
    }

    public function get_title() {
        return __( 'Course Content', 'ts-lms' );
    }

    public function get_icon() {
        return 'eicon-post-content';
    }

    protected function register_controls() {
        // --- Content Controls ---
        $this->start_controls_section( 'section_content_settings', array( 'label' => __( 'Content Settings', 'ts-lms' ) ) );

        $this->add_control( 'show_about_course', array( 'label' => __( 'Show About Course', 'ts-lms' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
        $this->add_control( 'about_course_title_text', array( 'label' => __( 'About Title', 'ts-lms' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'About Course', 'ts-lms' ), 'condition' => array( 'show_about_course' => 'yes' ) ) );

        $this->add_control( 'show_course_benefits', array( 'label' => __( 'Show Benefits', 'ts-lms' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'separator' => 'before' ) );
        $this->add_control( 'course_benefits_title_text', array( 'label' => __( 'Benefits Title', 'ts-lms' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'What Will You Learn?', 'ts-lms' ), 'condition' => array( 'show_course_benefits' => 'yes' ) ) );

        $this->add_control( 'show_curriculum', array( 'label' => __( 'Show Curriculum', 'ts-lms' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'separator' => 'before' ) );
        $this->add_control( 'curriculum_title_text', array( 'label' => __( 'Curriculum Title', 'ts-lms' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Course Content', 'ts-lms' ), 'condition' => array( 'show_curriculum' => 'yes' ) ) );

        $this->add_control( 'show_reviews', array( 'label' => __( 'Show Reviews', 'ts-lms' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'separator' => 'before' ) );
        $this->add_control( 'reviews_title_text', array( 'label' => __( 'Reviews Title', 'ts-lms' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Reviews', 'ts-lms' ), 'condition' => array( 'show_reviews' => 'yes' ) ) );

        $this->end_controls_section();

        // ================= STYLE TABS =================

        // --- About Style ---
        $this->start_controls_section(
            'section_style_about',
            array(
                'label' => __( 'About Course Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => array( 'show_about_course' => 'yes' ),
            )
        );

        $this->add_control( 'heading_about_title', array( 'label' => __( 'About Course Title', 'ts-lms' ), 'type' => Controls_Manager::HEADING ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'about_title_typography', 'selector' => '{{WRAPPER}} .ts-about-course-section .ts-course-section-title' ) );
        $this->add_control( 'about_title_color', array( 'label' => __( 'Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-about-course-section .ts-course-section-title' => 'color: {{VALUE}};' ) ) );
        $this->add_responsive_control( 'about_title_margin', array( 'label' => __( 'Margin', 'ts-lms' ), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => array( 'px', 'em', '%' ), 'selectors' => array( '{{WRAPPER}} .ts-about-course-section .ts-course-section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ) ) );

        $this->add_control( 'heading_about_text', array( 'label' => __( 'About Course Text', 'ts-lms' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'about_text_typography', 'selector' => '{{WRAPPER}} .ts-course-description-content' ) );
        $this->add_control( 'about_text_color', array( 'label' => __( 'Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-course-description-content' => 'color: {{VALUE}};' ) ) );

        $this->end_controls_section();

        // --- Benefits Style ---
        $this->start_controls_section(
            'section_style_benefits',
            array(
                'label' => __( 'Course Benefits Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => array( 'show_course_benefits' => 'yes' ),
            )
        );

        $this->add_control( 'heading_benefit_title', array( 'label' => __( 'Course Benefit Title', 'ts-lms' ), 'type' => Controls_Manager::HEADING ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'benefit_title_typography', 'selector' => '{{WRAPPER}} .ts-course-benefits-section .ts-course-section-title' ) );
        $this->add_control( 'benefit_title_color', array( 'label' => __( 'Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-course-benefits-section .ts-course-section-title' => 'color: {{VALUE}};' ) ) );

        $this->add_control( 'heading_benefit_list', array( 'label' => __( 'Course Benefit List', 'ts-lms' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
        $this->add_responsive_control( 'benefit_list_gap', array( 'label' => __( 'Gap', 'ts-lms' ), 'type' => Controls_Manager::SLIDER, 'selectors' => array( '{{WRAPPER}} .ts-benefits-content ul' => 'gap: {{SIZE}}{{UNIT}}; display: flex; flex-direction: column;' ) ) );
        $this->add_control( 'benefit_list_bg', array( 'label' => __( 'Background', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-benefits-content' => 'background-color: {{VALUE}};' ) ) );
        $this->add_responsive_control( 'benefit_list_padding', array( 'label' => __( 'Padding', 'ts-lms' ), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => array( 'px', 'em', '%' ), 'selectors' => array( '{{WRAPPER}} .ts-benefits-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ) ) );

        $this->add_control( 'heading_benefit_icon', array( 'label' => __( 'Course Benefit Icon', 'ts-lms' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
        $this->add_control( 'benefit_icon_color', array( 'label' => __( 'Icon Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-benefits-content ul li i, {{WRAPPER}} .ts-benefits-content ul li svg, {{WRAPPER}} .ts-benefits-content ul li:before' => 'color: {{VALUE}};' ) ) );
        $this->add_control( 'benefit_icon_size', array( 'label' => __( 'Icon Size', 'ts-lms' ), 'type' => Controls_Manager::SLIDER, 'selectors' => array( '{{WRAPPER}} .ts-benefits-content ul li i, {{WRAPPER}} .ts-benefits-content ul li svg' => 'font-size: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ) ) );

        $this->add_control( 'heading_benefit_text', array( 'label' => __( 'Course Benefit Text', 'ts-lms' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'benefit_text_typography', 'selector' => '{{WRAPPER}} .ts-benefits-content ul li' ) );
        $this->add_control( 'benefit_text_color', array( 'label' => __( 'Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-benefits-content ul li' => 'color: {{VALUE}};' ) ) );

        $this->end_controls_section();

        // --- Curriculum Style ---
        $this->start_controls_section(
            'section_style_curriculum',
            array(
                'label' => __( 'Curriculum Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => array( 'show_curriculum' => 'yes' ),
            )
        );

        $this->add_control( 'heading_curriculum_header', array( 'label' => __( 'Curriculum Header', 'ts-lms' ), 'type' => Controls_Manager::HEADING ) );
        $this->add_control( 'curr_header_bg', array( 'label' => __( 'Background Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-curriculum-topic-header' => 'background-color: {{VALUE}};' ) ) );
        $this->add_responsive_control( 'curr_header_padding', array( 'label' => __( 'Padding', 'ts-lms' ), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => array( 'px', 'em', '%' ), 'selectors' => array( '{{WRAPPER}} .ts-curriculum-topic-header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ) ) );
        $this->add_responsive_control( 'curr_header_radius', array( 'label' => __( 'Border Radius', 'ts-lms' ), 'type' => Controls_Manager::DIMENSIONS, 'selectors' => array( '{{WRAPPER}} .ts-curriculum-topic-header' => 'border-top-left-radius: {{TOP}}{{UNIT}}; border-top-right-radius: {{RIGHT}}{{UNIT}}; border-bottom-right-radius: {{BOTTOM}}{{UNIT}}; border-bottom-left-radius: {{LEFT}}{{UNIT}};' ) ) );

        $this->add_control( 'heading_curriculum_topic', array( 'label' => __( 'Topic', 'ts-lms' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'curr_topic_typography', 'selector' => '{{WRAPPER}} .ts-curriculum-topic-title' ) );
        $this->add_control( 'curr_topic_color', array( 'label' => __( 'Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-curriculum-topic-title' => 'color: {{VALUE}};' ) ) );

        $this->add_control( 'heading_curriculum_lesson', array( 'label' => __( 'Lesson', 'ts-lms' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
        $this->add_control( 'curr_lesson_bg', array( 'label' => __( 'Background Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-curriculum-item' => 'background-color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'curr_lesson_typography', 'selector' => '{{WRAPPER}} .ts-curriculum-item-title' ) );
        $this->add_control( 'curr_lesson_color', array( 'label' => __( 'Text Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-curriculum-item-title' => 'color: {{VALUE}};' ) ) );
        $this->add_control( 'curr_lesson_icon_color', array( 'label' => __( 'Icon Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-curriculum-item .dashicons' => 'color: {{VALUE}};' ) ) );

        $this->add_control( 'heading_curriculum_spacing', array( 'label' => __( 'Spacing', 'ts-lms' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
        $this->add_responsive_control( 'curr_topic_spacing', array( 'label' => __( 'Topic Spacing', 'ts-lms' ), 'type' => Controls_Manager::SLIDER, 'selectors' => array( '{{WRAPPER}} .ts-curriculum-topic' => 'margin-bottom: {{SIZE}}{{UNIT}};' ) ) );

        $this->end_controls_section();

        // --- Reviews Style ---
        $this->start_controls_section(
            'section_style_reviews',
            array(
                'label' => __( 'Reviews Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => array( 'show_reviews' => 'yes' ),
            )
        );

        $this->add_control( 'heading_review_section_title', array( 'label' => __( 'Review Section Title', 'ts-lms' ), 'type' => Controls_Manager::HEADING ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'review_title_typography', 'selector' => '{{WRAPPER}} .ts-reviews-section .ts-course-section-title' ) );
        $this->add_control( 'review_title_color', array( 'label' => __( 'Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-reviews-section .ts-course-section-title' => 'color: {{VALUE}};' ) ) );

        $this->add_control( 'heading_review_avg', array( 'label' => __( 'Review Avg', 'ts-lms' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
        $this->add_control( 'review_avg_bg', array( 'label' => __( 'Background', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-review-avg-box' => 'background-color: {{VALUE}};' ) ) );
        $this->add_control( 'review_avg_text_color', array( 'label' => __( 'Text Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-review-avg-number' => 'color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'review_avg_typography', 'selector' => '{{WRAPPER}} .ts-review-avg-number' ) );

        $this->add_control( 'heading_right_rating_bar', array( 'label' => __( 'Right Rating Bar', 'ts-lms' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
        $this->add_control( 'rating_bar_bg', array( 'label' => __( 'Bar Background', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'default' => '#e2e8f0', 'selectors' => array( '{{WRAPPER}} .ts-bar-bg' => 'background-color: {{VALUE}};' ) ) );
        $this->add_control( 'rating_bar_fill', array( 'label' => __( 'Bar Fill Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'default' => '#fbbf24', 'selectors' => array( '{{WRAPPER}} .ts-bar-fill' => 'background-color: {{VALUE}};' ) ) );
        $this->add_control( 'rating_bar_height', array( 'label' => __( 'Height', 'ts-lms' ), 'type' => Controls_Manager::SLIDER, 'selectors' => array( '{{WRAPPER}} .ts-bar-bg' => 'height: {{SIZE}}{{UNIT}}; border-radius: {{SIZE}}{{UNIT}};' ) ) );

        $this->add_control( 'heading_review_list', array( 'label' => __( 'Review List', 'ts-lms' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ) );
        $this->add_control( 'review_item_bg', array( 'label' => __( 'Item Background', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-review-item' => 'background-color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'review_item_typography', 'selector' => '{{WRAPPER}} .ts-review-content' ) );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;

        $settings = $this->get_settings_for_display();
        $course_post = get_post( $course_id );

        // 1. About Course
        if ( $settings['show_about_course'] === 'yes' ) : ?>
            <div class="ts-course-section ts-about-course-section">
                <?php if ( ! empty( $settings['about_course_title_text'] ) ) : ?>
                    <h3 class="ts-course-section-title"><?php echo esc_html( $settings['about_course_title_text'] ); ?></h3>
                <?php endif; ?>
                <div class="ts-course-description-content">
                    <?php echo apply_filters( 'the_content', $course_post->post_content ); ?>
                </div>
            </div>
        <?php endif;

        // 2. Course Benefits
        $benefits = get_post_meta($course_id, '_what_will_learn', true);
        if ( $settings['show_course_benefits'] === 'yes' && ! empty( $benefits ) ) : ?>
            <div class="ts-course-section ts-course-benefits-section">
                <?php if ( ! empty( $settings['course_benefits_title_text'] ) ) : ?>
                    <h3 class="ts-course-section-title"><?php echo esc_html( $settings['course_benefits_title_text'] ); ?></h3>
                <?php endif; ?>
                <div class="ts-benefits-content">
                    <?php echo wp_kses_post( $benefits ); ?>
                </div>
            </div>
        <?php endif;

        // 3. Curriculum
        if ( $settings['show_curriculum'] === 'yes' ) : 
            $topics = get_posts( array(
                'post_type'      => Topic::POST_TYPE,
                'posts_per_page' => -1,
                'post_parent'    => $course_id,
                'orderby'        => 'menu_order',
                'order'          => 'ASC',
            ) );
            
            if ( ! empty( $topics ) ) : ?>
            <div class="ts-course-section ts-curriculum-section">
                <?php if ( ! empty( $settings['curriculum_title_text'] ) ) : ?>
                    <h3 class="ts-course-section-title"><?php echo esc_html( $settings['curriculum_title_text'] ); ?></h3>
                <?php endif; ?>
                
                <div class="ts-curriculum-wrapper">
                    <?php foreach ( $topics as $topic ) : 
                        $items = get_posts( array(
                            'post_type'      => array( Lesson::POST_TYPE, Quiz::POST_TYPE, Assignment::POST_TYPE ),
                            'posts_per_page' => -1,
                            'post_parent'    => $topic->ID,
                            'orderby'        => 'menu_order',
                            'order'          => 'ASC',
                        ) );
                    ?>
                        <div class="ts-curriculum-topic" style="border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 24px; overflow: hidden;">
                            <div class="ts-curriculum-topic-header" style="background: #f8fafc; padding: 16px; border-bottom: 1px solid #e2e8f0;">
                                <h4 class="ts-curriculum-topic-title" style="margin: 0; font-size: 16px; font-weight: 600; color: #1e293b;"><?php echo esc_html( $topic->post_title ); ?></h4>
                                <span class="ts-topic-count" style="font-size: 13px; opacity: 0.7; display: block; margin-top: 4px;"><?php echo count($items); ?> <?php esc_html_e('Lessons', 'ts-lms'); ?></span>
                            </div>
                            <?php if ( ! empty( $items ) ) : ?>
                                <div class="ts-curriculum-items" style="background: #fff;">
                                    <?php foreach ( $items as $item ) : 
                                        $icon = 'dashicons-media-document';
                                        if ($item->post_type === Quiz::POST_TYPE) $icon = 'dashicons-forms';
                                        if ($item->post_type === Assignment::POST_TYPE) $icon = 'dashicons-clipboard';
                                        if ($item->post_type === Lesson::POST_TYPE) $icon = 'dashicons-video-alt3';

                                        $can_view = current_user_can('manage_options') || CourseManager::is_enrolled( $course_id, get_current_user_id() );
                                        $is_preview = get_post_meta($item->ID, '_lesson_preview', true);
                                    ?>
                                        <div class="ts-curriculum-item" style="padding: 12px 16px; display: flex; align-items: center; gap: 12px; border-bottom: 1px solid #f1f5f9;">
                                            <span class="dashicons <?php echo esc_attr($icon); ?>" style="font-size: 18px; color: #94a3b8;"></span>
                                            <span class="ts-curriculum-item-title" style="font-size: 14px; flex: 1; color: #64748b;"><?php echo esc_html($item->post_title); ?></span>
                                            <?php if ( ! $can_view && ! $is_preview ) : ?>
                                                <span class="dashicons dashicons-lock" style="font-size: 14px; color: #94a3b8;"></span>
                                            <?php elseif ( $is_preview && ! $can_view ) : ?>
                                                <span class="ts-badge" style="background: #dcfce7; color: #166534; font-size: 11px; padding: 2px 8px; border-radius: 999px;"><?php esc_html_e('Preview', 'ts-lms'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif;
        endif;

        // 4. Reviews
        if ( $settings['show_reviews'] === 'yes' ) : 
            global $wpdb;
            // Handle table existence check or just assume it exists since plugin is active
            $table_name = $wpdb->prefix . 'ts_course_reviews';
            $reviews = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table_name} WHERE course_id = %d AND status = 'approved' ORDER BY created_at DESC", $course_id ) );
            
            // Calculate stats
            $total_reviews = count($reviews);
            $rating_counts = array(5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0);
            $sum_rating = 0;
            if ( $reviews ) {
                foreach ( $reviews as $r ) {
                    $val = intval($r->rating);
                    if ( isset($rating_counts[$val]) ) $rating_counts[$val]++;
                    $sum_rating += $val;
                }
            }
            $avg_rating = $total_reviews > 0 ? round($sum_rating / $total_reviews, 1) : 0;
            ?>
            <div class="ts-course-section ts-reviews-section">
                <?php if ( ! empty( $settings['reviews_title_text'] ) ) : ?>
                    <h3 class="ts-course-section-title"><?php echo esc_html( $settings['reviews_title_text'] ); ?></h3>
                <?php endif; ?>
                
                <div class="ts-reviews-container">
                    <!-- Review Summary Box -->
                    <div class="ts-review-summary-box" style="display: flex; gap: 30px; margin-bottom: 30px; align-items: center; border: 1px solid #e2e8f0; padding: 20px; border-radius: 8px;">
                        
                        <div class="ts-review-avg-box" style="text-align: center; min-width: 120px;">
                            <div class="ts-review-avg-number" style="font-size: 48px; font-weight: 700; line-height: 1; margin-bottom: 8px;"><?php echo esc_html( $avg_rating ); ?></div>
                            <div class="ts-stars" style="color: #fbbf24; margin-bottom: 4px;">
                                <?php for($i=1; $i<=5; $i++) echo '<span class="dashicons dashicons-star-' . ($i <= round($avg_rating) ? 'filled' : 'empty') . '" style="font-size: 16px; width: 16px; height: 16px;"></span>'; ?>
                            </div>
                            <div class="ts-total-reviews" style="font-size: 13px; color: #64748b;"><?php echo esc_html( $total_reviews ); ?> <?php esc_html_e('Reviews', 'ts-lms'); ?></div>
                        </div>

                        <div class="ts-rating-bars" style="flex: 1;">
                            <?php for($i=5; $i>=1; $i--) : 
                                $percent = $total_reviews > 0 ? ($rating_counts[$i] / $total_reviews) * 100 : 0;
                            ?>
                                <div class="ts-rating-bar-row" style="display: flex; align-items: center; gap: 10px; margin-bottom: 6px;">
                                    <div class="ts-bar-star" style="width: 40px; font-size: 13px; display: flex; align-items: center; gap: 2px;">
                                        <span class="dashicons dashicons-star-filled" style="font-size: 14px; width: 14px; height: 14px; color: #fbbf24;"></span> <?php echo $i; ?>
                                    </div>
                                    <div class="ts-bar-bg" style="flex: 1; height: 8px; background: #e2e8f0; border-radius: 4px; overflow: hidden;">
                                        <div class="ts-bar-fill" style="width: <?php echo esc_attr($percent); ?>%; height: 100%; background: #fbbf24;"></div>
                                    </div>
                                    <div class="ts-bar-count" style="width: 30px; font-size: 12px; opacity: 0.7; text-align: right;"><?php echo $rating_counts[$i]; ?></div>
                                </div>
                            <?php endfor; ?>
                        </div>

                    </div>

                    <?php if ( empty($reviews) ) : ?>
                        <p><?php esc_html_e('No reviews yet.', 'ts-lms'); ?></p>
                    <?php else : ?>
                        <div class="ts-reviews-list">
                            <?php foreach ($reviews as $review) : ?>
                                <div class="ts-review-item" style="padding: 20px; border-bottom: 1px solid #f1f5f9; background: #fff; margin-bottom: 15px; border-radius: 8px;">
                                    <div style="display: flex; gap: 12px; margin-bottom: 12px;">
                                        <div class="ts-review-avatar"><?php echo get_avatar( $review->user_id, 40 ); ?></div>
                                        <div>
                                            <strong style="display: block; font-size: 15px;"><?php echo esc_html(get_user_by('id', $review->user_id)->display_name ?? 'User'); ?></strong>
                                            <span style="opacity: 0.6; font-size: 12px;"><?php echo date_i18n( get_option( 'date_format' ), strtotime( $review->created_at ) ); ?></span>
                                        </div>
                                        <div class="ts-review-stars" style="margin-left: auto; color: #fbbf24;">
                                            <?php for($k=1; $k<=5; $k++) echo '<span class="dashicons dashicons-star-' . ($k <= intval($review->rating) ? 'filled' : 'empty') . '" style="font-size: 14px; width: 14px; height: 14px;"></span>'; ?>
                                        </div>
                                    </div>
                                    <div class="ts-review-title" style="font-weight: 600; margin-bottom: 6px;"><?php echo esc_html($review->title); ?></div>
                                    <div class="ts-review-content" style="font-size: 14px; line-height: 1.6; color: #475569;"><?php echo esc_html($review->content); ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif;
    }
}
