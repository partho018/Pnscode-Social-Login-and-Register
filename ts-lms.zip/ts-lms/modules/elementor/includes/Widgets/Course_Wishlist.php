<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Wishlist extends Base_Widget {
    public function get_name() { return 'ts-course-wishlist-widget'; }
    public function get_title() { return __( 'Course Wishlist', 'ts-lms' ); }
    public function get_icon() { return 'eicon-heart'; }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section(
            'section_content',
            array(
                'label' => __( 'Wishlist Settings', 'ts-lms' ),
            )
        );

        $this->add_control(
            'view_type',
            array(
                'label'   => __( 'Design Template', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'text_icon',
                'options' => array(
                    'icon_only' => __( 'Icon Only (Minimal)', 'ts-lms' ),
                    'text_icon' => __( 'Icon with Text', 'ts-lms' ),
                    'button'    => __( 'Button Style (Premium)', 'ts-lms' ),
                ),
            )
        );

        $this->add_control(
            'wishlist_text',
            array(
                'label'     => __( 'Button Text', 'ts-lms' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => __( 'Add to Wishlist', 'ts-lms' ),
                'condition' => array(
                    'view_type' => array( 'text_icon', 'button' ),
                ),
            )
        );

        $this->add_responsive_control(
            'alignment',
            array(
                'label'     => __( 'Alignment', 'ts-lms' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => array(
                    'left'   => array( 'title' => __( 'Left', 'ts-lms' ), 'icon' => 'eicon-text-align-left' ),
                    'center' => array( 'title' => __( 'Center', 'ts-lms' ), 'icon' => 'eicon-text-align-center' ),
                    'right'  => array( 'title' => __( 'Right', 'ts-lms' ), 'icon' => 'eicon-text-align-right' ),
                ),
                'selectors' => array(
                    '{{WRAPPER}}' => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .ts-wishlist-btn' => 'justify-content: {{VALUE}};',
                ),
            )
        );

        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style Controls', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'      => 'typography',
                'selector'  => '{{WRAPPER}} .ts-wishlist-text',
                'condition' => array(
                    'view_type' => array( 'text_icon', 'button' ),
                ),
            )
        );

        $this->add_responsive_control(
            'gap',
            array(
                'label'      => __( 'Gap', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'range'      => array( 'px' => array( 'min' => 0, 'max' => 50 ) ),
                'default'    => array( 'size' => 8, 'unit' => 'px' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-wishlist-btn' => 'gap: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'icon_size',
            array(
                'label'      => __( 'Icon Size', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'range'      => array( 'px' => array( 'min' => 10, 'max' => 100 ) ),
                'default'    => array( 'size' => 20, 'unit' => 'px' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-wishlist-btn .dashicons' => 'font-size: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'button_margin',
            array(
                'label'      => __( 'Margin', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-wishlist-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
                'separator'  => 'before',
            )
        );

        $this->add_responsive_control(
            'button_padding',
            array(
                'label'      => __( 'Padding', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-wishlist-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'button_radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-wishlist-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->start_controls_tabs( 'tabs_button_style' );

        // Normal Tab
        $this->start_controls_tab(
            'tab_button_normal',
            array(
                'label' => __( 'Normal', 'ts-lms' ),
            )
        );

        $this->add_control(
            'text_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#1e293b',
                'selectors' => array(
                    '{{WRAPPER}} .ts-wishlist-text' => 'color: {{VALUE}};',
                ),
                'condition' => array(
                    'view_type' => array( 'text_icon', 'button' ),
                ),
            )
        );

        $this->add_control(
            'icon_color',
            array(
                'label'     => __( 'Heart Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#f43f5e',
                'selectors' => array(
                    '{{WRAPPER}} .ts-wishlist-btn .dashicons' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            array(
                'name'     => 'button_bg',
                'label'    => __( 'Background', 'ts-lms' ),
                'types'    => array( 'classic', 'gradient' ),
                'selector' => '{{WRAPPER}} .ts-wishlist-btn',
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'      => 'button_border',
                'selector'  => '{{WRAPPER}} .ts-wishlist-btn',
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'button_shadow',
                'selector' => '{{WRAPPER}} .ts-wishlist-btn',
            )
        );

        $this->end_controls_tab();

        // Hover Tab
        $this->start_controls_tab(
            'tab_button_hover',
            array(
                'label' => __( 'Hover', 'ts-lms' ),
            )
        );

        $this->add_control(
            'text_color_hover',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-wishlist-btn:hover .ts-wishlist-text' => 'color: {{VALUE}};',
                ),
                'condition' => array(
                    'view_type' => array( 'text_icon', 'button' ),
                ),
            )
        );

        $this->add_control(
            'icon_color_hover',
            array(
                'label'     => __( 'Heart Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-wishlist-btn:hover .dashicons' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            array(
                'name'     => 'button_bg_hover',
                'label'    => __( 'Background', 'ts-lms' ),
                'types'    => array( 'classic', 'gradient' ),
                'selector' => '{{WRAPPER}} .ts-wishlist-btn:hover',
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'      => 'button_border_hover',
                'selector'  => '{{WRAPPER}} .ts-wishlist-btn:hover',
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'button_shadow_hover',
                'selector' => '{{WRAPPER}} .ts-wishlist-btn:hover',
            )
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        $settings = $this->get_settings_for_display();
        
        $btn_class = 'ts-wishlist-btn ts-bookmark-btn';
        $btn_class .= ' ts-view-' . $settings['view_type'];

        ?>
        <button class="<?php echo esc_attr($btn_class); ?>" data-course-id="<?php echo esc_attr($course_id); ?>" 
                style="border: none; cursor: pointer; display: inline-flex; align-items: center; transition: all 0.3s ease;">
            
            <span class="dashicons dashicons-heart" style="line-height: 1;"></span>
            
            <?php if ( $settings['view_type'] !== 'icon_only' ) : ?>
                <span class="ts-wishlist-text" style="font-weight: 500;">
                    <?php echo esc_html($settings['wishlist_text']); ?>
                </span>
            <?php endif; ?>

        </button>

        <style>
            .ts-wishlist-btn:hover {
                transform: translateY(-2px);
            }
            .ts-wishlist-btn:active {
                transform: translateY(0);
            }
        </style>
        <?php
    }
}
