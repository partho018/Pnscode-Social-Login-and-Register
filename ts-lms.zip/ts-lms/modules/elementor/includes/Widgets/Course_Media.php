<?php
/**
 * Course Media Widget
 *
 * Elementor widget for displaying course media (thumbnail/image).
 *
 * @package TS_LMS\Modules\Elementor\Widgets
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Course Media Widget class.
 */
class Course_Media extends Base_Widget {

    public function get_name() {
        return 'ts-course-media';
    }

    public function get_title() {
        return __( 'Course Media', 'ts-lms' );
    }

    public function get_icon() {
        return 'eicon-featured-image';
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section(
            'section_content',
            array(
                'label' => __( 'Image', 'ts-lms' ),
            )
        );

        $this->add_control(
            'image_size',
            array(
                'label'   => __( 'Image Size', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'large',
                'options' => array(
                    'thumbnail' => __( 'Thumbnail', 'ts-lms' ),
                    'medium'    => __( 'Medium', 'ts-lms' ),
                    'large'     => __( 'Large', 'ts-lms' ),
                    'full'      => __( 'Full', 'ts-lms' ),
                ),
            )
        );

        $this->add_control(
            'aspect_ratio',
            array(
                'label'   => __( 'Aspect Ratio', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '16-9',
                'options' => array(
                    '1-1'   => '1:1',
                    '4-3'   => '4:3',
                    '16-9'  => '16:9',
                    'none'  => __( 'None', 'ts-lms' ),
                ),
            )
        );

        $this->add_control(
            'hover_zoom',
            array(
                'label'        => __( 'Hover Zoom', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'badge_text',
            array(
                'label'       => __( 'Badge Text', 'ts-lms' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'New', 'ts-lms' ),
            )
        );

        $this->add_control(
            'badge_position',
            array(
                'label'     => __( 'Badge Position', 'ts-lms' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'top-right',
                'options'   => array(
                    'top-left'     => __( 'Top Left', 'ts-lms' ),
                    'top-right'    => __( 'Top Right', 'ts-lms' ),
                    'bottom-left'  => __( 'Bottom Left', 'ts-lms' ),
                    'bottom-right' => __( 'Bottom Right', 'ts-lms' ),
                ),
                'condition' => array(
                    'badge_text!' => '',
                ),
            )
        );

        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Image', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'overlay_color',
            array(
                'label'     => __( 'Overlay Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-card-thumb::after' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'badge_bg_color',
            array(
                'label'     => __( 'Badge Background', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#4f46e5',
                'selectors' => array(
                    '{{WRAPPER}} .ts-media-badge' => 'background-color: {{VALUE}};',
                ),
                'condition' => array(
                    'badge_text!' => '',
                ),
            )
        );

        $this->add_control(
            'badge_text_color',
            array(
                'label'     => __( 'Badge Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => array(
                    '{{WRAPPER}} .ts-media-badge' => 'color: {{VALUE}};',
                ),
                'condition' => array(
                    'badge_text!' => '',
                ),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $course_id = $this->get_current_course_id();

        if ( ! $course_id ) {
            echo '<p>' . __( 'No course found', 'ts-lms' ) . '</p>';
            return;
        }

        $course = $this->get_course_data( $course_id );
        $aspect_class = 'aspect-' . $settings['aspect_ratio'];
        $zoom_class = $settings['hover_zoom'] === 'yes' ? 'hover-zoom' : '';

        ?>
        <div class="ts-course-card-thumb <?php echo esc_attr( $aspect_class . ' ' . $zoom_class ); ?>">
            <a href="<?php echo esc_url( $course['permalink'] ); ?>">
                <img src="<?php echo esc_url( $course['thumbnail'] ); ?>" alt="<?php echo esc_attr( $course['title'] ); ?>">
            </a>
            <?php if ( ! empty( $settings['badge_text'] ) ) : ?>
                <div class="ts-media-badge badge-<?php echo esc_attr( $settings['badge_position'] ); ?>">
                    <?php echo esc_html( $settings['badge_text'] ); ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}
