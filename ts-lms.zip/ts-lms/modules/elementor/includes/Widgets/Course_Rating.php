<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Rating extends Base_Widget {

    public function get_name() {
        return 'ts-course-rating';
    }

    public function get_title() {
        return __( 'Course Rating', 'ts-lms' );
    }

    public function get_icon() {
        return 'eicon-star';
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_rating',
            array(
                'label' => __( 'Rating Settings', 'ts-lms' ),
            )
        );

        $this->add_responsive_control(
            'alignment',
            array(
                'label'     => __( 'Alignment', 'ts-lms' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => array(
                    'flex-start' => array(
                        'title' => __( 'Left', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-left',
                    ),
                    'center'     => array(
                        'title' => __( 'Center', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-center',
                    ),
                    'flex-end'   => array(
                        'title' => __( 'Right', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-right',
                    ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-rating-wrap' => 'justify-content: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'show_count',
            array(
                'label'   => __( 'Show Review Count', 'ts-lms' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_rating_style',
            array(
                'label' => __( 'Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'rating_gap',
            array(
                'label'      => __( 'Gap', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'range'      => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 50,
                    ),
                ),
                'default' => array(
                    'size' => 8,
                    'unit' => 'px',
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-rating-wrap' => 'gap: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'star_color',
            array(
                'label'     => __( 'Star Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#f59e0b',
                'selectors' => array(
                    '{{WRAPPER}} .dashicons-star-filled' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_responsive_control(
            'star_size',
            array(
                'label'      => __( 'Star Size', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array(
                    'px' => array(
                        'min' => 10,
                        'max' => 50,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-stars .dashicons' => 'font-size: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'text_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-rating-text' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'typography',
                'selector' => '{{WRAPPER}} .ts-rating-text',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;

        $course = $this->get_course_data( $course_id );
        $settings = $this->get_settings_for_display();

        ?>
        <div class="ts-course-rating-wrap" style="display: flex; align-items: center;">
            <div class="ts-stars" style="display: flex;">
                <?php for($i=0; $i<5; $i++): ?>
                    <span class="dashicons dashicons-star-filled"></span>
                <?php endfor; ?>
            </div>
            <div class="ts-rating-text">
                <strong><?php echo number_format($course['rating'], 1); ?></strong>
                <?php if ($settings['show_count'] === 'yes'): ?>
                    <span>(<?php echo esc_html($course['review_count']); ?> reviews)</span>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}
