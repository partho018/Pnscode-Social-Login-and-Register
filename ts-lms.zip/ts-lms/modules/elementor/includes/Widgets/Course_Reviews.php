<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Reviews extends Base_Widget {
    public function get_name() { return 'ts-course-reviews'; }
    public function get_title() { return __( 'Course Reviews', 'ts-lms' ); }
    public function get_icon() { return 'eicon-review'; }

    protected function register_controls() {
        $this->start_controls_section( 'section_style', array( 'label' => __( 'Style', 'ts-lms' ), 'tab' => Controls_Manager::TAB_STYLE ) );
        $this->add_control( 'text_color', array( 'label' => __( 'Text Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-review-content' => 'color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'typography', 'selector' => '{{WRAPPER}} .ts-review-content' ) );
        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        $comments = get_comments(array('post_id' => $course_id, 'status' => 'approve'));
        if ( empty($comments) ) {
            echo '<p>' . __('No reviews yet.', 'ts-lms') . '</p>';
            return;
        }
        ?>
        <div class="ts-reviews-list">
            <?php foreach ($comments as $comment) : ?>
                <div class="ts-review-item" style="padding: 15px; border-bottom: 1px solid #f1f5f9;">
                    <div style="display: flex; gap: 10px; margin-bottom: 10px;">
                        <strong><?php echo esc_html($comment->comment_author); ?></strong>
                        <span style="opacity: 0.6; font-size: 12px;"><?php echo get_comment_date('', $comment); ?></span>
                    </div>
                    <div class="ts-review-content" style="font-size: 14px;"><?php echo esc_html($comment->comment_content); ?></div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }
}
