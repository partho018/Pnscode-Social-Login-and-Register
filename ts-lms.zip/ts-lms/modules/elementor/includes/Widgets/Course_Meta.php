<?php
/**
 * Course Meta Widget
 *
 * Elementor widget for displaying course metadata (category, level, duration, etc.).
 *
 * @package TS_LMS\Modules\Elementor\Widgets
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Course Meta Widget class.
 */
class Course_Meta extends Base_Widget {

    public function get_name() {
        return 'ts-course-meta';
    }

    public function get_title() {
        return __( 'Course Meta', 'ts-lms' );
    }

    public function get_icon() {
        return 'eicon-info-circle';
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section(
            'section_content',
            array(
                'label' => __( 'Meta Items', 'ts-lms' ),
            )
        );

        $this->add_control(
            'show_category',
            array(
                'label'        => __( 'Show Category', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_level',
            array(
                'label'        => __( 'Show Level', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_duration',
            array(
                'label'        => __( 'Show Duration', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_language',
            array(
                'label'        => __( 'Show Language', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_icon',
            array(
                'label'        => __( 'Show Icons', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'layout',
            array(
                'label'   => __( 'Layout', 'ts-lms' ),
                'type'    => Controls_Manager::CHOOSE,
                'default' => 'row',
                'options' => array(
                    'row' => array(
                        'title' => __( 'Horizontal', 'ts-lms' ),
                        'icon'  => 'eicon-h-align-left',
                    ),
                    'column' => array(
                        'title' => __( 'Vertical', 'ts-lms' ),
                        'icon'  => 'eicon-v-align-top',
                    ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-meta-row' => 'display: flex; flex-direction: {{VALUE}}; flex-wrap: wrap;',
                ),
            )
        );

        $this->add_responsive_control(
            'align_row',
            array(
                'label'     => __( 'Alignment', 'ts-lms' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => array(
                    'flex-start' => array(
                        'title' => __( 'Left', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-left',
                    ),
                    'center'     => array(
                        'title' => __( 'Center', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-center',
                    ),
                    'flex-end'   => array(
                        'title' => __( 'Right', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-right',
                    ),
                    'space-between' => array(
                        'title' => __( 'Space Between', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-justify',
                    ),
                ),
                'default'   => 'flex-start',
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-meta-row' => 'justify-content: {{VALUE}};',
                ),
                'condition' => array(
                    'layout' => 'row',
                ),
            )
        );

        $this->add_responsive_control(
            'align_column',
            array(
                'label'     => __( 'Alignment', 'ts-lms' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => array(
                    'flex-start' => array(
                        'title' => __( 'Left', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-left',
                    ),
                    'center'     => array(
                        'title' => __( 'Center', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-center',
                    ),
                    'flex-end'   => array(
                        'title' => __( 'Right', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-right',
                    ),
                    'stretch' => array(
                        'title' => __( 'Stretch', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-justify',
                    ),
                ),
                'default'   => 'flex-start',
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-meta-row' => 'align-items: {{VALUE}};',
                ),
                'condition' => array(
                    'layout' => 'column',
                ),
            )
        );

        $this->add_control(
            'text_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-meta-row .ts-meta-item' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'icon_color',
            array(
                'label'     => __( 'Icon Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-meta-row .dashicons' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_responsive_control(
            'meta_spacing',
            array(
                'label'      => __( 'Spacing', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 50,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-meta-row' => 'gap: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'meta_typography',
                'selector' => '{{WRAPPER}} .ts-course-meta-row .ts-meta-item',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $course_id = $this->get_current_course_id();

        if ( ! $course_id ) {
            echo '<p>' . __( 'No course found', 'ts-lms' ) . '</p>';
            return;
        }

        $course = $this->get_course_data( $course_id );

        ?>
        <div class="ts-course-meta-row">
            <?php if ( $settings['show_category'] === 'yes' && $course['category'] ) : ?>
                <div class="ts-meta-item">
                    <?php if ( $settings['show_icon'] === 'yes' ) : ?>
                        <span class="dashicons dashicons-category"></span>
                    <?php endif; ?>
                    <?php echo esc_html( $course['category'] ); ?>
                </div>
            <?php endif; ?>

            <?php if ( $settings['show_level'] === 'yes' && $course['level'] ) : ?>
                <div class="ts-meta-item">
                    <?php if ( $settings['show_icon'] === 'yes' ) : ?>
                        <span class="dashicons dashicons-chart-bar"></span>
                    <?php endif; ?>
                    <?php echo esc_html( ucfirst( $course['level'] ) ); ?>
                </div>
            <?php endif; ?>

            <?php if ( $settings['show_duration'] === 'yes' && ( $course['duration_hours'] || $course['duration_minutes'] ) ) : ?>
                <div class="ts-meta-item ts-course-duration">
                    <?php if ( $settings['show_icon'] === 'yes' ) : ?>
                        <span class="dashicons dashicons-clock"></span>
                    <?php endif; ?>
                    <?php 
                    if ( $course['duration_hours'] ) echo $course['duration_hours'] . 'h ';
                    if ( $course['duration_minutes'] ) echo $course['duration_minutes'] . 'm';
                    ?>
                </div>
            <?php endif; ?>

            <?php if ( $settings['show_language'] === 'yes' ) : ?>
                <div class="ts-meta-item">
                    <?php if ( $settings['show_icon'] === 'yes' ) : ?>
                        <span class="dashicons dashicons-translation"></span>
                    <?php endif; ?>
                    <?php echo esc_html__( 'English', 'ts-lms' ); ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}
