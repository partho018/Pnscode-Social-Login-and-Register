<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Target_Audience extends Base_Widget {
    public function get_name() { return 'ts-course-target-audience'; }
    public function get_title() { return __( 'Course Target Audience', 'ts-lms' ); }
    public function get_icon() { return 'eicon-bullet-list'; }

    protected function register_controls() {
        $this->start_controls_section( 'section_style', array( 'label' => __( 'Style', 'ts-lms' ), 'tab' => Controls_Manager::TAB_STYLE ) );
        $this->add_control( 'text_color', array( 'label' => __( 'Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-audience-content' => 'color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'typography', 'selector' => '{{WRAPPER}} .ts-audience-content' ) );
        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        $audience = get_post_meta($course_id, '_target_audience', true);
        if ( empty($audience) ) return;
        echo '<div class="ts-audience-content">' . wp_kses_post($audience) . '</div>';
    }
}
