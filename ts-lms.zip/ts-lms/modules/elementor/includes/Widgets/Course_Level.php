<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Level extends Base_Widget {

    public function get_name() {
        return 'ts-course-level-widget';
    }

    public function get_title() {
        return __( 'Course Level', 'ts-lms' );
    }

    public function get_icon() {
        return 'eicon-skill-bar';
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'text_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-single-level' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'typography',
                'selector' => '{{WRAPPER}} .ts-single-level',
            )
        );

        $this->add_control(
            'show_icon',
            array(
                'label'   => __( 'Show Icon', 'ts-lms' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );

        $this->add_control(
            'icon_color',
            array(
                'label'     => __( 'Icon Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .dashicons' => 'color: {{VALUE}};',
                ),
                'condition' => array( 'show_icon' => 'yes' ),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;

        $course = $this->get_course_data( $course_id );
        $settings = $this->get_settings_for_display();

        if ( empty( $course['level'] ) ) return;

        ?>
        <div class="ts-single-level" style="display: flex; align-items: center; gap: 8px;">
            <?php if ( $settings['show_icon'] === 'yes' ) : ?>
                <span class="dashicons dashicons-chart-bar"></span>
            <?php endif; ?>
            <span><?php echo esc_html( ucfirst( $course['level'] ) ); ?></span>
        </div>
        <?php
    }
}
