<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Price extends Base_Widget {

    public function get_name() {
        return 'ts-course-price-widget';
    }

    public function get_title() {
        return __( 'Course Price', 'ts-lms' );
    }

    public function get_icon() {
        return 'eicon-product-price';
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'price_color',
            array(
                'label'     => __( 'Price Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#10b981',
                'selectors' => array(
                    '{{WRAPPER}} .ts-single-price' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'price_typography',
                'selector' => '{{WRAPPER}} .ts-single-price',
            )
        );

        $this->add_responsive_control(
            'alignment',
            array(
                'label'     => __( 'Alignment', 'ts-lms' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => array(
                    'left'   => array( 'title' => __( 'Left', 'ts-lms' ), 'icon' => 'eicon-text-align-left' ),
                    'center' => array( 'title' => __( 'Center', 'ts-lms' ), 'icon' => 'eicon-text-align-center' ),
                    'right'  => array( 'title' => __( 'Right', 'ts-lms' ), 'icon' => 'eicon-text-align-right' ),
                ),
                'selectors' => array(
                    '{{WRAPPER}}' => 'text-align: {{VALUE}};',
                ),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;

        $course = $this->get_course_data( $course_id );

        echo '<div class="ts-single-price" style="font-weight: bold;">';
        if ( $course['is_free'] ) {
            esc_html_e( 'Free', 'ts-lms' );
        } else {
            echo number_format( (float) $course['price'], 2 ) . '৳';
        }
        echo '</div>';
    }
}
