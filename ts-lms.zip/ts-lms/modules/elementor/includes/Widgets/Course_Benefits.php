<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Benefits extends Base_Widget {
    public function get_name() { return 'ts-course-benefits'; }
    public function get_title() { return __( 'Course Benefits', 'ts-lms' ); }
    public function get_icon() { return 'eicon-bullet-list'; }

    protected function register_controls() {
        $this->start_controls_section( 'section_style', array( 'label' => __( 'Style', 'ts-lms' ), 'tab' => Controls_Manager::TAB_STYLE ) );
        $this->add_control( 'text_color', array( 'label' => __( 'Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} ul' => 'color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'typography', 'selector' => '{{WRAPPER}} ul' ) );
        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        $benefits = get_post_meta($course_id, '_what_will_learn', true);
        if ( empty($benefits) ) return;
        echo '<div class="ts-course-benefits">' . wp_kses_post($benefits) . '</div>';
    }
}
