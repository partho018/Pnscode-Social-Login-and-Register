<?php
/**
 * Course Action Widget
 *
 * Elementor widget for displaying course action button and price.
 *
 * @package TS_LMS\Modules\Elementor\Widgets
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Course Action Widget class.
 */
class Course_Action extends Base_Widget {

    public function get_name() {
        return 'ts-course-action';
    }

    public function get_title() {
        return __( 'Course Action', 'ts-lms' );
    }

    public function get_icon() {
        return 'eicon-button';
    }

    protected function register_controls() {
        // Price Section
        $this->start_controls_section(
            'section_price',
            array(
                'label' => __( 'Price', 'ts-lms' ),
            )
        );

        $this->add_control(
            'show_price',
            array(
                'label'        => __( 'Show Price', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'currency_symbol',
            array(
                'label'     => __( 'Currency Symbol', 'ts-lms' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => '৳',
                'condition' => array(
                    'show_price' => 'yes',
                ),
            )
        );

        $this->end_controls_section();

        // Button Section
        $this->start_controls_section(
            'section_button',
            array(
                'label' => __( 'Button', 'ts-lms' ),
            )
        );

        $this->add_control(
            'button_text',
            array(
                'label'   => __( 'Button Text', 'ts-lms' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'Enroll now', 'ts-lms' ),
            )
        );

        $this->add_control(
            'button_icon',
            array(
                'label' => __( 'Icon', 'ts-lms' ),
                'type'  => Controls_Manager::ICONS,
            )
        );

        $this->add_control(
            'icon_position',
            array(
                'label'   => __( 'Icon Position', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'left',
                'options' => array(
                    'left'  => __( 'Left', 'ts-lms' ),
                    'right' => __( 'Right', 'ts-lms' ),
                ),
            )
        );

        $this->add_responsive_control(
            'button_alignment',
            array(
                'label'   => __( 'Alignment', 'ts-lms' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => array(
                    'left'    => array(
                        'title' => __( 'Left', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-left',
                    ),
                    'center'  => array(
                        'title' => __( 'Center', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-center',
                    ),
                    'right'   => array(
                        'title' => __( 'Right', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-right',
                    ),
                    'justify' => array(
                        'title' => __( 'Justified', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-justify',
                    ),
                ),
            )
        );

        $this->end_controls_section();

        // Progress Bar Section
        $this->start_controls_section(
            'section_progress',
            array(
                'label' => __( 'Progress Bar', 'ts-lms' ),
            )
        );

        $this->add_control(
            'show_progress',
            array(
                'label'        => __( 'Show Progress Bar', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'progress_height',
            array(
                'label'      => __( 'Height', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array(
                    'px' => array(
                        'min' => 2,
                        'max' => 20,
                    ),
                ),
                'default'    => array(
                    'size' => 6,
                ),
                'condition'  => array(
                    'show_progress' => 'yes',
                ),
            )
        );

        $this->end_controls_section();

        // Button Style
        $this->start_controls_section(
            'section_button_style',
            array(
                'label' => __( 'Button', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'button_typography',
                'selector' => '{{WRAPPER}} .ts-btn-enroll',
            )
        );

        $this->start_controls_tabs( 'button_style_tabs' );

        $this->start_controls_tab(
            'button_normal',
            array(
                'label' => __( 'Normal', 'ts-lms' ),
            )
        );

        $this->add_control(
            'button_text_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-btn-enroll' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'button_bg_color',
            array(
                'label'     => __( 'Background Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-btn-enroll' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_hover',
            array(
                'label' => __( 'Hover', 'ts-lms' ),
            )
        );

        $this->add_control(
            'button_hover_text_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-btn-enroll:hover' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'button_hover_bg_color',
            array(
                'label'     => __( 'Background Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-btn-enroll:hover' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'      => 'button_border',
                'selector'  => '{{WRAPPER}} .ts-btn-enroll',
                'separator' => 'before',
            )
        );

        $this->add_control(
            'button_border_radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-btn-enroll' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'button_padding',
            array(
                'label'      => __( 'Padding', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-btn-enroll' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();

        // Price Style
        $this->start_controls_section(
            'section_price_style',
            array(
                'label' => __( 'Price', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'price_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-price' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'price_typography',
                'selector' => '{{WRAPPER}} .ts-course-price',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $course_id = $this->get_current_course_id();

        if ( ! $course_id ) {
            echo '<p>' . __( 'No course found', 'ts-lms' ) . '</p>';
            return;
        }

        $course = $this->get_course_data( $course_id );

        $alignment_class = '';
        if ( ! empty( $settings['button_alignment'] ) ) {
            $alignment_class = 'align-' . $settings['button_alignment'];
        }

        ?>
        <div class="ts-course-card-footer <?php echo esc_attr( $alignment_class ); ?>">
            <?php if ( $settings['show_price'] === 'yes' ) : ?>
                <div class="ts-course-price">
                    <?php if ( $course['is_free'] ) : ?>
                        <span class="free"><?php esc_html_e( 'Free', 'ts-lms' ); ?></span>
                    <?php else : ?>
                        <span class="price"><?php echo number_format( (float) $course['price'], 2 ) . esc_html( $settings['currency_symbol'] ); ?></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <a href="<?php echo esc_url( $course['permalink'] ); ?>" class="ts-btn-enroll">
                <?php if ( ! empty( $settings['button_icon']['value'] ) && $settings['icon_position'] === 'left' ) : ?>
                    <?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], array( 'aria-hidden' => 'true' ) ); ?>
                <?php endif; ?>
                
                <?php echo esc_html( $settings['button_text'] ); ?>
                
                <?php if ( ! empty( $settings['button_icon']['value'] ) && $settings['icon_position'] === 'right' ) : ?>
                    <?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], array( 'aria-hidden' => 'true' ) ); ?>
                <?php endif; ?>
            </a>

            <?php if ( $settings['show_progress'] === 'yes' ) : ?>
                <div class="ts-course-progress" style="height: <?php echo esc_attr( $settings['progress_height']['size'] ); ?>px;">
                    <div class="ts-progress-bar" style="width: 50%;"></div>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}
