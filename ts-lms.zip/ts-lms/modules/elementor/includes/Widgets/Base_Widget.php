<?php
/**
 * Base Widget Class for Elementor Widgets
 *
 * Provides common functionality for all TS LMS Elementor widgets.
 *
 * @package TS_LMS\Modules\Elementor\Widgets
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Base Widget class.
 */
abstract class Base_Widget extends Widget_Base {

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return array( '0-ts-lms' );
    }

    /**
     * Get course data helper.
     *
     * @param int $course_id Course ID.
     * @return array Course data.
     */
    protected function get_course_data( $course_id ) {
        $author_id   = get_post_field( 'post_author', $course_id );
        $author_name = get_the_author_meta( 'display_name', $author_id );
        $thumbnail   = get_the_post_thumbnail_url( $course_id, 'large' ) ?: 'https://placehold.co/800x450/e2e8f0/475569?text=Course+Image';

        // Metadata
        $price_type = get_post_meta( $course_id, '_course_price_type', true );
        $product_id = get_post_meta( $course_id, '_course_product_id', true );

        // Get price from WooCommerce product if linked
        $price = 0;
        if ( $product_id && function_exists( 'wc_get_product' ) ) {
            $product = wc_get_product( $product_id );
            if ( $product ) {
                $price = $product->get_regular_price();
            }
        }

        // Duration
        $h = get_post_meta( $course_id, '_total_duration_hours', true );
        $m = get_post_meta( $course_id, '_total_duration_minutes', true );

        // Level
        $level = get_post_meta( $course_id, '_course_level', true );

        // Categories
        $categories = wp_get_post_terms( $course_id, 'ts_course_category' );
        $primary_cat = ! empty( $categories ) ? $categories[0]->name : '';

        // Tags
        $tags = wp_get_post_terms( $course_id, 'ts_course_tag' );
        $primary_tag = ! empty( $tags ) ? $tags[0]->name : '';

        // Enrollment count
        global $wpdb;
        $enrollment_count = $wpdb->get_var( $wpdb->prepare( 
            "SELECT COUNT(*) FROM {$wpdb->prefix}ts_course_enrollments WHERE course_id = %d",
            $course_id
        ) );
        if ( ! $enrollment_count ) $enrollment_count = 0;

        // Reviews/Ratings
        $rating       = 5.00;  // Placeholder - integrate with review system
        $review_count = $enrollment_count > 0 ? max( 1, floor( $enrollment_count / 3 ) ) : 0;

        // Count Lessons
        $lesson_count = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} p 
             INNER JOIN {$wpdb->posts} t ON p.post_parent = t.ID 
             WHERE t.post_parent = %d AND p.post_type IN ('ts_lesson', 'ts_quiz', 'ts_assignment')",
            $course_id
        ) ) ?: 0;

        $is_free = ( $price_type === 'free' || empty( $price ) || $price == 0 );

        // Current user enrollment check
        $is_enrolled = false;
        $first_lesson_url = '';
        if ( is_user_logged_in() ) {
            $user_id = get_current_user_id();
            
            // Check if user is enrolled
            $is_enrolled = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}ts_course_enrollments WHERE course_id = %d AND user_id = %d",
                $course_id,
                $user_id
            ) );

            // Admins/Authors are considered enrolled
            if ( current_user_can( 'manage_options' ) || get_post_field( 'post_author', $course_id ) == $user_id ) {
                $is_enrolled = true;
            }

            if ( $is_enrolled ) {
                // Get first lesson
                $first_topic = get_posts( array(
                    'post_type'      => 'ts_topic',
                    'posts_per_page' => 1,
                    'post_parent'    => $course_id,
                    'orderby'        => 'menu_order',
                    'order'          => 'ASC',
                    'fields'         => 'ids',
                ) );

                if ( ! empty( $first_topic ) ) {
                    $first_item = get_posts( array(
                        'post_type'      => array( 'ts_lesson', 'ts_quiz', 'ts_assignment' ),
                        'posts_per_page' => 1,
                        'post_parent'    => $first_topic[0],
                        'orderby'        => 'menu_order',
                        'order'          => 'ASC',
                        'fields'         => 'ids',
                    ) );

                    if ( ! empty( $first_item ) ) {
                        $first_lesson_url = get_permalink( $first_item[0] );
                    }
                }
            }
        }

        // Check if in WooCommerce cart
        $is_in_cart = false;
        if ( $product_id && function_exists( 'WC' ) && WC()->cart ) {
            foreach ( WC()->cart->get_cart() as $cart_item_key => $values ) {
                if ( $values['product_id'] == $product_id ) {
                    $is_in_cart = true;
                    break;
                }
            }
        }

        return array(
            'id'               => $course_id,
            'title'            => get_the_title( $course_id ),
            'permalink'        => get_permalink( $course_id ),
            'excerpt'          => get_the_excerpt( $course_id ),
            'thumbnail'        => $thumbnail,
            'author_id'        => $author_id,
            'author_name'      => $author_name,
            'price'            => $price,
            'price_type'       => $price_type,
            'product_id'       => $product_id,
            'is_free'          => $is_free,
            'is_enrolled'      => (bool) $is_enrolled,
            'first_lesson_url' => $first_lesson_url,
            'is_in_cart'       => $is_in_cart,
            'lesson_count'     => $lesson_count,
            'duration_hours'   => $h,
            'duration_minutes' => $m,
            'level'            => $level,
            'category'         => $primary_cat,
            'tag'              => $primary_tag,
            'enrollment_count' => $enrollment_count,
            'rating'           => $rating,
            'review_count'     => $review_count,
        );
    }

    /**
     * Get current course ID in editor/preview.
     *
     * @return int|false Course ID or false.
     */
    protected function get_current_course_id() {
        // In editor, get the first published course
        if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
            $courses = get_posts( array(
                'post_type'      => 'ts_course',
                'posts_per_page' => 1,
                'post_status'    => 'publish',
                'fields'         => 'ids',
            ) );
            return ! empty( $courses ) ? $courses[0] : false;
        }

        // On frontend, get current post if it's a course
        if ( is_singular( 'ts_course' ) ) {
            return get_the_ID();
        }

        return false;
    }
}
