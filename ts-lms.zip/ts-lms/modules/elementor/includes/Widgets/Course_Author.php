<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Author extends Base_Widget {

    public function get_name() {
        return 'ts-course-author-widget';
    }

    public function get_title() {
        return __( 'Course Author', 'ts-lms' );
    }

    public function get_icon() {
        return 'eicon-person';
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_content',
            array(
                'label' => __( 'Content', 'ts-lms' ),
            )
        );

        $this->add_control(
            'show_avatar',
            array(
                'label'   => __( 'Show Avatar', 'ts-lms' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );

        $this->add_control(
            'label_text',
            array(
                'label'   => __( 'Label Text', 'ts-lms' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'By', 'ts-lms' ),
            )
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'avatar_heading',
            array(
                'label'     => __( 'Avatar', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'condition' => array( 'show_avatar' => 'yes' ),
            )
        );

        $this->add_responsive_control(
            'avatar_size',
            array(
                'label'      => __( 'Avatar Size', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array( 'px' => array( 'min' => 10, 'max' => 200 ) ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-author-avatar img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ),
                'condition'  => array( 'show_avatar' => 'yes' ),
            )
        );

        $this->add_control(
            'avatar_radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-author-avatar img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
                'condition'  => array( 'show_avatar' => 'yes' ),
            )
        );

        $this->add_control(
            'label_heading',
            array(
                'label'     => __( 'Label', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_control(
            'label_color',
            array(
                'label'     => __( 'Label Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-author-label' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'label_typography',
                'selector' => '{{WRAPPER}} .ts-author-label',
            )
        );

        $this->add_control(
            'info_heading',
            array(
                'label'     => __( 'Name', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_control(
            'name_color',
            array(
                'label'     => __( 'Name Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-author-name' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .ts-author-name a' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'name_typography',
                'selector' => '{{WRAPPER}} .ts-author-name',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;

        $course = $this->get_course_data( $course_id );
        $settings = $this->get_settings_for_display();

        ?>
        <div class="ts-single-course-author" style="display: flex; align-items: center; gap: 12px;">
            <?php if ( $settings['show_avatar'] === 'yes' ) : ?>
                <div class="ts-author-avatar">
                    <?php echo get_avatar( $course['author_id'], 64 ); ?>
                </div>
            <?php endif; ?>
            <div class="ts-author-info">
                <?php if ( ! empty( $settings['label_text'] ) ) : ?>
                    <span class="ts-author-label" style="opacity: 0.8; font-size: 0.9em;"><?php echo esc_html( $settings['label_text'] ); ?></span>
                <?php endif; ?>
                <div class="ts-author-name" style="font-weight: 600;"><?php echo esc_html( $course['author_name'] ); ?></div>
            </div>
        </div>
        <?php
    }
}
