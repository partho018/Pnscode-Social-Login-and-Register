<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Description extends Base_Widget {
    public function get_name() { return 'ts-course-description'; }
    public function get_title() { return __( 'Course Description', 'ts-lms' ); }
    public function get_icon() { return 'eicon-text-align-left'; }

    protected function register_controls() {
        $this->start_controls_section( 'section_style', array( 'label' => __( 'Style', 'ts-lms' ), 'tab' => Controls_Manager::TAB_STYLE ) );
        $this->add_control( 'text_color', array( 'label' => __( 'Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-description-content' => 'color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'typography', 'selector' => '{{WRAPPER}} .ts-description-content' ) );
        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        $post = get_post($course_id);
        if ( ! $post || empty($post->post_content) ) return;
        echo '<div class="ts-description-content">' . apply_filters('the_content', $post->post_content) . '</div>';
    }
}
