<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Duration extends Base_Widget {
    public function get_name() { return 'ts-course-duration-widget'; }
    public function get_title() { return __( 'Course Duration', 'ts-lms' ); }
    public function get_icon() { return 'eicon-clock-o'; }

    protected function register_controls() {
        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'gap',
            array(
                'label'      => __( 'Gap', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'range'      => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 50,
                    ),
                ),
                'default'    => array(
                    'size' => 8,
                    'unit' => 'px',
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-single-duration' => 'gap: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'heading_icon',
            array(
                'label'     => __( 'Icon', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_control(
            'icon_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-duration-icon' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_responsive_control(
            'icon_size',
            array(
                'label'      => __( 'Size', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'range'      => array(
                    'px' => array(
                        'min' => 10,
                        'max' => 100,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-duration-icon' => 'font-size: {{SIZE}}{{UNIT}}; line-height: 1;',
                ),
            )
        );

        $this->add_control(
            'heading_text',
            array(
                'label'     => __( 'Text', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_control(
            'text_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-duration-text' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'typography',
                'selector' => '{{WRAPPER}} .ts-duration-text',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;
        $course = $this->get_course_data( $course_id );
        if ( ! $course['duration_hours'] && ! $course['duration_minutes'] ) return;
        ?>
        <div class="ts-single-duration" style="display: flex; align-items: center;">
            <span class="ts-duration-icon dashicons dashicons-clock"></span>
            <span class="ts-duration-text">
                <?php 
                if ( $course['duration_hours'] ) echo $course['duration_hours'] . 'h ';
                if ( $course['duration_minutes'] ) echo $course['duration_minutes'] . 'm';
                ?>
            </span>
        </div>
        <?php
    }
}
