<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Carousel extends Course_Card_Wrapper {
    public function get_name() { return 'ts-course-carousel'; }
    public function get_title() { return __( 'Course Carousel', 'ts-lms' ); }
    public function get_icon() { return 'eicon-slider-3d'; }

    public function get_script_depends() {
        return [ 'swiper' ];
    }

    public function get_style_depends() {
        return [ 'swiper' ];
    }

    protected function register_controls() {
        // Reuse parent controls (Query, Card Design, etc.)
        parent::register_controls();
        
        // --- Carousel Settings ---
        $this->start_controls_section(
            'section_carousel_settings',
            array(
                'label' => __( 'Carousel Settings', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_responsive_control(
            'slides_to_show',
            array(
                'label'          => __( 'Slides to Show', 'ts-lms' ),
                'type'           => Controls_Manager::NUMBER,
                'min'            => 1,
                'max'            => 10,
                'default'        => 3,
                'tablet_default' => 2,
                'mobile_default' => 1,
            )
        );

        $this->add_control(
            'slides_to_scroll',
            array(
                'label'   => __( 'Slides to Scroll', 'ts-lms' ),
                'type'    => Controls_Manager::NUMBER,
                'min'     => 1,
                'max'     => 10,
                'default' => 1,
            )
        );

        $this->add_control(
            'autoplay',
            array(
                'label'   => __( 'Autoplay', 'ts-lms' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );

        $this->add_control(
            'autoplay_speed',
            array(
                'label'     => __( 'Autoplay Speed (ms)', 'ts-lms' ),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 5000,
                'condition' => array( 'autoplay' => 'yes' ),
            )
        );

        $this->add_control(
            'pause_on_hover',
            array(
                'label'     => __( 'Pause on Hover', 'ts-lms' ),
                'type'      => Controls_Manager::SWITCHER,
                'default'   => 'yes',
                'condition' => array( 'autoplay' => 'yes' ),
            )
        );

        $this->add_control(
            'infinite_loop',
            array(
                'label'   => __( 'Infinite Loop', 'ts-lms' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );

        $this->add_control(
            'nav_arrows',
            array(
                'label'   => __( 'Show Arrows', 'ts-lms' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );

        $this->add_control(
            'nav_dots',
            array(
                'label'   => __( 'Show Pagination (Dots)', 'ts-lms' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );

        $this->end_controls_section();

        // --- Style: Navigation ---
        $this->start_controls_section(
            'section_style_navigation',
            array(
                'label' => __( 'Navigation Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'arrow_prev_icon',
            array(
                'label' => __( 'Previous Arrow Icon', 'ts-lms' ),
                'type' => Controls_Manager::ICONS,
                'default' => array(
                    'value' => 'eicon-chevron-left',
                    'library' => 'eicons',
                ),
                'condition' => array( 'nav_arrows' => 'yes' ),
            )
        );

        $this->add_control(
            'arrow_next_icon',
            array(
                'label' => __( 'Next Arrow Icon', 'ts-lms' ),
                'type' => Controls_Manager::ICONS,
                'default' => array(
                    'value' => 'eicon-chevron-right',
                    'library' => 'eicons',
                ),
                'condition' => array( 'nav_arrows' => 'yes' ),
            )
        );

        $this->add_responsive_control(
            'arrow_size',
            array(
                'label'      => __( 'Arrow Size', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array( 'px' => array( 'min' => 10, 'max' => 100 ) ),
                'default'    => array( 'size' => 20, 'unit' => 'px' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-swiper-next, {{WRAPPER}} .ts-swiper-prev' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ts-swiper-nav-icon' => 'font-size: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ts-swiper-nav-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: auto;',
                ),
                'condition' => array( 'nav_arrows' => 'yes' ),
            )
        );

        $this->add_control(
            'arrow_color',
            array(
                'label'     => __( 'Arrow Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-swiper-next, {{WRAPPER}} .ts-swiper-prev' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .ts-swiper-nav-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
                ),
                'condition' => array( 'nav_arrows' => 'yes' ),
            )
        );

        $this->add_control(
            'arrow_bg_color',
            array(
                'label'     => __( 'Arrow Background', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-swiper-next, {{WRAPPER}} .ts-swiper-prev' => 'background-color: {{VALUE}}; padding: 0; border-radius: 50%; width: 50px; height: 50px;',
                ),
                'condition' => array( 'nav_arrows' => 'yes' ),
            )
        );

        $this->add_control(
            'dot_color',
            array(
                'label'     => __( 'Dot Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'background: {{VALUE}}; opacity: 0.5;',
                ),
                'condition' => array( 'nav_dots' => 'yes' ),
            )
        );

        $this->add_control(
            'dot_active_color',
            array(
                'label'     => __( 'Active Dot Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .swiper-pagination-bullet-active' => 'background: {{VALUE}}; opacity: 1;',
                ),
                'condition' => array( 'nav_dots' => 'yes' ),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        // --- Query Construction (Duplicated from Parent) ---
        $args = array(
            'post_type'      => 'ts_course',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
        );

        if ( $settings['course_selection'] === 'manual' && ! empty( $settings['course_ids'] ) ) {
            $ids = array_map( 'trim', explode( ',', $settings['course_ids'] ) );
            $args['post__in'] = $ids;
            $args['orderby'] = 'post__in';
        } else {
            $args['posts_per_page'] = $settings['posts_per_page'] ?: 6;
            $args['orderby'] = $settings['orderby'];
            $args['order'] = $settings['order'];
            
            if ( ! empty( $settings['filter_categories'] ) ) {
                $args['tax_query'] = array(
                    array(
                        'taxonomy' => 'ts_course_category',
                        'field'    => 'term_id',
                        'terms'    => $settings['filter_categories'],
                    ),
                );
            }
            if ( ! empty( $settings['filter_authors'] ) ) {
                $args['author__in'] = $settings['filter_authors'];
            }
        }

        $courses = new \WP_Query( $args );

        if ( ! $courses->have_posts() ) {
            echo '<p>' . esc_html__( 'No courses found.', 'ts-lms' ) . '</p>';
            return;
        }

        // Swiper Settings
        $swiper_config = json_encode(array(
            'slidesPerView' => $settings['slides_to_show_mobile'] ?: 1,
            'spaceBetween'  => 20,
            'breakpoints'   => array(
                768 => array(
                    'slidesPerView' => $settings['slides_to_show_tablet'] ?: 2,
                ),
                1024 => array(
                    'slidesPerView' => $settings['slides_to_show'] ?: 3,
                ),
            ),
            'loop'          => $settings['infinite_loop'] === 'yes',
            'autoplay'      => $settings['autoplay'] === 'yes' ? array( 'delay' => $settings['autoplay_speed'], 'disableOnInteraction' => false ) : false,
            'navigation'    => $settings['nav_arrows'] === 'yes' ? array( 'nextEl' => '.ts-swiper-next', 'prevEl' => '.ts-swiper-prev' ) : false,
            'pagination'    => $settings['nav_dots'] === 'yes' ? array( 'el' => '.swiper-pagination', 'clickable' => true ) : false,
        ));

        // Generate Unique ID
        $uid = 'ts-swiper-' . $this->get_id();

        // Wrapper Classes
        $wrapper_classes = array( 'ts-course-carousel-widget' );
        if ( ! empty( $settings['skin_style'] ) ) $wrapper_classes[] = 'skin-' . $settings['skin_style'];
        if ( ! empty( $settings['card_design_preset'] ) ) $wrapper_classes[] = 'ts-' . $settings['card_design_preset'];
        if ( ! empty( $settings['hover_animation'] ) && $settings['hover_animation'] !== 'none' ) $wrapper_classes[] = 'hover-' . $settings['hover_animation'];
        
        // Output default styles for custom arrows to ensure they work without style controls being triggered
        ?>
        <style>
            .ts-course-carousel-widget { position: relative; }
            .ts-swiper-next, .ts-swiper-prev {
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                z-index: 99;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .ts-swiper-prev { left: 0; }
            .ts-swiper-next { right: 0; }
        </style>
        <div class="<?php echo esc_attr( implode( ' ', $wrapper_classes ) ); ?>" id="<?php echo esc_attr($uid); ?>">
            <div class="swiper ts-course-swiper">
                <div class="swiper-wrapper">
                    <?php
                    while ( $courses->have_posts() ) {
                        $courses->the_post();
                        $course_data = $this->get_course_data( get_the_ID() );
                        
                        echo '<div class="swiper-slide">';
                        $this->render_course_card( $course_data, $settings );
                        echo '</div>';
                    }
                    wp_reset_postdata();
                    ?>
                </div>

                <?php if ( $settings['nav_arrows'] === 'yes' ) : ?>
                    <div class="ts-swiper-next">
                        <?php 
                        if ( ! empty( $settings['arrow_next_icon']['value'] ) ) {
                            echo '<span class="ts-swiper-nav-icon">';
                            \Elementor\Icons_Manager::render_icon( $settings['arrow_next_icon'], array( 'aria-hidden' => 'true' ) );
                            echo '</span>';
                        }
                        ?>
                    </div>
                    <div class="ts-swiper-prev">
                        <?php 
                        if ( ! empty( $settings['arrow_prev_icon']['value'] ) ) {
                            echo '<span class="ts-swiper-nav-icon">';
                            \Elementor\Icons_Manager::render_icon( $settings['arrow_prev_icon'], array( 'aria-hidden' => 'true' ) );
                            echo '</span>';
                        }
                        ?>
                    </div>
                <?php endif; ?>

                <?php if ( $settings['nav_dots'] === 'yes' ) : ?>
                    <div class="swiper-pagination"></div>
                <?php endif; ?>
            </div>
        </div>

        <script>
        jQuery(window).on('elementor/frontend/init', function() {
            elementorFrontend.hooks.addAction('frontend/element_ready/ts-course-carousel.default', function($scope, $) {
                var container = $scope.find('.swiper');
                if (!container.length) return;
                
                var config = <?php echo $swiper_config; ?>;
                
                if ( 'undefined' !== typeof Swiper ) {
                     new Swiper(container[0], config);
                }
            });
        });
        </script>
        <?php
    }
}
