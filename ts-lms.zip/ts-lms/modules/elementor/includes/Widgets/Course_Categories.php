<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Categories extends Base_Widget {
    public function get_name() { return 'ts-course-categories-widget'; }
    public function get_title() { return __( 'Course Categories', 'ts-lms' ); }
    public function get_icon() { return 'eicon-folder'; }

    protected function register_controls() {
        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'layout',
            array(
                'label'   => __( 'Layout', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'row',
                'options' => array(
                    'row'    => __( 'Horizontal', 'ts-lms' ),
                    'column' => __( 'Vertical', 'ts-lms' ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-categories-wrapper' => 'display: flex; flex-direction: {{VALUE}}; flex-wrap: wrap;',
                ),
            )
        );

        $this->add_responsive_control(
            'align_horiz',
            array(
                'label'     => __( 'Alignment', 'ts-lms' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => array(
                    'flex-start' => array( 'title' => __( 'Left', 'ts-lms' ), 'icon' => 'eicon-text-align-left' ),
                    'center'     => array( 'title' => __( 'Center', 'ts-lms' ), 'icon' => 'eicon-text-align-center' ),
                    'flex-end'   => array( 'title' => __( 'Right', 'ts-lms' ), 'icon' => 'eicon-text-align-right' ),
                ),
                'default'   => 'flex-start',
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-categories-wrapper' => 'justify-content: {{VALUE}};',
                ),
                'condition' => array(
                    'layout' => 'row',
                ),
            )
        );

        $this->add_responsive_control(
            'align_vert',
            array(
                'label'     => __( 'Alignment', 'ts-lms' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => array(
                    'flex-start' => array( 'title' => __( 'Left', 'ts-lms' ), 'icon' => 'eicon-text-align-left' ),
                    'center'     => array( 'title' => __( 'Center', 'ts-lms' ), 'icon' => 'eicon-text-align-center' ),
                    'flex-end'   => array( 'title' => __( 'Right', 'ts-lms' ), 'icon' => 'eicon-text-align-right' ),
                ),
                'default'   => 'flex-start',
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-categories-wrapper' => 'align-items: {{VALUE}};',
                ),
                'condition' => array(
                    'layout' => 'column',
                ),
            )
        );

        $this->add_responsive_control(
            'gap',
            array(
                'label'      => __( 'Gap', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'range'      => array(
                    'px' => array( 'min' => 0, 'max' => 50 ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-categories-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'text_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-single-cat' => 'color: {{VALUE}};',
                ),
                'separator' => 'before',
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'typography',
                'selector' => '{{WRAPPER}} .ts-single-cat',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;

        $terms = get_the_terms( $course_id, 'ts_course_category' );

        if ( empty( $terms ) || is_wp_error( $terms ) ) {
            return;
        }

        echo '<div class="ts-course-categories-wrapper">';
        foreach ( $terms as $term ) {
            echo '<a href="' . esc_url( get_term_link( $term ) ) . '" class="ts-single-cat">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div>';
    }
}
