<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Instructors extends Base_Widget {
    public function get_name() { return 'ts-course-instructors'; }
    public function get_title() { return __( 'Course Instructors', 'ts-lms' ); }
    public function get_icon() { return 'eicon-users'; }

    protected function register_controls() {
        // --- Content Controls ---
        $this->start_controls_section(
            'section_content',
            array(
                'label' => __( 'About the Instructor', 'ts-lms' ),
            )
        );

        $this->add_control(
            'title_text',
            array(
                'label'       => __( 'Title', 'ts-lms' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __( 'A course by', 'ts-lms' ),
                'placeholder' => __( 'Enter title here', 'ts-lms' ),
            )
        );

        $this->add_control(
            'show_avatar',
            array(
                'label'   => __( 'Profile Picture', 'ts-lms' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );

        $this->add_control(
            'show_name',
            array(
                'label'   => __( 'Display Name', 'ts-lms' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );

        $this->add_control(
            'show_designation',
            array(
                'label'   => __( 'Designation', 'ts-lms' ),
                'type'    => Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );

        $this->add_control(
            'link_target',
            array(
                'label'   => __( 'Link Target', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '_self',
                'options' => array(
                    '_self'  => __( 'Same Window', 'ts-lms' ),
                    '_blank' => __( 'New Window', 'ts-lms' ),
                ),
            )
        );

        $this->end_controls_section();

        // --- Style: Container ---
        $this->start_controls_section(
            'section_style_container',
            array(
                'label' => __( 'Container Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'container_gap',
            array(
                'label'      => __( 'Items Gap', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-instructor-card' => 'gap: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'container_padding',
            array(
                'label'      => __( 'Padding', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-instructor-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            array(
                'name'     => 'container_bg',
                'selector' => '{{WRAPPER}} .ts-instructor-card',
            )
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name'     => 'container_border',
                'selector' => '{{WRAPPER}} .ts-instructor-card',
            )
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'container_shadow',
                'selector' => '{{WRAPPER}} .ts-instructor-card',
            )
        );

        $this->add_responsive_control(
            'container_radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-instructor-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();

        // --- Style: Title ---
        $this->start_controls_section(
            'section_style_title',
            array(
                'label' => __( 'Title Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'title_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-instructor-title' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .ts-instructor-title',
            )
        );

        $this->add_responsive_control(
            'title_margin',
            array(
                'label'      => __( 'Margin', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-instructor-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();

        // --- Style: Avatar ---
        $this->start_controls_section(
            'section_style_avatar',
            array(
                'label'     => __( 'Avatar Style', 'ts-lms' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => array( 'show_avatar' => 'yes' ),
            )
        );

        $this->add_responsive_control(
            'avatar_size',
            array(
                'label'      => __( 'Size', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array( 'px' => array( 'min' => 20, 'max' => 200 ) ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-instructor-avatar img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'avatar_radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-instructor-avatar img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();

        // --- Style: Info (Name/Designation) ---
        $this->start_controls_section(
            'section_style_info',
            array(
                'label' => __( 'Name & Bio', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'name_color',
            array(
                'label'     => __( 'Name Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-instructor-name' => 'color: {{VALUE}};',
                ),
                'condition' => array( 'show_name' => 'yes' ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'      => 'name_typography',
                'selector'  => '{{WRAPPER}} .ts-instructor-name',
                'condition' => array( 'show_name' => 'yes' ),
            )
        );

        $this->add_control(
            'designation_color',
            array(
                'label'     => __( 'Designation Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-instructor-bio' => 'color: {{VALUE}};',
                ),
                'condition' => array( 'show_designation' => 'yes' ),
                'separator' => 'before',
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'      => 'designation_typography',
                'selector'  => '{{WRAPPER}} .ts-instructor-bio',
                'condition' => array( 'show_designation' => 'yes' ),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        $author_id = get_post_field('post_author', $course_id);
        $user = get_userdata($author_id);
        
        if ( ! $user ) return;

        $settings = $this->get_settings_for_display();
        $author_url = get_author_posts_url($author_id);

        echo '<div class="ts-instructor-wrapper">';
        
        // Title
        if ( ! empty( $settings['title_text'] ) ) {
            echo '<div class="ts-instructor-title">' . esc_html( $settings['title_text'] ) . '</div>';
        }

        // Card Wrapper with Link
        // If we want the whole card clickable or just parts of it. 
        // Typically name and image are linked. Let's make the card structure clean.
        
        echo '<div class="ts-instructor-card" style="display: flex; align-items: center; gap: 15px;">';
        
        // Avatar
        if ( 'yes' === $settings['show_avatar'] ) {
            echo '<a href="' . esc_url($author_url) . '" class="ts-instructor-avatar" target="' . esc_attr($settings['link_target']) . '">';
            echo get_avatar($author_id, 96);
            echo '</a>';
        }

        // Info
        echo '<div class="ts-instructor-info">';
        
        if ( 'yes' === $settings['show_name'] ) {
            echo '<a href="' . esc_url($author_url) . '" class="ts-instructor-name-link" style="text-decoration: none;" target="' . esc_attr($settings['link_target']) . '">';
            echo '<h4 class="ts-instructor-name" style="margin: 0;">' . esc_html($user->display_name) . '</h4>';
            echo '</a>';
        }

        if ( 'yes' === $settings['show_designation'] ) {
            // Usually 'description' is used for bio in WP
            $bio = get_user_meta($author_id, 'description', true);
            if ( ! empty( $bio ) ) {
                // Truncate or show simplified bio? Designation is usually short title.
                // Assuming description might be long, but requested as 'Designation', let's show a short snippet or custom field if available.
                // WP doesn't have a standard 'Job Title' field unless creating one. 
                // We will use description but keep it short or just display raw since user controls typography.
                echo '<div class="ts-instructor-bio" style="margin-top: 5px;">' . wp_kses_post($bio) . '</div>';
            }
        }
        
        echo '</div>'; // .ts-instructor-info
        echo '</div>'; // .ts-instructor-card
        echo '</div>'; // .ts-instructor-wrapper
    }
}
