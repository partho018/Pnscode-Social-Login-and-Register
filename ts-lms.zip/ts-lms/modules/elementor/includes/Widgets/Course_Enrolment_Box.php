<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Enrolment_Box extends Base_Widget {
    public function get_name() { return 'ts-course-enrolment-box'; }
    public function get_title() { return __( 'Course Enrolment Box', 'ts-lms' ); }
    public function get_icon() { return 'eicon-sidebar'; }

    protected function register_controls() {
        $this->start_controls_section( 'section_style', array( 'label' => __( 'Style', 'ts-lms' ), 'tab' => Controls_Manager::TAB_STYLE ) );
        $this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'border', 'selector' => '{{WRAPPER}} .ts-enrol-box' ) );
        $this->add_group_control( Group_Control_Box_Shadow::get_type(), array( 'name' => 'box_shadow', 'selector' => '{{WRAPPER}} .ts-enrol-box' ) );
        $this->add_control( 'bg_color', array( 'label' => __( 'Background Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'default' => '#ffffff', 'selectors' => array( '{{WRAPPER}} .ts-enrol-box' => 'background-color: {{VALUE}};' ) ) );
        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;
        $course = $this->get_course_data($course_id);
        
        $btn_class = 'ts-btn-enroll';
        $btn_text  = esc_html__( 'Enroll now', 'ts-lms' );
        $btn_url   = get_permalink($course_id);

        if ( $course['is_enrolled'] ) {
            $btn_text  = esc_html__( 'Start Learning', 'ts-lms' );
            $btn_class .= ' ts-btn-full';
            $btn_url   = $course['first_lesson_url'] ?: get_permalink($course_id);
        } elseif ( ! is_user_logged_in() ) {
            $btn_class .= ' ts-trigger-auth-modal';
            $btn_url    = 'javascript:void(0);';
        } elseif ( $course['is_in_cart'] ) {
            $btn_text  = esc_html__( 'View Card', 'ts-lms' );
            $btn_url   = wc_get_checkout_url();
        } else {
            if ( ! empty( $course['product_id'] ) ) {
                $btn_url = wc_get_checkout_url() . '?add-to-cart=' . $course['product_id'];
            }
        }
        ?>
        <div class="ts-enrol-box" style="padding: 30px; border-radius: 12px; border: 1px solid #e2e8f0; background: #fff;">
            <div class="ts-box-price" style="font-size: 32px; font-weight: 800; color: #1e293b; margin-bottom: 20px;">
                <?php echo $course['is_free'] ? __('Free', 'ts-lms') : number_format($course['price'], 2) . '৳'; ?>
            </div>
            
            <a href="<?php echo esc_url($btn_url); ?>" class="<?php echo esc_attr($btn_class); ?>" style="display: block; width: 100%; text-align: center; padding: 15px; background: #4f46e5; color: #fff; border-radius: 8px; font-weight: 700; text-decoration: none; margin-bottom: 25px;">
                <?php echo $btn_text; ?>
            </a>

            <div class="ts-box-meta" style="border-top: 1px solid #f1f5f9; padding-top: 20px;">
                <h5 style="margin: 0 0 15px; font-size: 16px; font-weight: 600;"><?php _e('This course includes:', 'ts-lms'); ?></h5>
                <ul style="list-style: none; padding: 0; margin: 0; display: grid; gap: 12px; font-size: 14px;">
                    <li style="display: flex; align-items: center; gap: 10px;"><span class="dashicons dashicons-clock"></span> <?php echo $course['duration_hours']; ?>h Duration</li>
                    <li style="display: flex; align-items: center; gap: 10px;"><span class="dashicons dashicons-welcome-learn-more"></span> <?php echo $course['lesson_count']; ?> Lessons</li>
                    <li style="display: flex; align-items: center; gap: 10px;"><span class="dashicons dashicons-awards"></span> Certificate of Completion</li>
                    <li style="display: flex; align-items: center; gap: 10px;"><span class="dashicons dashicons-admin-generic"></span> Full Lifetime Access</li>
                </ul>
            </div>
        </div>
        <?php
    }
}
