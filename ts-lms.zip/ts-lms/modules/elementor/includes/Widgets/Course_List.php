<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_List extends Course_Card_Wrapper {
    public function get_name() { return 'ts-course-list-simple'; }
    public function get_title() { return __( 'Course List', 'ts-lms' ); }
    public function get_icon() { return 'eicon-post-list'; }

    protected function render() {
        $settings = $this->get_settings_for_display();
        echo '<div class="ts-course-list-view">';
        parent::render();
        echo '</div>';
        echo '<style>.ts-course-list-view .ts-course-grid { grid-template-columns: 1fr !important; }</style>';
    }
}
