<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Purchase extends Base_Widget {
    public function get_name() { return 'ts-course-purchase-widget'; }
    public function get_title() { return __( 'Course Purchase', 'ts-lms' ); }
    public function get_icon() { return 'eicon-cart'; }

    protected function register_controls() {
        // --- Content Controls ---
        $this->start_controls_section(
            'section_content',
            array(
                'label' => __( 'Content', 'ts-lms' ),
            )
        );

        $this->add_control( 'show_enrolment_box', array( 'label' => __( 'Show Enrolment Box', 'ts-lms' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
        $this->add_control( 'show_price', array( 'label' => __( 'Show Price', 'ts-lms' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'condition' => array( 'show_enrolment_box' => 'yes' ) ) );
        $this->add_control( 'show_meta', array( 'label' => __( 'Show Meta', 'ts-lms' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'condition' => array( 'show_enrolment_box' => 'yes' ) ) );
        $this->add_control( 'show_course_progress', array( 'label' => __( 'Show Course Progress', 'ts-lms' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
        $this->add_control( 'show_purchase_btn', array( 'label' => __( 'Show Purchase Button', 'ts-lms' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
        $this->add_control( 'purchase_btn_text', array( 'label' => __( 'Purchase Button Text', 'ts-lms' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Enroll Now', 'ts-lms' ), 'condition' => array( 'show_purchase_btn' => 'yes' ) ) );
        $this->add_control( 'show_preview_mode', array( 'label' => __( 'Show Preview Button', 'ts-lms' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
        $this->add_control( 'preview_btn_text', array( 'label' => __( 'Preview Button Text', 'ts-lms' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Preview', 'ts-lms' ), 'condition' => array( 'show_preview_mode' => 'yes' ) ) );

        $this->end_controls_section();

        // --- Style: Box ---
        $this->start_controls_section(
            'section_style_box',
            array(
                'label'     => __( 'Box Style', 'ts-lms' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => array( 'show_enrolment_box' => 'yes' ),
            )
        );
        $this->add_group_control( \Elementor\Group_Control_Background::get_type(), array( 'name' => 'box_bg', 'selector' => '{{WRAPPER}} .ts-purchase-widget-container' ) );
        $this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'box_border', 'selector' => '{{WRAPPER}} .ts-purchase-widget-container' ) );
        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array( 'name' => 'box_shadow', 'selector' => '{{WRAPPER}} .ts-purchase-widget-container' ) );
        $this->add_responsive_control( 'box_padding', array( 'label' => __( 'Padding', 'ts-lms' ), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => array( 'px', 'em', '%' ), 'selectors' => array( '{{WRAPPER}} .ts-purchase-widget-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ) ) );
        $this->add_responsive_control( 'box_radius', array( 'label' => __( 'Border Radius', 'ts-lms' ), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => array( 'px', '%' ), 'selectors' => array( '{{WRAPPER}} .ts-purchase-widget-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ) ) );
        $this->end_controls_section();

        // --- Style: Price ---
        $this->start_controls_section(
            'section_style_price',
            array(
                'label'     => __( 'Price Style', 'ts-lms' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => array( 'show_enrolment_box' => 'yes', 'show_price' => 'yes' ),
            )
        );
        $this->add_control( 'price_color', array( 'label' => __( 'Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-box-price' => 'color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'price_typo', 'selector' => '{{WRAPPER}} .ts-box-price' ) );
        $this->add_responsive_control( 'price_align', array( 'label' => __( 'Alignment', 'ts-lms' ), 'type' => Controls_Manager::CHOOSE, 'options' => array( 'left' => array( 'title' => __( 'Left', 'ts-lms' ), 'icon' => 'eicon-text-align-left' ), 'center' => array( 'title' => __( 'Center', 'ts-lms' ), 'icon' => 'eicon-text-align-center' ), 'right' => array( 'title' => __( 'Right', 'ts-lms' ), 'icon' => 'eicon-text-align-right' ) ), 'selectors' => array( '{{WRAPPER}} .ts-box-price' => 'text-align: {{VALUE}};' ) ) );
        $this->end_controls_section();

        // --- Style: Progress ---
        $this->start_controls_section(
            'section_style_progress',
            array(
                'label'     => __( 'Progress Style', 'ts-lms' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => array( 'show_course_progress' => 'yes' ),
            )
        );
        $this->add_control( 'progress_color', array( 'label' => __( 'Bar Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-progress-fill' => 'background-color: {{VALUE}};' ) ) );
        $this->add_control( 'progress_bg', array( 'label' => __( 'Background Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-progress-bar' => 'background-color: {{VALUE}};' ) ) );
        $this->add_responsive_control( 'progress_height', array( 'label' => __( 'Height', 'ts-lms' ), 'type' => Controls_Manager::SLIDER, 'selectors' => array( '{{WRAPPER}} .ts-progress-bar' => 'height: {{SIZE}}{{UNIT}};' ) ) );
        $this->end_controls_section();

        // --- Style: Button (Purchase) ---
        $this->start_controls_section(
            'section_style_btn',
            array(
                'label'     => __( 'Purchase Button', 'ts-lms' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => array( 'show_purchase_btn' => 'yes' ),
            )
        );
        $this->start_controls_tabs( 'tabs_btn' );
        $this->start_controls_tab( 'tab_btn_normal', array( 'label' => __( 'Normal', 'ts-lms' ) ) );
        $this->add_control( 'btn_bg', array( 'label' => __( 'Background', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-btn-enroll' => 'background-color: {{VALUE}};' ) ) );
        $this->add_control( 'btn_color', array( 'label' => __( 'Text Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-btn-enroll' => 'color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'btn_border', 'selector' => '{{WRAPPER}} .ts-btn-enroll' ) );
        $this->end_controls_tab();
        $this->start_controls_tab( 'tab_btn_hover', array( 'label' => __( 'Hover', 'ts-lms' ) ) );
        $this->add_control( 'btn_bg_hover', array( 'label' => __( 'Background', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-btn-enroll:hover' => 'background-color: {{VALUE}};' ) ) );
        $this->add_control( 'btn_color_hover', array( 'label' => __( 'Text Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-btn-enroll:hover' => 'color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'btn_border_hover', 'selector' => '{{WRAPPER}} .ts-btn-enroll:hover' ) );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'btn_typo', 'selector' => '{{WRAPPER}} .ts-btn-enroll' ) );
        $this->add_responsive_control( 'btn_padding', array( 'label' => __( 'Padding', 'ts-lms' ), 'type' => Controls_Manager::DIMENSIONS, 'selectors' => array( '{{WRAPPER}} .ts-btn-enroll' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ) ) );
        $this->add_responsive_control( 'btn_radius', array( 'label' => __( 'Radius', 'ts-lms' ), 'type' => Controls_Manager::DIMENSIONS, 'selectors' => array( '{{WRAPPER}} .ts-btn-enroll' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ) ) );
        $this->end_controls_section();

        // --- Style: Preview Button ---
        $this->start_controls_section(
            'section_style_preview_btn',
            array(
                'label'     => __( 'Preview Button', 'ts-lms' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => array( 'show_preview_mode' => 'yes' ),
            )
        );
        $this->start_controls_tabs( 'tabs_preview_btn' );
        $this->start_controls_tab( 'tab_preview_btn_normal', array( 'label' => __( 'Normal', 'ts-lms' ) ) );
        $this->add_control( 'preview_btn_bg', array( 'label' => __( 'Background', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-btn-preview' => 'background-color: {{VALUE}};' ) ) );
        $this->add_control( 'preview_btn_color', array( 'label' => __( 'Text Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-btn-preview' => 'color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'preview_btn_border', 'selector' => '{{WRAPPER}} .ts-btn-preview' ) );
        $this->end_controls_tab();
        $this->start_controls_tab( 'tab_preview_btn_hover', array( 'label' => __( 'Hover', 'ts-lms' ) ) );
        $this->add_control( 'preview_btn_bg_hover', array( 'label' => __( 'Background', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-btn-preview:hover' => 'background-color: {{VALUE}};' ) ) );
        $this->add_control( 'preview_btn_color_hover', array( 'label' => __( 'Text Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-btn-preview:hover' => 'color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'preview_btn_border_hover', 'selector' => '{{WRAPPER}} .ts-btn-preview:hover' ) );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;
        $course = $this->get_course_data($course_id);
        $settings = $this->get_settings_for_display();

        $wrapper_class = 'ts-purchase-widget';
        if ( $settings['show_enrolment_box'] === 'yes' ) {
            $wrapper_class .= ' ts-purchase-widget-container';
        }

        ?>
        <div class="<?php echo esc_attr($wrapper_class); ?>">
            
            <?php if ( $settings['show_enrolment_box'] === 'yes' && $settings['show_price'] === 'yes' ) : ?>
                <div class="ts-box-price">
                    <?php echo $course['is_free'] ? __('Free', 'ts-lms') : number_format($course['price'], 2) . '৳'; ?>
                </div>
            <?php endif; ?>

            <?php 
            // Progress Bar (if enrolled)
            if ( $course['is_enrolled'] && $settings['show_course_progress'] === 'yes' ) {
                global $wpdb;
                $user_id = get_current_user_id();
                $completed = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}ts_lesson_completions WHERE user_id = %d AND course_id = %d", $user_id, $course_id ) ) ?: 0;
                $total_lessons = $course['lesson_count'] > 0 ? $course['lesson_count'] : 1;
                $percentage = min( 100, round( ($completed / $total_lessons) * 100 ) );
                ?>
                <div class="ts-course-progress">
                    <div class="ts-progress-meta">
                        <span><?php _e('Progress', 'ts-lms'); ?></span>
                        <span><?php echo $percentage; ?>%</span>
                    </div>
                    <div class="ts-progress-bar">
                        <div class="ts-progress-fill" style="width: <?php echo $percentage; ?>%;"></div>
                    </div>
                </div>
                <?php
            }
            ?>

            <?php if ( $settings['show_purchase_btn'] === 'yes' ) : 
                $btn_text = $settings['purchase_btn_text'];
                $btn_url = get_permalink($course_id);
                $btn_class = 'ts-btn-enroll';
                
                if ( $course['is_enrolled'] ) {
                    $btn_text = __('Start Learning', 'ts-lms');
                    $btn_url = $course['first_lesson_url'] ?: get_permalink($course_id);
                } elseif ( ! is_user_logged_in() ) {
                    $btn_class .= ' ts-trigger-auth-modal'; 
                    $btn_url = 'javascript:void(0);';
                } elseif ( $course['is_in_cart'] ) {
                    $btn_text = __('View Cart', 'ts-lms');
                    $btn_url = wc_get_checkout_url();
                } else {
                    if ( ! empty( $course['product_id'] ) ) {
                        $btn_url = wc_get_checkout_url() . '?add-to-cart=' . $course['product_id'];
                    }
                }
            ?>
                <a href="<?php echo esc_url($btn_url); ?>" class="<?php echo esc_attr($btn_class); ?>">
                    <?php echo esc_html($btn_text); ?>
                </a>
            <?php endif; ?>

            <?php if ( $settings['show_preview_mode'] === 'yes' ) : ?>
                <a href="#" class="ts-btn-preview">
                    <?php echo esc_html($settings['preview_btn_text']); ?>
                </a>
            <?php endif; ?>

            <?php if ( $settings['show_enrolment_box'] === 'yes' && $settings['show_meta'] === 'yes' ) : ?>
                <div class="ts-box-meta">
                    <h5 class="ts-meta-title"><?php _e('This course includes:', 'ts-lms'); ?></h5>
                    <ul class="ts-meta-list">
                        <li><span class="dashicons dashicons-clock"></span> <?php echo $course['duration_hours']; ?>h Duration</li>
                        <li><span class="dashicons dashicons-welcome-learn-more"></span> <?php echo $course['lesson_count']; ?> Lessons</li>
                        <li><span class="dashicons dashicons-awards"></span> Certificate of Completion</li>
                        <li><span class="dashicons dashicons-admin-generic"></span> Full Lifetime Access</li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>

        <style>
            /* Base Structural Styles - Overridable by Elementor Controls */
            .ts-purchase-widget { display: flex; flex-direction: column; gap: 15px; }
            .ts-purchase-widget-container { box-sizing: border-box; }
            
            .ts-box-price { font-weight: 700; font-size: 24px; }
            
            .ts-course-progress { display: flex; flex-direction: column; gap: 5px; margin-bottom: 10px; }
            .ts-progress-meta { display: flex; justify-content: space-between; font-size: 14px; color: #666; }
            .ts-progress-bar { width: 100%; height: 8px; background: #eee; border-radius: 4px; overflow: hidden; }
            .ts-progress-fill { height: 100%; background: #000; transition: width 0.3s ease; }
            
            .ts-btn-enroll, .ts-btn-preview { 
                display: flex; align-items: center; justify-content: center; 
                text-decoration: none; font-weight: 600; cursor: pointer; transition: all 0.3s ease; box-sizing: border-box;
                width: 100%; /* Default width */
            }
            
            .ts-box-meta { border-top: 1px solid #eee; padding-top: 15px; margin-top: 10px; }
            .ts-meta-title { margin: 0 0 10px; font-size: 16px; font-weight: 600; }
            .ts-meta-list { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 10px; }
            .ts-meta-list li { display: flex; align-items: center; gap: 8px; font-size: 14px; }
        </style>
        <?php
    }
}
