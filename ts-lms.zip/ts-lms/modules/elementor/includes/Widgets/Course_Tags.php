<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Tags extends Base_Widget {
    public function get_name() { return 'ts-course-tags-widget'; }
    public function get_title() { return __( 'Course Tags', 'ts-lms' ); }
    public function get_icon() { return 'eicon-tags'; }

    protected function register_controls() {
        // --- Content Controls ---
        $this->start_controls_section(
            'section_content',
            array(
                'label' => __( 'Content', 'ts-lms' ),
            )
        );

        $this->add_control(
            'title_text',
            array(
                'label'   => __( 'Title', 'ts-lms' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'Tags', 'ts-lms' ),
            )
        );

        $this->end_controls_section();

        // --- Style: Title ---
        $this->start_controls_section(
            'section_style_title',
            array(
                'label' => __( 'Title Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'title_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-tags-title' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .ts-tags-title',
            )
        );

        $this->add_responsive_control(
            'title_margin',
            array(
                'label'      => __( 'Margin', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-tags-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();

        // --- Style: Tags ---
        $this->start_controls_section(
            'section_style_tags',
            array(
                'label' => __( 'Tags Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'tags_gap',
            array(
                'label'      => __( 'Gap', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-tags-wrap' => 'gap: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'tag_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#1e293b',
                'selectors' => array(
                    '{{WRAPPER}} .ts-tag-item' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'tag_bg_color',
            array(
                'label'     => __( 'Background Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#f1f5f9',
                'selectors' => array(
                    '{{WRAPPER}} .ts-tag-item' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'tag_typography',
                'selector' => '{{WRAPPER}} .ts-tag-item',
            )
        );

        $this->add_responsive_control(
            'tag_padding',
            array(
                'label'      => __( 'Padding', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-tag-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'tag_radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-tag-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name'     => 'tag_border',
                'selector' => '{{WRAPPER}} .ts-tag-item',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        $tags = get_the_terms($course_id, 'ts_course_tag');
        
        if ( is_wp_error($tags) || empty($tags) ) return;

        $settings = $this->get_settings_for_display();

        echo '<div class="ts-course-tags-widget">';

        if ( ! empty( $settings['title_text'] ) ) {
            echo '<h4 class="ts-tags-title">' . esc_html( $settings['title_text'] ) . '</h4>';
        }

        echo '<div class="ts-tags-wrap" style="display: flex; flex-wrap: wrap; gap: 8px;">';
        foreach ($tags as $tag) {
            $tag_link = get_term_link( $tag );
            if ( is_wp_error( $tag_link ) ) {
                $tag_link = '#';
            }
            // Use <a> for better accessibility/functionality, fallback to span if previously purely visual, but <a> is standard. 
            // We'll use <a> but ensure it inherits styles properly.
            echo '<a href="' . esc_url($tag_link) . '" class="ts-tag-item" style="text-decoration: none; display: inline-flex; align-items: center; transition: all 0.3s;">' . esc_html($tag->name) . '</a>';
        }
        echo '</div>';
        echo '</div>';

        // Styling for clean defaults if no controls used yet
        ?>
        <style>
            .ts-tag-item:hover { opacity: 0.8; }
            .ts-tags-title { margin-bottom: 10px; font-weight: 600; }
        </style>
        <?php
    }
}
