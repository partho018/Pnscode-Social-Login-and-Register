<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Requirements extends Base_Widget {
    public function get_name() { return 'ts-course-requirements'; }
    public function get_title() { return __( 'Course Requirements', 'ts-lms' ); }
    public function get_icon() { return 'eicon-bullet-list'; }

    protected function register_controls() {
        // --- Content Controls ---
        $this->start_controls_section(
            'section_content',
            array(
                'label' => __( 'Content', 'ts-lms' ),
            )
        );

        $this->add_control(
            'title_text',
            array(
                'label'   => __( 'Title', 'ts-lms' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'Course Requirements', 'ts-lms' ),
            )
        );

        $this->add_control(
            'selected_icon',
            array(
                'label' => __( 'List Icon', 'ts-lms' ),
                'type' => Controls_Manager::ICONS,
                'default' => array(
                    'value' => 'fas fa-check',
                    'library' => 'fa-solid',
                ),
            )
        );

        $this->end_controls_section();

        // --- Style: Title ---
        $this->start_controls_section(
            'section_style_title',
            array(
                'label' => __( 'Title Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'title_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-requirements-title' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .ts-requirements-title',
            )
        );

        $this->add_responsive_control(
            'title_margin',
            array(
                'label'      => __( 'Margin', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-requirements-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();

        // --- Style: List & Icon ---
        $this->start_controls_section(
            'section_style_list',
            array(
                'label' => __( 'List & Icon Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'list_gap',
            array(
                'label'      => __( 'List Item Gap', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-requirements-list' => 'display: flex; flex-direction: column; gap: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ts-requirements-list li' => 'margin-bottom: {{SIZE}}{{UNIT}};', // Fallback
                ),
            )
        );

        $this->add_control(
            'list_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-requirements-list' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .ts-requirements-list li' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'list_typography',
                'selector' => '{{WRAPPER}} .ts-requirements-list, {{WRAPPER}} .ts-requirements-list li',
            )
        );

        $this->add_control(
            'heading_icon',
            array(
                'label'     => __( 'Icon Style', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_control(
            'icon_color',
            array(
                'label'     => __( 'Icon Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-requirement-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
                    '{{WRAPPER}} .ts-requirements-list li i' => 'color: {{VALUE}};', // Fallback
                ),
            )
        );

        $this->add_responsive_control(
            'icon_size',
            array(
                'label'      => __( 'Icon Size', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'selectors'  => array(
                    '{{WRAPPER}} .ts-requirement-icon' => 'font-size: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ts-requirement-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: auto;',
                ),
            )
        );

        $this->add_responsive_control(
            'icon_gap',
            array(
                'label'      => __( 'Icon Gap', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'selectors'  => array(
                    '{{WRAPPER}} .ts-requirements-list li' => 'gap: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ts-requirement-icon' => 'margin-right: {{SIZE}}{{UNIT}};', // Fallback
                ),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        $requirements = get_post_meta($course_id, '_requirements_instructions', true);
        
        if ( empty($requirements) ) return;

        $settings = $this->get_settings_for_display();

        echo '<div class="ts-course-requirements-widget">';

        if ( ! empty( $settings['title_text'] ) ) {
            echo '<h4 class="ts-requirements-title">' . esc_html( $settings['title_text'] ) . '</h4>';
        }

        // Logic: Aggressively clean and normalize the content into a list of items
        
        // 1. Decode entities
        $clean_reqs = html_entity_decode( $requirements );

        // 2. Normalize line endings
        $clean_reqs = str_replace( array( "\r\n", "\r" ), PHP_EOL, $clean_reqs );

        // 3. Convert block-level HTML tags to line breaks
        $clean_reqs = str_ireplace( 
            array( '</li>', '<br>', '<br/>', '<br />', '</p>', '</div>', '</ul>', '</h1>', '</h2>', '</h3>', '</h4>', '</h5>', '</h6>' ), 
            PHP_EOL, 
            $clean_reqs 
        );
        
        // 4. Strip leftover tags
        $clean_reqs = strip_tags( $clean_reqs );
        
        // 5. Convert to array
        $raw_items = explode( PHP_EOL, $clean_reqs );
        $items = array();

        foreach ( $raw_items as $item ) {
            $text = trim( $item );
            if ( ! empty( $text ) && $text !== '&nbsp;' && $text !== "\xC2\xA0" ) {
                $items[] = $text;
            }
        }

        if ( ! empty( $items ) ) {
            echo '<ul class="ts-requirements-list" style="list-style: none; padding: 0; margin: 0;">';
            foreach ( $items as $item_text ) {
                echo '<li style="display: flex; align-items: flex-start;">';
                
                // Render Icon
                if ( ! empty( $settings['selected_icon']['value'] ) ) {
                    echo '<span class="ts-requirement-icon" style="line-height: inherit; flex-shrink: 0;">';
                    \Elementor\Icons_Manager::render_icon( $settings['selected_icon'], array( 'aria-hidden' => 'true' ) );
                    echo '</span>';
                }
                
                echo '<span class="ts-requirement-text">' . esc_html( $item_text ) . '</span>';
                echo '</li>';
            }
            echo '</ul>';
        }

        echo '</div>';
    }
}
