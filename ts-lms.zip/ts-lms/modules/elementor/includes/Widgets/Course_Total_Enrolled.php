<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Total_Enrolled extends Base_Widget {
    public function get_name() { return 'ts-course-total-enrolled-widget'; }
    public function get_title() { return __( 'Course Total Enrolled', 'ts-lms' ); }
    public function get_icon() { return 'eicon-person'; }

    protected function register_controls() {
        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'gap',
            array(
                'label'      => __( 'Gap', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'range'      => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 50,
                    ),
                ),
                'default'    => array(
                    'size' => 8,
                    'unit' => 'px',
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-single-enrolled' => 'gap: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'heading_icon',
            array(
                'label'     => __( 'Icon', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_control(
            'icon_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-enrolled-icon' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_responsive_control(
            'icon_size',
            array(
                'label'      => __( 'Size', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'range'      => array(
                    'px' => array(
                        'min' => 10,
                        'max' => 100,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-enrolled-icon' => 'font-size: {{SIZE}}{{UNIT}}; line-height: 1;',
                ),
            )
        );

        $this->add_control(
            'heading_text',
            array(
                'label'     => __( 'Text', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_control(
            'text_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-enrolled-text' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'typography',
                'selector' => '{{WRAPPER}} .ts-enrolled-text',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;
        $course = $this->get_course_data( $course_id );
        ?>
        <div class="ts-single-enrolled" style="display: flex; align-items: center;">
            <span class="ts-enrolled-icon dashicons dashicons-groups"></span>
            <span class="ts-enrolled-text"><?php printf( _n( '%s student', '%s students', $course['enrollment_count'], 'ts-lms' ), number_format_i18n( $course['enrollment_count'] ) ); ?></span>
        </div>
        <?php
    }
}
