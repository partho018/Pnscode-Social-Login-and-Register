<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Thumbnail extends Base_Widget {

    public function get_name() {
        return 'ts-course-thumbnail-widget';
    }

    public function get_title() {
        return __( 'Course Thumbnail', 'ts-lms' );
    }

    public function get_icon() {
        return 'eicon-image';
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'width',
            array(
                'label'      => __( 'Width', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', '%', 'vw' ),
                'range'      => array(
                    '%' => array(
                        'min' => 10,
                        'max' => 100,
                    ),
                    'px' => array(
                        'min' => 50,
                        'max' => 1000,
                    ),
                ),
                'default' => array(
                    'unit' => '%',
                    'size' => 100,
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-single-thumb-container' => 'width: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'image_ratio',
            array(
                'label'   => __( 'Aspect Ratio', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '16/9',
                'options' => array(
                    '16/9'   => '16:9',
                    '4/3'    => '4:3',
                    '1/1'    => '1:1',
                    '21/9'   => '21:9',
                    'auto'   => __( 'Auto', 'ts-lms' ),
                    'custom' => __( 'Custom', 'ts-lms' ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-single-thumb-container' => 'aspect-ratio: {{VALUE}};',
                ),
            )
        );

        $this->add_responsive_control(
            'image_ratio_custom',
            array(
                'label'     => __( 'Custom Ratio', 'ts-lms' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => array(
                    'px' => array(
                        'min'  => 0.1,
                        'max'  => 3,
                        'step' => 0.01,
                    ),
                ),
                'default'   => array(
                    'size' => 1.77,
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-single-thumb-container' => 'aspect-ratio: {{SIZE}};',
                ),
                'condition' => array(
                    'image_ratio' => 'custom',
                ),
            )
        );

        $this->add_control(
            'object_fit',
            array(
                'label'     => __( 'Object Fit', 'ts-lms' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'cover',
                'options'   => array(
                    'fill'    => __( 'Fill', 'ts-lms' ),
                    'cover'   => __( 'Cover', 'ts-lms' ),
                    'contain' => __( 'Contain', 'ts-lms' ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-single-thumb-container img' => 'object-fit: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'border',
                'selector' => '{{WRAPPER}} .ts-single-thumb-container img, {{WRAPPER}} .ts-single-thumb-container',
            )
        );

        $this->add_control(
            'radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-single-thumb-container img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .ts-single-thumb-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'box_shadow',
                'selector' => '{{WRAPPER}} .ts-single-thumb-container',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;

        $thumbnail = get_the_post_thumbnail_url( $course_id, 'full' ) ?: $this->get_course_data( $course_id )['thumbnail'];

        ?>
        <div class="ts-single-thumb-container" style="position: relative; overflow: hidden; width: 100%;">
            <img src="<?php echo esc_url( $thumbnail ); ?>" style="width: 100%; height: 100%; display: block;">
        </div>
        <?php
    }
}
