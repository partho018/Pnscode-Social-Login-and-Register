<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Status extends Base_Widget {
    public function get_name() { return 'ts-course-status-widget'; }
    public function get_title() { return __( 'Course Status', 'ts-lms' ); }
    public function get_icon() { return 'eicon-info-circle'; }

    protected function register_controls() {
        $this->start_controls_section( 'section_style', array( 'label' => __( 'Style', 'ts-lms' ), 'tab' => Controls_Manager::TAB_STYLE ) );
        $this->add_control( 'text_color', array( 'label' => __( 'Color', 'ts-lms' ), 'type' => Controls_Manager::COLOR, 'selectors' => array( '{{WRAPPER}} .ts-status-badge' => 'color: {{VALUE}};' ) ) );
        $this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'typography', 'selector' => '{{WRAPPER}} .ts-status-badge' ) );
        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        $status = get_post_meta($course_id, '_course_status', true) ?: 'active';
        $label = ucfirst($status);
        
        $colors = array(
            'active' => array('bg' => '#dcfce7', 'text' => '#166534'),
            'upcoming' => array('bg' => '#fef9c3', 'text' => '#854d0e'),
            'completed' => array('bg' => '#d1edff', 'text' => '#1e40af'),
        );
        $color = isset($colors[$status]) ? $colors[$status] : $colors['active'];

        echo '<span class="ts-status-badge" style="padding: 4px 12px; border-radius: 999px; font-size: 12px; font-weight: 600; background: '.esc_attr($color['bg']).'; color: '.esc_attr($color['text']).';">' . esc_html($label) . '</span>';
    }
}
