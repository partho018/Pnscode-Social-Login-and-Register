<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_Last_Update extends Base_Widget {
    public function get_name() { return 'ts-course-last-update-widget'; }
    public function get_title() { return __( 'Course Last Update', 'ts-lms' ); }
    public function get_icon() { return 'eicon-calendar'; }

    protected function register_controls() {
        $this->start_controls_section(
            'section_style',
            array(
                'label' => __( 'Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'gap',
            array(
                'label'      => __( 'Gap', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'range'      => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 50,
                    ),
                ),
                'default'    => array(
                    'size' => 8,
                    'unit' => 'px',
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-single-update' => 'gap: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'heading_icon',
            array(
                'label'     => __( 'Icon', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_control(
            'icon_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-last-update-icon' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_responsive_control(
            'icon_size',
            array(
                'label'      => __( 'Size', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'range'      => array(
                    'px' => array(
                        'min' => 10,
                        'max' => 100,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-last-update-icon' => 'font-size: {{SIZE}}{{UNIT}}; line-height: 1;',
                ),
            )
        );

        $this->add_control(
            'heading_text',
            array(
                'label'     => __( 'Text', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_control(
            'text_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-last-update-text' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'typography',
                'selector' => '{{WRAPPER}} .ts-last-update-text',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $course_id = $this->get_current_course_id();
        if ( ! $course_id ) return;
        $date = get_the_modified_date( '', $course_id );
        ?>
        <div class="ts-single-update" style="display: flex; align-items: center;">
            <span class="ts-last-update-icon dashicons dashicons-update"></span>
            <span class="ts-last-update-text"><?php printf( __( 'Last Update: %s', 'ts-lms' ), $date ); ?></span>
        </div>
        <?php
    }
}
