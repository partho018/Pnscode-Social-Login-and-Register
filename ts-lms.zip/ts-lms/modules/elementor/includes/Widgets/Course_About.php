<?php
namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Course_About extends Course_Description {
    public function get_name() { return 'ts-course-about'; }
    public function get_title() { return __( 'Course About', 'ts-lms' ); }
    public function get_icon() { return 'eicon-info-circle-o'; }
}
