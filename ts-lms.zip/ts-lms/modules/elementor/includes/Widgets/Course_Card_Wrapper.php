<?php
/**
 * Course Card Wrapper Widget
 *
 * Elementor widget for displaying course cards in grid or list layout.
 *
 * @package TS_LMS\Modules\Elementor\Widgets
 * @since 1.0.0
 */

namespace TS_LMS\Modules\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Course Card Wrapper Widget class.
 */
class Course_Card_Wrapper extends Base_Widget {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'ts-course-card-wrapper';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Course Card', 'ts-lms' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-posts-grid';
    }

    /**
     * Register widget controls.
     *
     * @return void
     */
    protected function register_controls() {
        // ===== CONTENT TAB =====
        
        // 1. LAYOUT SECTION (First)
        $this->start_controls_section(
            'section_layout',
            array(
                'label' => __( 'Layout', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'layout_type',
            array(
                'label'   => __( 'Layout Type', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'grid',
                'options' => array(
                    'grid' => __( 'Grid', 'ts-lms' ),
                    'list' => __( 'List', 'ts-lms' ),
                ),
            )
        );

        $this->add_responsive_control(
            'columns',
            array(
                'label'          => __( 'Columns', 'ts-lms' ),
                'type'           => Controls_Manager::SELECT,
                'default'        => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options'        => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ),
                'condition'      => array(
                    'layout_type' => 'grid',
                ),
                'selectors'      => array(
                    '{{WRAPPER}} .ts-course-grid' => 'grid-template-columns: repeat({{VALUE}}, 1fr);',
                ),
            )
        );

        $this->add_responsive_control(
            'column_gap',
            array(
                'label'      => __( 'Column Gap', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 100,
                    ),
                ),
                'default'    => array(
                    'size' => 25,
                    'unit' => 'px',
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-grid' => 'gap: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'equal_height',
            array(
                'label'        => __( 'Equal Height Cards', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'ts-lms' ),
                'label_off'    => __( 'No', 'ts-lms' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            )
        );

        $this->end_controls_section();

        // 2. SKIN SECTION
        $this->start_controls_section(
            'section_skin',
            array(
                'label' => __( 'Skin', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'skin_style',
            array(
                'label'   => __( 'Style', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'classic',
                'options' => array(
                    'classic' => __( 'Classic', 'ts-lms' ),
                    'modern'  => __( 'Modern', 'ts-lms' ),
                    'minimal' => __( 'Minimal', 'ts-lms' ),
                ),
            )
        );

        $this->add_control(
            'hover_animation',
            array(
                'label'   => __( 'Hover Animation', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'lift',
                'options' => array(
                    'none'      => __( 'None', 'ts-lms' ),
                    'lift'      => __( 'Lift', 'ts-lms' ),
                    'zoom'      => __( 'Zoom', 'ts-lms' ),
                    'shadow'    => __( 'Shadow', 'ts-lms' ),
                    'float'     => __( 'Float', 'ts-lms' ),
                    'sink'      => __( 'Sink', 'ts-lms' ),
                    'pulse'     => __( 'Pulse', 'ts-lms' ),
                    'rotate'    => __( 'Rotate', 'ts-lms' ),
                    'skew'      => __( 'Skew', 'ts-lms' ),
                    'grayscale' => __( 'Grayscale Reveal', 'ts-lms' ),
                ),
            )
        );

        $this->add_control(
            'show_image',
            array(
                'label'        => __( 'Show Image', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'image_resolution',
            array(
                'label'     => __( 'Image Resolution', 'ts-lms' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'large',
                'options'   => array(
                    'thumbnail' => __( 'Thumbnail (150x150)', 'ts-lms' ),
                    'medium'    => __( 'Medium (300x300)', 'ts-lms' ),
                    'large'     => __( 'Large (1024x1024)', 'ts-lms' ),
                    'full'      => __( 'Full', 'ts-lms' ),
                ),
                'condition' => array(
                    'show_image' => 'yes',
                ),
            )
        );

        $this->add_control(
            'image_aspect_ratio',
            array(
                'label'     => __( 'Image Aspect Ratio', 'ts-lms' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'aspect-16-9',
                'options'   => array(
                    'aspect-1-1'  => __( '1:1 (Square)', 'ts-lms' ),
                    'aspect-4-3'  => __( '4:3 (Classic)', 'ts-lms' ),
                    'aspect-16-9' => __( '16:9 (Widescreen)', 'ts-lms' ),
                    'aspect-none' => __( 'Original', 'ts-lms' ),
                ),
                'condition' => array(
                    'show_image' => 'yes',
                ),
            )
        );

        $this->add_control(
            'masonry_layout',
            array(
                'label'        => __( 'Masonry Layout', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'return_value' => 'yes',
                'description'  => __( 'Enable masonry grid layout (variable heights)', 'ts-lms' ),
            )
        );

        $this->end_controls_section();

        // 3. CONTENT ELEMENTS SECTION
        $this->start_controls_section(
            'section_content_elements',
            array(
                'label' => __( 'Content Elements', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'show_rating',
            array(
                'label'        => __( 'Rating', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_avatar',
            array(
                'label'        => __( 'Avatar', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_author',
            array(
                'label'        => __( 'Author', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_category',
            array(
                'label'        => __( 'Category', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_difficulty',
            array(
                'label'        => __( 'Difficulty Level', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_meta_data',
            array(
                'label'        => __( 'Meta Data (Duration, Students)', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_wishlist',
            array(
                'label'        => __( 'Wishlist Button', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_footer',
            array(
                'label'        => __( 'Footer (Price & Button)', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->end_controls_section();

        // 4. QUERY SECTION (2nd to last)
        $this->start_controls_section(
            'section_query',
            array(
                'label' => __( 'Query', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'course_selection',
            array(
                'label'   => __( 'Course Selection', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'auto',
                'options' => array(
                    'auto'   => __( 'Automatic', 'ts-lms' ),
                    'manual' => __( 'Manual (IDs)', 'ts-lms' ),
                ),
            )
        );

        $this->add_control(
            'course_ids',
            array(
                'label'       => __( 'Course IDs', 'ts-lms' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'e.g. 23, 45, 67', 'ts-lms' ),
                'description' => __( 'Enter course IDs separated by commas', 'ts-lms' ),
                'condition'   => array(
                    'course_selection' => 'manual',
                ),
            )
        );

        $this->add_control(
            'posts_per_page',
            array(
                'label'     => __( 'Posts Per Page', 'ts-lms' ),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 6,
                'min'       => 1,
                'max'       => 100,
                'condition' => array(
                    'course_selection' => 'auto',
                ),
            )
        );

        $this->add_control(
            'filter_categories',
            array(
                'label'       => __( 'Categories', 'ts-lms' ),
                'type'        => Controls_Manager::SELECT2,
                'multiple'    => true,
                'options'     => $this->get_course_categories(),
                'description' => __( 'Select categories to filter courses (leave empty for all)', 'ts-lms' ),
                'condition'   => array(
                    'course_selection' => 'auto',
                ),
            )
        );

        $this->add_control(
            'filter_authors',
            array(
                'label'       => __( 'Authors', 'ts-lms' ),
                'type'        => Controls_Manager::SELECT2,
                'multiple'    => true,
                'options'     => $this->get_course_authors(),
                'description' => __( 'Select authors to filter courses (leave empty for all)', 'ts-lms' ),
                'condition'   => array(
                    'course_selection' => 'auto',
                ),
            )
        );

        $this->add_control(
            'orderby',
            array(
                'label'     => __( 'Order By', 'ts-lms' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'date',
                'options'   => array(
                    'date'          => __( 'Date', 'ts-lms' ),
                    'title'         => __( 'Title', 'ts-lms' ),
                    'author'        => __( 'Author', 'ts-lms' ),
                    'modified'      => __( 'Last Modified', 'ts-lms' ),
                    'rand'          => __( 'Random', 'ts-lms' ),
                    'menu_order'    => __( 'Menu Order', 'ts-lms' ),
                    'comment_count' => __( 'Most Reviewed', 'ts-lms' ),
                ),
                'condition' => array(
                    'course_selection' => 'auto',
                ),
            )
        );

        $this->add_control(
            'order',
            array(
                'label'     => __( 'Order', 'ts-lms' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'DESC',
                'options'   => array(
                    'ASC'  => __( 'Ascending (A-Z, 0-9, Old to New)', 'ts-lms' ),
                    'DESC' => __( 'Descending (Z-A, 9-0, New to Old)', 'ts-lms' ),
                ),
                'condition' => array(
                    'course_selection' => 'auto',
                ),
            )
        );

        $this->end_controls_section();

        // 5. PAGINATION SECTION (Last)
        $this->start_controls_section(
            'section_pagination',
            array(
                'label' => __( 'Pagination', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'show_pagination',
            array(
                'label'        => __( 'Enable Pagination', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'pagination_type',
            array(
                'label'     => __( 'Pagination Type', 'ts-lms' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'numbers',
                'options'   => array(
                    'numbers'   => __( 'Numbers', 'ts-lms' ),
                    'prev_next' => __( 'Previous/Next', 'ts-lms' ),
                    'load_more' => __( 'Load More Button', 'ts-lms' ),
                ),
                'condition' => array(
                    'show_pagination' => 'yes',
                ),
            )
        );

        $this->end_controls_section();

        // ===== STYLE TAB =====

        // Card Designs (New requested section)
        $this->start_controls_section(
            'section_card_designs',
            array(
                'label' => __( 'Card Designs', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'card_design_preset',
            array(
                'label'   => __( 'Choose Design Template', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'design-1',
                'options' => array(
                    'design-1'  => __( 'Style 1', 'ts-lms' ),
                    'design-2'  => __( 'Style 2', 'ts-lms' ),
                    'design-3'  => __( 'Style 3', 'ts-lms' ),
                    'design-4'  => __( 'Style 4', 'ts-lms' ),
                    'design-5'  => __( 'Style 5', 'ts-lms' ),
                    'design-6'  => __( 'Style 6', 'ts-lms' ),
                    'design-7'  => __( 'Style 7', 'ts-lms' ),
                    'design-8'  => __( 'Style 8', 'ts-lms' ),
                    'design-9'  => __( 'Style 9', 'ts-lms' ),
                    'design-10' => __( 'Style 10', 'ts-lms' ),
                ),
            )
        );

        $this->end_controls_section();

        // Card Style (General adjustments)
        $this->start_controls_section(
            'section_card_style',
            array(
                'label' => __( 'Card Style', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'card_padding',
            array(
                'label'      => __( 'Padding', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-card-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'card_margin',
            array(
                'label'      => __( 'Margin', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-card' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'card_border_radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'card_border',
                'selector' => '{{WRAPPER}} .ts-course-card',
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'card_box_shadow',
                'selector' => '{{WRAPPER}} .ts-course-card',
            )
        );

        $this->add_control(
            'card_background',
            array(
                'label'     => __( 'Background Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-card' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'card_separator',
            array(
                'label'     => __( 'Body Separator', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_control(
            'show_separator',
            array(
                'label'        => __( 'Show Separator Line', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'ts-lms' ),
                'label_off'    => __( 'Hide', 'ts-lms' ),
                'return_value' => 'yes',
                'default'      => 'no',
            )
        );

        $this->add_control(
            'separator_color',
            array(
                'label'     => __( 'Separator Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#e2e8f0',
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-card-body > *:not(:last-child)' => 'border-bottom: 1px solid {{VALUE}}; padding-bottom: 15px; margin-bottom: 15px;',
                ),
                'condition' => array(
                    'show_separator' => 'yes',
                ),
            )
        );

        $this->end_controls_section();

        // 3. TITLE STYLE SECTION
        $this->start_controls_section(
            'section_title_style',
            array(
                'label' => __( 'Title', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'title_alignment',
            array(
                'label'     => __( 'Alignment', 'ts-lms' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => array(
                    'left'   => array(
                        'title' => __( 'Left', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-left',
                    ),
                    'center' => array(
                        'title' => __( 'Center', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-center',
                    ),
                    'right'  => array(
                        'title' => __( 'Right', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-right',
                    ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-title' => 'text-align: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'title_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-title a' => 'color: {{VALUE}}; text-decoration: none;',
                ),
            )
        );

        $this->add_control(
            'title_hover_color',
            array(
                'label'     => __( 'Hover Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-title a:hover' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .ts-course-title a',
            )
        );

        $this->add_responsive_control(
            'title_padding',
            array(
                'label'      => __( 'Padding', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'title_margin',
            array(
                'label'      => __( 'Margin', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'default'    => array(
                    'bottom' => '15',
                    'unit'   => 'px',
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'title_bg_color',
            array(
                'label'     => __( 'Background Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-title' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'title_border',
                'selector' => '{{WRAPPER}} .ts-course-title',
            )
        );

        $this->add_responsive_control(
            'title_radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();

        // 4. RATING STYLE SECTION
        $this->start_controls_section(
            'section_rating_style',
            array(
                'label' => __( 'Rating', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_responsive_control(
            'rating_alignment',
            array(
                'label'     => __( 'Alignment', 'ts-lms' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => array(
                    'flex-start' => array(
                        'title' => __( 'Left', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-left',
                    ),
                    'center'     => array(
                        'title' => __( 'Center', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-center',
                    ),
                    'flex-end'   => array(
                        'title' => __( 'Right', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-right',
                    ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-rating' => 'justify-content: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'star_size',
            array(
                'label'      => __( 'Icon Size', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px', 'em' ),
                'range'      => array(
                    'px' => array(
                        'min' => 10,
                        'max' => 50,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-rating .dashicons' => 'font-size: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'star_color',
            array(
                'label'     => __( 'Filled Star Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#f59e0b',
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-rating .dashicons-star-filled' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'rating_text_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-rating-value, {{WRAPPER}} .ts-rating-count' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'rating_typography',
                'selector' => '{{WRAPPER}} .ts-rating-value, {{WRAPPER}} .ts-rating-count',
            )
        );

        $this->end_controls_section();

        // 5. CONTENT ELEMENTS STYLE SECTION
        $this->start_controls_section(
            'section_elements_style',
            array(
                'label' => __( 'Content Elements', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'elements_layout',
            array(
                'label'     => __( 'Display Layout', 'ts-lms' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'flex',
                'options'   => array(
                    'flex' => __( 'Inline (Auto-wrap)', 'ts-lms' ),
                    'grid' => __( 'Grid (3 Columns)', 'ts-lms' ),
                    'stacked' => __( 'Stacked (Vertical)', 'ts-lms' ),
                ),
                'prefix_class' => 'ts-elements-layout-',
                'selectors' => array(
                    '{{WRAPPER}}.ts-elements-layout-flex .ts-course-meta-row, {{WRAPPER}}.ts-elements-layout-flex .ts-course-stats' => 'display: flex; flex-wrap: wrap;',
                    '{{WRAPPER}}.ts-elements-layout-grid .ts-course-meta-row, {{WRAPPER}}.ts-elements-layout-grid .ts-course-stats' => 'display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;',
                    '{{WRAPPER}}.ts-elements-layout-stacked .ts-course-meta-row, {{WRAPPER}}.ts-elements-layout-stacked .ts-course-stats' => 'display: flex; flex-direction: column; align-items: flex-start;',
                ),
            )
        );

        $this->add_responsive_control(
            'elements_column_gap',
            array(
                'label'     => __( 'Horizontal Gap', 'ts-lms' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 50,
                    ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-meta-row, {{WRAPPER}} .ts-course-stats' => 'column-gap: {{SIZE}}{{UNIT}};',
                ),
                'condition' => array(
                    'elements_layout' => array( 'flex', 'grid' ),
                ),
            )
        );

        $this->add_responsive_control(
            'elements_row_gap',
            array(
                'label'     => __( 'Vertical Gap', 'ts-lms' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 50,
                    ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-meta-row, {{WRAPPER}} .ts-course-stats' => 'row-gap: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.ts-elements-layout-stacked .ts-meta-item, {{WRAPPER}}.ts-elements-layout-stacked .ts-stat-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'elements_alignment',
            array(
                'label'     => __( 'Alignment', 'ts-lms' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => array(
                    'flex-start' => array(
                        'title' => __( 'Left', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-left',
                    ),
                    'center'     => array(
                        'title' => __( 'Center', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-center',
                    ),
                    'flex-end'   => array(
                        'title' => __( 'Right', 'ts-lms' ),
                        'icon'  => 'eicon-text-align-right',
                    ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-meta-row, {{WRAPPER}} .ts-course-author-wrapper, {{WRAPPER}} .ts-course-stats' => 'justify-content: {{VALUE}};',
                    '{{WRAPPER}}.ts-elements-layout-stacked .ts-course-meta-row, {{WRAPPER}}.ts-elements-layout-stacked .ts-course-stats' => 'align-items: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'elements_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-meta-item, {{WRAPPER}} .ts-author-info, {{WRAPPER}} .ts-stat-item' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .ts-meta-item .dashicons, {{WRAPPER}} .ts-stat-item .dashicons' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'elements_typography',
                'selector' => '{{WRAPPER}} .ts-meta-item, {{WRAPPER}} .ts-author-info, {{WRAPPER}} .ts-stat-item',
            )
        );

        $this->add_control(
            'icon_scale',
            array(
                'label'      => __( 'Icon Size', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array(
                    'px' => array(
                        'min' => 10,
                        'max' => 30,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-meta-item .dashicons, {{WRAPPER}} .ts-stat-item .dashicons' => 'font-size: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'elements_box_heading',
            array(
                'label'     => __( 'Box Style', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_responsive_control(
            'elements_padding',
            array(
                'label'      => __( 'Padding', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-meta-row, {{WRAPPER}} .ts-course-stats' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'elements_border',
                'selector' => '{{WRAPPER}} .ts-course-meta-row, {{WRAPPER}} .ts-course-stats',
            )
        );

        $this->end_controls_section();

        // 6. FOOTER/ACTION STYLE SECTION
        $this->start_controls_section(
            'section_footer_style',
            array(
                'label' => __( 'Footer & Action', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'price_heading',
            array(
                'label'     => __( 'Price', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
            )
        );

        $this->add_control(
            'price_color',
            array(
                'label'     => __( 'Price Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-price' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'price_typography',
                'selector' => '{{WRAPPER}} .ts-course-price',
            )
        );

        $this->add_control(
            'button_heading',
            array(
                'label'     => __( 'Button', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->start_controls_tabs( 'tabs_button_style' );

        $this->start_controls_tab(
            'tab_button_normal',
            array(
                'label' => __( 'Normal', 'ts-lms' ),
            )
        );

        $this->add_control(
            'button_bg_color',
            array(
                'label'     => __( 'Background Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-btn-enroll' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'button_text_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-btn-enroll' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'button_border',
                'selector' => '{{WRAPPER}} .ts-btn-enroll',
            )
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_button_hover',
            array(
                'label' => __( 'Hover', 'ts-lms' ),
            )
        );

        $this->add_control(
            'button_bg_color_hover',
            array(
                'label'     => __( 'Background Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-btn-enroll:hover' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'button_text_color_hover',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-btn-enroll:hover' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'button_border_color_hover',
            array(
                'label'     => __( 'Border Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-btn-enroll:hover' => 'border-color: {{VALUE}};',
                ),
            )
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'button_radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-btn-enroll' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
                'separator'  => 'before',
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'button_typography',
                'selector' => '{{WRAPPER}} .ts-btn-enroll',
            )
        );

        $this->add_control(
            'footer_box_heading',
            array(
                'label'     => __( 'Footer Container Style', 'ts-lms' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );

        $this->add_responsive_control(
            'footer_padding',
            array(
                'label'      => __( 'Padding', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-card-footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_responsive_control(
            'footer_margin',
            array(
                'label'      => __( 'Margin', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-card-footer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'footer_bg_color',
            array(
                'label'     => __( 'Background Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ts-course-card-footer' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'footer_border',
                'selector' => '{{WRAPPER}} .ts-course-card-footer',
            )
        );

        $this->add_responsive_control(
            'footer_radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-course-card-footer' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();

        // 7. DIFFICULTY STYLE SECTION
        $this->start_controls_section(
            'section_difficulty_style',
            array(
                'label' => __( 'Difficulty Badge', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'difficulty_position',
            array(
                'label'   => __( 'Position', 'ts-lms' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'top-left',
                'options' => array(
                    'top-left'     => __( 'Top Left', 'ts-lms' ),
                    'top-right'    => __( 'Top Right', 'ts-lms' ),
                    'bottom-left'  => __( 'Bottom Left', 'ts-lms' ),
                    'bottom-right' => __( 'Bottom Right', 'ts-lms' ),
                ),
                'selectors' => array(
                    '{{WRAPPER}} .ts-difficulty-badge' => 'top: auto; bottom: auto; left: auto; right: auto;',
                ),
            )
        );

        $this->add_control(
            'difficulty_bg_color',
            array(
                'label'     => __( 'Background Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#4f46e5',
                'selectors' => array(
                    '{{WRAPPER}} .ts-difficulty-badge' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'difficulty_text_color',
            array(
                'label'     => __( 'Text Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => array(
                    '{{WRAPPER}} .ts-difficulty-badge' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'difficulty_typography',
                'selector' => '{{WRAPPER}} .ts-difficulty-badge',
            )
        );

        $this->add_responsive_control(
            'difficulty_padding',
            array(
                'label'      => __( 'Padding', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'default'    => array(
                    'top'      => '6',
                    'bottom'   => '6',
                    'left'     => '12',
                    'right'    => '12',
                    'unit'     => 'px',
                    'isLinked' => false,
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-difficulty-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->add_control(
            'difficulty_radius',
            array(
                'label'      => __( 'Border Radius', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'default'    => array(
                    'top'      => '6',
                    'bottom'   => '6',
                    'left'     => '6',
                    'right'    => '6',
                    'unit'     => 'px',
                    'isLinked' => true,
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-difficulty-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();

        // 8. FOOTER SEPARATOR STYLE SECTION
        $this->start_controls_section(
            'section_footer_separator_style',
            array(
                'label' => __( 'Footer Separator', 'ts-lms' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'show_footer_separator',
            array(
                'label'        => __( 'Show Separator', 'ts-lms' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'ts-lms' ),
                'label_off'    => __( 'Hide', 'ts-lms' ),
                'return_value' => 'yes',
                'default'      => 'no',
            )
        );

        $this->add_control(
            'footer_separator_color',
            array(
                'label'     => __( 'Color', 'ts-lms' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#e2e8f0',
                'selectors' => array(
                    '{{WRAPPER}} .ts-footer-separator' => 'border-top-color: {{VALUE}};',
                ),
                'condition' => array(
                    'show_footer_separator' => 'yes',
                ),
            )
        );

        $this->add_responsive_control(
            'footer_separator_thickness',
            array(
                'label'      => __( 'Thickness (Width)', 'ts-lms' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array( 'px' ),
                'range'      => array(
                    'px' => array(
                        'min' => 1,
                        'max' => 10,
                    ),
                ),
                'default'    => array(
                    'size' => 1,
                    'unit' => 'px',
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-footer-separator' => 'border-top-width: {{SIZE}}{{UNIT}};',
                ),
                'condition' => array(
                    'show_footer_separator' => 'yes',
                ),
            )
        );

        $this->add_responsive_control(
            'footer_separator_padding',
            array(
                'label'      => __( 'Vertical Spacing (Padding)', 'ts-lms' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', 'em', '%' ),
                'allowed_dimensions' => array( 'top', 'bottom' ),
                'default'    => array(
                    'top'    => '20',
                    'bottom' => '20',
                    'unit'   => 'px',
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ts-footer-separator' => 'padding-top: {{TOP}}{{UNIT}}; padding-bottom: {{BOTTOM}}{{UNIT}};',
                ),
                'condition' => array(
                    'show_footer_separator' => 'yes',
                ),
            )
        );

        $this->end_controls_section();
    }

    /**
     * Render widget output on the frontend.
     *
     * @return void
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        // Query arguments
        $args = array(
            'post_type'      => 'ts_course',
            'post_status'    => 'publish',
            'posts_per_page' => 6, // Sane default
        );

        // Manual selection
        if ( $settings['course_selection'] === 'manual' && ! empty( $settings['course_ids'] ) ) {
            $ids = array_map( 'trim', explode( ',', $settings['course_ids'] ) );
            $args['post__in'] = $ids;
            $args['orderby'] = 'post__in';
        } else {
            // Automatic selection
            $args['posts_per_page'] = $settings['posts_per_page'];
            $args['orderby'] = $settings['orderby'];
            $args['order'] = $settings['order'];
            
            // Category filter
            if ( ! empty( $settings['filter_categories'] ) ) {
                $args['tax_query'] = array(
                    array(
                        'taxonomy' => 'ts_course_category',
                        'field'    => 'term_id',
                        'terms'    => $settings['filter_categories'],
                    ),
                );
            }
            
            // Author filter
            if ( ! empty( $settings['filter_authors'] ) ) {
                $args['author__in'] = $settings['filter_authors'];
            }
        }

        $courses = new \WP_Query( $args );

        // Grid classes
        $grid_classes = array( 'ts-course-grid' );
        
        // Skin style
        $grid_classes[] = 'skin-' . $settings['skin_style'];
        
        // Card Design Preset
        if ( ! empty( $settings['card_design_preset'] ) ) {
            $grid_classes[] = 'ts-' . $settings['card_design_preset'];
        }
        
        // Layout type
        if ( $settings['layout_type'] === 'list' ) {
            $grid_classes[] = 'ts-layout-list';
        }

        // Equal height
        if ( $settings['equal_height'] === 'yes' ) {
            $grid_classes[] = 'ts-equal-height';
        }

        // Hover animation
        if ( ! empty( $settings['hover_animation'] ) && $settings['hover_animation'] !== 'none' ) {
            $grid_classes[] = 'hover-' . $settings['hover_animation'];
        }
        
        // Masonry layout
        if ( $settings['masonry_layout'] === 'yes' ) {
            $grid_classes[] = 'ts-masonry';
        }

        ?>
        <div class="<?php echo esc_attr( implode( ' ', $grid_classes ) ); ?>">
            <?php
            if ( $courses->have_posts() ) {
                while ( $courses->have_posts() ) {
                    $courses->the_post();
                    $course_data = $this->get_course_data( get_the_ID() );
                    $this->render_course_card( $course_data, $settings );
                }
                wp_reset_postdata();
            } else {
                echo '<p>' . esc_html__( 'No courses found.', 'ts-lms' ) . '</p>';
            }
            ?>
        </div>
        <?php
    }

    /**
     * Render single course card.
     *
     * @param array $course Course data.
     * @param array $settings Widget settings.
     * @return void
     */
    protected function render_course_card( $course, $settings ) {
        // Get image with selected resolution
        $image_size   = ! empty( $settings['image_resolution'] ) ? $settings['image_resolution'] : 'large';
        $aspect_ratio = ! empty( $settings['image_aspect_ratio'] ) ? $settings['image_aspect_ratio'] : 'aspect-16-9';
        $thumbnail    = get_the_post_thumbnail_url( $course['id'], $image_size ) ?: $course['thumbnail'];
        
        ?>
        <div class="ts-course-card">
            <?php if ( $settings['show_image'] === 'yes' ) : ?>
                <div class="ts-course-card-thumb <?php echo esc_attr( $aspect_ratio ); ?>">
                    <a href="<?php echo esc_url( $course['permalink'] ); ?>">
                        <img src="<?php echo esc_url( $thumbnail ); ?>" alt="<?php echo esc_attr( $course['title'] ); ?>">
                    </a>

                    <?php 
                    $difficulty_pos = ! empty( $settings['difficulty_position'] ) ? $settings['difficulty_position'] : 'top-left';
                    if ( $settings['show_difficulty'] === 'yes' && $course['level'] ) : ?>
                        <div class="ts-difficulty-badge ts-pos-<?php echo esc_attr( $difficulty_pos ); ?>">
                            <?php echo esc_html( ucfirst( $course['level'] ) ); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ( $settings['show_wishlist'] === 'yes' ) : ?>
                        <button class="ts-bookmark-btn" data-course-id="<?php echo esc_attr( $course['id'] ); ?>" title="<?php esc_attr_e( 'Add to Wishlist', 'ts-lms' ); ?>">
                            <span class="dashicons dashicons-heart"></span>
                        </button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <div class="ts-course-card-body">
                <?php if ( $settings['show_rating'] === 'yes' ) : ?>
                    <div class="ts-course-rating">
                        <div class="ts-stars">
                            <?php for( $i = 0; $i < 5; $i++ ) : ?>
                                <span class="dashicons dashicons-star-filled"></span>
                            <?php endfor; ?>
                        </div>
                        <span class="ts-rating-value"><?php echo number_format( $course['rating'], 2 ); ?></span>
                        <span class="ts-rating-count">(<?php echo esc_html( $course['review_count'] ); ?>)</span>
                    </div>
                <?php endif; ?>

                <h3 class="ts-course-title">
                    <a href="<?php echo esc_url( $course['permalink'] ); ?>" style="text-decoration: none !important;"><?php echo esc_html( $course['title'] ); ?></a>
                </h3>

                <?php if ( $settings['show_meta_data'] === 'yes' || $settings['show_difficulty'] === 'yes' || $settings['show_category'] === 'yes' ) : ?>
                    <div class="ts-course-meta-row">
                        <?php if ( $settings['show_category'] === 'yes' && $course['category'] ) : ?>
                            <div class="ts-meta-item">
                                <span class="dashicons dashicons-category"></span>
                                <?php echo esc_html( $course['category'] ); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ( $settings['show_meta_data'] === 'yes' && ( $course['duration_hours'] || $course['duration_minutes'] ) ) : ?>
                            <div class="ts-meta-item ts-course-duration">
                                <span class="dashicons dashicons-clock"></span>
                                <?php 
                                if ( $course['duration_hours'] ) echo $course['duration_hours'] . 'h ';
                                if ( $course['duration_minutes'] ) echo $course['duration_minutes'] . 'm';
                                ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php if ( $settings['show_author'] === 'yes' || $settings['show_avatar'] === 'yes' ) : ?>
                    <div class="ts-course-author-wrapper">
                        <?php if ( $settings['show_avatar'] === 'yes' ) : ?>
                            <div class="ts-author-avatar">
                                <?php echo get_avatar( $course['author_id'], 32 ); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ( $settings['show_author'] === 'yes' ) : ?>
                            <div class="ts-author-info">
                                <?php echo esc_html__( 'By', 'ts-lms' ); ?> <span><?php echo esc_html( $course['author_name'] ); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php if ( $settings['show_meta_data'] === 'yes' ) : ?>
                    <div class="ts-course-stats">
                        <div class="ts-stat-item">
                            <span class="dashicons dashicons-groups"></span>
                            <?php printf( _n( '%s student', '%s students', $course['enrollment_count'], 'ts-lms' ), number_format_i18n( $course['enrollment_count'] ) ); ?>
                        </div>
                        <?php if ( $course['review_count'] > 0 ) : ?>
                            <div class="ts-stat-item">
                                <span class="dashicons dashicons-star-filled"></span>
                                <?php printf( _n( '%s review', '%s reviews', $course['review_count'], 'ts-lms' ), number_format_i18n( $course['review_count'] ) ); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div> <!-- End .ts-course-card-body -->

            <?php if ( $settings['show_footer_separator'] === 'yes' ) : ?>
                <div class="ts-footer-separator"></div>
            <?php endif; ?>

            <?php if ( $settings['show_footer'] === 'yes' ) : ?>
                <div class="ts-course-card-footer <?php echo $course['is_enrolled'] ? 'is-enrolled' : ''; ?>" style="padding: 0 20px 20px 20px;">
                    <?php if ( ! $course['is_enrolled'] ) : ?>
                        <div class="ts-course-price">
                            <?php if ( $course['is_free'] ) : ?>
                                <span class="free"><?php esc_html_e( 'Free', 'ts-lms' ); ?></span>
                            <?php else : ?>
                                <span class="price"><?php echo number_format( (float) $course['price'], 2 ) . '৳'; ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php 
                    $btn_class = 'ts-btn-enroll';
                    $btn_text  = esc_html__( 'Enroll now', 'ts-lms' );
                    $btn_url   = $course['permalink'];

                    if ( $course['is_enrolled'] ) {
                        $btn_text  = esc_html__( 'Start Learning', 'ts-lms' );
                        $btn_class .= ' ts-btn-full';
                        $btn_url   = $course['first_lesson_url'] ?: $course['permalink'];
                    } elseif ( ! is_user_logged_in() ) {
                        $btn_class .= ' ts-trigger-auth-modal';
                        $btn_url    = 'javascript:void(0);';
                    } elseif ( $course['is_in_cart'] ) {
                        $btn_text  = esc_html__( 'View Card', 'ts-lms' );
                        $btn_url   = wc_get_checkout_url();
                    } else {
                        // Logged in but not enrolled - Redirect to checkout with add-to-cart
                        if ( ! empty( $course['product_id'] ) ) {
                            $btn_url = $course['permalink'];
                        } else {
                            $btn_url = add_query_arg( 'enroll_course', $course['id'], $course['permalink'] );
                        }
                    }
                    ?>

                    <a href="<?php echo esc_url( $btn_url ); ?>" class="<?php echo esc_attr( $btn_class ); ?>" data-course-id="<?php echo esc_attr( $course['id'] ); ?>">
                        <?php echo $btn_text; ?>
                    </a>
                </div>
            <?php endif; ?>
        </div> <!-- End .ts-course-card -->
        <?php
    }

    /**
     * Get course categories for filter dropdown.
     *
     * @return array Categories list.
     */
    protected function get_course_categories() {
        $categories = get_terms( array(
            'taxonomy'   => 'ts_course_category',
            'hide_empty' => false,
        ) );

        $options = array();
        
        if ( ! is_wp_error( $categories ) && ! empty( $categories ) ) {
            foreach ( $categories as $category ) {
                $options[ $category->term_id ] = $category->name;
            }
        }

        return $options;
    }

    /**
     * Get course authors for filter dropdown.
     *
     * @return array Authors list.
     */
    protected function get_course_authors() {
        $authors = get_users( array(
            'capability' => 'edit_posts',
            'orderby' => 'display_name',
            'order'   => 'ASC',
        ) );

        $options = array();
        
        if ( ! empty( $authors ) ) {
            foreach ( $authors as $author ) {
                // Check if author has any courses
                $course_count = count_user_posts( $author->ID, 'ts_course' );
                if ( $course_count > 0 ) {
                    $options[ $author->ID ] = $author->display_name . ' (' . $course_count . ')';
                }
            }
        }

        return $options;
    }
}
