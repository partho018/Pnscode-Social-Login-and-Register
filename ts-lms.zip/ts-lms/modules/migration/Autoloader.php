<?php
/**
 * Migration Module Autoloader
 *
 * @package TS_LMS\Modules\Migration
 */

namespace TS_LMS\Modules\Migration;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Autoloader class for Migration module.
 */
class Autoloader {
    
    /**
     * Register the autoloader.
     */
    public static function register() {
        spl_autoload_register( array( __CLASS__, 'autoload' ) );
    }
    
    /**
     * Autoload classes.
     *
     * @param string $class The class name.
     */
    public static function autoload( $class ) {
        // Check if the class belongs to this namespace
        $prefix = 'TS_LMS\\Modules\\Migration\\';
        
        if ( strpos( $class, $prefix ) !== 0 ) {
            return;
        }
        
        // Get the relative class name
        $relative_class = substr( $class, strlen( $prefix ) );
        
        // Convert namespace to file path
        $file = __DIR__ . '/' . str_replace( '\\', '/', $relative_class ) . '.php';
        
        // If the file exists, require it
        if ( file_exists( $file ) ) {
            require_once $file;
        }
    }
}
