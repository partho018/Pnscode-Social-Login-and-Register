<?php
/**
 * Migration Module
 *
 * @package TS_LMS\Modules\Migration
 */

namespace TS_LMS\Modules\Migration;

use TS_LMS\Modules\Migration\Database\MigrationTables;
use TS_LMS\Modules\Migration\Admin\MigrationPage;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Main Migration Module class.
 */
class Module {
    
    /**
     * Module instance.
     *
     * @var Module
     */
    private static $instance = null;
    
    /**
     * Get module instance.
     *
     * @return Module
     */
    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor.
     */
    private function __construct() {
        $this->init_hooks();
    }
    
    /**
     * Initialize hooks.
     */
    private function init_hooks() {
        // Initialize admin interface
        if ( is_admin() ) {
            add_action( 'admin_menu', array( $this, 'register_admin_menu' ), 20 );
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
        }
        
        // Register AJAX handlers
        add_action( 'wp_ajax_ts_lms_scan_tutor_data', array( 'TS_LMS\Modules\Migration\Admin\AjaxHandler', 'scan_tutor_data' ) );
        add_action( 'wp_ajax_ts_lms_start_migration', array( 'TS_LMS\Modules\Migration\Admin\AjaxHandler', 'start_migration' ) );
        add_action( 'wp_ajax_ts_lms_get_migration_progress', array( 'TS_LMS\Modules\Migration\Admin\AjaxHandler', 'get_migration_progress' ) );
        add_action( 'wp_ajax_ts_lms_rollback_migration', array( 'TS_LMS\Modules\Migration\Admin\AjaxHandler', 'rollback_migration' ) );
    }
    
    /**
     * Register admin menu.
     */
    public function register_admin_menu() {
        // Only show migration menu if enabled in settings
        if ( class_exists( 'TS_LMS\Admin\Settings' ) ) {
            $settings = \TS_LMS\Admin\Settings::get_settings();
            if ( ! isset( $settings['enable_migration'] ) || ! $settings['enable_migration'] ) {
                return;
            }
        }

        add_submenu_page(
            'ts-lms',
            __( 'Migration', 'ts-lms' ),
            __( 'Migration', 'ts-lms' ),
            'manage_options',
            'ts-lms-migration',
            array( 'TS_LMS\Modules\Migration\Admin\MigrationPage', 'render' )
        );
    }
    
    /**
     * Enqueue admin assets.
     *
     * @param string $hook Current admin page hook.
     */
    public function enqueue_admin_assets( $hook ) {
        if ( 'ts-lms_page_ts-lms-migration' !== $hook ) {
            return;
        }
        
        wp_enqueue_style(
            'ts-lms-migration-admin',
            plugin_dir_url( __FILE__ ) . 'assets/css/migration-admin.css',
            array(),
            TS_LMS_VERSION
        );
        
        wp_enqueue_script(
            'ts-lms-migration-admin',
            plugin_dir_url( __FILE__ ) . 'assets/js/migration-admin.js',
            array( 'jquery' ),
            TS_LMS_VERSION,
            true
        );
        
        wp_localize_script( 'ts-lms-migration-admin', 'tsLmsMigration', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'ts_lms_migration_nonce' ),
            'strings'  => array(
                'scanning'          => __( 'Scanning Tutor LMS data...', 'ts-lms' ),
                'migrating'         => __( 'Migration in progress...', 'ts-lms' ),
                'complete'          => __( 'Migration completed successfully!', 'ts-lms' ),
                'error'             => __( 'An error occurred during migration.', 'ts-lms' ),
                'confirm_start'     => __( 'Are you sure you want to start the migration? Make sure you have a backup!', 'ts-lms' ),
                'confirm_rollback'  => __( 'Are you sure you want to rollback? This will restore Tutor LMS data.', 'ts-lms' ),
            ),
        ) );
    }
    
    /**
     * Install module (create database tables).
     */
    public static function install() {
        MigrationTables::create_tables();
        
        // Set installed flag
        update_option( 'ts_lms_migration_installed', true );
    }
}
