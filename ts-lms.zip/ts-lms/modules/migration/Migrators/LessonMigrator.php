<?php
/**
 * Lesson Migrator
 *
 * @package TS_LMS\Modules\Migration\Migrators
 */

namespace TS_LMS\Modules\Migration\Migrators;

use TS_LMS\Modules\Migration\Core\DataMapper;
use TS_LMS\Modules\Migration\Utils\Logger;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * LessonMigrator class.
 */
class LessonMigrator {
    
    /**
     * Migrate lessons.
     *
     * @param string $migration_id Migration ID.
     * @param array  $options Migration options.
     * @return array Results.
     */
    public static function migrate( $migration_id, $options = array() ) {
        global $wpdb;
        
        $results = array(
            'success' => 0,
            'failed'  => 0,
            'skipped' => 0,
        );
        
        // Get all Tutor LMS lessons and topics
        $lessons = $wpdb->get_results(
            "SELECT * FROM {$wpdb->posts} 
            WHERE post_type IN ('lesson', 'topics') 
            AND post_status IN ('publish', 'draft', 'pending')
            ORDER BY menu_order ASC, ID ASC",
            ARRAY_A
        );
        
        Logger::info( $migration_id, sprintf( 'Found %d lessons/topics to migrate', count( $lessons ) ) );
        
        foreach ( $lessons as $lesson ) {
            try {
                $new_lesson_id = self::migrate_single_lesson( $migration_id, $lesson );
                
                if ( $new_lesson_id ) {
                    $results['success']++;
                    Logger::success( $migration_id, sprintf( 'Migrated lesson: %s (ID: %d → %d)', $lesson['post_title'], $lesson['ID'], $new_lesson_id ) );
                } else {
                    $results['failed']++;
                    Logger::error( $migration_id, sprintf( 'Failed to migrate lesson: %s (ID: %d)', $lesson['post_title'], $lesson['ID'] ) );
                }
            } catch ( \Exception $e ) {
                $results['failed']++;
                Logger::error( $migration_id, sprintf( 'Error migrating lesson %d: %s', $lesson['ID'], $e->getMessage() ) );
            }
        }
        
        return $results;
    }
    
    /**
     * Migrate a single lesson.
     *
     * @param string $migration_id Migration ID.
     * @param array  $lesson Lesson data.
     * @return int|false New lesson ID or false on failure.
     */
    private static function migrate_single_lesson( $migration_id, $lesson ) {
        // Transform lesson data
        $lesson_data = DataMapper::transform_lesson_data( $lesson );
        
        // Get parent course ID
        $parent_course_id = get_post_meta( $lesson['ID'], '_tutor_course_id_for_lesson', true );
        
        if ( $parent_course_id ) {
            // Map to new course ID
            $new_course_id = CourseMigrator::get_mapped_id( $migration_id, $parent_course_id );
            if ( $new_course_id ) {
                $lesson_data['post_parent'] = $new_course_id;
            }
        }
        
        // Preserve menu order
        $lesson_data['menu_order'] = $lesson['menu_order'] ?? 0;
        
        // Insert new lesson
        $new_lesson_id = wp_insert_post( $lesson_data, true );
        
        if ( is_wp_error( $new_lesson_id ) ) {
            return false;
        }
        
        // Save mapping
        self::save_mapping( $migration_id, $lesson['ID'], $new_lesson_id );
        
        // Migrate lesson meta
        self::migrate_lesson_meta( $migration_id, $lesson['ID'], $new_lesson_id );
        
        return $new_lesson_id;
    }
    
    /**
     * Migrate lesson meta.
     *
     * @param string $migration_id Migration ID.
     * @param int    $old_id Old lesson ID.
     * @param int    $new_id New lesson ID.
     */
    private static function migrate_lesson_meta( $migration_id, $old_id, $new_id ) {
        global $wpdb;
        
        $meta_data = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d",
                $old_id
            ),
            ARRAY_A
        );
        
        foreach ( $meta_data as $meta ) {
            // Skip WordPress internal meta and course ID meta (already handled)
            if ( strpos( $meta['meta_key'], '_edit_' ) === 0 || 
                 strpos( $meta['meta_key'], '_wp_' ) === 0 ||
                 $meta['meta_key'] === '_tutor_course_id_for_lesson' ) {
                continue;
            }
            
            // Map meta key
            $new_meta_key = DataMapper::map_meta_key( $meta['meta_key'] );
            
            // Add meta to new lesson
            add_post_meta( $new_id, $new_meta_key, maybe_unserialize( $meta['meta_value'] ) );
        }
    }
    
    /**
     * Save ID mapping.
     *
     * @param string $migration_id Migration ID.
     * @param int    $old_id Old ID.
     * @param int    $new_id New ID.
     */
    private static function save_mapping( $migration_id, $old_id, $new_id ) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'ts_lms_migration_mapping';
        
        $wpdb->insert(
            $table,
            array(
                'migration_id' => $migration_id,
                'source_type'  => 'lesson',
                'source_id'    => $old_id,
                'target_type'  => 'ts_lesson',
                'target_id'    => $new_id,
            ),
            array( '%s', '%s', '%d', '%s', '%d' )
        );
    }
}
