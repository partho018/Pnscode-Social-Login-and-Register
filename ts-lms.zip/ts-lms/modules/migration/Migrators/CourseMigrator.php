<?php
/**
 * Course Migrator
 *
 * @package TS_LMS\Modules\Migration\Migrators
 */

namespace TS_LMS\Modules\Migration\Migrators;

use TS_LMS\Modules\Migration\Core\DataMapper;
use TS_LMS\Modules\Migration\Utils\Logger;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * CourseMigrator class.
 */
class CourseMigrator {
    
    /**
     * Migrate courses.
     *
     * @param string $migration_id Migration ID.
     * @param array  $options Migration options.
     * @return array Results.
     */
    public static function migrate( $migration_id, $options = array() ) {
        global $wpdb;
        
        $results = array(
            'success' => 0,
            'failed'  => 0,
            'skipped' => 0,
        );
        
        // Get all Tutor LMS courses
        $courses = $wpdb->get_results(
            "SELECT * FROM {$wpdb->posts} 
            WHERE post_type = 'courses' 
            AND post_status IN ('publish', 'draft', 'pending')
            ORDER BY ID ASC",
            ARRAY_A
        );
        
        Logger::info( $migration_id, sprintf( 'Found %d courses to migrate', count( $courses ) ) );
        
        foreach ( $courses as $course ) {
            try {
                $new_course_id = self::migrate_single_course( $migration_id, $course );
                
                if ( $new_course_id ) {
                    $results['success']++;
                    Logger::success( $migration_id, sprintf( 'Migrated course: %s (ID: %d → %d)', $course['post_title'], $course['ID'], $new_course_id ) );
                } else {
                    $results['failed']++;
                    Logger::error( $migration_id, sprintf( 'Failed to migrate course: %s (ID: %d)', $course['post_title'], $course['ID'] ) );
                }
            } catch ( \Exception $e ) {
                $results['failed']++;
                Logger::error( $migration_id, sprintf( 'Error migrating course %d: %s', $course['ID'], $e->getMessage() ) );
            }
        }
        
        return $results;
    }
    
    /**
     * Migrate a single course.
     *
     * @param string $migration_id Migration ID.
     * @param array  $course Course data.
     * @return int|false New course ID or false on failure.
     */
    private static function migrate_single_course( $migration_id, $course ) {
        // Transform course data
        $course_data = DataMapper::transform_course_data( $course );
        
        // Insert new course
        $new_course_id = wp_insert_post( $course_data, true );
        
        if ( is_wp_error( $new_course_id ) ) {
            return false;
        }
        
        // Save mapping
        self::save_mapping( $migration_id, $course['ID'], $new_course_id );
        
        // Migrate course meta
        self::migrate_course_meta( $migration_id, $course['ID'], $new_course_id );
        
        // Migrate course taxonomies
        self::migrate_course_taxonomies( $migration_id, $course['ID'], $new_course_id );
        
        // Migrate featured image
        self::migrate_featured_image( $migration_id, $course['ID'], $new_course_id );
        
        return $new_course_id;
    }
    
    /**
     * Migrate course meta.
     *
     * @param string $migration_id Migration ID.
     * @param int    $old_id Old course ID.
     * @param int    $new_id New course ID.
     */
    private static function migrate_course_meta( $migration_id, $old_id, $new_id ) {
        global $wpdb;
        
        $meta_data = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d",
                $old_id
            ),
            ARRAY_A
        );
        
        foreach ( $meta_data as $meta ) {
            // Skip WordPress internal meta
            if ( strpos( $meta['meta_key'], '_edit_' ) === 0 || strpos( $meta['meta_key'], '_wp_' ) === 0 ) {
                continue;
            }
            
            // Map meta key
            $new_meta_key = DataMapper::map_meta_key( $meta['meta_key'] );
            
            // Add meta to new course
            add_post_meta( $new_id, $new_meta_key, maybe_unserialize( $meta['meta_value'] ) );
        }
    }
    
    /**
     * Migrate course taxonomies.
     *
     * @param string $migration_id Migration ID.
     * @param int    $old_id Old course ID.
     * @param int    $new_id New course ID.
     */
    private static function migrate_course_taxonomies( $migration_id, $old_id, $new_id ) {
        // Migrate categories
        $categories = wp_get_post_terms( $old_id, 'course-category', array( 'fields' => 'ids' ) );
        if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
            wp_set_post_terms( $new_id, $categories, 'ts_course_category' );
        }
        
        // Migrate tags
        $tags = wp_get_post_terms( $old_id, 'course-tag', array( 'fields' => 'ids' ) );
        if ( ! empty( $tags ) && ! is_wp_error( $tags ) ) {
            wp_set_post_terms( $new_id, $tags, 'ts_course_tag' );
        }
    }
    
    /**
     * Migrate featured image.
     *
     * @param string $migration_id Migration ID.
     * @param int    $old_id Old course ID.
     * @param int    $new_id New course ID.
     */
    private static function migrate_featured_image( $migration_id, $old_id, $new_id ) {
        $thumbnail_id = get_post_thumbnail_id( $old_id );
        
        if ( $thumbnail_id ) {
            set_post_thumbnail( $new_id, $thumbnail_id );
        }
    }
    
    /**
     * Save ID mapping.
     *
     * @param string $migration_id Migration ID.
     * @param int    $old_id Old ID.
     * @param int    $new_id New ID.
     */
    private static function save_mapping( $migration_id, $old_id, $new_id ) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'ts_lms_migration_mapping';
        
        $wpdb->insert(
            $table,
            array(
                'migration_id' => $migration_id,
                'source_type'  => 'course',
                'source_id'    => $old_id,
                'target_type'  => 'ts_course',
                'target_id'    => $new_id,
            ),
            array( '%s', '%s', '%d', '%s', '%d' )
        );
    }
    
    /**
     * Get mapped course ID.
     *
     * @param string $migration_id Migration ID.
     * @param int    $old_id Old course ID.
     * @return int|null New course ID or null.
     */
    public static function get_mapped_id( $migration_id, $old_id ) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'ts_lms_migration_mapping';
        
        $new_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT target_id FROM {$table} 
                WHERE migration_id = %s 
                AND source_type = 'course' 
                AND source_id = %d",
                $migration_id,
                $old_id
            )
        );
        
        return $new_id ? (int) $new_id : null;
    }
}
