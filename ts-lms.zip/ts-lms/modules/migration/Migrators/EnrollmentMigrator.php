<?php
/**
 * Enrollment Migrator
 *
 * @package TS_LMS\Modules\Migration\Migrators
 */

namespace TS_LMS\Modules\Migration\Migrators;

use TS_LMS\Modules\Migration\Core\DataMapper;
use TS_LMS\Modules\Migration\Utils\Logger;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * EnrollmentMigrator class.
 */
class EnrollmentMigrator {
    
    /**
     * Migrate enrollments.
     *
     * @param string $migration_id Migration ID.
     * @param array  $options Migration options.
     * @return array Results.
     */
    public static function migrate( $migration_id, $options = array() ) {
        global $wpdb;
        
        $results = array(
            'success' => 0,
            'failed'  => 0,
            'skipped' => 0,
        );
        
        $enrollments_table = $wpdb->prefix . 'tutor_enrollments';
        
        // Check if table exists
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$enrollments_table}'" ) !== $enrollments_table ) {
            Logger::warning( $migration_id, 'Tutor enrollments table not found' );
            return $results;
        }
        
        // Get all enrollments
        $enrollments = $wpdb->get_results(
            "SELECT * FROM {$enrollments_table} ORDER BY enrollment_id ASC",
            ARRAY_A
        );
        
        Logger::info( $migration_id, sprintf( 'Found %d enrollments to migrate', count( $enrollments ) ) );
        
        foreach ( $enrollments as $enrollment ) {
            try {
                $success = self::migrate_single_enrollment( $migration_id, $enrollment );
                
                if ( $success ) {
                    $results['success']++;
                } else {
                    $results['failed']++;
                }
            } catch ( \Exception $e ) {
                $results['failed']++;
                Logger::error( $migration_id, sprintf( 'Error migrating enrollment %d: %s', $enrollment['enrollment_id'], $e->getMessage() ) );
            }
        }
        
        Logger::success( $migration_id, sprintf( 'Migrated %d/%d enrollments', $results['success'], count( $enrollments ) ) );
        
        return $results;
    }
    
    /**
     * Migrate a single enrollment.
     *
     * @param string $migration_id Migration ID.
     * @param array  $enrollment Enrollment data.
     * @return bool Success status.
     */
    private static function migrate_single_enrollment( $migration_id, $enrollment ) {
        global $wpdb;
        
        // Get mapped course ID
        $new_course_id = CourseMigrator::get_mapped_id( $migration_id, $enrollment['course_id'] );
        
        if ( ! $new_course_id ) {
            Logger::warning( $migration_id, sprintf( 'Course mapping not found for enrollment %d (course %d)', $enrollment['enrollment_id'], $enrollment['course_id'] ) );
            return false;
        }
        
        // Check if TS LMS enrollments table exists
        $ts_enrollments_table = $wpdb->prefix . 'ts_lms_enrollments';
        
        // Insert enrollment
        $result = $wpdb->insert(
            $ts_enrollments_table,
            array(
                'user_id'     => $enrollment['user_id'],
                'course_id'   => $new_course_id,
                'enrolled_at' => $enrollment['enrollment_date'] ?? current_time( 'mysql' ),
                'status'      => 'active',
            ),
            array( '%d', '%d', '%s', '%s' )
        );
        
        return $result !== false;
    }
}
