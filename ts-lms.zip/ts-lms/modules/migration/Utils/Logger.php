<?php
/**
 * Logger Utility
 *
 * @package TS_LMS\Modules\Migration\Utils
 */

namespace TS_LMS\Modules\Migration\Utils;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Logger class for migration operations.
 */
class Logger {
    
    /**
     * Log types.
     */
    const TYPE_INFO    = 'info';
    const TYPE_SUCCESS = 'success';
    const TYPE_WARNING = 'warning';
    const TYPE_ERROR   = 'error';
    
    /**
     * Log a message.
     *
     * @param string $migration_id Migration ID.
     * @param string $type Log type.
     * @param string $message Log message.
     * @param array  $data Additional data.
     * @return bool
     */
    public static function log( $migration_id, $type, $message, $data = array() ) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'ts_lms_migration_log';
        
        $result = $wpdb->insert(
            $table,
            array(
                'migration_id' => $migration_id,
                'type'         => $type,
                'message'      => $message,
                'data'         => maybe_serialize( $data ),
                'created_at'   => current_time( 'mysql' ),
            ),
            array( '%s', '%s', '%s', '%s', '%s' )
        );
        
        return $result !== false;
    }
    
    /**
     * Log info message.
     *
     * @param string $migration_id Migration ID.
     * @param string $message Message.
     * @param array  $data Additional data.
     * @return bool
     */
    public static function info( $migration_id, $message, $data = array() ) {
        return self::log( $migration_id, self::TYPE_INFO, $message, $data );
    }
    
    /**
     * Log success message.
     *
     * @param string $migration_id Migration ID.
     * @param string $message Message.
     * @param array  $data Additional data.
     * @return bool
     */
    public static function success( $migration_id, $message, $data = array() ) {
        return self::log( $migration_id, self::TYPE_SUCCESS, $message, $data );
    }
    
    /**
     * Log warning message.
     *
     * @param string $migration_id Migration ID.
     * @param string $message Message.
     * @param array  $data Additional data.
     * @return bool
     */
    public static function warning( $migration_id, $message, $data = array() ) {
        return self::log( $migration_id, self::TYPE_WARNING, $message, $data );
    }
    
    /**
     * Log error message.
     *
     * @param string $migration_id Migration ID.
     * @param string $message Message.
     * @param array  $data Additional data.
     * @return bool
     */
    public static function error( $migration_id, $message, $data = array() ) {
        return self::log( $migration_id, self::TYPE_ERROR, $message, $data );
    }
    
    /**
     * Get logs for a migration.
     *
     * @param string $migration_id Migration ID.
     * @param string $type Optional. Filter by type.
     * @param int    $limit Optional. Limit number of results.
     * @return array
     */
    public static function get_logs( $migration_id, $type = '', $limit = 100 ) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'ts_lms_migration_log';
        
        $where = $wpdb->prepare( 'WHERE migration_id = %s', $migration_id );
        
        if ( ! empty( $type ) ) {
            $where .= $wpdb->prepare( ' AND type = %s', $type );
        }
        
        $query = "SELECT * FROM {$table} {$where} ORDER BY created_at DESC LIMIT %d";
        
        $results = $wpdb->get_results(
            $wpdb->prepare( $query, $limit ),
            ARRAY_A
        );
        
        // Unserialize data
        foreach ( $results as &$result ) {
            $result['data'] = maybe_unserialize( $result['data'] );
        }
        
        return $results;
    }
    
    /**
     * Clear logs for a migration.
     *
     * @param string $migration_id Migration ID.
     * @return bool
     */
    public static function clear_logs( $migration_id ) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'ts_lms_migration_log';
        
        $result = $wpdb->delete(
            $table,
            array( 'migration_id' => $migration_id ),
            array( '%s' )
        );
        
        return $result !== false;
    }
}
