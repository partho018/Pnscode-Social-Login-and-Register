<?php
/**
 * Migration Engine
 *
 * @package TS_LMS\Modules\Migration\Core
 */

namespace TS_LMS\Modules\Migration\Core;

use TS_LMS\Modules\Migration\Migrators\CourseMigrator;
use TS_LMS\Modules\Migration\Migrators\LessonMigrator;
use TS_LMS\Modules\Migration\Migrators\EnrollmentMigrator;
use TS_LMS\Modules\Migration\Utils\Logger;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * MigrationEngine class - Orchestrates the migration process.
 */
class MigrationEngine {
    
    /**
     * Migration ID.
     *
     * @var string
     */
    private $migration_id;
    
    /**
     * Migration options.
     *
     * @var array
     */
    private $options;
    
    /**
     * Constructor.
     *
     * @param array $options Migration options.
     */
    public function __construct( $options = array() ) {
        $this->migration_id = uniqid( 'migration_' );
        $this->options = wp_parse_args( $options, array(
            'migrate_courses'     => true,
            'migrate_lessons'     => true,
            'migrate_quizzes'     => false, // Not implemented yet
            'migrate_enrollments' => true,
            'migrate_media'       => true,
        ) );
    }
    
    /**
     * Get migration ID.
     *
     * @return string
     */
    public function get_migration_id() {
        return $this->migration_id;
    }
    
    /**
     * Run the migration.
     *
     * @return array Results.
     */
    public function run() {
        Logger::info( $this->migration_id, 'Starting migration process' );
        
        $results = array(
            'migration_id' => $this->migration_id,
            'started_at'   => current_time( 'mysql' ),
            'status'       => 'running',
            'steps'        => array(),
        );
        
        try {
            // Step 1: Validate Tutor LMS
            if ( ! TutorDetector::is_tutor_installed() ) {
                throw new \Exception( 'Tutor LMS is not installed' );
            }
            
            Logger::info( $this->migration_id, 'Tutor LMS detected, version: ' . TutorDetector::get_tutor_version() );
            
            // Step 2: Migrate courses
            if ( $this->options['migrate_courses'] ) {
                Logger::info( $this->migration_id, 'Starting course migration' );
                $results['steps']['courses'] = CourseMigrator::migrate( $this->migration_id, $this->options );
            }
            
            // Step 3: Migrate lessons
            if ( $this->options['migrate_lessons'] ) {
                Logger::info( $this->migration_id, 'Starting lesson migration' );
                $results['steps']['lessons'] = LessonMigrator::migrate( $this->migration_id, $this->options );
            }
            
            // Step 4: Migrate enrollments
            if ( $this->options['migrate_enrollments'] ) {
                Logger::info( $this->migration_id, 'Starting enrollment migration' );
                $results['steps']['enrollments'] = EnrollmentMigrator::migrate( $this->migration_id, $this->options );
            }
            
            // Mark as complete
            $results['status'] = 'completed';
            $results['completed_at'] = current_time( 'mysql' );
            
            Logger::success( $this->migration_id, 'Migration completed successfully' );
            
        } catch ( \Exception $e ) {
            $results['status'] = 'failed';
            $results['error'] = $e->getMessage();
            $results['failed_at'] = current_time( 'mysql' );
            
            Logger::error( $this->migration_id, 'Migration failed: ' . $e->getMessage() );
        }
        
        // Save migration results
        $this->save_migration_results( $results );
        
        return $results;
    }
    
    /**
     * Save migration results.
     *
     * @param array $results Migration results.
     */
    private function save_migration_results( $results ) {
        set_transient( 'ts_lms_migration_' . $this->migration_id, $results, DAY_IN_SECONDS );
        
        // Also save to options for permanent record
        $migrations = get_option( 'ts_lms_migrations', array() );
        $migrations[ $this->migration_id ] = $results;
        update_option( 'ts_lms_migrations', $migrations );
    }
    
    /**
     * Get migration results.
     *
     * @param string $migration_id Migration ID.
     * @return array|null Results or null if not found.
     */
    public static function get_migration_results( $migration_id ) {
        // Try transient first
        $results = get_transient( 'ts_lms_migration_' . $migration_id );
        
        if ( false === $results ) {
            // Try options
            $migrations = get_option( 'ts_lms_migrations', array() );
            $results = isset( $migrations[ $migration_id ] ) ? $migrations[ $migration_id ] : null;
        }
        
        return $results;
    }
}
