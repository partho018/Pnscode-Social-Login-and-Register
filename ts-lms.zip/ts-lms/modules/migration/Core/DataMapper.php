<?php
/**
 * Data Mapper
 *
 * @package TS_LMS\Modules\Migration\Core
 */

namespace TS_LMS\Modules\Migration\Core;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * DataMapper class - Maps Tutor LMS data to TS LMS format.
 */
class DataMapper {
    
    /**
     * Post type mappings.
     *
     * @var array
     */
    private static $post_type_map = array(
        'courses'    => 'ts_course',
        'lesson'     => 'ts_lesson',
        'topics'     => 'ts_lesson', // Topics are treated as lessons in TS LMS
        'tutor_quiz' => 'ts_quiz',
    );
    
    /**
     * Meta key mappings.
     *
     * @var array
     */
    private static $meta_key_map = array(
        // Course meta
        '_tutor_course_price_type'           => '_ts_course_price_type',
        '_tutor_course_price'                => '_ts_course_price',
        '_tutor_course_product_id'           => '_ts_course_product_id',
        '_tutor_course_level'                => '_ts_course_level',
        '_tutor_course_duration'             => '_ts_course_duration',
        '_tutor_course_benefits'             => '_ts_course_benefits',
        '_tutor_course_requirements'         => '_ts_course_requirements',
        '_tutor_course_target_audience'      => '_ts_course_target_audience',
        '_tutor_course_material_includes'    => '_ts_course_materials',
        
        // Lesson meta
        '_tutor_lesson_video_source'         => '_ts_lesson_video_source',
        '_tutor_lesson_video_url'            => '_ts_lesson_video_url',
        '_tutor_lesson_thumbnail'            => '_ts_lesson_thumbnail',
        
        // Quiz meta
        '_tutor_quiz_option'                 => '_ts_quiz_settings',
        '_tutor_quiz_time_limit'             => '_ts_quiz_time_limit',
        '_tutor_quiz_pass_mark'              => '_ts_quiz_pass_mark',
        '_tutor_quiz_attempts_allowed'       => '_ts_quiz_attempts_allowed',
    );
    
    /**
     * Map post type from Tutor LMS to TS LMS.
     *
     * @param string $tutor_type Tutor LMS post type.
     * @return string TS LMS post type.
     */
    public static function map_post_type( $tutor_type ) {
        return isset( self::$post_type_map[ $tutor_type ] ) 
            ? self::$post_type_map[ $tutor_type ] 
            : $tutor_type;
    }
    
    /**
     * Map meta key from Tutor LMS to TS LMS.
     *
     * @param string $tutor_key Tutor LMS meta key.
     * @return string TS LMS meta key.
     */
    public static function map_meta_key( $tutor_key ) {
        return isset( self::$meta_key_map[ $tutor_key ] ) 
            ? self::$meta_key_map[ $tutor_key ] 
            : $tutor_key;
    }
    
    /**
     * Transform course data.
     *
     * @param array $course_data Tutor LMS course data.
     * @return array Transformed data for TS LMS.
     */
    public static function transform_course_data( $course_data ) {
        $transformed = array(
            'post_type'    => 'ts_course',
            'post_title'   => $course_data['post_title'] ?? '',
            'post_content' => $course_data['post_content'] ?? '',
            'post_excerpt' => $course_data['post_excerpt'] ?? '',
            'post_status'  => $course_data['post_status'] ?? 'publish',
            'post_author'  => $course_data['post_author'] ?? get_current_user_id(),
        );
        
        return $transformed;
    }
    
    /**
     * Transform lesson data.
     *
     * @param array $lesson_data Tutor LMS lesson data.
     * @return array Transformed data for TS LMS.
     */
    public static function transform_lesson_data( $lesson_data ) {
        $transformed = array(
            'post_type'    => 'ts_lesson',
            'post_title'   => $lesson_data['post_title'] ?? '',
            'post_content' => $lesson_data['post_content'] ?? '',
            'post_status'  => $lesson_data['post_status'] ?? 'publish',
            'post_author'  => $lesson_data['post_author'] ?? get_current_user_id(),
            'post_parent'  => 0, // Will be set during migration
        );
        
        return $transformed;
    }
    
    /**
     * Transform quiz data.
     *
     * @param array $quiz_data Tutor LMS quiz data.
     * @return array Transformed data for TS LMS.
     */
    public static function transform_quiz_data( $quiz_data ) {
        $transformed = array(
            'post_type'    => 'ts_quiz',
            'post_title'   => $quiz_data['post_title'] ?? '',
            'post_content' => $quiz_data['post_content'] ?? '',
            'post_status'  => $quiz_data['post_status'] ?? 'publish',
            'post_author'  => $quiz_data['post_author'] ?? get_current_user_id(),
            'post_parent'  => 0, // Will be set during migration
        );
        
        return $transformed;
    }
    
    /**
     * Transform enrollment data.
     *
     * @param array $enrollment Tutor LMS enrollment data.
     * @return array Transformed data for TS LMS.
     */
    public static function transform_enrollment_data( $enrollment ) {
        return array(
            'user_id'     => $enrollment['user_id'] ?? 0,
            'course_id'   => 0, // Will be mapped during migration
            'enrolled_at' => $enrollment['enrollment_date'] ?? current_time( 'mysql' ),
            'status'      => 'active',
        );
    }
}
