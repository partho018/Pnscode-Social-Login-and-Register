<?php
/**
 * Tutor LMS Detector
 *
 * @package TS_LMS\Modules\Migration\Core
 */

namespace TS_LMS\Modules\Migration\Core;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * TutorDetector class - Detects and scans Tutor LMS data.
 */
class TutorDetector {
    
    /**
     * Check if Tutor LMS is installed.
     *
     * @return bool
     */
    public static function is_tutor_installed() {
        return defined( 'TUTOR_VERSION' ) || class_exists( 'TUTOR\Tutor' );
    }
    
    /**
     * Check if Tutor LMS is active.
     *
     * @return bool
     */
    public static function is_tutor_active() {
        return is_plugin_active( 'tutor/tutor.php' ) || is_plugin_active( 'tutor-lms/tutor.php' );
    }
    
    /**
     * Scan Tutor LMS data and return counts.
     *
     * @return array
     */
    public static function scan_data() {
        global $wpdb;
        
        $data = array(
            'installed' => self::is_tutor_installed(),
            'active'    => self::is_tutor_active(),
            'counts'    => array(
                'courses'      => 0,
                'lessons'      => 0,
                'topics'       => 0,
                'quizzes'      => 0,
                'questions'    => 0,
                'students'     => 0,
                'instructors'  => 0,
                'enrollments'  => 0,
                'quiz_attempts'=> 0,
            ),
        );
        
        if ( ! self::is_tutor_installed() ) {
            return $data;
        }
        
        // Count courses
        $data['counts']['courses'] = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'courses' AND post_status = 'publish'"
        );
        
        // Count lessons
        $data['counts']['lessons'] = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'lesson' AND post_status = 'publish'"
        );
        
        // Count topics
        $data['counts']['topics'] = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'topics' AND post_status = 'publish'"
        );
        
        // Count quizzes
        $data['counts']['quizzes'] = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'tutor_quiz' AND post_status = 'publish'"
        );
        
        // Count quiz questions
        $questions_table = $wpdb->prefix . 'tutor_quiz_questions';
        if ( self::table_exists( $questions_table ) ) {
            $data['counts']['questions'] = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$questions_table}"
            );
        }
        
        // Count students (users with student role or enrolled in courses)
        $enrollments_table = $wpdb->prefix . 'tutor_enrollments';
        if ( self::table_exists( $enrollments_table ) ) {
            $data['counts']['students'] = (int) $wpdb->get_var(
                "SELECT COUNT(DISTINCT user_id) FROM {$enrollments_table}"
            );
            
            $data['counts']['enrollments'] = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$enrollments_table}"
            );
        }
        
        // Count instructors
        $data['counts']['instructors'] = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(DISTINCT u.ID) 
                FROM {$wpdb->users} u 
                INNER JOIN {$wpdb->usermeta} um ON u.ID = um.user_id 
                WHERE um.meta_key = %s 
                AND um.meta_value LIKE %s",
                $wpdb->prefix . 'capabilities',
                '%tutor_instructor%'
            )
        );
        
        // Count quiz attempts
        $attempts_table = $wpdb->prefix . 'tutor_quiz_attempts';
        if ( self::table_exists( $attempts_table ) ) {
            $data['counts']['quiz_attempts'] = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$attempts_table}"
            );
        }
        
        return $data;
    }
    
    /**
     * Check if a database table exists.
     *
     * @param string $table_name Table name.
     * @return bool
     */
    private static function table_exists( $table_name ) {
        global $wpdb;
        
        $result = $wpdb->get_var(
            $wpdb->prepare(
                "SHOW TABLES LIKE %s",
                $table_name
            )
        );
        
        return $result === $table_name;
    }
    
    /**
     * Get Tutor LMS version.
     *
     * @return string
     */
    public static function get_tutor_version() {
        if ( defined( 'TUTOR_VERSION' ) ) {
            return TUTOR_VERSION;
        }
        return '';
    }
}
