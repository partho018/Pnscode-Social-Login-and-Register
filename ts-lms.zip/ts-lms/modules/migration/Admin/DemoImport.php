<?php
/**
 * Demo Import Class
 *
 * @package TS_LMS\Modules\Migration
 */

namespace TS_LMS\Modules\Migration\Admin;

/**
 * Handles the Demo Course Import functionality.
 */
class DemoImport {

    /**
     * Initialize the class.
     */
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 25 );
        add_action( 'wp_ajax_ts_lms_import_demo_courses', array( __CLASS__, 'ajax_import_demo' ) );
    }

    /**
     * Register the demo import menu.
     */
    public static function register_menu() {
        if ( class_exists( 'TS_LMS\Admin\Settings' ) ) {
            $settings = \TS_LMS\Admin\Settings::get_settings();
            if ( ! isset( $settings['enable_demo_import'] ) || ! $settings['enable_demo_import'] ) {
                return;
            }
        }

        add_submenu_page(
            'ts-lms',
            __( 'Demo Import', 'ts-lms' ),
            __( 'Demo Import', 'ts-lms' ),
            'manage_options',
            'ts-lms-demo-import',
            array( __CLASS__, 'render_page' )
        );
    }

    /**
     * Render the demo import page.
     */
    public static function render_page() {
        include TS_LMS_PLUGIN_DIR . 'modules/migration/templates/demo-import.php';
    }

    /**
     * AJAX handler for demo import.
     */
    public static function ajax_import_demo() {
        check_ajax_referer( 'ts_lms_demo_import', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ts-lms' ) ) );
        }

        $index = isset( $_POST['index'] ) ? intval( $_POST['index'] ) : 0;
        $courses = self::get_demo_data();

        if ( ! isset( $courses[ $index ] ) ) {
            wp_send_json_success( array( 'done' => true, 'message' => __( 'All courses processed.', 'ts-lms' ) ) );
        }

        $course_data = $courses[ $index ];
        
        // Skip if already exists (optional, but good for retries)
        $existing = get_page_by_title( $course_data['title'], OBJECT, 'ts_course' );
        if ( $existing ) {
             wp_send_json_success( array( 
                'done'    => false, 
                'index'   => $index + 1, 
                'message' => sprintf( __( 'Skipped (exists): %s', 'ts-lms' ), $course_data['title'] ) 
            ) );
        }

        $course_id = self::import_single_course( $course_data );

        if ( $course_id ) {
            wp_send_json_success( array( 
                'done'    => false, 
                'index'   => $index + 1, 
                'message' => sprintf( __( 'Imported: %s', 'ts-lms' ), $course_data['title'] ) 
            ) );
        } else {
            wp_send_json_error( array( 'message' => sprintf( __( 'Failed to import: %s', 'ts-lms' ), $course_data['title'] ) ) );
        }
    }

    /**
     * Get demo courses data.
     */
    private static function get_demo_data() {
        return array(
            array(
                'title'   => 'Mastering Modern Web Development',
                'excerpt' => 'A comprehensive guide to HTML, CSS, and JavaScript.',
                'content' => 'Learn how to build stunning websites from scratch. This course covers everything from responsive design to interactive web applications.',
                'level'   => 'beginner',
                'type'    => 'paid',
                'video'   => 'https://www.youtube.com/watch?v=kUMe1FH4CHE',
                'price'   => 49.99,
                'image'   => 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80'
            ),
            array(
                'title'   => 'Graphic Design Fundamentals',
                'excerpt' => 'Unlock your creativity with Photoshop and Illustrator.',
                'content' => 'Deep dive into the world of digital art. Master the tools and techniques used by professional designers.',
                'level'   => 'all_levels',
                'type'    => 'paid',
                'video'   => 'https://www.youtube.com/watch?v=un50Bs4BvZ8',
                'price'   => 29.00,
                'image'   => 'https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&w=800&q=80'
            ),
            array(
                'title'   => 'Python for Data Science',
                'excerpt' => 'Analyze data like a pro using Python, Pandas, and Matplotlib.',
                'content' => 'Transform raw data into meaningful insights. Perfect for aspiring data analysts and scientists.',
                'level'   => 'intermediate',
                'type'    => 'subscription',
                'video'   => 'https://www.youtube.com/watch?v=rfscVS0vtbw',
                'price'   => 19.99,
                'image'   => 'https://images.unsplash.com/photo-1551288049-bbbda536ad4a?auto=format&fit=crop&w=800&q=80'
            ),
            array(
                'title'   => 'Digital Marketing Mastery',
                'excerpt' => 'Grow your business with SEO, SEM, and Social Media.',
                'content' => 'Master the strategies that drive traffic and conversions in the digital age.',
                'level'   => 'all_levels',
                'type'    => 'paid',
                'video'   => 'https://www.youtube.com/watch?v=fXvU7E_j86s',
                'price'   => 99.00,
                'image'   => 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80'
            ),
            array(
                'title'   => 'Professional Photography Course',
                'excerpt' => 'Capture every moment perfectly with your DSLR.',
                'content' => 'Learn the art of lighting, composition, and post-processing in this complete guide.',
                'level'   => 'beginner',
                'type'    => 'paid',
                'video'   => 'https://www.youtube.com/watch?v=V7z7BAZdt2M',
                'price'   => 59.99,
                'image'   => 'https://images.unsplash.com/photo-1452784444945-3f422708bcea?auto=format&fit=crop&w=800&q=80'
            ),
            array(
                'title'   => 'Cybersecurity Essentials',
                'excerpt' => 'Protect your digital world from hackers and malware.',
                'content' => 'Understand the threats and learn how to defend your network and data.',
                'level'   => 'intermediate',
                'type'    => 'subscription',
                'video'   => 'https://www.youtube.com/watch?v=R96m7i_0O74',
                'price'   => 29.99,
                'image'   => 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80'
            ),
            array(
                'title'   => 'Full Stack React & Node Development',
                'excerpt' => 'Build scalable applications with the MERN stack.',
                'content' => 'A hands-on approach to building modern, real-world applications with React, Node, and MongoDB.',
                'level'   => 'advanced',
                'type'    => 'paid',
                'video'   => 'https://www.youtube.com/watch?v=mS3pMBf-T74',
                'price'   => 149.00,
                'image'   => 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?auto=format&fit=crop&w=800&q=80'
            ),
            array(
                'title'   => 'Personal Finance & Investing',
                'excerpt' => 'Take control of your money and build long-term wealth.',
                'content' => 'Learn how to budget, save, and invest in stocks, bonds, and real estate.',
                'level'   => 'all_levels',
                'type'    => 'paid',
                'video'   => 'https://www.youtube.com/watch?v=YfbeJ_w1JIs',
                'price'   => 39.00,
                'image'   => 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=800&q=80'
            ),
            array(
                'title'   => 'Advanced AutoCAD for Architects',
                'excerpt' => 'Precision drawing and modeling for the construction industry.',
                'content' => 'Go beyond the basics and master complex 3D modeling and automation in AutoCAD.',
                'level'   => 'advanced',
                'type'    => 'paid',
                'video'   => 'https://www.youtube.com/watch?v=vtP16vS-Q3Y',
                'price'   => 199.99,
                'image'   => 'https://images.unsplash.com/photo-1503387762-592916ee6f1a?auto=format&fit=crop&w=800&q=80'
            ),
            array(
                'title'   => 'UI/UX Design with Figma',
                'excerpt' => 'Create user-friendly interfaces that people love to use.',
                'content' => 'Learn the principles of user-centered design and master Figma for prototyping.',
                'level'   => 'beginner',
                'type'    => 'subscription',
                'video'   => 'https://www.youtube.com/watch?v=68w2VwalD5w',
                'price'   => 15.00,
                'image'   => 'https://images.unsplash.com/photo-1586717791821-3f44a563eb4c?auto=format&fit=crop&w=800&q=80'
            ),
        );
    }

    /**
     * Import a single demo course.
     */
    private static function import_single_course( $data ) {
        $course_id = wp_insert_post( array(
            'post_title'   => $data['title'],
            'post_content' => $data['content'],
            'post_excerpt' => $data['excerpt'],
            'post_status'  => 'publish',
            'post_type'    => 'ts_course',
        ) );

        if ( is_wp_error( $course_id ) ) {
            return false;
        }

        // Set metadata
        update_post_meta( $course_id, '_ts_course_level', $data['level'] );
        update_post_meta( $course_id, '_ts_course_price_type', $data['type'] );
        update_post_meta( $course_id, '_ts_course_video_source', 'youtube' );
        update_post_meta( $course_id, '_ts_course_video_url', $data['video'] );

        // Set Featured Image
        if ( ! empty( $data['image'] ) ) {
            self::set_featured_image( $course_id, $data['image'], $data['title'] );
        }

        // Handle WooCommerce integration
        if ( class_exists( 'WooCommerce' ) ) {
            self::create_link_product( $course_id, $data );
        }

        // Add dummy curriculum (1 topic, 2 lessons)
        self::add_dummy_curriculum( $course_id );

        return $course_id;
    }

    /**
     * Create/Link WooCommerce Product.
     */
    private static function create_link_product( $course_id, $data ) {
        $product_id = wp_insert_post( array(
            'post_title'   => $data['title'],
            'post_content' => $data['content'],
            'post_status'  => 'publish',
            'post_type'    => 'product',
        ) );

        if ( ! is_wp_error( $product_id ) ) {
            wp_set_object_terms( $product_id, 'simple', 'product_type' );
            update_post_meta( $product_id, '_regular_price', $data['price'] );
            update_post_meta( $product_id, '_price', $data['price'] );
            update_post_meta( $product_id, '_virtual', 'yes' );
            update_post_meta( $product_id, '_downloadable', 'yes' );
            
            // Link course to product
            update_post_meta( $course_id, '_ts_course_product_id', $product_id );
            
            // Link product to course (for reverse lookup if needed)
            update_post_meta( $product_id, '_ts_lms_course_id', $course_id );

            // Set Featured Image for product too
            if ( ! empty( $data['image'] ) ) {
                $attach_id = get_post_thumbnail_id( $course_id );
                if ( $attach_id ) {
                    set_post_thumbnail( $product_id, $attach_id );
                }
            }

            if ( $data['type'] === 'subscription' && class_exists( 'WC_Subscriptions' ) ) {
                 wp_set_object_terms( $product_id, 'subscription', 'product_type' );
                 update_post_meta( $product_id, '_subscription_period', 'month' );
                 update_post_meta( $product_id, '_subscription_period_interval', '1' );
            }
        }
    }

    /**
     * Set featured image from URL.
     */
    private static function set_featured_image( $post_id, $image_url, $desc ) {
        if ( ! function_exists( 'media_handle_sideload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
        }

        // Download the image
        $tmp = download_url( $image_url );

        if ( is_wp_error( $tmp ) ) {
            error_log( 'TS LMS Demo Import: Download failed for ' . $image_url . ' - ' . $tmp->get_error_message() );
            return;
        }

        $file_array = array(
            'name'     => sanitize_file_name( $desc ) . '.jpg',
            'tmp_name' => $tmp,
        );

        // Do the sideload
        $id = media_handle_sideload( $file_array, $post_id, $desc );

        // Clean up
        @unlink( $tmp );

        if ( ! is_wp_error( $id ) ) {
            set_post_thumbnail( $post_id, $id );
        } else {
            error_log( 'TS LMS Demo Import: Sideload failed for ' . $image_url . ' - ' . $id->get_error_message() );
        }
    }

    /**
     * Add dummy curriculum to a course.
     */
    private static function add_dummy_curriculum( $course_id ) {
        // 1. Create Topic (Lesson with post_parent = course_id)
        $topic_id = wp_insert_post( array(
            'post_title'   => 'Introduction to the Course',
            'post_status'  => 'publish',
            'post_type'    => 'ts_lesson', // Topics are also ts_lesson but with children
            'post_parent'  => $course_id,
        ) );

        if ( ! is_wp_error( $topic_id ) ) {
            // 2. Create Lessons (Lessons with post_parent = topic_id)
            $lessons = array( 'Welcome and Overview', 'Setting Up Your Environment' );
            foreach ( $lessons as $idx => $title ) {
                $lesson_id = wp_insert_post( array(
                    'post_title'  => $title,
                    'post_status' => 'publish',
                    'post_type'   => 'ts_lesson',
                    'post_parent' => $topic_id,
                    'menu_order'  => $idx + 1
                ) );
                
                if ( ! is_wp_error( $lesson_id ) ) {
                    update_post_meta( $lesson_id, '_ts_lesson_course_id', $course_id );
                }
            }
        }
    }
}
