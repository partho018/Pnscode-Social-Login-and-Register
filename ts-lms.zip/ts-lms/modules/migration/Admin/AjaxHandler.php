<?php
/**
 * AJAX Handler for Migration
 *
 * @package TS_LMS\Modules\Migration\Admin
 */

namespace TS_LMS\Modules\Migration\Admin;

use TS_LMS\Modules\Migration\Core\TutorDetector;
use TS_LMS\Modules\Migration\Core\MigrationEngine;
use TS_LMS\Modules\Migration\Utils\Logger;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * AjaxHandler class.
 */
class AjaxHandler {
    
    /**
     * Scan Tutor LMS data.
     */
    public static function scan_tutor_data() {
        check_ajax_referer( 'ts_lms_migration_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied', 'ts-lms' ) ) );
        }
        
        $scan_data = TutorDetector::scan_data();
        
        wp_send_json_success( $scan_data );
    }
    
    /**
     * Start migration.
     */
    public static function start_migration() {
        check_ajax_referer( 'ts_lms_migration_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied', 'ts-lms' ) ) );
        }
        
        // Get options
        $options = array(
            'migrate_courses'     => isset( $_POST['migrate_courses'] ) ? (bool) $_POST['migrate_courses'] : true,
            'migrate_lessons'     => isset( $_POST['migrate_lessons'] ) ? (bool) $_POST['migrate_lessons'] : true,
            'migrate_quizzes'     => isset( $_POST['migrate_quizzes'] ) ? (bool) $_POST['migrate_quizzes'] : false,
            'migrate_enrollments' => isset( $_POST['migrate_enrollments'] ) ? (bool) $_POST['migrate_enrollments'] : true,
            'migrate_media'       => isset( $_POST['migrate_media'] ) ? (bool) $_POST['migrate_media'] : true,
        );
        
        // Create migration engine
        $engine = new MigrationEngine( $options );
        
        // Run migration
        $results = $engine->run();
        
        wp_send_json_success( $results );
    }
    
    /**
     * Get migration progress.
     */
    public static function get_migration_progress() {
        check_ajax_referer( 'ts_lms_migration_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied', 'ts-lms' ) ) );
        }
        
        $migration_id = isset( $_POST['migration_id'] ) ? sanitize_text_field( $_POST['migration_id'] ) : '';
        
        if ( empty( $migration_id ) ) {
            wp_send_json_error( array( 'message' => __( 'Migration ID required', 'ts-lms' ) ) );
        }
        
        $results = MigrationEngine::get_migration_results( $migration_id );
        
        if ( ! $results ) {
            wp_send_json_error( array( 'message' => __( 'Migration not found', 'ts-lms' ) ) );
        }
        
        // Get logs
        $logs = Logger::get_logs( $migration_id, '', 50 );
        $results['logs'] = $logs;
        
        wp_send_json_success( $results );
    }
    
    /**
     * Rollback migration.
     */
    public static function rollback_migration() {
        check_ajax_referer( 'ts_lms_migration_nonce', 'nonce' );
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied', 'ts-lms' ) ) );
        }
        
        $migration_id = isset( $_POST['migration_id'] ) ? sanitize_text_field( $_POST['migration_id'] ) : '';
        
        if ( empty( $migration_id ) ) {
            wp_send_json_error( array( 'message' => __( 'Migration ID required', 'ts-lms' ) ) );
        }
        
        // TODO: Implement rollback functionality
        wp_send_json_error( array( 'message' => __( 'Rollback functionality coming soon', 'ts-lms' ) ) );
    }
}
