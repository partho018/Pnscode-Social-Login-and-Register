<?php
/**
 * Migration Admin Page
 *
 * @package TS_LMS\Modules\Migration\Admin
 */

namespace TS_LMS\Modules\Migration\Admin;

use TS_LMS\Modules\Migration\Core\TutorDetector;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * MigrationPage class.
 */
class MigrationPage {
    
    /**
     * Render the migration page.
     */
    public static function render() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'You do not have sufficient permissions to access this page.', 'ts-lms' ) );
        }
        
        ?>
        <div class="wrap ts-lms-migration-wrap">
            <h1><?php esc_html_e( 'Tutor LMS to TS LMS Migration', 'ts-lms' ); ?></h1>
            
            <div class="ts-lms-migration-container">
                
                <!-- Scan Section -->
                <div class="ts-migration-section" id="scan-section">
                    <h2><?php esc_html_e( 'Step 1: Scan Tutor LMS Data', 'ts-lms' ); ?></h2>
                    <p><?php esc_html_e( 'First, let\'s scan your Tutor LMS installation to see what data can be migrated.', 'ts-lms' ); ?></p>
                    
                    <button type="button" class="button button-primary" id="scan-tutor-btn">
                        <span class="dashicons dashicons-search"></span>
                        <?php esc_html_e( 'Scan Tutor LMS Data', 'ts-lms' ); ?>
                    </button>
                    
                    <div id="scan-results" style="display:none; margin-top: 20px;">
                        <h3><?php esc_html_e( 'Scan Results', 'ts-lms' ); ?></h3>
                        <div class="scan-results-grid">
                            <div class="scan-stat">
                                <span class="scan-label"><?php esc_html_e( 'Courses', 'ts-lms' ); ?></span>
                                <span class="scan-value" id="scan-courses">0</span>
                            </div>
                            <div class="scan-stat">
                                <span class="scan-label"><?php esc_html_e( 'Lessons', 'ts-lms' ); ?></span>
                                <span class="scan-value" id="scan-lessons">0</span>
                            </div>
                            <div class="scan-stat">
                                <span class="scan-label"><?php esc_html_e( 'Quizzes', 'ts-lms' ); ?></span>
                                <span class="scan-value" id="scan-quizzes">0</span>
                            </div>
                            <div class="scan-stat">
                                <span class="scan-label"><?php esc_html_e( 'Students', 'ts-lms' ); ?></span>
                                <span class="scan-value" id="scan-students">0</span>
                            </div>
                            <div class="scan-stat">
                                <span class="scan-label"><?php esc_html_e( 'Enrollments', 'ts-lms' ); ?></span>
                                <span class="scan-value" id="scan-enrollments">0</span>
                            </div>
                            <div class="scan-stat">
                                <span class="scan-label"><?php esc_html_e( 'Instructors', 'ts-lms' ); ?></span>
                                <span class="scan-value" id="scan-instructors">0</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Migration Options Section -->
                <div class="ts-migration-section" id="options-section" style="display:none;">
                    <h2><?php esc_html_e( 'Step 2: Configure Migration Options', 'ts-lms' ); ?></h2>
                    
                    <div class="migration-options">
                        <label>
                            <input type="checkbox" id="migrate-courses" checked>
                            <?php esc_html_e( 'Migrate Courses', 'ts-lms' ); ?>
                        </label>
                        <label>
                            <input type="checkbox" id="migrate-lessons" checked>
                            <?php esc_html_e( 'Migrate Lessons', 'ts-lms' ); ?>
                        </label>
                        <label>
                            <input type="checkbox" id="migrate-enrollments" checked>
                            <?php esc_html_e( 'Migrate Enrollments', 'ts-lms' ); ?>
                        </label>
                        <label>
                            <input type="checkbox" id="migrate-media" checked>
                            <?php esc_html_e( 'Migrate Media Files', 'ts-lms' ); ?>
                        </label>
                    </div>
                    
                    <div class="migration-warning">
                        <p><strong><?php esc_html_e( 'Important:', 'ts-lms' ); ?></strong></p>
                        <ul>
                            <li><?php esc_html_e( 'Make sure you have a complete backup of your site before proceeding.', 'ts-lms' ); ?></li>
                            <li><?php esc_html_e( 'The migration process may take several minutes depending on the amount of data.', 'ts-lms' ); ?></li>
                            <li><?php esc_html_e( 'Do not close this page or navigate away during migration.', 'ts-lms' ); ?></li>
                        </ul>
                    </div>
                    
                    <button type="button" class="button button-primary button-large" id="start-migration-btn">
                        <span class="dashicons dashicons-update"></span>
                        <?php esc_html_e( 'Start Migration', 'ts-lms' ); ?>
                    </button>
                </div>
                
                <!-- Migration Progress Section -->
                <div class="ts-migration-section" id="progress-section" style="display:none;">
                    <h2><?php esc_html_e( 'Migration in Progress', 'ts-lms' ); ?></h2>
                    
                    <div class="migration-progress">
                        <div class="progress-bar-container">
                            <div class="progress-bar" id="migration-progress-bar"></div>
                        </div>
                        <p class="progress-text" id="progress-text"><?php esc_html_e( 'Starting migration...', 'ts-lms' ); ?></p>
                    </div>
                    
                    <div class="migration-logs">
                        <h3><?php esc_html_e( 'Migration Log', 'ts-lms' ); ?></h3>
                        <div id="migration-log-content"></div>
                    </div>
                </div>
                
                <!-- Results Section -->
                <div class="ts-migration-section" id="results-section" style="display:none;">
                    <h2><?php esc_html_e( 'Migration Complete!', 'ts-lms' ); ?></h2>
                    
                    <div class="migration-results" id="migration-results"></div>
                    
                    <div class="migration-actions">
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=ts-lms-course' ) ); ?>" class="button button-primary">
                            <?php esc_html_e( 'View Courses', 'ts-lms' ); ?>
                        </a>
                        <button type="button" class="button" id="view-logs-btn">
                            <?php esc_html_e( 'View Detailed Logs', 'ts-lms' ); ?>
                        </button>
                    </div>
                </div>
                
            </div>
        </div>
        <?php
    }
}
