/**
 * Migration Admin JavaScript
 */

(function ($) {
  "use strict";

  let currentMigrationId = null;

  $(document).ready(function () {
    initMigration();
  });

  function initMigration() {
    // Scan button
    $("#scan-tutor-btn").on("click", scanTutorData);

    // Start migration button
    $("#start-migration-btn").on("click", startMigration);

    // View logs button
    $("#view-logs-btn").on("click", viewLogs);
  }

  /**
   * Scan Tutor LMS data
   */
  function scanTutorData() {
    const $btn = $("#scan-tutor-btn");
    $btn.addClass("loading").prop("disabled", true);

    $.ajax({
      url: tsLmsMigration.ajax_url,
      type: "POST",
      data: {
        action: "ts_lms_scan_tutor_data",
        nonce: tsLmsMigration.nonce,
      },
      success: function (response) {
        if (response.success) {
          displayScanResults(response.data);
          $("#options-section").slideDown();
        } else {
          alert(response.data.message || tsLmsMigration.strings.error);
        }
      },
      error: function () {
        alert(tsLmsMigration.strings.error);
      },
      complete: function () {
        $btn.removeClass("loading").prop("disabled", false);
      },
    });
  }

  /**
   * Display scan results
   */
  function displayScanResults(data) {
    if (!data.installed) {
      showNotification("Tutor LMS is not installed!", "error");
      return;
    }

    const counts = data.counts;

    // Animate numbers counting up (faster)
    animateValue("scan-courses", 0, counts.courses || 0, 500);
    animateValue(
      "scan-lessons",
      0,
      (counts.lessons || 0) + (counts.topics || 0),
      500,
    );
    animateValue("scan-quizzes", 0, counts.quizzes || 0, 500);
    animateValue("scan-students", 0, counts.students || 0, 500);
    animateValue("scan-enrollments", 0, counts.enrollments || 0, 500);
    animateValue("scan-instructors", 0, counts.instructors || 0, 500);

    $("#scan-results").slideDown(400);
  }

  /**
   * Animate number counting (optimized)
   */
  function animateValue(id, start, end, duration) {
    const element = document.getElementById(id);
    if (!element) return;

    const range = end - start;
    const increment = range / (duration / 20);
    let current = start;

    const timer = setInterval(function () {
      current += increment;
      if (
        (increment > 0 && current >= end) ||
        (increment < 0 && current <= end)
      ) {
        current = end;
        clearInterval(timer);
      }
      element.textContent = Math.floor(current);
    }, 20);
  }

  /**
   * Show notification
   */
  function showNotification(message, type = "info") {
    const notification = $(
      `<div class="ts-notification ts-notification-${type}">${message}</div>`,
    );
    $("body").append(notification);

    setTimeout(() => {
      notification.addClass("show");
    }, 10);

    setTimeout(() => {
      notification.removeClass("show");
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }

  /**
   * Start migration
   */
  function startMigration() {
    if (!confirm(tsLmsMigration.strings.confirm_start)) {
      return;
    }

    const $btn = $("#start-migration-btn");
    $btn.addClass("loading").prop("disabled", true);

    // Get options
    const options = {
      migrate_courses: $("#migrate-courses").is(":checked"),
      migrate_lessons: $("#migrate-lessons").is(":checked"),
      migrate_enrollments: $("#migrate-enrollments").is(":checked"),
      migrate_media: $("#migrate-media").is(":checked"),
    };

    // Show progress section
    $("#options-section").slideUp();
    $("#progress-section").slideDown();

    $.ajax({
      url: tsLmsMigration.ajax_url,
      type: "POST",
      data: {
        action: "ts_lms_start_migration",
        nonce: tsLmsMigration.nonce,
        ...options,
      },
      success: function (response) {
        if (response.success) {
          currentMigrationId = response.data.migration_id;
          displayMigrationResults(response.data);
        } else {
          alert(response.data.message || tsLmsMigration.strings.error);
          $("#progress-section").slideUp();
          $("#options-section").slideDown();
        }
      },
      error: function () {
        alert(tsLmsMigration.strings.error);
        $("#progress-section").slideUp();
        $("#options-section").slideDown();
      },
      complete: function () {
        $btn.removeClass("loading").prop("disabled", false);
      },
    });
  }

  /**
   * Display migration results
   */
  function displayMigrationResults(data) {
    if (data.status === "completed") {
      $("#migration-progress-bar").css("width", "100%").text("100%");
      $("#progress-text").text(tsLmsMigration.strings.complete);

      // Build results HTML
      let resultsHtml = '<div class="results-grid">';

      if (data.steps.courses) {
        resultsHtml += buildResultItem("Courses", data.steps.courses.success);
      }

      if (data.steps.lessons) {
        resultsHtml += buildResultItem("Lessons", data.steps.lessons.success);
      }

      if (data.steps.enrollments) {
        resultsHtml += buildResultItem(
          "Enrollments",
          data.steps.enrollments.success,
        );
      }

      resultsHtml += "</div>";

      $("#migration-results").html(resultsHtml);

      // Show results section
      setTimeout(function () {
        $("#progress-section").slideUp();
        $("#results-section").slideDown();
      }, 1000);
    } else if (data.status === "failed") {
      $("#progress-text").html(
        '<span style="color: #dc3545;">' + data.error + "</span>",
      );
    }
  }

  /**
   * Build result item HTML
   */
  function buildResultItem(label, value) {
    return `
            <div class="result-item">
                <div class="result-label">${label} Migrated</div>
                <div class="result-value">${value}</div>
            </div>
        `;
  }

  /**
   * View detailed logs
   */
  function viewLogs() {
    if (!currentMigrationId) {
      return;
    }

    $.ajax({
      url: tsLmsMigration.ajax_url,
      type: "POST",
      data: {
        action: "ts_lms_get_migration_progress",
        nonce: tsLmsMigration.nonce,
        migration_id: currentMigrationId,
      },
      success: function (response) {
        if (response.success && response.data.logs) {
          displayLogs(response.data.logs);
          $("#migration-log-content").parent().slideDown();
        }
      },
    });
  }

  /**
   * Display logs
   */
  function displayLogs(logs) {
    let logsHtml = "";

    logs.forEach(function (log) {
      logsHtml += `<div class="log-entry ${log.type}">
                [${log.created_at}] ${log.message}
            </div>`;
    });

    $("#migration-log-content").html(logsHtml);
  }
})(jQuery);
