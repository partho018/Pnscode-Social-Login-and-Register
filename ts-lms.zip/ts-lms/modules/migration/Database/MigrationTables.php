<?php
/**
 * Migration Database Tables
 *
 * @package TS_LMS\Modules\Migration\Database
 */

namespace TS_LMS\Modules\Migration\Database;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Migration Tables class.
 */
class MigrationTables {
    
    /**
     * Create migration tables.
     */
    public static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        
        // Migration log table
        $log_table = $wpdb->prefix . 'ts_lms_migration_log';
        $log_sql = "CREATE TABLE IF NOT EXISTS {$log_table} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            migration_id VARCHAR(50) NOT NULL,
            type VARCHAR(50) NOT NULL,
            message TEXT,
            data LONGTEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_migration_id (migration_id),
            INDEX idx_type (type)
        ) {$charset_collate};";
        
        dbDelta( $log_sql );
        
        // Migration mapping table
        $mapping_table = $wpdb->prefix . 'ts_lms_migration_mapping';
        $mapping_sql = "CREATE TABLE IF NOT EXISTS {$mapping_table} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            migration_id VARCHAR(50) NOT NULL,
            source_type VARCHAR(50) NOT NULL,
            source_id BIGINT NOT NULL,
            target_type VARCHAR(50) NOT NULL,
            target_id BIGINT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_migration_id (migration_id),
            INDEX idx_source (source_type, source_id),
            INDEX idx_target (target_type, target_id)
        ) {$charset_collate};";
        
        dbDelta( $mapping_sql );
        
        // Migration backup table
        $backup_table = $wpdb->prefix . 'ts_lms_migration_backup';
        $backup_sql = "CREATE TABLE IF NOT EXISTS {$backup_table} (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            migration_id VARCHAR(50) NOT NULL UNIQUE,
            backup_data LONGTEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_migration_id (migration_id)
        ) {$charset_collate};";
        
        dbDelta( $backup_sql );
    }
    
    /**
     * Drop migration tables.
     */
    public static function drop_tables() {
        global $wpdb;
        
        $tables = array(
            $wpdb->prefix . 'ts_lms_migration_log',
            $wpdb->prefix . 'ts_lms_migration_mapping',
            $wpdb->prefix . 'ts_lms_migration_backup',
        );
        
        foreach ( $tables as $table ) {
            $wpdb->query( "DROP TABLE IF EXISTS {$table}" );
        }
    }
}
