<?php
/**
 * TS LMS Uninstall
 *
 * This file is called automatically when the plugin is deleted.
 * 
 * @package TS_LMS
 */

// If uninstall not called from WordPress, exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Get setting to check if we should erase data
$settings = get_option( 'ts_lms_settings', array() );
$erase_on_uninstall = isset( $settings['erase_on_uninstall'] ) ? $settings['erase_on_uninstall'] : 0;

if ( $erase_on_uninstall ) {
    global $wpdb;

    // 1. Delete Options
    delete_option( 'ts_lms_settings' );
    delete_option( 'ts_lms_activated' );
    delete_option( 'ts_lms_courses_schema_version' );
    delete_option( 'ts_lms_quizzes_schema_version' );
    delete_option( 'ts_lms_licensing_schema_version' );
    delete_option( 'ts_lms_reports_schema_version' );
    
    // 2. Delete Custom Post Types Data (Posts & Meta)
    $post_types = array( 'ts_course', 'ts_lesson', 'ts_quiz', 'ts_assignment', 'ts_question', 'ts_announcement', 'ts_certificate' );
    
    foreach ( $post_types as $post_type ) {
        $post_ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type = %s", $post_type ) );
        
        if ( ! empty( $post_ids ) ) {
            foreach ( $post_ids as $post_id ) {
                wp_delete_post( $post_id, true ); // Force delete from bin too
            }
        }
    }

    // 3. Delete Custom Tables
    // Handle Course Module Tables
    if ( file_exists( __DIR__ . '/modules/courses/includes/Database/Installer.php' ) ) {
        require_once __DIR__ . '/modules/courses/includes/Database/Installer.php';
        if ( class_exists( '\TS_LMS\Modules\Courses\Database\Installer' ) ) {
            \TS_LMS\Modules\Courses\Database\Installer::uninstall();
        }
    }

    // fallback if file not found or class not loaded
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ts_course_instructors" );
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ts_lesson_order" );
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ts_course_enrollments" );
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ts_lesson_progress" );
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ts_bundle_courses" );
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ts_course_reviews" );

    // Clear any transients
    delete_transient( 'ts_lms_course_product_ids' );
}
