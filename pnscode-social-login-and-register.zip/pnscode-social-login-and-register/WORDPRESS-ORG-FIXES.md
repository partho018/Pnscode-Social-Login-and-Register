# WordPress.org Plugin Review - Issues & Fixes

## Review ID

F1 pnscode-social-login-and-register/partho800/20Jan26/T1 20Jan26/3.7

## Issues Summary

### ✅ FIXED: Tested Up To Value

- **Issue**: Tested up to 6.4, needs to be 6.8
- **Fix**: Updated readme.txt line 5 to `Tested up to: 6.8`
- **Status**: COMPLETE

### ✅ FIXED: Contributors List

- **Issue**: Contributors listed as "ParthoSamadder" instead of WordPress.org username "partho800"
- **Fix**: Updated readme.txt line 2 to `Contributors: partho800`
- **Status**: COMPLETE

### ✅ FIXED: External Services Documentation

- **Issue**: Plugin uses Google OAuth, Facebook Graph API, and reCAPTCHA without disclosure
- **Fix**: Added comprehensive "External Services" section to readme.txt with:
  - Google OAuth 2.0 (login functionality)
  - Facebook Graph API (login functionality)
  - Google reCAPTCHA v3 (security)
  - Including purpose, data sent, when it's sent, and links to ToS/Privacy Policy
- **Status**: COMPLETE

### ⚠️ TO FIX: Use wp_enqueue commands

- **Issue**: Inline `<style>` tag in includes/class-slr-page-handler.php:93
- **Location**: includes/class-slr-page-handler.php lines 93-136
- **Fix Required**: Move inline styles to assets/css/frontend.css and enqueue properly
- **Priority**: HIGH

### ⚠️ TO FIX: Sanitization for register_setting()

- **Issue**: Missing sanitize_callback in register_setting() calls
- **Locations**:
  - admin/class-slr-admin.php:31-32
- **Fix Required**: Add sanitize_callback parameter
- **Priority**: HIGH

### ⚠️ TO FIX: Nonces and User Permissions

- **Issue**: Missing nonce checks on $_GET/$\_POST inputs
- **Locations**:
  - admin/views/providers.php:12
  - includes/class-slr-social-auth.php:84
  - admin/views/documentation.php:10
  - includes/class-slr-email-verification.php:90
- **Fix Required**: Add nonce verification and capability checks
- **Priority**: CRITICAL

### ⚠️ TO FIX: Data Sanitization, Escaping, and Validation

- **Issue**: Multiple instances of unsanitized/unescaped data
- **Categories**:
  1. Nonce checks need wp_unslash() and sanitize_text_field()
  2. $\_SERVER variables need sanitization
  3. json_decode() output needs sanitization
  4. \_e() and \_\_() need proper escaping functions
  5. Variables echoed without escaping
- **Priority**: CRITICAL

### ⚠️ TO FIX: Generic Function/Class Names

- **Issue**: Prefix "slr" is only 3 characters, minimum is 4 (recommend 5+)
- **Current Prefix**: slr, SLR
- **Required Prefix**: pnscsolo, PNSCSOLO (5 characters)
- **Affected Elements**: 42+ functions, classes, constants, options
- **Priority**: CRITICAL
- **Scope**: ENTIRE PLUGIN

## Detailed Fix Plan

### 1. Inline Styles Fix

**File**: includes/class-slr-page-handler.php

Move styles from lines 93-136 to assets/css/frontend.css and use wp_add_inline_style() if needed.

### 2. Register Setting Sanitization

**File**: admin/class-slr-admin.php

```php
// BEFORE:
register_setting('slr_general_settings', 'slr_general_settings');
register_setting('slr_registration_fields', 'slr_registration_fields');

// AFTER:
register_setting('slr_general_settings', 'slr_general_settings', array(
    'type' => 'array',
    'sanitize_callback' => array($this, 'sanitize_general_settings'),
));
register_setting('slr_registration_fields', 'slr_registration_fields', array(
    'type' => 'array',
    'sanitize_callback' => array($this, 'sanitize_registration_fields'),
));
```

### 3. Nonce Checks

Add nonce verification to all $_GET/$\_POST handlers:

```php
// Example for admin/views/providers.php
if (isset($_GET['provider'])) {
    check_admin_referer('pnscsolo_provider_view');
    $active_provider = sanitize_text_field(wp_unslash($_GET['provider']));
}
```

### 4. Proper Escaping

Replace all instances:

- `_e()` → `esc_html_e()` or `esc_attr_e()`
- `__()` → `esc_html__()` or `esc_attr__()`
- `echo $var` → `echo esc_html($var)` or `echo esc_attr($var)`

### 5. Prefix Rename (MAJOR CHANGE)

**Scope**: Entire plugin

**Rename Pattern**:

- `SLR_` → `PNSCSOLO_` (class names, constants)
- `slr_` → `pnscsolo_` (function names, options)
- `.slr-` → `.pnscsolo-` (CSS classes)
- `#slr-` → `#pnscsolo-` (CSS IDs)
- `slrAjax` → `pnscsoloAjax` (JavaScript objects)
- `social-login` → `pnscsolo-social-login` (menu slugs)

**Files to Rename**:

- All `class-slr-*.php` → `class-pnscsolo-*.php`

**Database Migration Needed**:

- Option names will change
- Need to create upgrade routine to migrate old options to new names

## Execution Strategy

### Phase 1: Quick Fixes (Can do now)

1. ✅ readme.txt updates (DONE)
2. Fix inline styles
3. Add sanitize callbacks
4. Fix escaping issues

### Phase 2: Prefix Rename (Requires testing)

1. Run rename script
2. Update all file references
3. Create database migration
4. Test thoroughly

### Phase 3: Security Hardening

1. Add all nonce checks
2. Add capability checks
3. Sanitize all inputs
4. Escape all outputs

## Testing Checklist

Before resubmitting:

- [ ] Install Plugin Check plugin
- [ ] Run PHPCS with WordPress Coding Standards
- [ ] Test on clean WordPress 6.8 installation
- [ ] Enable WP_DEBUG and check for errors
- [ ] Test all social login providers
- [ ] Test registration form
- [ ] Test WooCommerce integration
- [ ] Verify all admin pages work
- [ ] Check database options migration

## Notes

- The prefix rename is the most extensive change
- Database options will need migration from old to new names
- All CSS/JS will need updates
- Consider creating a migration routine for existing users
- Test extensively before resubmission

## Timeline Estimate

- Quick fixes: 2-3 hours
- Prefix rename: 4-6 hours
- Testing: 2-3 hours
- **Total**: 8-12 hours of work

## Submission Checklist

Before replying to WordPress.org:

- [ ] All issues fixed
- [ ] Plugin tested on clean WP install
- [ ] WP_DEBUG enabled, no errors
- [ ] Plugin Check shows no critical issues
- [ ] New ZIP uploaded to WordPress.org
- [ ] Brief, concise reply email sent (not AI-generated bloat)
