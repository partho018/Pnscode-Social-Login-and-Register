# Social Login & Custom Registration Plugin

A comprehensive WordPress plugin that provides social login integration and a fully customizable registration form builder.

## Features

### ✅ Custom Registration Form Builder
- **Admin-Controlled Form**: Complete control over registration form fields from the admin panel
- **Field Management**: Add, remove, enable/disable, and reorder fields
- **Field Customization**: 
  - Change field labels and placeholders
  - Set fields as required or optional
  - Drag & drop to reorder fields
- **Field Types**: Text, Email, Password, Phone, Select/Dropdown, Checkbox, Textarea, Number, URL, Date
- **Custom Fields**: All custom fields are saved as user meta data

### ✅ Social Login Integration
- **Multiple Providers**: Google, Facebook, X (Twitter), LinkedIn, GitHub
- **Easy Configuration**: Simple admin interface for each provider
- **Individual Control**: Enable/disable each provider independently
- **Custom Button Text**: Customize login button text for each provider
- **Auto Account Creation**: Automatically creates WordPress accounts on first social login
- **Seamless Login**: Existing users are logged in automatically

### ✅ Built-in Documentation
- **Complete Setup Guides**: Step-by-step instructions for each social provider
- **Developer Console Links**: Direct links to create apps
- **Troubleshooting**: Common errors and solutions
- **Callback URLs**: Auto-generated callback URLs with copy functionality

### ✅ Admin Panel
- **General Settings**: 
  - Enable/disable plugin functionality
  - Control registration and social login
  - Set redirect URLs after login/registration
  - Configure default user role
- **Form Builder**: Visual interface for managing registration fields
- **Social Providers**: Configure credentials for each provider
- **Documentation**: Built-in guides for setup

### ✅ Frontend Integration
- **Shortcodes**:
  - `[slr_registration_form]` - Display registration form
  - `[slr_social_login]` - Display social login buttons
  - `[slr_login_form]` - Display complete login form with social options
- **WordPress Integration**: Automatically adds social login to default WordPress login/register pages
- **Responsive Design**: Mobile-friendly forms and buttons
- **Modern UI**: Beautiful gradient buttons and smooth animations

## Installation

1. Upload the `Social Login` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to 'Social Login' in the admin menu to configure settings

## Configuration

### General Settings
1. Navigate to **Social Login > General Settings**
2. Enable the plugin and desired features
3. Set redirect URLs for after login/registration
4. Choose default user role for new users

### Registration Form Builder
1. Go to **Social Login > Form Builder**
2. Add new fields or customize existing ones
3. Drag and drop to reorder fields
4. Toggle fields on/off as needed
5. Click "Save Form" to apply changes

### Social Provider Setup

#### Google
1. Go to **Social Login > Social Providers > Google**
2. Click "View Setup Guide" for detailed instructions
3. Create a Google Cloud project and OAuth credentials
4. Copy Client ID and Client Secret
5. Add the callback URL to your Google app
6. Enable the provider and save

#### Facebook
1. Go to **Social Login > Social Providers > Facebook**
2. Create a Facebook app at developers.facebook.com
3. Add Facebook Login product
4. Configure OAuth redirect URIs
5. Copy App ID and App Secret
6. Enable and save

#### Twitter (X)
1. Go to **Social Login > Social Providers > X (Twitter)**
2. Create an app in Twitter Developer Portal
3. Enable OAuth 2.0
4. Add callback URL
5. Copy Client ID and Secret
6. Enable and save

#### LinkedIn
1. Go to **Social Login > Social Providers > LinkedIn**
2. Create a LinkedIn app
3. Request "Sign In with LinkedIn using OpenID Connect"
4. Add redirect URL
5. Copy credentials
6. Enable and save

#### GitHub
1. Go to **Social Login > Social Providers > GitHub**
2. Create an OAuth app in GitHub settings
3. Set authorization callback URL
4. Generate client secret
5. Copy credentials
6. Enable and save

## Usage

### Using Shortcodes

**Registration Form:**
```
[slr_registration_form]
[slr_registration_form title="Sign Up" submit_text="Create Account"]
```

**Social Login Buttons:**
```
[slr_social_login]
[slr_social_login title="Login with" style="icon-only"]
```

**Complete Login Form:**
```
[slr_login_form]
[slr_login_form show_social="yes"]
```

### Automatic Integration
The plugin automatically adds social login buttons to:
- WordPress default login page (`wp-login.php`)
- WordPress default registration page

## Requirements

- WordPress 5.8 or higher
- PHP 7.4 or higher
- HTTPS (required for production use with social providers)

## Developer Information

### Hooks & Filters
The plugin provides various hooks for developers to extend functionality:

```php
// Modify registration form arguments
apply_filters('slr_registration_form_args', $args);

// Modify social button arguments
apply_filters('slr_social_buttons_args', $args);

// After user registration
do_action('slr_after_user_registration', $user_id, $data);

// After social login
do_action('slr_after_social_login', $user_id, $provider, $social_data);
```

### File Structure
```
Social Login/
├── admin/
│   ├── class-slr-admin.php
│   ├── class-slr-admin-menu.php
│   └── views/
│       ├── general-settings.php
│       ├── form-builder.php
│       ├── providers.php
│       ├── documentation.php
│       ├── docs/
│       └── partials/
├── assets/
│   ├── css/
│   │   ├── admin.css
│   │   └── frontend.css
│   └── js/
│       ├── admin.js
│       └── frontend.js
├── includes/
│   ├── class-slr-settings.php
│   ├── class-slr-form-builder.php
│   ├── class-slr-social-auth.php
│   ├── class-slr-user-handler.php
│   └── providers/
│       ├── class-slr-provider-base.php
│       ├── class-slr-google.php
│       ├── class-slr-facebook.php
│       ├── class-slr-twitter.php
│       ├── class-slr-linkedin.php
│       └── class-slr-github.php
├── public/
│   ├── class-slr-shortcodes.php
│   └── class-slr-frontend.php
└── pnscode-social-login-and-register.php
```

## Security

- All AJAX requests are nonce-protected
- User inputs are sanitized and validated
- OAuth state parameter prevents CSRF attacks
- Client secrets are stored securely in WordPress options

## Support

For issues, questions, or feature requests, please refer to the built-in documentation or contact support.

## Changelog

### Version 1.0.0
- Initial release
- Custom registration form builder
- Social login for Google, Facebook, Twitter, LinkedIn, GitHub
- Built-in documentation
- Shortcode support
- Responsive design

## License

GPL v2 or later

## Credits

Developed with ❤️ for WordPress community
