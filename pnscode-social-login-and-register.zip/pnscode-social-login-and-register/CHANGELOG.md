# Changelog

All notable changes to the Social Login & Custom Registration Plugin will be documented in this file.

## [1.0.0] - 2026-01-16

### Added
- **Custom Registration Form Builder**
  - Visual drag-and-drop form builder in admin panel
  - Add, remove, enable/disable, and reorder form fields
  - Customize field labels, placeholders, and requirements
  - Support for 10+ field types (text, email, password, phone, select, checkbox, textarea, number, url, date)
  - Custom fields saved as user meta data
  - Live form preview in sidebar

- **Social Login Integration**
  - Google OAuth 2.0 integration
  - Facebook Login integration
  - X (Twitter) OAuth 2.0 integration
  - LinkedIn OpenID Connect integration
  - GitHub OAuth integration
  - Individual enable/disable control for each provider
  - Custom button text configuration
  - Automatic account creation on first social login
  - Seamless login for existing users

- **Built-in Documentation System**
  - Complete setup guides for all 5 social providers
  - Step-by-step instructions with screenshots
  - Common errors and troubleshooting solutions
  - Direct links to developer consoles
  - Auto-generated callback URLs with copy functionality

- **Admin Panel**
  - General Settings page with plugin controls
  - Form Builder page with drag-and-drop interface
  - Social Providers settings with tabbed navigation
  - Documentation page with provider-specific guides
  - Modern UI with toggle switches and status indicators
  - Responsive design for all screen sizes

- **Frontend Features**
  - `[slr_registration_form]` shortcode for custom registration
  - `[slr_social_login]` shortcode for social login buttons
  - `[slr_login_form]` shortcode for complete login form
  - Automatic integration with WordPress default login/register pages
  - Responsive, mobile-friendly forms
  - Modern UI with gradient buttons and smooth animations
  - AJAX form submission with loading states
  - Comprehensive error handling

- **Security Features**
  - CSRF protection with WordPress nonces
  - Input sanitization and validation
  - OAuth state parameter for security
  - Secure credential storage in WordPress options
  - Permission checks for admin operations

- **Developer Features**
  - Well-documented code with inline comments
  - Object-oriented architecture
  - Extensible provider system
  - Action and filter hooks for customization
  - Clean file structure and naming conventions

### Technical Details
- Minimum WordPress version: 5.8
- Minimum PHP version: 7.4
- HTTPS required for production use
- jQuery dependency for JavaScript
- WordPress AJAX API for form submissions
- OAuth 2.0 and OpenID Connect standards

### Files Created
- Main plugin file: `pnscode-social-login-and-register.php`
- Admin classes: 7 files
- Core includes: 10 files
- Provider classes: 6 files
- Frontend classes: 2 files
- Admin views: 11 files
- CSS files: 2 files
- JavaScript files: 2 files
- Documentation: 3 files (README.md, README-BN.md, SUMMARY.md)

### Database Schema
- Options table entries for settings and configuration
- User meta entries for custom fields and social data
- No custom database tables required

### Supported Languages
- English (default)
- Bengali (documentation)
- Translation-ready with text domain

---

## Future Enhancements (Planned)

### Version 1.1.0 (Planned)
- [ ] Email verification for manual registration
- [ ] Two-factor authentication support
- [ ] User profile management page
- [ ] Import/export form configurations
- [ ] Additional social providers (Apple, Microsoft, Discord)
- [ ] Advanced field types (file upload, date picker, color picker)
- [ ] Conditional field logic
- [ ] Form submission notifications
- [ ] Integration with popular email marketing services
- [ ] GDPR compliance features

### Version 1.2.0 (Planned)
- [ ] Multi-step registration forms
- [ ] Custom CSS editor
- [ ] Form analytics and statistics
- [ ] A/B testing for forms
- [ ] Custom redirect rules based on user role
- [ ] Social profile data sync
- [ ] User import/export functionality
- [ ] REST API endpoints
- [ ] Webhook support
- [ ] Advanced spam protection

---

## Support

For bug reports, feature requests, or questions:
- Check the built-in documentation: **Social Login → Documentation**
- Review README.md for detailed usage instructions
- Review README-BN.md for বাংলা instructions

## Credits

- Developed for WordPress community
- OAuth libraries: Native WordPress HTTP API
- Icons: Provider official brand assets
- UI inspiration: Modern WordPress admin design patterns

## License

GPL v2 or later - https://www.gnu.org/licenses/gpl-2.0.html
