# Automatic Login/Register Pages - Complete Guide

## ✅ **Auto-Replace Feature Activated!**

Plugin activate করার সাথে সাথে automatically:

1. ✅ **Login page তৈরি হবে** (`/login`)
2. ✅ **Register page তৈরি হবে** (`/register`)
3. ✅ **WordPress default login/register replace হবে**
4. ✅ **সব login/register link automatic update হবে**

---

## 🚀 **কিভাবে কাজ করে:**

### Plugin Activation এর পর:

**Automatically হবে:**
1. একটা "Login" page create হবে
2. একটা "Register" page create হবে
3. সব WordPress login link এই pages এ redirect করবে
4. সব WordPress register link এই pages এ redirect করবে

**User Experience:**
- User যেকোনো জায়গা থেকে "Login" এ click করলে → `/login` page এ যাবে
- User যেকোনো জায়গা থেকে "Register" এ click করলে → `/register` page এ যাবে
- WordPress default `wp-login.php` → Custom login form দেখাবে

---

## 📋 **Features:**

### 1. **Automatic Page Creation**
Plugin activate করলেই:
```
✅ /login page তৈরি হবে
✅ /register page তৈরি হবে
✅ Shortcode automatically add হবে
✅ Published হবে
```

### 2. **URL Replacement**
সব জায়গায় automatic replace:
```
Before: /wp-login.php
After:  /login

Before: /wp-login.php?action=register
After:  /register
```

### 3. **Link Hijacking**
WordPress এর সব login/register link automatic update:
```php
wp_login_url()        → /login
wp_registration_url() → /register
```

### 4. **Fallback Support**
যদি custom pages না থাকে:
```
✅ wp-login.php এ custom form দেখাবে
✅ কোনো error হবে না
✅ Seamless experience
```

---

## 🎯 **User Flow Examples:**

### Example 1: Comment Form Login
```
User clicks "Login to comment"
    ↓
Redirects to /login (custom page)
    ↓
Shows plugin's login form with social buttons
    ↓
User logs in
    ↓
Returns to comment form
```

### Example 2: WooCommerce Account
```
User clicks "My Account"
    ↓
Not logged in → Redirects to /login
    ↓
Shows custom login form
    ↓
User logs in with Google
    ↓
Goes to My Account page
```

### Example 3: Menu Link
```
User clicks "Register" in menu
    ↓
Goes to /register page
    ↓
Shows registration form + social buttons
    ↓
User registers
    ↓
Redirects to homepage
```

---

## 📝 **Created Pages:**

### Login Page (`/login`)
**Content:**
```
[slr_login_form]
```

**Shows:**
- Username/Email field
- Password field
- Remember Me
- Forgot Password link
- Login button
- Social login buttons
- Register link

### Register Page (`/register`)
**Content:**
```
[slr_registration_form]
```

**Shows:**
- Registration form fields
- Register button
- OR divider
- Social login buttons
- Login link

---

## 🔧 **Customization:**

### Option 1: Edit Pages
```
1. Go to Pages → All Pages
2. Edit "Login" or "Register" page
3. Customize content, add text, images, etc.
4. Keep the shortcode
5. Update
```

### Option 2: Change URLs
```
1. Edit page slug
2. /login → /sign-in
3. /register → /sign-up
4. Links automatically update
```

### Option 3: Disable Auto-Replace
```php
// In general settings
'auto_create_pages' => false
```

---

## 💡 **Advanced Usage:**

### Custom Login Page Design
```html
<div style="text-align: center; margin-bottom: 30px;">
    <h1>Welcome Back!</h1>
    <p>Login to access your account</p>
</div>

[slr_login_form]

<div style="text-align: center; margin-top: 20px;">
    <p>Need help? <a href="/contact">Contact us</a></p>
</div>
```

### Custom Register Page Design
```html
<div class="hero-section">
    <h1>Join Our Community</h1>
    <p>Create your account in seconds</p>
</div>

[slr_registration_form]

<div class="benefits">
    <h3>Why Join?</h3>
    <ul>
        <li>✅ Exclusive content</li>
        <li>✅ Member discounts</li>
        <li>✅ Community access</li>
    </ul>
</div>
```

---

## 🎨 **Integration Examples:**

### WooCommerce
```
WooCommerce login → /login (custom)
WooCommerce register → /register (custom)
My Account → Works seamlessly
```

### BuddyPress
```
BuddyPress login → /login (custom)
BuddyPress register → /register (custom)
Profile pages → Works seamlessly
```

### Custom Theme
```php
// In header.php
<?php if (!is_user_logged_in()): ?>
    <a href="<?php echo wp_login_url(); ?>">Login</a>
    <a href="<?php echo wp_registration_url(); ?>">Register</a>
<?php endif; ?>
```
Automatically uses custom pages!

---

## 🔍 **How It Works Technically:**

### 1. **Filter Hooks**
```php
add_filter('login_url', 'custom_login_url');
add_filter('register_url', 'custom_register_url');
```

### 2. **Action Hooks**
```php
add_action('login_init', 'replace_login_page');
```

### 3. **Page Detection**
```php
// Checks if custom pages exist
$login_page_id = get_option('slr_login_page_id');

// Redirects if found
if ($login_page_id) {
    wp_redirect(get_permalink($login_page_id));
}
```

---

## ✨ **Benefits:**

### For Users:
- ✅ **Consistent experience** - Same design everywhere
- ✅ **Modern UI** - Beautiful forms with social login
- ✅ **Easy navigation** - Clear login/register pages
- ✅ **Mobile friendly** - Responsive design

### For Site Owners:
- ✅ **No manual setup** - Works out of the box
- ✅ **Fully customizable** - Edit pages as needed
- ✅ **SEO friendly** - Clean URLs (/login, /register)
- ✅ **Theme independent** - Works with any theme

### For Developers:
- ✅ **Standard WordPress** - Uses wp_login_url(), etc.
- ✅ **Filter support** - Can be customized
- ✅ **No conflicts** - Works with other plugins
- ✅ **Clean code** - Well documented

---

## 🚀 **Quick Start:**

### Step 1: Activate Plugin
```
Plugins → Activate "Social Login & Custom Registration"
```

### Step 2: Check Pages
```
Pages → All Pages
You'll see:
- Login (published)
- Register (published)
```

### Step 3: Test
```
1. Logout
2. Click any login link
3. Should go to /login
4. See custom form with social buttons
```

### Step 4: Customize (Optional)
```
1. Edit Login/Register pages
2. Add your branding
3. Customize text
4. Update
```

---

## 📊 **What Gets Replaced:**

### WordPress Core:
- ✅ `wp-login.php` → `/login`
- ✅ `wp-login.php?action=register` → `/register`
- ✅ Login widget → Custom page
- ✅ Admin bar login → Custom page

### Themes:
- ✅ Theme login links → Custom page
- ✅ Theme register links → Custom page
- ✅ Custom login forms → Custom page

### Plugins:
- ✅ WooCommerce → Custom pages
- ✅ BuddyPress → Custom pages
- ✅ bbPress → Custom pages
- ✅ Other plugins → Custom pages

---

## 🎉 **Summary:**

**Plugin activate করলেই:**

1. ✅ Login page তৈরি হবে (`/login`)
2. ✅ Register page তৈরি হবে (`/register`)
3. ✅ সব login link automatic update হবে
4. ✅ সব register link automatic update হবে
5. ✅ WordPress default forms replace হবে
6. ✅ Social login everywhere available হবে
7. ✅ কোনো manual setup লাগবে না

**User যেকোনো জায়গা থেকে login/register এ click করলে plugin এর custom form দেখবে!**

**Perfect! Automatic replacement ready! 🚀**
