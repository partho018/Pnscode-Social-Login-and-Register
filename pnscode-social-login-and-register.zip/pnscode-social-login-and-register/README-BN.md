# Social Login & Custom Registration Plugin - বাংলা গাইড

## প্লাগিন সম্পর্কে

এটি একটি সম্পূর্ণ WordPress Social Login এবং Custom Registration সিস্টেম যেখানে:

✅ **Admin Panel থেকে Registration Form সম্পূর্ণ কন্ট্রোল করা যায়**
✅ **৫টি Social Provider: Google, Facebook, X (Twitter), LinkedIn, GitHub**
✅ **প্রতিটা Provider এর জন্য Built-in Setup Documentation**
✅ **Shortcode দিয়ে যেকোনো পেইজে Form বসানো যায়**

## ইনস্টলেশন

1. প্লাগিন ফোল্ডার `/wp-content/plugins/` এ আপলোড করুন
2. WordPress Admin থেকে প্লাগিন Activate করুন
3. Admin Menu তে "Social Login" দেখতে পাবেন

## সেটিংস কনফিগার করা

### ১. General Settings
**Social Login > General Settings** এ যান:
- Plugin Enable করুন
- Registration Enable করুন
- Social Login Enable করুন
- Login/Registration এর পর কোথায় redirect হবে সেট করুন
- নতুন ইউজারদের জন্য Default Role সিলেক্ট করুন

### ২. Registration Form তৈরি করা
**Social Login > Form Builder** এ যান:

**Field যোগ করা:**
- "Add New Field" বাটনে ক্লিক করুন
- Field Type সিলেক্ট করুন (Text, Email, Password, Phone, Select, Checkbox, Textarea)
- Field Label এবং Placeholder লিখুন
- Required চেকবক্স দিয়ে বাধ্যতামূলক করুন
- Enable/Disable toggle দিয়ে on/off করুন

**Field সাজানো:**
- Drag & Drop করে Field এর Order পরিবর্তন করুন
- Edit আইকনে ক্লিক করে Field এডিট করুন
- Delete আইকনে ক্লিক করে Field মুছে ফেলুন

**সেভ করা:**
- সব পরিবর্তন শেষে "Save Form" বাটনে ক্লিক করুন

### ৩. Social Login Setup করা

প্রতিটা Social Provider এর জন্য আলাদা আলাদা সেটাপ করতে হবে:

#### Google Setup
1. **Social Login > Social Providers > Google** এ যান
2. "View Setup Guide" ক্লিক করে বিস্তারিত দেখুন
3. [Google Cloud Console](https://console.cloud.google.com/) এ যান
4. নতুন Project তৈরি করুন
5. OAuth 2.0 Credentials তৈরি করুন
6. Callback URL যোগ করুন (প্লাগিন থেকে Copy করুন)
7. Client ID এবং Client Secret কপি করুন
8. প্লাগিনে Paste করে Enable করুন এবং Save করুন

#### Facebook Setup
1. **Social Login > Social Providers > Facebook** এ যান
2. [Facebook Developers](https://developers.facebook.com/apps/) এ যান
3. নতুন App তৈরি করুন
4. Facebook Login Product যোগ করুন
5. Valid OAuth Redirect URIs তে Callback URL যোগ করুন
6. App ID এবং App Secret কপি করুন
7. প্লাগিনে Paste করে Enable করুন

#### Twitter (X) Setup
1. **Social Login > Social Providers > X (Twitter)** এ যান
2. [Twitter Developer Portal](https://developer.twitter.com/) এ যান
3. নতুন App তৈরি করুন
4. OAuth 2.0 Enable করুন
5. Callback URL যোগ করুন
6. Client ID এবং Secret কপি করুন
7. প্লাগিনে Paste করে Enable করুন

#### LinkedIn Setup
1. **Social Login > Social Providers > LinkedIn** এ যান
2. [LinkedIn Developers](https://www.linkedin.com/developers/apps) এ যান
3. নতুন App তৈরি করুন
4. "Sign In with LinkedIn using OpenID Connect" Request করুন
5. Redirect URL যোগ করুন
6. Credentials কপি করুন
7. প্লাগিনে Paste করে Enable করুন

#### GitHub Setup
1. **Social Login > Social Providers > GitHub** এ যান
2. [GitHub Developer Settings](https://github.com/settings/developers) এ যান
3. নতুন OAuth App তৈরি করুন
4. Authorization Callback URL যোগ করুন
5. Client Secret Generate করুন
6. Credentials কপি করুন
7. প্লাগিনে Paste করে Enable করুন

## ব্যবহার করা

### Shortcode ব্যবহার করে

**Registration Form দেখানোর জন্য:**
```
[slr_registration_form]
```

কাস্টম Title এবং Button Text সহ:
```
[slr_registration_form title="নিবন্ধন করুন" submit_text="সাইন আপ"]
```

**Social Login Buttons দেখানোর জন্য:**
```
[slr_social_login]
```

শুধু Icon দেখানোর জন্য:
```
[slr_social_login style="icon-only"]
```

**সম্পূর্ণ Login Form:**
```
[slr_login_form]
```

### Automatic Integration

প্লাগিন automatically Social Login Buttons যোগ করে:
- WordPress এর default login page এ
- WordPress এর default registration page এ

## গুরুত্বপূর্ণ তথ্য

### Callback URL
প্রতিটা Social Provider এ Callback URL যোগ করা অত্যন্ত জরুরি। প্লাগিনের Provider Settings পেইজ থেকে Callback URL কপি করুন এবং সেই Provider এর Developer Console এ Paste করুন।

### HTTPS প্রয়োজন
Production সাইটে Social Login ব্যবহার করতে হলে আপনার সাইটে অবশ্যই HTTPS থাকতে হবে।

### Testing
প্রথমে Development Mode এ Test করুন। সব ঠিকঠাক কাজ করলে তারপর Production এ নিন।

## সাধারণ সমস্যা ও সমাধান

### "Redirect URI mismatch" Error
**সমস্যা:** Callback URL মিলছে না  
**সমাধান:** প্লাগিন থেকে Callback URL কপি করে হুবহু Provider এর Console এ Paste করুন। http/https এবং trailing slash মিলাতে হবে।

### "Invalid Client" Error
**সমস্যা:** Client ID বা Secret ভুল  
**সমাধান:** Client ID এবং Secret আবার চেক করুন। কোনো extra space আছে কিনা দেখুন।

### Social Login Button দেখাচ্ছে না
**সমস্যা:** Provider Enable করা নেই বা Credentials দেওয়া নেই  
**সমাধান:** 
1. General Settings থেকে Social Login Enable করুন
2. Provider Settings থেকে সেই Provider Enable করুন
3. Client ID এবং Secret সঠিকভাবে দিন

## সাপোর্ট

বিস্তারিত Documentation এর জন্য **Social Login > Documentation** দেখুন। প্রতিটা Provider এর জন্য সম্পূর্ণ Setup Guide এবং Troubleshooting আছে।

## ফিচার লিস্ট

✅ Admin Panel থেকে Form Field Add/Remove/Edit করা যায়
✅ Field Label/Placeholder পরিবর্তন করা যায়
✅ Required/Optional সেট করা যায়
✅ Drag & Drop দিয়ে Field Order পরিবর্তন করা যায়
✅ ৫টি Social Provider Support (Google, Facebook, X, LinkedIn, GitHub)
✅ প্রতিটা Provider আলাদাভাবে On/Off করা যায়
✅ Built-in Complete Documentation
✅ Shortcode Support
✅ Responsive Design
✅ Modern UI with Animations
✅ AJAX Form Submission
✅ Custom Field সব user meta হিসেবে save হয়

## লাইসেন্স

GPL v2 or later

---

**তৈরি করেছেন:** WordPress Community এর জন্য ❤️
