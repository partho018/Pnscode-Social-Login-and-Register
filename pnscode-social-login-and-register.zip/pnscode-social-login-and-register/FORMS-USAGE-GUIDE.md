# Complete Login & Registration Guide - Updated

## ✅ সম্পূর্ণ Features

### Registration Form এখন আরও শক্তিশালী!

Registration page এ এখন **3 ভাবে** register করা যাবে:

1. ✅ **Social Login দিয়ে** (Google, Facebook, X, LinkedIn, GitHub)
2. ✅ **Manual Registration** (Form fill করে)
3. ✅ **Already have account?** Login link

---

## 📝 Registration Form Shortcode

### Basic Usage (সব features সহ):
```
[slr_registration_form]
```

এতে থাকবে:
- ✅ Social login buttons (top এ)
- ✅ "OR" divider
- ✅ Registration form fields
- ✅ Register button
- ✅ "Already have an account? Login" link

---

### Advanced Usage:

**Full Options:**
```
[slr_registration_form 
    title="Create Account" 
    submit_text="Sign Up"
    show_social="yes"
    show_login_link="yes"
    login_url="/login"
]
```

**Parameters:**
- `show_title` - Title দেখাবে কিনা (yes/no) - Default: yes
- `title` - Form title - Default: "Register"
- `submit_text` - Submit button text - Default: "Register"
- `show_social` - Social login buttons দেখাবে কিনা (yes/no) - Default: yes
- `show_login_link` - Login link দেখাবে কিনা (yes/no) - Default: yes
- `login_url` - Custom login page URL (optional)

---

### Examples:

**1. Without Social Login:**
```
[slr_registration_form show_social="no"]
```

**2. Without Login Link:**
```
[slr_registration_form show_login_link="no"]
```

**3. Only Social Registration:**
```
[slr_registration_form show_social="yes" show_login_link="no"]
```
শুধু social login buttons দেখাবে, manual form দেখাবে না

**4. Custom URLs:**
```
[slr_registration_form login_url="/custom-login"]
```

**5. Bangla Version:**
```
[slr_registration_form title="নিবন্ধন করুন" submit_text="সাইন আপ"]
```

**6. Minimal (No extras):**
```
[slr_registration_form show_social="no" show_login_link="no"]
```

---

## 📝 Login Form Shortcode

### Basic Usage:
```
[slr_login_form]
```

এতে থাকবে:
- ✅ Username/Email field
- ✅ Password field
- ✅ Remember Me
- ✅ Forgot Password link
- ✅ Login button
- ✅ Social login buttons
- ✅ "Don't have an account? Register" link

---

### Advanced Usage:

**Full Options:**
```
[slr_login_form 
    show_social="yes" 
    show_register_link="yes" 
    show_forgot_password="yes"
    register_url="/register"
    redirect="/dashboard"
]
```

**Parameters:**
- `show_social` - Social login buttons (yes/no) - Default: yes
- `show_register_link` - Register link (yes/no) - Default: yes
- `show_forgot_password` - Forgot password link (yes/no) - Default: yes
- `register_url` - Custom registration page URL (optional)
- `redirect` - Login এর পর redirect URL (optional)

---

## 🎯 Complete Page Setup

### Method 1: Separate Pages (Recommended)

**Login Page (`/login`):**
```
[slr_login_form register_url="/register"]
```

**Register Page (`/register`):**
```
[slr_registration_form login_url="/login"]
```

এতে:
- Login page থেকে Register page এ যাওয়া যাবে
- Register page থেকে Login page এ যাওয়া যাবে
- উভয় page এ social login option থাকবে

---

### Method 2: All-in-One Page

একটা page এ login এবং register দুটোই:

```html
<div style="max-width: 900px; margin: 0 auto;">
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
        <div>
            <h2>Login</h2>
            [slr_login_form show_register_link="no"]
        </div>
        <div>
            <h2>Register</h2>
            [slr_registration_form show_login_link="no"]
        </div>
    </div>
</div>
```

---

## 🎨 Visual Layout

### Registration Page Layout:

```
┌─────────────────────────────────┐
│         Register                │
├─────────────────────────────────┤
│  [Continue with Google]         │
│  [Continue with Facebook]       │
│  [Continue with LinkedIn]       │
│  [Continue with GitHub]         │
├─────────────────────────────────┤
│            OR                   │
├─────────────────────────────────┤
│  Username: [________]           │
│  Email:    [________]           │
│  Password: [________]           │
│  [Register Button]              │
├─────────────────────────────────┤
│  Already have an account? Login │
└─────────────────────────────────┘
```

### Login Page Layout:

```
┌─────────────────────────────────┐
│         Login                   │
├─────────────────────────────────┤
│  Username: [________]           │
│  Password: [________]           │
│  □ Remember Me                  │
│            Forgot Password? →   │
│  [Log In Button]                │
├─────────────────────────────────┤
│            OR                   │
├─────────────────────────────────┤
│  [Continue with Google]         │
│  [Continue with Facebook]       │
│  [Continue with LinkedIn]       │
│  [Continue with GitHub]         │
├─────────────────────────────────┤
│  Don't have an account? Register│
└─────────────────────────────────┘
```

---

## 💡 Use Cases

### Use Case 1: Quick Social Registration
User registration page এ গিয়ে:
1. Google button এ click করে
2. Google account select করে
3. একবারে register + login হয়ে যায়

### Use Case 2: Manual Registration
User registration page এ গিয়ে:
1. Form fill করে
2. Register button এ click করে
3. Email verification (যদি enable থাকে)
4. Login করে

### Use Case 3: Existing User
User registration page এ গিয়ে:
1. "Already have an account? Login" এ click করে
2. Login page এ redirect হয়

---

## 🎨 Customization Options

### Hide Social Buttons:
```
<!-- Registration without social -->
[slr_registration_form show_social="no"]

<!-- Login without social -->
[slr_login_form show_social="no"]
```

### Hide Cross Links:
```
<!-- Registration without login link -->
[slr_registration_form show_login_link="no"]

<!-- Login without register link -->
[slr_login_form show_register_link="no"]
```

### Custom Styling:
```css
/* Registration page social buttons */
.slr-registration-form-wrapper .slr-social-buttons {
    /* Your custom styles */
}

/* OR divider */
.slr-login-divider {
    /* Your custom styles */
}
```

---

## 🚀 Quick Start Guide

### Step 1: Create Pages

**Create Login Page:**
1. Pages → Add New
2. Title: "Login"
3. Content: `[slr_login_form register_url="/register"]`
4. Publish

**Create Register Page:**
1. Pages → Add New
2. Title: "Register"
3. Content: `[slr_registration_form login_url="/login"]`
4. Publish

### Step 2: Configure Social Providers

1. Go to: Social Login → Social Providers
2. Setup at least one provider (Google recommended)
3. Enable the provider
4. Save settings

### Step 3: Test

1. Visit `/register` page
2. You should see:
   - Social login buttons at top
   - OR divider
   - Registration form
   - Login link at bottom

---

## ✨ Features Summary

### Registration Page Features:
1. ✅ **Social Login Buttons** (Top)
   - Google
   - Facebook
   - X (Twitter)
   - LinkedIn
   - GitHub

2. ✅ **OR Divider**
   - Clean separator

3. ✅ **Manual Registration Form**
   - Custom fields (Admin controlled)
   - Validation
   - AJAX submission

4. ✅ **Login Link** (Bottom)
   - "Already have an account? Login"

### Login Page Features:
1. ✅ **Login Form**
   - Username/Email
   - Password
   - Remember Me
   - Forgot Password link

2. ✅ **Social Login Buttons**
   - All enabled providers

3. ✅ **Register Link**
   - "Don't have an account? Register"

---

## 🎯 Benefits

### For Users:
- ✅ **3 ways to register**: Social, Manual, or Already have account
- ✅ **Quick registration**: One click with social login
- ✅ **Flexibility**: Choose preferred method
- ✅ **Easy navigation**: Links between login/register

### For Site Owners:
- ✅ **Higher conversion**: Multiple registration options
- ✅ **Less friction**: Social login reduces barriers
- ✅ **Better UX**: Clear, modern design
- ✅ **Full control**: Enable/disable features as needed

---

## 📱 Responsive Design

সব features mobile-friendly:
- ✅ Social buttons stack vertically on mobile
- ✅ Forms adjust to screen size
- ✅ Touch-friendly buttons
- ✅ Proper spacing

---

## 🎉 Summary

**Registration Page এখন complete!**

User এখন **3 ভাবে** register করতে পারবে:
1. Social login দিয়ে (quick & easy)
2. Manual form fill করে (traditional)
3. Already account থাকলে login link এ click করে

**সব কিছু একই page এ, modern design এ! 🚀**
